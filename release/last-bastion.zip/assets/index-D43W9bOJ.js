const al={click:[.5,0,1100,.005,.01,.04,1,1.5,0,0,0,0,0,0,0,0,0,.7],coin:[.35,.05,1675,0,.03,.12,1,1.8,0,0,837,.05],build:[.9,.05,140,.01,.1,.4,2,1.6,-2,0,0,0,0,.5,0,0,.08,.6,.06],chime:[.55,0,784,.01,.12,.45,0,2,0,0,392,.08,0,0,0,0,0,.6],upgrade:[.6,0,523,.02,.15,.4,0,1.6,0,0,262,.09,.09,0,0,0,0,.7],horn:[.9,0,98,.25,.6,.9,2,.6,0,0,0,0,0,0,3,0,.12,.7,.2],dawn:[.55,0,660,.02,.35,.9,0,2,0,0,330,.12,.13,0,0,0,0,.55],arrow:[.18,.2,520,0,.01,.07,4,1.4,-24],bolt:[.35,.1,190,0,.02,.14,3,1,-9,0,0,0,0,.2],magic:[.28,.1,680,.01,.05,.25,0,2,0,0,-280,.05,0,0,0,0,0,.5,.05],fire:[.35,.2,140,.02,.1,.3,4,1,0,0,0,0,0,.8],frost:[.3,.1,1400,.01,.04,.2,0,2.5,0,0,-600,.04,0,.2],hit:[.3,.2,300,0,.01,.07,4,2.4,0,0,0,0,0,1.2],poof:[.3,.3,220,.02,.05,.28,4,2,-5,0,0,0,0,.6,0,0,.08,.5],crash:[.9,.2,70,.01,.2,.7,4,1.5,-2,0,0,0,0,1.8,0,0,.18,.5,.2],hurt:[.45,.1,190,0,.03,.14,2,1.5,-10],whoosh:[.6,.05,260,.05,.12,.35,2,1.2,14,0,0,0,0,.2,0,0,0,.7],heal:[.45,0,520,.05,.2,.5,0,1.5,4,0,260,.1,0,0,0,0,0,.6],victory:[.8,0,523,.05,.4,.8,1,1,0,0,262,.15,.2],defeat:[.8,0,220,.05,.5,1.2,2,1,-.4,0,0,0,0,0,0,0,.2,.6],roar:[.9,.1,60,.2,.5,.8,2,.8,0,0,0,0,0,1.3,4,0,.1,.8,.1],deny:[.35,0,150,0,.04,.1,2,1,0,0,0,0,0,0,0,0,0,.6],respawn:[.5,0,392,.03,.25,.5,0,1.5,0,0,196,.1,.1,0,0,0,0,.6],hold:[.12,0,600,0,.01,.03,1,1,0,0,0,0,0,0,0,0,0,.5]};function Bh(s,t,e=Math.random){let[n=1,i=.05,r=220,a=0,o=0,l=.1,c=0,h=1,u=0,d=0,f=0,_=0,v=0,p=0,m=0,b=0,T=0,y=1,E=0,w=0]=t;const R=Math.PI*2,x=Z=>Z>0?1:-1,S=u*=500*R/s/s;let C=r*=(1+i*2*e()-i)*R/s;a=a*s+9,E*=s,o*=s,l*=s,T*=s,d*=500*R/s**3,m*=R/s,f*=R/s,_*=s,v=v*s|0;const P=a+E+o+l+T|0,D=new Float32Array(P);let z=0,L=0,F=1,X=0,W=0,tt=0,$;const et=b*100|0;for(let Z=0;Z<P;Z++)(!et||!(++W%et))&&(tt=c?c>1?c>2?c>3?Math.sin((z%R)**3):Math.max(Math.min(Math.tan(z),1),-1):1-(2*z/R%2+2)%2:1-4*Math.abs(Math.round(z/R)-z/R):Math.sin(z),tt=(v?1-w+w*Math.sin(R*Z/v):1)*x(tt)*Math.abs(tt)**h*n*.3*(Z<a?Z/a:Z<a+E?1-(Z-a)/E*(1-y):Z<a+E+o?y:Z<P-T?(P-Z-T)/l*y:0),tt=T?tt/2+(T>Z?0:(Z<P-T?1:(P-Z)/T)*D[Z-T|0]/2):tt),D[Z]=tt,$=(r+=u+=d)*Math.cos(m*L++),z+=$-$*p*(1-(Math.sin(Z)+1)*1e9%2),F&&++F>_&&(r+=f,C+=f,F=0),v&&!(++X%v)&&(r=C,u=S,F=F||1);return D}const Us=s=>440*Math.pow(2,(s-69)/12);class Oh{constructor(){this.ctx=null,this.buffers=new Map,this.lastPlay=new Map,this.playing=0,this.muteReasons=new Set,this.musicVol=.6,this.sfxVol=.8,this.music=null,this.mood="menu"}unlock(){if(this.ctx){this.ctx.state==="suspended"&&!this.muteReasons.size&&this.ctx.resume().catch(()=>{});return}const t=window.AudioContext||window.webkitAudioContext;if(!t)return;try{this.ctx=new t}catch{this.ctx=null;return}const e=this.ctx;this.master=e.createGain(),this.master.connect(e.destination),this.musicBus=e.createGain(),this.sfxBus=e.createGain();const n=e.createDynamicsCompressor();n.threshold.value=-14,n.ratio.value=4,this.sfxBus.connect(n).connect(this.master),this.musicBus.connect(this.master),this.applyVolumes();const i=Object.keys(al);let r=0;const a=()=>{for(let o=0;o<4&&r<i.length;o++,r++)this.makeBuffers(i[r]);r<i.length&&setTimeout(a,0)};a(),this.music=new zh(e,this.musicBus),this.music.setMood(this.mood),this.muteReasons.size&&this.applyMute()}makeBuffers(t){if(!this.ctx)return;const e=[],n=t==="hit"||t==="arrow"||t==="poof"||t==="coin"?3:1;for(let i=0;i<n;i++){const r=Bh(this.ctx.sampleRate,al[t]),a=this.ctx.createBuffer(1,r.length,this.ctx.sampleRate);a.getChannelData(0).set(r),e.push(a)}this.buffers.set(t,e)}setVolumes(t,e){this.musicVol=t,this.sfxVol=e,this.applyVolumes()}applyVolumes(){if(!this.ctx)return;const t=this.ctx.currentTime;this.musicBus.gain.setTargetAtTime(this.musicVol*.55,t,.05),this.sfxBus.gain.setTargetAtTime(this.sfxVol,t,.05)}setMuted(t,e){e?this.muteReasons.add(t):this.muteReasons.delete(t),this.applyMute()}applyMute(){if(!this.ctx)return;const t=this.muteReasons.size>0,e=this.ctx.currentTime;this.master.gain.cancelScheduledValues(e),this.master.gain.setValueAtTime(t?0:this.master.gain.value,e),t?(this.master.gain.value=0,this.ctx.suspend().catch(()=>{})):(this.ctx.resume().catch(()=>{}),this.master.gain.setTargetAtTime(1,e,.08))}get isMuted(){return this.muteReasons.size>0}setMood(t){var e;this.mood=t,(e=this.music)==null||e.setMood(t)}play(t,e=1,n=1){var h;const i=this.ctx;if(!i||this.muteReasons.size||this.sfxVol<=0||e<=.02)return;const r=this.buffers.get(t);if(!r)return;const a=i.currentTime,o=(h=this.lastPlay.get(t))!=null?h:-1;if(a-o<.035||this.playing>24)return;this.lastPlay.set(t,a);const l=i.createBufferSource();l.buffer=r[Math.floor(Math.random()*r.length)],l.playbackRate.value=n*(.96+Math.random()*.08);const c=i.createGain();c.gain.value=Math.min(1,e),l.connect(c).connect(this.sfxBus),this.playing++,l.onended=()=>{this.playing--,l.disconnect(),c.disconnect()},l.start()}update(){var t;(t=this.music)==null||t.tick()}}class zh{constructor(t,e){this.ctx=t,this.mood="menu",this.seed=12345;const n=t.sampleRate;this.noise=t.createBuffer(1,n,t.sampleRate);const i=this.noise.getChannelData(0);for(let l=0;l<n;l++)i[l]=Math.random()*2-1;this.delay=t.createDelay(1),this.delay.delayTime.value=.36;const r=t.createGain();r.gain.value=.28;const a=t.createGain();a.gain.value=.35,this.delay.connect(r).connect(this.delay),this.delay.connect(a).connect(e);const o=(l,c,h,u,d)=>{const f=t.createGain();return f.gain.value=0,f.connect(e),{kind:l,bpm:c,root:h,scale:u,chords:d,bus:f,next:0,step:0,motif:[]}};this.themes={menu:o("menu",72,60,[0,2,4,7,9],[[0,4,7],[9,12,16],[5,9,12],[7,11,14]]),day:o("day",88,62,[0,2,4,7,9],[[0,4,7],[-3,0,4],[5,9,12],[7,11,14]]),night:o("night",112,57,[0,3,5,7,10],[[0,3,7],[-4,0,3],[-2,2,5],[-5,-1,2]])};for(const l of Object.values(this.themes))l.motif=this.makeMotif(l)}rnd(){return this.seed=this.seed*1664525+1013904223>>>0,this.seed/4294967296}makeMotif(t){const e=[];for(let n=0;n<16;n++){const i=t.kind==="night"?this.rnd()<.55:this.rnd()<.35;e.push(i?-1:Math.floor(this.rnd()*(t.scale.length+3)))}return e[0]=0,e}setMood(t){this.mood=t;const e=this.ctx.currentTime;for(const n of Object.values(this.themes)){const i=n.kind===t;n.bus.gain.cancelScheduledValues(e),n.bus.gain.setTargetAtTime(i?1:0,e,i?1.2:.9),i&&n.next<e&&(n.next=e+.1)}}tick(){const t=this.ctx.currentTime;if(this.ctx.state==="running")for(const e of Object.values(this.themes)){if(!(e.kind===this.mood||e.bus.gain.value>.02))continue;e.next<t&&(e.next=t+.05);const i=60/e.bpm/2;for(;e.next<t+.2;)this.schedule(e,e.step,e.next,i),e.step++,e.next+=i,e.step%64===0&&this.rnd()<.5&&(e.motif=this.makeMotif(e))}}schedule(t,e,n,i){const r=Math.floor(e/8)%t.chords.length,a=e%8,o=t.chords[r],l=t.root;if(a===0)for(const u of o)this.pad(t,Us(l+u),n,i*8,t.kind==="night"?"sawtooth":"triangle",t.kind==="night"?.025:.035);t.kind==="night"?this.bass(t,Us(l-12+o[0]),n,i*.9,.11):(a===0||a===4)&&this.bass(t,Us(l-12+o[0]+(a===4?7:0)),n,i*3,.08);const c=t.motif[e%16],h=t.kind==="night"?Math.floor(e/16)%2===1:!0;if(c>=0&&h){const u=Math.floor(c/t.scale.length),d=t.scale[c%t.scale.length],f=l+12+d+u*12-(t.kind==="menu",0);this.pluck(t,Us(f),n,t.kind==="night"?.045:.06,t.kind==="night"?"square":"triangle")}t.kind==="night"?((a===0||a===4)&&this.kick(t,n,.5),(a===2||a===6)&&this.snare(t,n,.12),a===7&&r===3&&this.snare(t,n+i/2,.1),this.hat(t,n,a%2===0?.035:.02)):t.kind==="day"&&(a%2===1&&this.hat(t,n,.018),a===0&&this.kick(t,n,.12))}env(t,e,n,i,r){t.gain.setValueAtTime(1e-4,e),t.gain.exponentialRampToValueAtTime(i,e+n),t.gain.exponentialRampToValueAtTime(1e-4,e+n+r)}osc(t,e,n,i,r,a,o){const l=this.ctx.createOscillator();l.type=e,l.frequency.value=n;let c=l;if(o){const h=this.ctx.createBiquadFilter();h.type="lowpass",h.frequency.value=o,l.connect(h),c=h}c.connect(a),a.connect(t.bus),l.start(i),l.stop(i+r+.05),l.onended=()=>{l.disconnect(),a.disconnect()}}pad(t,e,n,i,r,a){for(const o of[-5,5]){const l=this.ctx.createGain();l.gain.setValueAtTime(1e-4,n),l.gain.linearRampToValueAtTime(a,n+i*.3),l.gain.linearRampToValueAtTime(1e-4,n+i);const c=this.ctx.createOscillator();c.type=r,c.frequency.value=e,c.detune.value=o;const h=this.ctx.createBiquadFilter();h.type="lowpass",h.frequency.value=t.kind==="night"?900:1600,c.connect(h).connect(l).connect(t.bus),c.start(n),c.stop(n+i+.05),c.onended=()=>{c.disconnect(),h.disconnect(),l.disconnect()}}}pluck(t,e,n,i,r){const a=this.ctx.createGain();this.env(a,n,.005,i,.45),this.osc(t,r,e,n,.5,a,r==="square"?1800:void 0),a.connect(this.delay)}bass(t,e,n,i,r){const a=this.ctx.createGain();this.env(a,n,.01,r,i),this.osc(t,t.kind==="night"?"sawtooth":"sine",e,n,i+.05,a,t.kind==="night"?380:600)}kick(t,e,n){const i=this.ctx.createOscillator(),r=this.ctx.createGain();i.frequency.setValueAtTime(130,e),i.frequency.exponentialRampToValueAtTime(42,e+.18),this.env(r,e,.003,n,.25),i.connect(r).connect(t.bus),i.start(e),i.stop(e+.3),i.onended=()=>{i.disconnect(),r.disconnect()}}noiseHit(t,e,n,i,r,a,o){const l=this.ctx.createBufferSource();l.buffer=this.noise;const c=this.ctx.createBiquadFilter();c.type=o,c.frequency.value=i,c.Q.value=r;const h=this.ctx.createGain();this.env(h,e,.002,n,a),l.connect(c).connect(h).connect(t.bus),l.start(e,Math.random()*.5),l.stop(e+a+.05),l.onended=()=>{l.disconnect(),c.disconnect(),h.disconnect()}}snare(t,e,n){this.noiseHit(t,e,n,1400,.8,.16,"bandpass")}hat(t,e,n){this.noiseHit(t,e,n,7e3,1,.05,"highpass")}}class Gh{constructor(t,e){this.keys=new Set,this.edges=new Set,this.joy={active:!1,id:-1,ox:0,oy:0,dx:0,dy:0},this.mouse={down:!1,x:0,y:0},this.holdButton=!1,this.touchMode=!1,this.enabled=!0,this.onGesture=null,this.offs=[],this.radius=56,this.base=document.createElement("div"),this.base.className="joy-base",this.knob=document.createElement("div"),this.knob.className="joy-knob",this.base.appendChild(this.knob),e.appendChild(this.base);const n=(r,a,o,l)=>{r.addEventListener(a,o,l),this.offs.push(()=>r.removeEventListener(a,o,l))};n(window,"keydown",r=>{this.gesture(),["Space","ArrowUp","ArrowDown","ArrowLeft","ArrowRight","Tab"].includes(r.code)&&r.preventDefault(),!(r.ctrlKey||r.metaKey||r.altKey)&&(this.keys.has(r.code)||this.edges.add(r.code),this.keys.add(r.code),this.touchMode=!1)}),n(window,"keyup",r=>{this.keys.delete(r.code)}),n(window,"blur",()=>this.reset()),n(t,"pointerdown",r=>{if(this.gesture(),!!this.enabled){if(r.pointerType==="touch"||r.pointerType==="pen"){if(this.touchMode=!0,this.joy.active)return;this.joy={active:!0,id:r.pointerId,ox:r.clientX,oy:r.clientY,dx:0,dy:0},this.base.style.transform=`translate(${r.clientX-this.radius}px, ${r.clientY-this.radius}px)`,this.base.classList.add("on"),this.knob.style.transform="translate(0px, 0px)"}else r.button===0&&(this.touchMode=!1,this.mouse={down:!0,x:r.clientX,y:r.clientY});try{t.setPointerCapture(r.pointerId)}catch{}}}),n(t,"pointermove",r=>{if(this.joy.active&&r.pointerId===this.joy.id){let a=r.clientX-this.joy.ox,o=r.clientY-this.joy.oy;const l=Math.hypot(a,o);if(l>this.radius*1.4){const f=(l-this.radius*1.4)/l;this.joy.ox+=a*f,this.joy.oy+=o*f,a=r.clientX-this.joy.ox,o=r.clientY-this.joy.oy,this.base.style.transform=`translate(${this.joy.ox-this.radius}px, ${this.joy.oy-this.radius}px)`}const c=Math.hypot(a,o),h=Math.min(c,this.radius),u=c>0?a/c*h:0,d=c>0?o/c*h:0;this.joy.dx=u/this.radius,this.joy.dy=d/this.radius,this.knob.style.transform=`translate(${u}px, ${d}px)`}else this.mouse.down&&(this.mouse.x=r.clientX,this.mouse.y=r.clientY)});const i=r=>{this.joy.active&&r.pointerId===this.joy.id&&this.endJoy(),r.pointerType==="mouse"&&(this.mouse.down=!1)};n(t,"pointerup",i),n(t,"pointercancel",i),n(t,"lostpointercapture",i)}endJoy(){this.joy.active=!1,this.joy.dx=0,this.joy.dy=0,this.base.classList.remove("on")}gesture(){var t;(t=this.onGesture)==null||t.call(this)}pressed(...t){let e=!1;for(const n of t)this.edges.delete(n)&&(e=!0);return e}down(...t){for(const e of t)if(this.keys.has(e))return!0;return!1}screenMove(){let t=0,e=0;this.down("KeyA","ArrowLeft")&&(t-=1),this.down("KeyD","ArrowRight")&&(t+=1),this.down("KeyW","ArrowUp")&&(e-=1),this.down("KeyS","ArrowDown")&&(e+=1),this.joy.active&&(t+=this.joy.dx,e+=this.joy.dy);const n=Math.hypot(t,e);return n>1&&(t/=n,e/=n),n<.12&&(t=0,e=0),{x:t,y:e}}get hold(){return this.down("Space")||this.holdButton}endFrame(){this.edges.clear()}reset(){this.keys.clear(),this.edges.clear(),this.holdButton=!1,this.mouse.down=!1,this.endJoy()}destroy(){for(const t of this.offs)t();this.offs=[],this.base.remove()}}const me={leaderboardName:"endlessNights",saveVersion:2,saveDebounceMs:2500,interstitialCooldownMs:65e3,hero:{hp:220,speed:8.2,regen:14,regenDelay:3,respawn:7,radius:.7,buildRadius:2.6},build:{secondsPerCoin:.09,minHold:.45,maxHold:1.4},economy:{castleIncome:3,cleanBonus:2,startCoins:8},dawnSeconds:3.2,duskSeconds:2.2,rewardCoins:5,maxUnits:260},yo=new Set(["farm","mine","fish"]),_r={castle:3.4,wall:.9,tower:1.3,magic:1.3,barracks:1.8,range:1.8,farm:1.7,mine:1.6,fish:1.5,forge:1.6},ol={castle:{base:{cost:0,stats:{hp:600,income:3,attack:{damage:6,range:9,cooldown:1.2,projectile:"arrow"}}},specs:[{id:"citadel",cost:10,stats:{hp:950,income:3,attack:{damage:8,range:10,cooldown:.75,projectile:"arrow"}}},{id:"court",cost:10,stats:{hp:700,income:6,attack:{damage:6,range:9,cooldown:1.1,projectile:"arrow"}}}],modCost:18,mods:[{id:"bastions",hpMul:1.5,multishotAdd:1},{id:"treasury",incomeAdd:3}]},wall:{base:{cost:2,stats:{hp:150}},specs:[{id:"stone",cost:4,stats:{hp:380}},{id:"spiked",cost:4,stats:{hp:220,thorns:7}}],modCost:7,mods:[{id:"reinforced",hpMul:1.7},{id:"tar",thornsAdd:8,hpMul:1.15}]},tower:{base:{cost:5,stats:{hp:140,attack:{damage:7,range:9,cooldown:1,projectile:"arrow"}}},specs:[{id:"archer",cost:6,stats:{hp:170,attack:{damage:7,range:10,cooldown:.5,projectile:"arrow"}}},{id:"ballista",cost:6,stats:{hp:190,attack:{damage:30,range:12,cooldown:1.9,projectile:"bolt",pierce:3,armorPierce:!0}}}],modCost:10,mods:[{id:"keen",dmgMul:1.45,rangeAdd:1.5},{id:"volley",multishotAdd:2,cdMul:.9}]},magic:{base:{cost:8,stats:{hp:130,attack:{damage:12,range:9,cooldown:1.6,projectile:"orb",splash:2.2}}},specs:[{id:"frost",cost:10,stats:{hp:150,attack:{damage:10,range:10,cooldown:1.2,projectile:"frost",splash:2.6,slow:.45,armorPierce:!0}}},{id:"fire",cost:10,stats:{hp:150,attack:{damage:18,range:9.5,cooldown:1.7,projectile:"fire",splash:3,burn:5,armorPierce:!0}}}],modCost:14,mods:[{id:"resonance",dmgMul:1.55},{id:"farsight",rangeAdd:3,cdMul:.8}]},barracks:{base:{cost:6,stats:{hp:180,troops:{unit:"militia",count:2}}},specs:[{id:"spear",cost:8,stats:{hp:220,troops:{unit:"spearman",count:3}}},{id:"sword",cost:8,stats:{hp:220,troops:{unit:"swordsman",count:3}}}],modCost:12,mods:[{id:"veterans",troopsAdd:1,hpTroopsAdd:.3},{id:"warcry",dmgMul:1.5}]},range:{base:{cost:7,stats:{hp:150,troops:{unit:"bowman",count:2}}},specs:[{id:"bows",cost:9,stats:{hp:180,troops:{unit:"bowman",count:4}}},{id:"xbows",cost:9,stats:{hp:180,troops:{unit:"crossbowman",count:3}}}],modCost:12,mods:[{id:"firearrows",burnAdd:4},{id:"squad",troopsAdd:1,hpTroopsAdd:.3}]},farm:{base:{cost:3,stats:{hp:90,income:1}},specs:[{id:"mill",cost:5,stats:{hp:110,income:2}},{id:"militia",cost:5,stats:{hp:130,income:1,troops:{unit:"militia",count:2}}}],modCost:8,mods:[{id:"harvest",incomeAdd:1},{id:"fence",hpMul:2.5,troopsAdd:1}]},mine:{base:{cost:7,stats:{hp:140,income:2}},specs:[{id:"deep",cost:8,stats:{hp:150,income:4}},{id:"fort",cost:8,stats:{hp:320,income:3,attack:{damage:6,range:8,cooldown:1.1,projectile:"arrow"}}}],modCost:12,mods:[{id:"vein",incomeAdd:2},{id:"vaults",hpMul:2,incomeAdd:1}]},fish:{base:{cost:4,stats:{hp:80,income:1}},specs:[{id:"pier",cost:6,stats:{hp:100,income:3}},{id:"market",cost:6,stats:{hp:110,income:2,cleanBonus:2}}],modCost:9,mods:[{id:"nets",incomeAdd:1},{id:"stilts",hpMul:2.5,cleanAdd:1}]},forge:{base:{cost:8,stats:{hp:170,buffTroops:.1,buffTowers:.1,buffHero:.1}},specs:[{id:"armory",cost:10,stats:{hp:200,buffTroops:.3,buffTowers:.1,buffHero:.3}},{id:"workshop",cost:10,stats:{hp:200,buffTroops:.1,buffTowers:.3,buffHero:.1}}],modCost:14,mods:[{id:"temper",buffAdd:.15},{id:"mail",hpTroopsAdd:.3,hpMul:1.5}]}};function Hh(s,t){var n,i,r,a,o,l,c,h,u,d,f;const e=JSON.parse(JSON.stringify(s));return t.hpMul&&(e.hp=Math.round(e.hp*t.hpMul)),e.attack&&(t.dmgMul&&(e.attack.damage=Math.round(e.attack.damage*t.dmgMul*10)/10),t.rangeAdd&&(e.attack.range+=t.rangeAdd),t.cdMul&&(e.attack.cooldown=Math.round(e.attack.cooldown*t.cdMul*100)/100),t.multishotAdd&&(e.attack.multishot=((n=e.attack.multishot)!=null?n:1)+t.multishotAdd),t.splashAdd&&(e.attack.splash=((i=e.attack.splash)!=null?i:0)+t.splashAdd)),t.incomeAdd&&(e.income=((r=e.income)!=null?r:0)+t.incomeAdd),t.troopsAdd&&e.troops&&(e.troops.count+=t.troopsAdd),t.thornsAdd&&(e.thorns=((a=e.thorns)!=null?a:0)+t.thornsAdd),t.cleanAdd&&(e.cleanBonus=((o=e.cleanBonus)!=null?o:0)+t.cleanAdd),t.buffAdd&&(e.buffTroops=((l=e.buffTroops)!=null?l:0)+t.buffAdd,e.buffTowers=((c=e.buffTowers)!=null?c:0)+t.buffAdd,e.buffHero=((h=e.buffHero)!=null?h:0)+t.buffAdd),t.hpTroopsAdd&&(e.hpTroops=((u=e.hpTroops)!=null?u:0)+t.hpTroopsAdd),e.troops&&(t.dmgMul&&(e.buffTroops=((d=e.buffTroops)!=null?d:0)+(t.dmgMul-1)),t.burnAdd&&(e.troopBurn=((f=e.troopBurn)!=null?f:0)+t.burnAdd)),e}function Vh(){const s={};for(const t of Object.keys(ol)){const e=ol[t],n=t;s[n]={id:n,kind:t,tier:0,cost:e.base.cost,stats:e.base.stats,next:e.specs.map(i=>`${t}_${i.id}`),look:"base"};for(const i of e.specs){const r=`${t}_${i.id}`;s[r]={id:r,kind:t,tier:1,cost:i.cost,stats:i.stats,parent:n,next:e.mods.map(a=>`${r}_${a.id}`),look:i.id};for(const a of e.mods){const o=`${r}_${a.id}`;s[o]={id:o,kind:t,tier:2,cost:e.modCost,stats:Hh(i.stats,a),parent:r,next:[],look:i.id}}}}return s}const gi=Vh();function Tc(s){const t=gi[s];return t.tier===2?`mod.${t.kind}.${s.split("_").pop()}`:`bld.${s}`}const bo=[{id:"tithe",unlockLevel:1},{id:"swift",unlockLevel:1},{id:"purse",unlockLevel:2},{id:"masons",unlockLevel:2},{id:"stout",unlockLevel:3},{id:"ramparts",unlockLevel:4},{id:"drill",unlockLevel:4},{id:"focus",unlockLevel:6},{id:"guard",unlockLevel:7},{id:"harvest",unlockLevel:8}],Wh=bo.map(s=>s.id);function Xh(s){return s>=6?3:2}const So=[{id:"swift",mult:1.25},{id:"poverty",mult:1.3},{id:"nowalls",mult:1.25},{id:"tough",mult:1.4},{id:"fragile",mult:1.2}],xr=3;function vr(s){var e,n;let t=1;for(const i of s)t*=(n=(e=So.find(r=>r.id===i))==null?void 0:e.mult)!=null?n:1;return Math.round(t*100)/100}function Ta(s){return 25*(s-1)*(s+2)}function Xi(s){let t=1;for(;Ta(t+1)<=s&&t<99;)t++;return t}const qh={title:"Last Bastion",subtitle:"Hold until dawn",loading:"Loading…","err.fatal":"Something went wrong. Please reload the page.","menu.play":"Play","menu.continue":"Continue","menu.continueInfo":"{map}, night {n}","menu.maps":"Choose map","menu.armory":"Weapons & perks","menu.mutators":"Mutators","menu.achievements":"Achievements","menu.leaders":"Leaderboard","menu.settings":"Settings","menu.newRun":"New run","menu.newRunConfirm":"Start a new run? The unfinished run will be lost.","ruler.level":"Ruler level {n}","ruler.max":"Max level",glory:"Glory",back:"Back",close:"Close",ok:"OK",cancel:"Cancel",yes:"Yes",no:"No",video:"Video","hud.night":"Night {n}/{m}","hud.nightEndless":"Night {n}","hud.day":"Day","hud.startNight":"Start night","hud.rally":"Rally troops","hud.rallyHold":"Hold here","hud.ability":"Ability","hud.build":"Build","hud.upgrade":"Upgrade","hud.coinsAd":"+{n} coins","hud.respawnIn":"Respawn: {n}","hud.respawnAd":"Revive now","hud.dawnIncome":"Morning income: +{n}","hud.clean":"Flawless defense","hud.nightFalls":"Night {n}","hud.nightFallsSub":"The mist is coming","hud.dawn":"Dawn","hud.dawnSub":"The night is survived","hud.bossNight":"Boss night!","hud.enemies":"Enemies: {n}","hud.noCoins":"Not enough coins","hud.lastNight":"Final night","hud.rewardOk":"Reward received!","hud.adFail":"Video is not available right now","hud.rallyOn":"Troops follow the hero","hud.rallyOff":"Troops hold this position","choice.title":"Choose an upgrade","choice.sub":"Every upgrade is a choice between two branches","choice.key":"Key {k}","pause.title":"Paused","pause.resume":"Resume","pause.exit":"Main menu","pause.exitConfirm":"Return to the menu? The run is saved at the start of the current day.","pause.controls":"Controls","pause.controlsPc":"WASD/arrows — move · Space (hold) — build · Q — ability · R — troops · Enter — start night · Esc — pause","pause.controlsTouch":"Left joystick — move · Right buttons — build, ability, troops","defeat.title":"The castle has fallen","defeat.second":"Second chance","defeat.secondDesc":"The castle is restored and the night starts over","defeat.results":"See results","results.victory":"Victory!","results.defeat":"Defeat","results.endless":"Endless Nights","results.nights":"Nights survived","results.kills":"Enemies defeated","results.lost":"Buildings lost","results.glory":"Glory earned","results.double":"×2 glory","results.doubled":"Glory doubled!","results.continue":"Continue","results.levelUp":"New ruler level: {n}!","results.unlocked":"Unlocked: {s}","results.mult":"Mutator multiplier ×{n}","results.record":"New record!","results.mapUnlocked":"A new map is unlocked!","map.valley":"The Valley","map.swamp":"Marsh Crossing","map.pass":"Mountain Pass","map.valley.d":"Green hills and a quiet river. Three roads lead to the castle.","map.swamp.d":"Misty marshes, a bridge over the river and four attack routes.","map.pass.d":"A rocky pass: the enemy marches through four gorges.","map.nights":"Nights: {n}","map.locked":"Win on the previous map","map.best":"Best: {n} nights","map.won":"Completed","map.endless":"Endless Nights","map.endlessBest":"Record: {n}","map.endlessLocked":"Unlocks after victory","map.start":"To battle","map.title":"Choose map","map.loadout":"Weapon: {w} · Perks: {p} · Mutators: {m}","map.none":"none","armory.title":"Weapons & perks","armory.weapons":"Hero weapon","armory.perks":"Perks","armory.slots":"{n} of {m} selected","armory.level":"Level {n}","armory.ability":"Ability: {s}","armory.selected":"Selected","weapon.sword":"Sword","weapon.bow":"Bow","weapon.spear":"Spear","weapon.staff":"Staff","weapon.sword.d":"Hits several nearby enemies.","weapon.bow.d":"Shoots from afar.","weapon.spear.d":"Long reach, heavy damage.","weapon.staff.d":"Star bolts deal area damage.","ability.whirl":"Blade Whirl","ability.volley":"Arrow Rain","ability.charge":"Battering Charge","ability.starfall":"Starfall","ability.whirl.d":"Strikes all enemies around the hero.","ability.volley.d":"Rains arrows on the nearest enemies.","ability.charge.d":"Dashes through enemy ranks.","ability.starfall.d":"Stars hit enemies and heal allies.","perk.tithe":"Tithe","perk.tithe.d":"+1 coin every morning","perk.swift":"Swift steed","perk.swift.d":"Hero moves 15% faster","perk.purse":"Heavy purse","perk.purse.d":"+4 coins at the start of a run","perk.masons":"Masons guild","perk.masons.d":"Towers cost 20% less","perk.stout":"Hardened","perk.stout.d":"Hero health +40%","perk.ramparts":"Sturdy walls","perk.ramparts.d":"Wall durability +60%","perk.drill":"Drill","perk.drill.d":"+1 soldier in every squad","perk.focus":"Focus","perk.focus.d":"Ability cooldown −30%","perk.guard":"Royal guard","perk.guard.d":"Castle 50% sturdier and shoots faster","perk.harvest":"Rich soil","perk.harvest.d":"From night 4, income buildings give +1","mut.title":"Mutators","mut.sub":"Make the run harder — earn more glory","mut.mult":"Glory multiplier: ×{n}","mut.locked":"Unlock at ruler level {n}","mut.swift":"Swift mist","mut.swift.d":"Enemies are 25% faster","mut.poverty":"Lean times","mut.poverty.d":"Building income −30%","mut.nowalls":"No walls","mut.nowalls.d":"Walls cannot be built","mut.tough":"Hardened mist","mut.tough.d":"Enemy health +40%","mut.fragile":"Fragile castle","mut.fragile.d":"Castle durability −40%","ach.title":"Achievements","ach.count":"{n} of {m} earned","ach.first_build":"First stone","ach.first_build.d":"Build your first building","ach.first_night":"First dawn","ach.first_night.d":"Survive the first night","ach.win_valley":"Keeper of the Valley","ach.win_valley.d":"Win on The Valley","ach.win_swamp":"Lord of the Marsh","ach.win_swamp.d":"Win on Marsh Crossing","ach.win_pass":"Warden of the Pass","ach.win_pass.d":"Win on Mountain Pass","ach.boss_slayer":"Giant slayer","ach.boss_slayer.d":"Defeat a boss","ach.clean5":"Impregnable","ach.clean5.d":"5 nights in a row without losing a building","ach.kills500":"Mist breaker","ach.kills500.d":"Defeat 500 enemies (total)","ach.kills5000":"Light in the dark","ach.kills5000.d":"Defeat 5000 enemies (total)","ach.builder100":"Architect","ach.builder100.d":"Build or upgrade 100 times (total)","ach.full_upgrade":"Master builder","ach.full_upgrade.d":"Fully upgrade a building","ach.rich50":"Treasurer","ach.rich50.d":"Hold 50 coins","ach.hero50":"Hero of ballads","ach.hero50.d":"The hero personally defeats 50 enemies in a run","ach.army20":"Host","ach.army20.d":"Have 20 soldiers at once","ach.income15":"Prosperity","ach.income15.d":"Earn 15+ coins in one morning","ach.mutator_win":"Trial","ach.mutator_win.d":"Win with a mutator","ach.mutator3_win":"Daredevil","ach.mutator3_win.d":"Win with three mutators","ach.endless15":"Long night","ach.endless15.d":"Survive 15 nights in Endless Nights","ach.endless25":"Eternal bastion","ach.endless25.d":"Survive 25 nights in Endless Nights","ach.level5":"Worthy ruler","ach.level5.d":"Reach ruler level 5","ach.level10":"Legend of the realm","ach.level10.d":"Reach ruler level 10","ach.all_weapons":"Weapon master","ach.all_weapons.d":"Win with every weapon","ach.ability100":"Willpower","ach.ability100.d":"Use your ability 100 times","ach.flawless":"Not a scratch","ach.flawless.d":"Win while the castle keeps over half of its durability","ach.unlocked":"Achievement: {s}","lb.title":"Leaderboard","lb.sub":"Most nights survived in Endless Nights","lb.auth":"Sign in to get your result on the board","lb.authBtn":"Sign in","lb.empty":"Nobody here yet — be the first!","lb.you":"You","lb.local":"Your record: {n}","lb.unavailable":"The leaderboard is unavailable right now","lb.loading":"Loading…","lb.player":"Player","set.title":"Settings","set.music":"Music","set.sfx":"Sounds","set.vibration":"Vibration","set.quality":"Graphics","set.q.auto":"Auto","set.q.high":"High","set.q.medium":"Medium","set.q.low":"Low","set.language":"Language","set.reset":"Reset progress","set.resetConfirm":"All progress will be permanently deleted. Continue?","set.resetDone":"Progress reset","set.on":"On","set.off":"Off","tut.move":"Move with WASD or the arrow keys","tut.moveTouch":"Drag on the left side to move","tut.slot":"Ride to a glowing circle","tut.hold":"Hold Space to build","tut.holdTouch":"Hold the “Build” button","tut.paths":"Red roads show where enemies will come from","tut.night":"Ready? Press “Start night”","tut.fight":"The hero attacks automatically. Ability — Q","tut.fightTouch":"The hero attacks automatically. Tap the ability button","tut.choice":"An upgrade is a choice between two branches","stat.income":"Income +{n}","stat.dmg":"Damage {n}","stat.rate":"{n} shots/s","stat.range":"Range {n}","stat.hp":"Durability {n}","stat.troops":"Soldiers: {n}","stat.splash":"Area damage","stat.slow":"Slows enemies","stat.burn":"Sets on fire","stat.pierce":"Pierces {n} targets","stat.multi":"Projectiles: {n}","stat.buff":"Ally damage +{n}%","stat.thorns":"Thorns: {n} damage","stat.clean":"+{n} for flawless defense","stat.hpTroops":"Soldier health +{n}%","unit.grunt":"Mist warrior","unit.runner":"Runner","unit.shieldbearer":"Shieldbearer","unit.skirmisher":"Skirmisher","unit.ram":"Ram","unit.wisp":"Flying wisp","unit.raider":"Raider","unit.giant":"Giant","unit.boss_warlord":"Mist Warlord","unit.boss_hag":"Marsh Hag","unit.boss_colossus":"Stone Colossus","bld.castle":"Castle","bld.castle.d":"Heart of the realm. If it falls, the run is lost.","bld.castle_citadel":"Citadel","bld.castle_citadel.d":"Sturdier, shoots more often.","bld.castle_court":"Trade court","bld.castle_court.d":"More income every morning.","mod.castle.bastions":"Bastions","mod.castle.bastions.d":"Durability ×1.5 and a second archer.","mod.castle.treasury":"Treasury","mod.castle.treasury.d":"+3 coins every morning.","bld.wall":"Palisade","bld.wall.d":"Blocks the road for ground enemies.","bld.wall_stone":"Stone wall","bld.wall_stone.d":"Very sturdy.","bld.wall_spiked":"Spiked palisade","bld.wall_spiked.d":"Hurts those who hack at it.","mod.wall.reinforced":"Reinforced","mod.wall.reinforced.d":"Durability ×1.7.","mod.wall.tar":"Tar cauldrons","mod.wall.tar.d":"More damage to attackers.","bld.tower":"Watchtower","bld.tower.d":"Shoots arrows at enemies.","bld.tower_archer":"Archer tower","bld.tower_archer.d":"Rapid shots.","bld.tower_ballista":"Ballista","bld.tower_ballista.d":"Heavy bolts pierce the ranks.","mod.tower.keen":"Keen eye","mod.tower.keen.d":"Damage ×1.45 and more range.","mod.tower.volley":"Volley","mod.tower.volley.d":"Three projectiles per shot.","bld.magic":"Mage tower","bld.magic.d":"Arcane orbs deal area damage.","bld.magic_frost":"Frost spire","bld.magic_frost.d":"Slows enemies.","bld.magic_fire":"Fire spire","bld.magic_fire.d":"Sets crowds ablaze.","mod.magic.resonance":"Resonance","mod.magic.resonance.d":"Damage ×1.55.","mod.magic.farsight":"Farsight","mod.magic.farsight.d":"More range and fire rate.","bld.barracks":"Barracks","bld.barracks.d":"Militia guards the road.","bld.barracks_spear":"Spearmen","bld.barracks_spear.d":"Strong against giants and rams.","bld.barracks_sword":"Swordsmen","bld.barracks_sword.d":"Tough melee fighters.","mod.barracks.veterans":"Veterans","mod.barracks.veterans.d":"+1 soldier and more health.","mod.barracks.warcry":"War cry","mod.barracks.warcry.d":"Soldier damage ×1.5.","bld.range":"Archery range","bld.range.d":"Archers support the defense.","bld.range_bows":"Longbowmen","bld.range_bows.d":"More archers.","bld.range_xbows":"Crossbowmen","bld.range_xbows.d":"Pierce shields.","mod.range.firearrows":"Fire arrows","mod.range.firearrows.d":"Arrows set enemies on fire.","mod.range.squad":"Squad","mod.range.squad.d":"+1 archer and more health.","bld.farm":"Farm","bld.farm.d":"Brings coins every morning.","bld.farm_mill":"Windmill","bld.farm_mill.d":"More income.","bld.farm_militia":"Peasant militia","bld.farm_militia.d":"Peasants defend the farm.","mod.farm.harvest":"Rich harvest","mod.farm.harvest.d":"+1 income.","mod.farm.fence":"Fence","mod.farm.fence.d":"Sturdier and +1 defender.","bld.mine":"Mine","bld.mine.d":"Digs gold. A tempting target for raiders.","bld.mine_deep":"Deep mine","bld.mine_deep.d":"Lots of gold.","bld.mine_fort":"Fortified mine","bld.mine_fort.d":"Palisade and an archer.","mod.mine.vein":"Gold vein","mod.mine.vein.d":"+2 income.","mod.mine.vaults":"Stone vaults","mod.mine.vaults.d":"Durability ×2 and +1 income.","bld.fish":"Fishing hut","bld.fish.d":"Cheap income by the water.","bld.fish_pier":"Pier","bld.fish_pier.d":"More boats — more income.","bld.fish_market":"Fish market","bld.fish_market.d":"Bonus for a flawless night.","mod.fish.nets":"Nets","mod.fish.nets.d":"+1 income.","mod.fish.stilts":"Stilts","mod.fish.stilts.d":"Sturdier and a bigger bonus.","bld.forge":"Forge","bld.forge.d":"Boosts the damage of all defenders.","bld.forge_armory":"Armory","bld.forge_armory.d":"Stronger soldiers and hero.","bld.forge_workshop":"Workshop","bld.forge_workshop.d":"Stronger towers.","mod.forge.temper":"Tempering","mod.forge.temper.d":"+15% damage for everyone.","mod.forge.mail":"Chainmail","mod.forge.mail.d":"Sturdier soldiers."},Ir={title:"Последний Бастион",subtitle:"Продержись до рассвета",loading:"Загрузка…","err.fatal":"Что-то пошло не так. Перезагрузите страницу.","menu.play":"Играть","menu.continue":"Продолжить","menu.continueInfo":"{map}, ночь {n}","menu.maps":"Выбор карты","menu.armory":"Оружие и перки","menu.mutators":"Мутаторы","menu.achievements":"Достижения","menu.leaders":"Лидеры","menu.settings":"Настройки","menu.newRun":"Новая партия","menu.newRunConfirm":"Начать новую партию? Незавершённая партия будет потеряна.","ruler.level":"Уровень правителя {n}","ruler.max":"Максимальный уровень",glory:"Слава",back:"Назад",close:"Закрыть",ok:"Хорошо",cancel:"Отмена",yes:"Да",no:"Нет",video:"Видео","hud.night":"Ночь {n}/{m}","hud.nightEndless":"Ночь {n}","hud.day":"День","hud.startNight":"Начать ночь","hud.rally":"Собрать отряд","hud.rallyHold":"Оставить здесь","hud.ability":"Способность","hud.build":"Строить","hud.upgrade":"Улучшить","hud.coinsAd":"+{n} монет","hud.respawnIn":"Возрождение: {n}","hud.respawnAd":"Возродить сейчас","hud.dawnIncome":"Доход утром: +{n}","hud.clean":"Чистая оборона","hud.nightFalls":"Ночь {n}","hud.nightFallsSub":"Враги приближаются","hud.dawn":"Рассвет","hud.dawnSub":"Ночь пережита","hud.bossNight":"Ночь босса!","hud.enemies":"Врагов: {n}","hud.noCoins":"Не хватает монет","hud.lastNight":"Последняя ночь","hud.rewardOk":"Награда получена!","hud.adFail":"Видео сейчас недоступно","hud.rallyOn":"Отряд следует за героем","hud.rallyOff":"Отряд держит позицию","choice.title":"Выбери улучшение","choice.sub":"Каждое улучшение — выбор одной из двух веток","choice.key":"Клавиша {k}","pause.title":"Пауза","pause.resume":"Продолжить","pause.exit":"В меню","pause.exitConfirm":"Выйти в меню? Партия сохранена на начало текущего дня.","pause.controls":"Управление","pause.controlsPc":"WASD/стрелки — движение · Пробел (удерживать) — строить · Q — способность · R — отряд · Enter — начать ночь · Esc — пауза","pause.controlsTouch":"Джойстик слева — движение · Кнопки справа — строить, способность, отряд","defeat.title":"Замок пал","defeat.second":"Второй шанс","defeat.secondDesc":"Замок восстановится, ночь начнётся заново","defeat.results":"К итогам","results.victory":"Победа!","results.defeat":"Поражение","results.endless":"Бесконечные ночи","results.nights":"Пережито ночей","results.kills":"Убито врагов","results.lost":"Потеряно построек","results.glory":"Очки славы","results.double":"×2 славы","results.doubled":"Слава удвоена!","results.continue":"Продолжить","results.levelUp":"Новый уровень правителя: {n}!","results.unlocked":"Открыто: {s}","results.mult":"Множитель мутаторов ×{n}","results.record":"Новый рекорд!","results.mapUnlocked":"Открыта новая карта!","map.valley":"Долина","map.swamp":"Болотная переправа","map.pass":"Горный перевал","map.valley.d":"Зелёные холмы и тихая река. Три дороги ведут к замку.","map.swamp.d":"Туманные топи, мост через реку и четыре пути атаки.","map.pass.d":"Скалистый перевал: враги идут сквозь четыре ущелья.","map.nights":"Ночей: {n}","map.locked":"Победите на предыдущей карте","map.best":"Лучшее: {n} ноч.","map.won":"Пройдена","map.endless":"Бесконечные ночи","map.endlessBest":"Рекорд: {n}","map.endlessLocked":"Откроется после победы","map.start":"В бой","map.title":"Выбор карты","map.loadout":"Оружие: {w} · Перки: {p} · Мутаторы: {m}","map.none":"нет","armory.title":"Оружие и перки","armory.weapons":"Оружие героя","armory.perks":"Перки","armory.slots":"Выбрано {n} из {m}","armory.level":"Уровень {n}","armory.ability":"Способность: {s}","armory.selected":"Выбрано","weapon.sword":"Меч","weapon.bow":"Лук","weapon.spear":"Копьё","weapon.staff":"Посох","weapon.sword.d":"Бьёт нескольких врагов рядом.","weapon.bow.d":"Стреляет издалека.","weapon.spear.d":"Длинный выпад, мощный урон.","weapon.staff.d":"Звёздные снаряды бьют по площади.","ability.whirl":"Вихрь клинка","ability.volley":"Град стрел","ability.charge":"Таранный рывок","ability.starfall":"Звездопад","ability.whirl.d":"Удар по всем врагам вокруг героя.","ability.volley.d":"Дождь стрел на ближайших врагов.","ability.charge.d":"Рывок сквозь строй врагов.","ability.starfall.d":"Звёзды бьют врагов и лечат своих.","perk.tithe":"Десятина","perk.tithe.d":"+1 монета каждое утро","perk.swift":"Быстрый скакун","perk.swift.d":"Герой быстрее на 15%","perk.purse":"Тугой кошель","perk.purse.d":"+4 монеты в начале партии","perk.masons":"Гильдия каменщиков","perk.masons.d":"Башни дешевле на 20%","perk.stout":"Закалка","perk.stout.d":"Здоровье героя +40%","perk.ramparts":"Крепкие стены","perk.ramparts.d":"Прочность стен +60%","perk.drill":"Муштра","perk.drill.d":"+1 воин в каждом отряде","perk.focus":"Сосредоточение","perk.focus.d":"Перезарядка способности −30%","perk.guard":"Королевская стража","perk.guard.d":"Замок прочнее на 50% и стреляет быстрее","perk.harvest":"Щедрая земля","perk.harvest.d":"С 4-й ночи доходные здания дают +1","mut.title":"Мутаторы","mut.sub":"Усложни партию — получи больше славы","mut.mult":"Множитель славы: ×{n}","mut.locked":"Откроются на уровне правителя {n}","mut.swift":"Стремительная мгла","mut.swift.d":"Враги быстрее на 25%","mut.poverty":"Скудные времена","mut.poverty.d":"Доход построек −30%","mut.nowalls":"Без стен","mut.nowalls.d":"Стены строить нельзя","mut.tough":"Закалённая мгла","mut.tough.d":"Здоровье врагов +40%","mut.fragile":"Хрупкий замок","mut.fragile.d":"Прочность замка −40%","ach.title":"Достижения","ach.count":"Получено {n} из {m}","ach.first_build":"Первый камень","ach.first_build.d":"Построй первое здание","ach.first_night":"Первый рассвет","ach.first_night.d":"Переживи первую ночь","ach.win_valley":"Хранитель Долины","ach.win_valley.d":"Победи на карте «Долина»","ach.win_swamp":"Повелитель топей","ach.win_swamp.d":"Победи на «Болотной переправе»","ach.win_pass":"Страж перевала","ach.win_pass.d":"Победи на «Горном перевале»","ach.boss_slayer":"Гроза великанов","ach.boss_slayer.d":"Победи босса","ach.clean5":"Неприступный","ach.clean5.d":"5 ночей подряд без потерь построек","ach.kills500":"Разгоняющий мглу","ach.kills500.d":"Победи 500 врагов (всего)","ach.kills5000":"Свет во тьме","ach.kills5000.d":"Победи 5000 врагов (всего)","ach.builder100":"Зодчий","ach.builder100.d":"Построй или улучши 100 раз (всего)","ach.full_upgrade":"Мастер","ach.full_upgrade.d":"Полностью улучши здание","ach.rich50":"Казначей","ach.rich50.d":"Накопи 50 монет","ach.hero50":"Герой баллад","ach.hero50.d":"Герой лично победил 50 врагов за партию","ach.army20":"Войско","ach.army20.d":"Собери 20 воинов одновременно","ach.income15":"Процветание","ach.income15.d":"Получи 15+ монет за одно утро","ach.mutator_win":"Испытание","ach.mutator_win.d":"Победи с мутатором","ach.mutator3_win":"Безумец","ach.mutator3_win.d":"Победи с тремя мутаторами","ach.endless15":"Долгая ночь","ach.endless15.d":"Переживи 15 ночей в «Бесконечных ночах»","ach.endless25":"Вечный бастион","ach.endless25.d":"Переживи 25 ночей в «Бесконечных ночах»","ach.level5":"Достойный правитель","ach.level5.d":"Достигни 5 уровня правителя","ach.level10":"Легенда королевства","ach.level10.d":"Достигни 10 уровня правителя","ach.all_weapons":"Оружейник","ach.all_weapons.d":"Победи с каждым оружием","ach.ability100":"Сила воли","ach.ability100.d":"Используй способность 100 раз","ach.flawless":"Ни царапины","ach.flawless.d":"Победи, сохранив замку больше половины прочности","ach.unlocked":"Достижение: {s}","lb.title":"Лидеры","lb.sub":"Больше всего ночей в «Бесконечных ночах»","lb.auth":"Войдите, чтобы ваш результат попал в таблицу","lb.authBtn":"Войти","lb.empty":"Пока никого нет — станьте первым!","lb.you":"Вы","lb.local":"Ваш рекорд: {n}","lb.unavailable":"Таблица лидеров сейчас недоступна","lb.loading":"Загрузка…","lb.player":"Игрок","set.title":"Настройки","set.music":"Музыка","set.sfx":"Звуки","set.vibration":"Вибрация","set.quality":"Графика","set.q.auto":"Авто","set.q.high":"Высокая","set.q.medium":"Средняя","set.q.low":"Низкая","set.language":"Язык","set.reset":"Сбросить прогресс","set.resetConfirm":"Весь прогресс будет удалён без возможности восстановления. Продолжить?","set.resetDone":"Прогресс сброшен","set.on":"Вкл","set.off":"Выкл","tut.move":"Двигайся: WASD или стрелки","tut.moveTouch":"Двигайся: веди пальцем слева","tut.slot":"Подъедь к светящемуся кругу","tut.hold":"Удерживай Пробел, чтобы построить","tut.holdTouch":"Удерживай кнопку «Строить»","tut.paths":"Красные дороги — отсюда придут враги","tut.night":"Готов? Нажми «Начать ночь»","tut.fight":"Герой бьёт сам. Способность — Q","tut.fightTouch":"Герой бьёт сам. Жми кнопку способности","tut.choice":"Улучшение — выбор из двух веток","stat.income":"Доход +{n}","stat.dmg":"Урон {n}","stat.rate":"{n} выстр./с","stat.range":"Дальность {n}","stat.hp":"Прочность {n}","stat.troops":"Воинов: {n}","stat.splash":"Урон по площади","stat.slow":"Замедляет врагов","stat.burn":"Поджигает","stat.pierce":"Пробивает {n} целей","stat.multi":"Снарядов: {n}","stat.buff":"Урон союзников +{n}%","stat.thorns":"Шипы: {n} урона","stat.clean":"+{n} за чистую оборону","stat.hpTroops":"Здоровье воинов +{n}%","unit.grunt":"Мглистый воин","unit.runner":"Бегун","unit.shieldbearer":"Щитоносец","unit.skirmisher":"Стрелок","unit.ram":"Таран","unit.wisp":"Летучий дух","unit.raider":"Налётчик","unit.giant":"Великан","unit.boss_warlord":"Вождь Мглы","unit.boss_hag":"Болотная ведьма","unit.boss_colossus":"Каменный колосс","bld.castle":"Замок","bld.castle.d":"Сердце королевства. Падёт — партия проиграна.","bld.castle_citadel":"Цитадель","bld.castle_citadel.d":"Крепче и метче стреляет.","bld.castle_court":"Торговый двор","bld.castle_court.d":"Больше дохода каждое утро.","mod.castle.bastions":"Бастионы","mod.castle.bastions.d":"Прочность ×1.5 и второй стрелок.","mod.castle.treasury":"Казна","mod.castle.treasury.d":"+3 монеты каждое утро.","bld.wall":"Частокол","bld.wall.d":"Перекрывает дорогу наземным врагам.","bld.wall_stone":"Каменная стена","bld.wall_stone.d":"Очень прочная.","bld.wall_spiked":"Шипованный частокол","bld.wall_spiked.d":"Ранит тех, кто его рубит.","mod.wall.reinforced":"Укрепление","mod.wall.reinforced.d":"Прочность ×1.7.","mod.wall.tar":"Смоляные котлы","mod.wall.tar.d":"Больше урона атакующим.","bld.tower":"Сторожевая башня","bld.tower.d":"Обстреливает врагов стрелами.","bld.tower_archer":"Лучная башня","bld.tower_archer.d":"Частые выстрелы.","bld.tower_ballista":"Баллиста","bld.tower_ballista.d":"Тяжёлые болты пробивают строй.","mod.tower.keen":"Меткость","mod.tower.keen.d":"Урон ×1.45 и дальность.","mod.tower.volley":"Залп","mod.tower.volley.d":"Три снаряда за выстрел.","bld.magic":"Магическая башня","bld.magic.d":"Магические сферы бьют по площади.","bld.magic_frost":"Ледяной шпиль","bld.magic_frost.d":"Замедляет врагов.","bld.magic_fire":"Огненный шпиль","bld.magic_fire.d":"Поджигает толпы.","mod.magic.resonance":"Резонанс","mod.magic.resonance.d":"Урон ×1.55.","mod.magic.farsight":"Дальновидение","mod.magic.farsight.d":"Дальность и скорострельность.","bld.barracks":"Казарма","bld.barracks.d":"Ополченцы охраняют дорогу.","bld.barracks_spear":"Копейщики","bld.barracks_spear.d":"Сильны против великанов и таранов.","bld.barracks_sword":"Мечники","bld.barracks_sword.d":"Крепкие бойцы ближнего боя.","mod.barracks.veterans":"Ветераны","mod.barracks.veterans.d":"+1 воин и больше здоровья.","mod.barracks.warcry":"Боевой клич","mod.barracks.warcry.d":"Урон воинов ×1.5.","bld.range":"Стрельбище","bld.range.d":"Лучники поддерживают оборону.","bld.range_bows":"Лучники","bld.range_bows.d":"Больше стрелков.","bld.range_xbows":"Арбалетчики","bld.range_xbows.d":"Пробивают щиты.","mod.range.firearrows":"Огненные стрелы","mod.range.firearrows.d":"Стрелы поджигают врагов.","mod.range.squad":"Отряд","mod.range.squad.d":"+1 стрелок и больше здоровья.","bld.farm":"Ферма","bld.farm.d":"Приносит монеты каждое утро.","bld.farm_mill":"Мельница","bld.farm_mill.d":"Больше дохода.","bld.farm_militia":"Ополчение","bld.farm_militia.d":"Крестьяне защищают ферму.","mod.farm.harvest":"Богатый урожай","mod.farm.harvest.d":"+1 к доходу.","mod.farm.fence":"Ограда","mod.farm.fence.d":"Прочнее и +1 защитник.","bld.mine":"Шахта","bld.mine.d":"Добывает золото. Лакомая цель для налётчиков.","bld.mine_deep":"Глубокая шахта","bld.mine_deep.d":"Много золота.","bld.mine_fort":"Укреплённая шахта","bld.mine_fort.d":"Частокол и стрелок.","mod.mine.vein":"Золотая жила","mod.mine.vein.d":"+2 к доходу.","mod.mine.vaults":"Каменные своды","mod.mine.vaults.d":"Прочность ×2 и +1 к доходу.","bld.fish":"Рыбацкая хижина","bld.fish.d":"Дешёвый доход у воды.","bld.fish_pier":"Пристань","bld.fish_pier.d":"Больше лодок — больше дохода.","bld.fish_market":"Рыбный рынок","bld.fish_market.d":"Бонус за ночь без потерь.","mod.fish.nets":"Сети","mod.fish.nets.d":"+1 к доходу.","mod.fish.stilts":"Сваи","mod.fish.stilts.d":"Прочнее и больше бонус.","bld.forge":"Кузница","bld.forge.d":"Усиливает урон всех защитников.","bld.forge_armory":"Оружейная","bld.forge_armory.d":"Сильнее воины и герой.","bld.forge_workshop":"Мастерская","bld.forge_workshop.d":"Сильнее башни.","mod.forge.temper":"Закалка","mod.forge.temper.d":"+15% урона всем.","mod.forge.mail":"Кольчуги","mod.forge.mail.d":"Воины живучее."},Yh={ru:Ir,en:qh};let wo=Ir,Ac="ru";function Cc(s){const t=(s||"").toLowerCase().slice(0,2);return["ru","be","kk","uk","uz","ky","tg","hy","az","tt"].includes(t)?"ru":"en"}function Rc(s){Ac=s,wo=Yh[s],document.documentElement.lang=s}function Pc(){return Ac}function Lc(s,t){return t?s.replace(/\{(\w+)\}/g,(e,n)=>t[n]!==void 0?String(t[n]):`{${n}}`):s}function Y(s,t){var e,n;return Lc((n=(e=wo[s])!=null?e:Ir[s])!=null?n:s,t)}function fe(s,t){var i,r;const e=wo,n=Ir;return Lc((r=(i=e[s])!=null?i:n[s])!=null?r:s,t)}const Lt=(s,t,e,n)=>({id:s,kind:t,x:e,z:n}),an=(s,t,e)=>({id:s,kind:"wall",path:t,at:e}),Dc={valley:{id:"valley",nights:8,seed:1337,half:36,startCoins:8,palette:{grass:10473594,grass2:8831082,meadow:12902538,path:14730382,sand:15654824,rock:11775672,cliff:10130339,snow:16053498,water:8177376,fogDay:13625070,fogNight:1975360,skyDay:12575474,skyNight:1317427,leaves:[7323507,9096042,5941354,10998379]},terrain:{hills:[[-24,4,7,2.2],[20,18,6,1.6],[-4,-24,7,2.4],[26,-6,5,1.2],[-20,20,5,1.2],[8,26,6,1.8]],ponds:[[16,-30,4]],rivers:[{pts:[[-46,-4],[-31,-12],[-22,-22],[-13,-46]],w:5}],rocks:[[25,-7,3],[-30,8,2],[6,-30,2]],edge:6,noise:.5,treeDensity:.9,trees:["round","round","pine","birch"]},slots:[Lt("castle","castle",0,0),Lt("farm1","farm",-4,-8),Lt("farm2","farm",-1.5,-12.5),Lt("farm3","farm",-12,-4),Lt("farm4","farm",-10.5,-12),Lt("fish1","fish",-21,-15),Lt("mine1","mine",23,-3),Lt("tower1","tower",14,-6),Lt("tower2","tower",-15,6),Lt("tower3","tower",5,14),Lt("tower4","tower",23,-13),Lt("magic1","magic",-4,9),Lt("barracks1","barracks",8,-1),Lt("barracks2","barracks",-10,2),Lt("range1","range",12,6),Lt("forge1","forge",-6.5,-2.5),an("wall1",0,.45),an("wall2",1,.5),an("wall3",2,.48)],paths:[[[40,-34],[28,-24],[18,-15],[9,-8],[3,-2.5]],[[-40,32],[-28,24],[-17,14],[-8,6],[-2.8,2.2]],[[34,40],[24,28],[14,17],[6,7],[2.2,2.6]]],schedule:[[0],[1],[0,1],[2],[0,2],[1,2],[0,1,2],[0,1,2]],roster:[{unit:"grunt",from:1,weight:10},{unit:"runner",from:2,weight:5},{unit:"skirmisher",from:3,weight:4},{unit:"shieldbearer",from:4,weight:3},{unit:"raider",from:5,weight:3},{unit:"wisp",from:5,weight:3},{unit:"ram",from:6,weight:2},{unit:"giant",from:7,weight:1}],budget:{base:5,growth:.6,pow:1.35},boss:"boss_warlord",bridges:[]},swamp:{id:"swamp",nights:10,seed:4242,half:37,startCoins:9,palette:{grass:9420682,grass2:8040064,meadow:11127179,path:13218954,sand:14077856,rock:10462888,cliff:8818831,snow:15659760,water:7320488,fogDay:12901843,fogNight:1583148,skyDay:12048588,skyNight:1056799,leaves:[7183978,8367726,9416286,6066022]},terrain:{hills:[[18,20,6,1.4],[-8,-22,6,1.2],[26,-16,5,1.4]],ponds:[[13,23,5],[-11,-21,4.5],[24,2,3.5],[-12,22,4],[29,-18,3],[10,-27,3]],rivers:[{pts:[[-30,-46],[-25,-24],[-21,-6],[-25,14],[-36,44]],w:6}],rocks:[[14,-9,2.5],[-14,10,2]],edge:4,noise:.35,treeDensity:.75,trees:["willow","willow","round","dead","pine"]},slots:[Lt("castle","castle",0,0),Lt("farm1","farm",9,11),Lt("farm2","farm",13,15.5),Lt("farm3","farm",-8,9),Lt("fish1","fish",-17,-12),Lt("fish2","fish",6.5,19.8),Lt("fish3","fish",18,0),Lt("mine1","mine",14,-11),Lt("tower1","tower",-12,-9.5),Lt("tower2","tower",13,-2),Lt("tower3","tower",-6,16),Lt("tower4","tower",4,-18),Lt("magic1","magic",-6,-7),Lt("magic2","magic",6,4.5),Lt("barracks1","barracks",-8,3.5),Lt("barracks2","barracks",2,-10),Lt("range1","range",3.5,10),Lt("forge1","forge",-4,-11.5),an("wall1",0,.62),an("wall2",1,.52),an("wall3",2,.55),an("wall4",3,.5)],paths:[[[-42,-9],[-30,-8],[-18,-6],[-9,-3],[-3.2,-1]],[[36,-38],[24,-27],[14,-19.5],[6,-6],[2.5,-2.5]],[[-3,42],[-1,30],[-2,22],[-1,12],[-.3,3.4]],[[42,12],[30,9],[20,7],[9,1.5],[3.4,.5]]],schedule:[[0],[1],[0,2],[1,3],[0,1],[2,3],[0,1,2],[1,2,3],[0,1,2,3],[0,1,2,3]],roster:[{unit:"grunt",from:1,weight:9},{unit:"runner",from:1,weight:5},{unit:"wisp",from:2,weight:5},{unit:"skirmisher",from:3,weight:4},{unit:"shieldbearer",from:4,weight:3},{unit:"raider",from:4,weight:3},{unit:"ram",from:6,weight:2},{unit:"giant",from:7,weight:1.2}],budget:{base:6,growth:.62,pow:1.4},boss:"boss_hag",bridges:[{x:-21.6,z:-6.2,rot:0,len:9}]},pass:{id:"pass",nights:12,seed:9001,half:35,startCoins:10,palette:{grass:11061644,grass2:9812100,meadow:12768922,path:14205856,sand:14274740,rock:11183542,cliff:9341084,snow:16185340,water:8831964,fogDay:14016746,fogNight:1449011,skyDay:13098222,skyNight:1119790,leaves:[7249784,6131312,8367742,9418880]},terrain:{hills:[[-22,-22,11,9],[22,-22,11,10],[22,22,11,9],[-22,22,11,10],[-34,-12,7,7],[-12,-34,7,8],[34,-12,7,7],[12,-34,7,8],[34,14,7,8],[14,34,7,7],[-34,14,7,7],[-14,34,7,8]],ponds:[[-9,-11,2.6]],rivers:[],rocks:[[-14.5,12.5,2.5],[17.5,-11.5,2.5],[14.5,13.5,2.5],[-15,-17,2]],edge:12,noise:.6,treeDensity:.6,trees:["pine","snowpine","pine","birch"]},slots:[Lt("castle","castle",0,0),Lt("farm1","farm",-6,-6),Lt("farm2","farm",6,6.5),Lt("fish1","fish",-13,-14),Lt("mine1","mine",-12,10.5),Lt("mine2","mine",15,-9.5),Lt("mine3","mine",12,11),Lt("tower1","tower",6,-6.5),Lt("tower2","tower",-6.5,6),Lt("tower3","tower",6.5,-17),Lt("tower4","tower",-17,-6.5),Lt("tower5","tower",17.5,7.5),Lt("magic1","magic",-5,-16.5),Lt("magic2","magic",6.5,17),Lt("barracks1","barracks",12,-4.5),Lt("barracks2","barracks",-12.5,4.5),Lt("range1","range",-7.5,13),Lt("range2","range",9.5,-12.5),Lt("forge1","forge",-12,-7),an("wall1",0,.58),an("wall2",1,.6),an("wall3",2,.6),an("wall4",3,.58)],paths:[[[2,-42],[0,-30],[3,-19],[2,-8],[.5,-3.4]],[[-42,-2],[-30,2],[-19,-1],[-8,0],[-3.4,0]],[[42,4],[30,0],[19,2],[8,1],[3.4,.5]],[[-4,42],[-2,30],[-3,19],[-2,8],[-.5,3.4]]],schedule:[[0],[1],[0,2],[3],[1,2],[0,3],[0,1,2],[1,2,3],[0,1,2,3],[0,1,2,3],[0,1,2,3],[0,1,2,3]],roster:[{unit:"grunt",from:1,weight:8},{unit:"runner",from:1,weight:5},{unit:"shieldbearer",from:2,weight:4},{unit:"skirmisher",from:2,weight:4},{unit:"wisp",from:3,weight:4},{unit:"raider",from:3,weight:3},{unit:"ram",from:4,weight:2.5},{unit:"giant",from:5,weight:1.5}],budget:{base:7,growth:.62,pow:1.45},boss:"boss_colossus",bridges:[]}},Hn=["valley","swamp","pass"],Mr={sword:{id:"sword",damage:17,cooldown:.55,range:2.1,cleave:2,ability:"whirl",abilityCd:10,abilityDamage:55,abilityRadius:4,unlockLevel:1},bow:{id:"bow",damage:11,cooldown:.55,range:9.5,projectile:"arrow",cleave:0,ability:"volley",abilityCd:12,abilityDamage:22,abilityRadius:4.5,unlockLevel:2},spear:{id:"spear",damage:24,cooldown:.8,range:3,cleave:1,ability:"charge",abilityCd:8,abilityDamage:70,abilityRadius:2,unlockLevel:3},staff:{id:"staff",damage:14,cooldown:.9,range:7.5,projectile:"star",splash:1.8,cleave:0,ability:"starfall",abilityCd:14,abilityDamage:40,abilityRadius:6.5,unlockLevel:5}},xs=["sword","bow","spear","staff"],ll="lastbastion.save";function Aa(){const s={};for(const t of Hn)s[t]={won:!1,best:0,wins:0,endlessBest:0};return{v:me.saveVersion,t:0,glory:0,maps:s,weapon:"sword",perks:[],mutators:[],ach:[],totals:{kills:0,built:0,abilities:0,runs:0,wins:0,weaponsWon:[]},settings:{music:.6,sfx:.8,vibration:!0,quality:"auto",lang:"auto"},tutorialDone:!1,run:null,endlessBest:0}}const $h=[s=>{const t={...s,v:1};if(typeof s.gloryPoints=="number"&&(t.glory=s.gloryPoints),Array.isArray(s.unlockedMaps)){t.maps={};for(const e of s.unlockedMaps)t.maps[e]={won:!0,best:0,wins:1}}return typeof s.volume=="number"&&(t.settings={music:s.volume,sfx:s.volume}),delete t.gloryPoints,delete t.unlockedMaps,delete t.volume,t},s=>{var e;const t={...s,v:2};if(Array.isArray(s.achievements)&&!Array.isArray(s.ach)&&(t.ach=s.achievements),delete t.achievements,t.maps)for(const n of Object.keys(t.maps))t.maps[n]={endlessBest:0,...t.maps[n]};return t.settings={lang:"auto",...(e=t.settings)!=null?e:{}},t}],Xe=(s,t,e=-1/0,n=1/0)=>typeof s=="number"&&isFinite(s)?Math.min(n,Math.max(e,s)):t;function cl(s){var o,l,c;const t=Aa();if(!s||typeof s!="object")return t;let e={...s},n=typeof e.v=="number"?e.v:0;for(n>me.saveVersion&&(n=me.saveVersion);n<me.saveVersion;)e=$h[n](e),n++;const i=t;i.t=Xe(e.t,0,0),i.glory=Math.floor(Xe(e.glory,0,0));for(const h of Hn){const u=(o=e.maps)==null?void 0:o[h];u&&typeof u=="object"&&(i.maps[h]={won:!!u.won,best:Math.floor(Xe(u.best,0,0)),wins:Math.floor(Xe(u.wins,0,0)),endlessBest:Math.floor(Xe(u.endlessBest,0,0))})}xs.includes(e.weapon)&&(i.weapon=e.weapon),Array.isArray(e.perks)&&(i.perks=e.perks.filter(h=>Wh.includes(h)).slice(0,3)),Array.isArray(e.mutators)&&(i.mutators=e.mutators.filter(h=>So.some(u=>u.id===h))),Array.isArray(e.ach)&&(i.ach=[...new Set(e.ach.filter(h=>typeof h=="string"))]);const r=(l=e.totals)!=null?l:{};i.totals={kills:Math.floor(Xe(r.kills,0,0)),built:Math.floor(Xe(r.built,0,0)),abilities:Math.floor(Xe(r.abilities,0,0)),runs:Math.floor(Xe(r.runs,0,0)),wins:Math.floor(Xe(r.wins,0,0)),weaponsWon:Array.isArray(r.weaponsWon)?r.weaponsWon.filter(h=>xs.includes(h)):[]};const a=(c=e.settings)!=null?c:{};return i.settings={music:Xe(a.music,t.settings.music,0,1),sfx:Xe(a.sfx,t.settings.sfx,0,1),vibration:typeof a.vibration=="boolean"?a.vibration:!0,quality:["auto","high","medium","low"].includes(a.quality)?a.quality:"auto",lang:["auto","ru","en"].includes(a.lang)?a.lang:"auto"},i.tutorialDone=!!e.tutorialDone,i.run=e.run&&typeof e.run=="object"&&Hn.includes(e.run.map)&&typeof e.run.night=="number"?e.run:null,i.endlessBest=Math.floor(Xe(e.endlessBest,0,0)),i}class Kh{constructor(t,e=Zh()){this.cloud=t,this.storage=e,this.data=Aa(),this.timer=null,this.dirty=!1}async load(){var a;let t=null;try{const o=(a=this.storage)==null?void 0:a.getItem(ll);o&&(t=JSON.parse(o))}catch{t=null}let e=null;try{e=await this.cloud.loadCloud()}catch{e=null}const n=cl(t),i=cl(e);let r=n;return(i.t>n.t||i.t===n.t&&i.glory>n.glory)&&(r=i),this.data=r,r}change(t,e=!1){if(t==null||t(this.data),this.data.t=Date.now(),this.writeLocal(),this.dirty=!0,e){this.flush();return}this.timer||(this.timer=setTimeout(()=>{this.timer=null,this.flush()},me.saveDebounceMs))}flush(){this.timer&&(clearTimeout(this.timer),this.timer=null),this.dirty&&(this.dirty=!1,this.cloud.saveCloud(this.data,!0).catch(()=>{this.dirty=!0}))}writeLocal(){var t;try{(t=this.storage)==null||t.setItem(ll,JSON.stringify(this.data))}catch{}}reset(t=!0){const e=this.data.settings;this.data=Aa(),t&&(this.data.settings=e),this.change(void 0,!0)}}function Zh(){try{if(typeof localStorage=="undefined")return null;const s="__lb_probe";return localStorage.setItem(s,"1"),localStorage.removeItem(s),localStorage}catch{return null}}const on=s=>({team:1,...s}),ns=s=>({team:0,threat:0,targets:"any",...s}),Bn={grunt:on({id:"grunt",hp:34,speed:2.6,damage:5,cooldown:1,range:1.1,radius:.45,scale:1,targets:"any",threat:1}),runner:on({id:"runner",hp:20,speed:4.8,damage:3,cooldown:.7,range:1,radius:.4,scale:.85,targets:"any",threat:1}),shieldbearer:on({id:"shieldbearer",hp:80,speed:2.1,damage:6,cooldown:1.1,range:1.1,radius:.55,scale:1.1,targets:"any",armor:.6,threat:3}),skirmisher:on({id:"skirmisher",hp:24,speed:2.5,damage:6,cooldown:1.6,range:7,radius:.4,scale:.95,ranged:"dart",targets:"any",threat:2}),ram:on({id:"ram",hp:170,speed:1.7,damage:34,cooldown:2,range:1.4,radius:.9,scale:1,targets:"buildings",big:!0,bldMul:1,threat:5}),wisp:on({id:"wisp",hp:26,speed:3.6,damage:4,cooldown:.9,range:1.2,radius:.45,scale:.9,flying:!0,targets:"any",threat:2}),raider:on({id:"raider",hp:44,speed:3.9,damage:8,cooldown:.9,range:1.1,radius:.5,scale:1,targets:"economy",bldMul:2,threat:3}),giant:on({id:"giant",hp:460,speed:1.45,damage:38,cooldown:2.2,range:1.8,radius:1.1,scale:1.9,targets:"any",big:!0,splash:1.8,bldMul:1.3,threat:12}),boss_warlord:on({id:"boss_warlord",hp:2200,speed:1.5,damage:55,cooldown:2,range:2.2,radius:1.4,scale:2.4,targets:"any",big:!0,splash:2.4,bldMul:1.5,threat:40,boss:!0,summon:{unit:"grunt",count:3,every:8}}),boss_hag:on({id:"boss_hag",hp:2800,speed:1.6,damage:40,cooldown:1.6,range:7.5,radius:1.3,scale:2.2,ranged:"hex",targets:"any",big:!0,splash:2.2,bldMul:1.4,threat:55,boss:!0,summon:{unit:"wisp",count:4,every:7}}),boss_colossus:on({id:"boss_colossus",hp:4200,speed:1.25,damage:85,cooldown:2.6,range:2.6,radius:1.8,scale:3,targets:"buildings",big:!0,splash:3.2,bldMul:1.6,threat:75,boss:!0,summon:{unit:"shieldbearer",count:2,every:9}}),militia:ns({id:"militia",hp:55,speed:3.4,damage:6,cooldown:1,range:1.1,radius:.45,scale:1,aggro:6}),spearman:ns({id:"spearman",hp:75,speed:3.4,damage:8,cooldown:1,range:1.8,radius:.45,scale:1,bonusVsBig:2.5,aggro:6.5}),swordsman:ns({id:"swordsman",hp:100,speed:3.4,damage:11,cooldown:.9,range:1.2,radius:.5,scale:1.05,aggro:6.5}),bowman:ns({id:"bowman",hp:40,speed:3.2,damage:7,cooldown:1,range:8.5,radius:.4,scale:.95,ranged:"arrow",aggro:9}),crossbowman:ns({id:"crossbowman",hp:48,speed:3,damage:19,cooldown:2,range:10,radius:.45,scale:1,ranged:"bolt",aggro:10.5})},Jh=["grunt","runner","shieldbearer","skirmisher","ram","wisp","raider","giant","boss_warlord","boss_hag","boss_colossus"],Qh=["militia","spearman","swordsman","bowman","crossbowman"],jh=[...Jh,...Qh];class td{constructor(t,e={skill:.7,noise:.15}){var i;this.g=t,this.o=e,this.target=null,this.stuckT=0,this.lastX=0,this.lastZ=0,this.detour=0,this.waitT=0,this.builtSeen=0;let n=((i=e.seed)!=null?i:7)>>>0;this.r=()=>(n=n*1664525+1013904223>>>0)/4294967296}update(t){const e=this.g,n=e.input;if(n.hold=!1,n.moveX=0,n.moveZ=0,e.choice){e.chooseUpgrade(this.pickOption(e.choice.options)),this.target=null;return}e.phase==="day"?this.day(t):e.phase==="night"?this.night():this.target=null}moveTo(t,e,n,i){const r=this.g,a=r.hero;let o=t-a.x,l=e-a.z;if(Math.hypot(o,l)<=i)return!0;const h=Math.hypot(a.x-this.lastX,a.z-this.lastZ);if(this.lastX=a.x,this.lastZ=a.z,h<a.speed*n*.3?this.stuckT+=n:this.stuckT=Math.max(0,this.stuckT-n),this.stuckT>.4&&(this.detour=(this.r()<.5?-1:1)*(.9+this.r()*.6),this.stuckT=0),this.detour!==0){const d=Math.cos(this.detour),f=Math.sin(this.detour);[o,l]=[o*d-l*f,o*f+l*d],this.detour*=Math.pow(.2,n),Math.abs(this.detour)<.05&&(this.detour=0)}const u=Math.hypot(o,l)||1;return r.input.moveX=o/u,r.input.moveZ=l/u,!1}day(t){const e=this.g;if(e.stats.built!==this.builtSeen&&(this.builtSeen=e.stats.built,this.target=null,this.waitT=.15),this.waitT>0){this.waitT-=t;return}if(this.target&&this.target!=="night"){const r=e.actionFor(this.target);(!r||r.cost>e.coins)&&(this.target=null)}if(this.target||(this.target=this.pickTarget()),this.target==="night"){this.moveTo(e.castle.x+3,e.castle.z+5,t,2.5)&&(e.input.startNight=!0,this.target=null,this.waitT=.5);return}const n=this.target,i=n.radius+me.hero.buildRadius-.6;(this.moveTo(n.x,n.z,t,i)||e.activeSlot()===n)&&(e.input.moveX=0,e.input.moveZ=0,e.activeSlot()===n?e.input.hold=!0:this.moveTo(n.x,n.z,t,.5))}night(){const t=this.g,e=t.hero;if(!e.alive)return;let n=null,i=1/0;for(const a of t.units){if(!a.alive||a.team!==1)continue;const o=Math.hypot(a.x-t.castle.x,a.z-t.castle.z);o<i&&(i=o,n=a)}if(n&&i<26){const a=n.x-e.x,o=n.z-e.z,l=Math.hypot(a,o),c=e.weapon.range*.8;if(l>c&&(t.input.moveX=a/l,t.input.moveZ=o/l),e.hp<e.maxHp*.3){const h=t.castle.x+3-e.x,u=t.castle.z+4-e.z,d=Math.hypot(h,u)||1;t.input.moveX=h/d,t.input.moveZ=u/d}}else{const a=t.castle.x+3-e.x,o=t.castle.z+4-e.z,l=Math.hypot(a,o);l>1.5&&(t.input.moveX=a/l,t.input.moveZ=o/l)}let r=0;t.enemyGrid.query(e.x,e.z,e.weapon.abilityRadius+1,()=>{r++}),r>=3&&e.abilityCd<=0&&(t.input.ability=!0)}pickOption(t){if(t.length<2)return 0;if(this.r()<this.o.noise)return this.r()<.5?0:1;const e=n=>{var a,o,l,c,h,u,d;const i=n.stats;let r=0;return i.income&&(r+=i.income*6),i.attack&&(r+=i.attack.damage*((a=i.attack.multishot)!=null?a:1)/i.attack.cooldown*(1+((o=i.attack.splash)!=null?o:0)*.5)*1.2),i.troops&&(r+=i.troops.count*Bn[i.troops.unit].damage*1.3),r+=i.hp/60,r+=(((l=i.buffTroops)!=null?l:0)+((c=i.buffTowers)!=null?c:0)+((h=i.buffHero)!=null?h:0))*20,r+=((u=i.thorns)!=null?u:0)*1.5+((d=i.cleanBonus)!=null?d:0)*4,r};return e(t[0])>=e(t[1])?0:1}pickTarget(){var o,l,c,h,u;const t=this.g,e=t.cfg.endless?8:t.map.nights-t.night+1,n=new Set(t.plan.paths),i=this.defensePressure();let r=null,a=0;for(const d of t.buildings){const f=t.actionFor(d);if(!f||f.cost>t.coins)continue;const _=f.options[0],v=d.node;let p=0;const m=_.stats;if(yo.has(d.kind)||d.kind==="castle"){const T=((o=m.income)!=null?o:0)-((l=v==null?void 0:v.stats.income)!=null?l:0);p+=T*Math.max(0,e-1)*1.3}if(m.attack){const T=m.attack.damage*((c=m.attack.multishot)!=null?c:1)/m.attack.cooldown,y=v!=null&&v.stats.attack?v.stats.attack.damage*((h=v.stats.attack.multishot)!=null?h:1)/v.stats.attack.cooldown:0;p+=Math.max(0,T-y)*1.6*i*this.coverage(d,n,m.attack.range)}m.troops&&(p+=m.troops.count*4*i*this.coverage(d,n,10)),d.kind==="wall"&&(p+=(n.has(d.slot.path)?7:1.5)*i*this.o.skill+(1-this.o.skill)*3),d.kind==="forge"&&(p+=6*i),d.kind==="castle"&&(p+=4*i),p+=(m.hp-((u=v==null?void 0:v.stats.hp)!=null?u:0))/150;const b=p/f.cost+this.r()*this.o.noise;b>a&&(a=b,r=d)}return r&&a>.35?r:"night"}coverage(t,e,n){if(this.o.skill<.3)return 1;let i=1/0;for(const a of e)i=Math.min(i,this.g.paths[a].distanceTo(t.x,t.z));return(i<n?1:i<n+8?.55:.25)*this.o.skill+(1-this.o.skill)}defensePressure(){var i;const t=this.g;let e=8;for(const r of t.buildings){if(!r.node)continue;const a=r.node.stats.attack;a&&(e+=a.damage*((i=a.multishot)!=null?i:1)/a.cooldown),r.node.stats.troops&&(e+=r.node.stats.troops.count*5)}const n=t.plan.budget*2.2;return Math.max(.6,Math.min(3,n/e))}}class ed{constructor(){this.map=new Map}on(t,e){let n=this.map.get(t);return n||this.map.set(t,n=new Set),n.add(e),()=>n.delete(e)}emit(t,e){const n=this.map.get(t);if(n)for(const i of n)i(e)}clear(){this.map.clear()}}const Hr=Math.PI*2;function Vn(s,t,e){return s<t?t:s>e?e:s}function Ns(s,t,e){return s+(t-s)*e}function $e(s,t,e){const n=Vn((e-s)/(t-s),0,1);return n*n*(3-2*n)}function nd(s,t){return Math.hypot(s.x-t.x,s.z-t.z)}function Ic(s,t,e,n){const i=s-e,r=t-n;return i*i+r*r}function vs(s,t,e){let n=(t-s)%Hr;return n>Math.PI&&(n-=Hr),n<-Math.PI&&(n+=Hr),s+n*e}function id(s,t,e,n,i,r){const a=i-e,o=r-n,l=a*a+o*o;let c=l>0?((s-e)*a+(t-n)*o)/l:0;c=Vn(c,0,1);const h=e+a*c,u=n+o*c;return{t:c,d2:Ic(s,t,h,u),x:h,z:u}}function Uc(s,t,e,n,i,r,a,o){const l=e-s,c=n-t,h=a-i,u=o-r,d=l*u-c*h;if(Math.abs(d)<1e-9)return!1;const f=i-s,_=r-t,v=(f*u-_*h)/d,p=(f*c-_*l)/d;return v>=0&&v<=1&&p>=0&&p<=1}class qi{constructor(t){this.pts=t.map(([e,n])=>({x:e,z:n})),this.cum=[0];for(let e=1;e<this.pts.length;e++)this.cum.push(this.cum[e-1]+nd(this.pts[e-1],this.pts[e]));this.length=this.cum[this.cum.length-1]}sample(t,e){t=Vn(t,0,this.length);let n=1;for(;n<this.cum.length-1&&this.cum[n]<t;)n++;const i=this.pts[n-1],r=this.pts[n],a=this.cum[n]-this.cum[n-1]||1,o=(t-this.cum[n-1])/a;return e.x=i.x+(r.x-i.x)*o,e.z=i.z+(r.z-i.z)*o,e.tx=(r.x-i.x)/a,e.tz=(r.z-i.z)/a,e}project(t,e){let n={s:0,d2:1/0};for(let i=1;i<this.pts.length;i++){const r=this.pts[i-1],a=this.pts[i],o=id(t,e,r.x,r.z,a.x,a.z);o.d2<n.d2&&(n={s:this.cum[i-1]+o.t*(this.cum[i]-this.cum[i-1]),d2:o.d2})}return n}distanceTo(t,e){return Math.sqrt(this.project(t,e).d2)}}class Ms{constructor(t){this.s=t>>>0||2654435769}next(){let t=this.s=this.s+1831565813>>>0;return t=Math.imul(t^t>>>15,t|1),t^=t+Math.imul(t^t>>>7,t|61),((t^t>>>14)>>>0)/4294967296}range(t,e){return t+(e-t)*this.next()}int(t,e){return Math.floor(this.range(t,e+1))}pick(t){return t[Math.floor(this.next()*t.length)]}chance(t){return this.next()<t}weighted(t,e){let n=0;for(const r of t)n+=e(r);let i=this.next()*n;for(const r of t)if(i-=e(r),i<=0)return r;return t[t.length-1]}}function sd(s){let t=2166136261;for(let e=0;e<s.length;e++)t^=s.charCodeAt(e),t=Math.imul(t,16777619);return t>>>0}function yr(s){const t=new Uint8Array(512),e=new Ms(s),n=Array.from({length:256},(r,a)=>a);for(let r=255;r>0;r--){const a=Math.floor(e.next()*(r+1));[n[r],n[a]]=[n[a],n[r]]}for(let r=0;r<512;r++)t[r]=n[r&255];const i=(r,a)=>t[t[r&255]+a&511]/255;return(r,a)=>{const o=Math.floor(r),l=Math.floor(a),c=r-o,h=a-l,u=c*c*(3-2*c),d=h*h*(3-2*h),f=i(o,l),_=i(o+1,l),v=i(o,l+1),p=i(o+1,l+1);return(f+(_-f)*u+(v-f)*d+(f-_-v+p)*u*d)*2-1}}class hl{constructor(t=4){this.cellSize=t,this.cells=new Map,this.pool=[]}key(t,e){return t+512<<10|e+512}clear(){for(const t of this.cells.values())t.length=0,this.pool.push(t);this.cells.clear()}insert(t){var i;const e=this.key(Math.floor(t.x/this.cellSize),Math.floor(t.z/this.cellSize));let n=this.cells.get(e);n||(n=(i=this.pool.pop())!=null?i:[],this.cells.set(e,n)),n.push(t)}query(t,e,n,i){const r=this.cellSize,a=Math.floor((t-n)/r),o=Math.floor((t+n)/r),l=Math.floor((e-n)/r),c=Math.floor((e+n)/r),h=n*n;for(let u=a;u<=o;u++)for(let d=l;d<=c;d++){const f=this.cells.get(this.key(u,d));if(f)for(let _=0;_<f.length;_++){const v=f[_];if(!v.alive)continue;const p=v.x-t,m=v.z-e,b=p*p+m*m;if(b<=h&&i(v,b))return}}}nearest(t,e,n,i){let r=null,a=1/0;return this.query(t,e,n,(o,l)=>{l<a&&(!i||i(o))&&(a=l,r=o)}),r}}let Nc=1;class rd{constructor(){this.ent="u",this.id=Nc++,this.team=1,this.x=0,this.z=0,this.hp=1,this.maxHp=1,this.alive=!1,this.radius=.5,this.facing=0,this.moving=!1,this.speed=1,this.damage=1,this.path=0,this.s=0,this.lat=0,this.target=null,this.atkCd=0,this.think=0,this.slowT=0,this.slowAmt=0,this.burnT=0,this.burnDps=0,this.burnSrc=0,this.owner=null,this.holdX=0,this.holdZ=0,this.slotIdx=0,this.onHitBurn=0,this.attackT=9,this.hitT=9,this.age=0,this.summonT=0,this.bumpX=0,this.bumpZ=0}}class ad{constructor(t,e,n,i){this.slot=t,this.ent="b",this.id=Nc++,this.node=null,this.hp=0,this.maxHp=0,this.ruined=!1,this.atkCd=0,this.troops=[],this.wall=null,this.rallyX=0,this.rallyZ=0,this.builtT=99,this.hitT=9,this.attackT=9,this.lostThisNight=!1,this.kind=t.kind,this.x=e,this.z=n,this.radius=i}get built(){return this.node!==null}get alive(){return this.node!==null&&!this.ruined}}class od{constructor(t){this.weapon=t,this.ent="h",this.x=0,this.z=0,this.facing=0,this.hp=1,this.maxHp=1,this.alive=!0,this.deadT=0,this.atkCd=0,this.abilityCd=0,this.lastHurt=-99,this.radius=.7,this.moving=!1,this.speed=8,this.attackT=9,this.hitT=9,this.abilityT=9,this.kills=0,this.dashT=0,this.dashX=0,this.dashZ=0,this.dashHit=new Set}}class ld{constructor(){this.alive=!1,this.kind="arrow",this.team=0,this.x=0,this.z=0,this.sx=0,this.sz=0,this.tx=0,this.tz=0,this.h0=1,this.arc=1,this.target=null,this.speed=20,this.damage=0,this.splash=0,this.pierce=0,this.slow=0,this.burn=0,this.armorPierce=!1,this.bonusVsBig=1,this.bldMul=1,this.traveled=0,this.total=1,this.hits=[],this.dirX=0,this.dirZ=0,this.heal=0,this.fromHero=!1,this.delay=0}}function cd(s,t){const e=new Set(s),n=new Set(t);return{enemySpeed:n.has("swift")?1.25:1,enemyHp:n.has("tough")?1.4:1,incomeMul:n.has("poverty")?.7:1,castleHp:(n.has("fragile")?.6:1)*(e.has("guard")?1.5:1),noWalls:n.has("nowalls"),heroSpeed:e.has("swift")?1.15:1,heroHp:e.has("stout")?1.4:1,abilityCd:e.has("focus")?.7:1,towerCost:e.has("masons")?.8:1,wallHp:e.has("ramparts")?1.6:1,extraTroops:e.has("drill")?1:0,tithe:e.has("tithe")?1:0,startCoins:e.has("purse")?4:0,castleCd:e.has("guard")?.7:1,harvest:e.has("harvest"),dmgTroops:0,dmgTowers:0,dmgHero:0,hpTroops:0}}const hd=0,dl=.3;class dd{constructor(t){this.map=t,this.res=.5,this.ext=t.half+22,this.noise=yr(t.seed),this.noise2=yr(t.seed*7+3),this.paths=t.paths.map(e=>new qi(e)),this.rivers=t.terrain.rivers.map(e=>({line:new qi(e.pts),w:e.w})),this.n=Math.ceil(this.ext*2/this.res)+1,this.grid=new Float32Array(this.n*this.n);for(let e=0;e<this.n;e++)for(let n=0;n<this.n;n++)this.grid[e*this.n+n]=this.compute(-this.ext+n*this.res,-this.ext+e*this.res)}compute(t,e){const n=this.map.terrain,i=this.map.half;let r=this.noise(t*.06,e*.06)*n.noise+this.noise2(t*.17,e*.17)*n.noise*.12+dl;for(const[l,c,h,u]of n.hills){const d=(t-l)**2+(e-c)**2;r+=u*Math.exp(-d/(h*h)*1.6)*(.85+.15*this.noise2(t*.3,e*.3))}const a=Math.max(Math.abs(t),Math.abs(e));r+=n.edge*$e(i-3,i+12,a)*(.65+.35*this.noise(t*.11+9,e*.11));let o=0;for(const l of this.paths){const c=l.distanceTo(t,e);o=Math.max(o,1-$e(2.4,6,c))}for(const l of this.map.slots){if(l.x===void 0||l.z===void 0)continue;const c=_r[l.kind],h=Math.hypot(t-l.x,e-l.z);o=Math.max(o,1-$e(c+1.2,c+4,h))}o>0&&(r=r+(dl+this.noise2(t*.3,e*.3)*.05-r)*o);for(const[l,c,h]of n.ponds){const u=Math.hypot(t-l,e-c),d=$e(h-1.8,h+1.2,u);r=Math.min(r,-1.3+(r+1.3)*d)}for(const l of this.rivers){const c=l.line.distanceTo(t,e),h=$e(l.w/2-1.4,l.w/2+1.4,c);r=Math.min(r,-1.3+(r+1.3)*h)}return r}height(t,e){const n=Vn((t+this.ext)/this.res,0,this.n-1.001),i=Vn((e+this.ext)/this.res,0,this.n-1.001),r=Math.floor(n),a=Math.floor(i),o=n-r,l=i-a,c=this.grid,h=this.n,u=c[a*h+r],d=c[a*h+r+1],f=c[(a+1)*h+r],_=c[(a+1)*h+r+1];return u+(d-u)*o+(f-u)*l+(u-d-f+_)*o*l}onBridge(t,e){for(const n of this.map.bridges){const i=Math.cos(n.rot),r=Math.sin(n.rot),a=(t-n.x)*i-(e-n.z)*r,o=(t-n.x)*r+(e-n.z)*i;if(Math.abs(a)<n.len/2&&Math.abs(o)<1.8)return!0}return!1}walkable(t,e){const n=this.map.half-1;if(Math.abs(t)>n||Math.abs(e)>n)return!1;const i=this.height(t,e);return i<-.35?this.onBridge(t,e):i<2.6}}function ud(s,t,e){return t===s.nights?!0:e&&t>s.nights&&(t-s.nights)%5===0}function ul(s,t){const{base:e,growth:n,pow:i}=s.budget,r=Math.min(t,s.nights);let a=e*Math.pow(1+n*(r-1),i);return t>s.nights&&(a*=Math.pow(1.11,t-s.nights)),Math.round(a)}function fd(s,t){return t<=s.nights?s.schedule[t-1]:s.paths.map((e,n)=>n)}function pd(s,t,e,n=!1){var v;const i=new Ms(sd(`${s.id}:${t}:${e}`)),r=fd(s,t);let a=ul(s,t);const o=ud(s,t,n)?s.boss:null,l=[],c=s.roster.filter(p=>p.from<=t),h=c.filter(p=>p.from===t).map(p=>p.unit);o&&(l.push({unit:o,count:1,path:r[0],delay:14,interval:1}),a=Math.max(a*.55,6));const u=r.map(()=>i.range(.85,1.15)),d=u.reduce((p,m)=>p+m,0);r.forEach((p,m)=>{let b=Math.round(a*u[m]/d),T=i.range(0,3)+m*1.5;const y=h.length?h[m%h.length]:null;let E=!0;for(;b>0;){let w;if(E&&y&&Bn[y].threat<=b)w=y;else{const C=c.filter(P=>Bn[P.unit].threat<=b&&(Bn[P.unit].threat<=3||b>=Bn[P.unit].threat*2));if(!C.length)break;w=i.weighted(C,P=>P.weight).unit}E=!1;const R=Bn[w].threat,x=Math.max(1,Math.floor(b/R)),S=R>=5?1:Math.min(x,i.int(3,7));l.push({unit:w,count:S,path:p,delay:T,interval:Bn[w].speed>4?.35:.6}),b-=S*R,T+=S*.6+i.range(2.5,6)}});const f=new Map;for(const p of l){let m=f.get(p.path);m||f.set(p.path,m=new Map),m.set(p.unit,((v=m.get(p.unit))!=null?v:0)+p.count)}const _=t>s.nights?1+.05*(t-s.nights):1;return{night:t,groups:l,paths:r,boss:o,budget:ul(s,t),preview:f,hpMul:_}}function md(s){const t=[];for(const e of s.groups)for(let n=0;n<e.count;n++)t.push({t:e.delay+n*e.interval,unit:e.unit,path:e.path});return t.sort((e,n)=>e.t-n.t),t}function En(s){return s.ent==="b",s.alive}function ke(s,t,e,n){var i,r;if(!(!En(t)||e<=0))if(t.ent==="u"){let a=e;if(n.ranged&&!n.armorPierce&&t.def.armor&&(a*=1-t.def.armor),n.bonusVsBig&&t.def.big&&(a*=n.bonusVsBig),t.hp-=a,n.silent||(t.hitT=0,s.events.emit("hit",{e:t,dmg:a})),n.burn&&(t.burnDps=t.burnT>0?Math.max(t.burnDps,n.burn):n.burn,t.burnT=3),n.slow&&(t.slowAmt=t.slowT>0?Math.max(t.slowAmt,n.slow):n.slow,t.slowT=2.2),!n.silent&&n.src&&n.src!=="hero"&&n.src.ent==="u"&&!t.def.big){const o=t.x-n.src.x,l=t.z-n.src.z,c=Math.hypot(o,l)||1;t.x+=o/c*.08,t.z+=l/c*.08}t.hp<=0&&gd(s,t,n.src)}else if(t.ent==="b"){const a=e*((i=n.bldMul)!=null?i:1);t.hp-=a,t.hitT=0,n.silent||s.events.emit("hit",{e:t,dmg:a});const o=(r=t.node)==null?void 0:r.stats.thorns;o&&n.src&&n.src!=="hero"&&n.src.ent==="u"&&!n.ranged&&ke(s,n.src,o,{src:t}),t.hp<=0&&(t.hp=0,t.ruined=!0,t.lostThisNight=!0,s.stats.lost++,s.recomputeAuras(),s.events.emit("bdestroyed",{b:t}))}else{const a=t;a.hp-=e,a.hitT=0,a.lastHurt=s.time,n.silent||s.events.emit("hit",{e:t,dmg:e}),a.hp<=0&&(a.hp=0,a.alive=!1,a.deadT=me.hero.respawn,a.dashT=0,s.events.emit("heroDeath",{}))}}function gd(s,t,e){if(t.alive=!1,t.hp=0,t.team===1)s.stats.kills++,e==="hero"&&(s.stats.heroKills++,s.hero.kills++),t.def.boss&&s.stats.bossKills++;else if(t.owner){const n=t.owner.troops.indexOf(t);n>=0&&t.owner.troops.splice(n,1)}s.events.emit("death",{u:t})}function _d(s,t){var e,n,i;return 1+s.mods.dmgTroops+((i=(n=(e=t.owner)==null?void 0:e.node)==null?void 0:n.stats.buffTroops)!=null?i:0)}function Fc(s,t,e){var o,l,c,h;const n=t.def;t.atkCd=n.cooldown*(.9+Math.random()*.2),t.attackT=0;const i=t.team===0?_d(s,t):1,r=t.damage*i;if(n.ranged){const u=ys(s,n.ranged,t.team,t.x,t.z,e,r,n.big?2.4:1.1);u.bonusVsBig=(o=n.bonusVsBig)!=null?o:1,u.bldMul=(l=n.bldMul)!=null?l:1,u.splash=(c=n.splash)!=null?c:0,u.burn=t.onHitBurn,u.armorPierce=n.id==="crossbowman";return}if(n.targets==="buildings"&&e.ent!=="b")return;const a={src:t,bonusVsBig:n.bonusVsBig,bldMul:(h=n.bldMul)!=null?h:1,burn:t.onHitBurn||void 0};if(n.splash){const u=n.splash;(t.team===1?s.allyGrid:s.enemyGrid).query(e.x,e.z,u,f=>{f!==e&&ke(s,f,r*.6,a)}),t.team===1&&s.hero.alive&&e!==s.hero&&Math.hypot(s.hero.x-e.x,s.hero.z-e.z)<u&&ke(s,s.hero,r*.6,a)}ke(s,e,r,a),s.events.emit("melee",{x:e.x,z:e.z,team:t.team})}function ys(s,t,e,n,i,r,a,o,l,c){const h=s.allocProjectile();return h.kind=t,h.team=e,h.x=h.sx=n,h.z=h.sz=i,h.target=r,h.tx=r?r.x:l!=null?l:n,h.tz=r?r.z:c!=null?c:i,h.damage=a,h.h0=o,h.speed=xd[t],h.arc=vd[t],h.total=Math.max(.5,Math.hypot(h.tx-n,h.tz-i)),s.events.emit("shoot",{p:h}),h}const xd={arrow:24,bolt:30,orb:14,frost:15,fire:13,dart:18,hex:11,rock:12,star:18},vd={arrow:.18,bolt:.04,orb:.08,frost:.08,fire:.2,dart:.15,hex:.1,rock:.35,star:.05};function Md(s,t,e){var c,h,u,d,f;const n=(c=e.multishot)!=null?c:1,r=1+(t.kind==="tower"||t.kind==="magic"||t.kind==="mine"?s.mods.dmgTowers:t.kind==="castle"?s.mods.dmgTowers*.5:0),a=[],o=e.range;if(s.enemyGrid.query(t.x,t.z,o,_=>{a.push(_)}),!a.length)return;a.sort((_,v)=>(_.x-t.x)**2+(_.z-t.z)**2-((v.x-t.x)**2+(v.z-t.z)**2));const l=t.kind==="castle"?6.5:t.kind==="mine"?2.5:4.4;for(let _=0;_<n;_++){const v=a[_%a.length],p=ys(s,e.projectile,0,t.x,t.z,v,e.damage*r,l);if(p.splash=(h=e.splash)!=null?h:0,p.pierce=(u=e.pierce)!=null?u:0,p.slow=(d=e.slow)!=null?d:0,p.burn=(f=e.burn)!=null?f:0,p.armorPierce=!!e.armorPierce,p.pierce){const m=Math.hypot(v.x-t.x,v.z-t.z)||1;p.dirX=(v.x-t.x)/m,p.dirZ=(v.z-t.z)/m,p.total=o+2,p.target=null}_<n-1&&a.length===1&&(p.delay=_*.12)}t.attackT=0}function yd(s,t){if(s.phase==="night"||s.phase==="defeat")for(const n of s.buildings){if(!n.alive)continue;const i=n.node.stats.attack;if(i&&(n.atkCd-=t,n.atkCd<=0&&s.enemiesAlive>0)){const r=s.projectiles.length;Md(s,n,i),s.projectiles.length>r?n.atkCd=i.cooldown*(n.kind==="castle"?s.mods.castleCd:1):n.atkCd=.2}}for(const n of s.projectiles)if(n.alive){if(n.delay>0){n.delay-=t;continue}bd(s,n,t)}}function bd(s,t,e){const n=t.speed*e;if(t.pierce){t.x+=t.dirX*n,t.z+=t.dirZ*n,t.tx=t.x+t.dirX,t.tz=t.z+t.dirZ,t.traveled+=n,s.enemyGrid.query(t.x,t.z,.9,o=>{if(!t.hits.includes(o.id)&&(t.hits.push(o.id),ke(s,o,t.damage,{src:null,ranged:!0,armorPierce:t.armorPierce}),t.hits.length>=t.pierce))return t.alive=!1,!0}),t.traveled>=t.total&&(t.alive=!1);return}t.target&&En(t.target)&&(t.tx=t.target.x,t.tz=t.target.z);const i=t.tx-t.x,r=t.tz-t.z,a=Math.hypot(i,r);if(t.traveled+=n,a<=n+.15){t.x=t.tx,t.z=t.tz,Sd(s,t),t.alive=!1;return}t.x+=i/a*n,t.z+=r/a*n,t.total=Math.max(t.total,t.traveled+a)}function Sd(s,t){const n={src:t.fromHero?"hero":null,ranged:!0,armorPierce:t.armorPierce,bonusVsBig:t.bonusVsBig,bldMul:t.bldMul,burn:t.burn||void 0,slow:t.slow||void 0};if(t.heal&&kc(s,t.x,t.z,1.6,t.heal),t.splash>0)if(t.team===0)s.enemyGrid.query(t.x,t.z,t.splash,i=>{ke(s,i,t.damage,n)});else{s.allyGrid.query(t.x,t.z,t.splash,i=>{ke(s,i,t.damage*.7,n)}),s.hero.alive&&Math.hypot(s.hero.x-t.x,s.hero.z-t.z)<t.splash&&ke(s,s.hero,t.damage*.7,n);for(const i of s.buildings)i.alive&&Math.hypot(i.x-t.x,i.z-t.z)<t.splash+i.radius&&ke(s,i,t.damage,n)}else t.target&&En(t.target)&&ke(s,t.target,t.damage,n);s.events.emit("impact",{x:t.x,z:t.z,kind:t.kind,splash:t.splash})}function kc(s,t,e,n,i){for(const a of s.units)a.alive&&a.team===0&&Math.hypot(a.x-t,a.z-e)<n&&(a.hp=Math.min(a.maxHp,a.hp+a.maxHp*i));for(const a of s.buildings)a.alive&&Math.hypot(a.x-t,a.z-e)<n+a.radius&&(a.hp=Math.min(a.maxHp,a.hp+a.maxHp*i));const r=s.hero;r.alive&&Math.hypot(r.x-t,r.z-e)<n&&(r.hp=Math.min(r.maxHp,r.hp+r.maxHp*i))}function wd(s,t){var c;const e=s.hero;if(e.attackT+=t,e.hitT+=t,e.abilityT+=t,e.abilityCd=Math.max(0,e.abilityCd-t),!e.alive){e.deadT-=t,e.deadT<=0&&s.respawnHero(),s.input.ability=!1;return}const n=s.input;let i=n.moveX,r=n.moveZ;const a=Math.hypot(i,r);a>1&&(i/=a,r/=a);let o=e.speed;if(e.dashT>0&&(e.dashT-=t,i=e.dashX,r=e.dashZ,o=26,s.enemyGrid.query(e.x,e.z,e.weapon.abilityRadius,h=>{e.dashHit.has(h.id)||(e.dashHit.add(h.id),ke(s,h,e.weapon.abilityDamage*(1+s.mods.dmgHero),{src:"hero"}),h.alive&&!h.def.big&&(h.x+=e.dashX*1.2,h.z+=e.dashZ*1.2))})),e.moving=Math.hypot(i,r)>.05,e.moving){const h=o*t,u=e.x+i*h,d=e.z+r*h;s.hf.walkable(u,d)?(e.x=u,e.z=d):s.hf.walkable(u,e.z)?e.x=u:s.hf.walkable(e.x,d)&&(e.z=d),Ed(s,e),e.facing=vs(e.facing,Math.atan2(i,r),Math.min(1,t*12))}s.time-e.lastHurt>me.hero.regenDelay&&(e.hp=Math.min(e.maxHp,e.hp+me.hero.regen*t)),e.atkCd-=t;const l=e.weapon;if(e.atkCd<=0&&s.enemiesAlive>0){const h=s.enemyGrid.nearest(e.x,e.z,l.range+1.2);if(h&&Math.hypot(h.x-e.x,h.z-e.z)-h.radius<=l.range){e.atkCd=l.cooldown,e.attackT=0,e.moving||(e.facing=Math.atan2(h.x-e.x,h.z-e.z));const u=l.damage*(1+s.mods.dmgHero);if(l.projectile){const d=ys(s,l.projectile,0,e.x,e.z,h,u,2.2);d.splash=(c=l.splash)!=null?c:0,d.fromHero=!0}else{ke(s,h,u,{src:"hero"});let d=l.cleave;d>0&&s.enemyGrid.query(h.x,h.z,1.8,f=>{f===h||d<=0||(d--,ke(s,f,u*.6,{src:"hero"}))}),s.events.emit("melee",{x:h.x,z:h.z,team:0})}}}n.ability&&(n.ability=!1,e.abilityCd<=0&&Td(s))}function Ed(s,t){for(const e of s.buildings){if(!e.alive||e.wall)continue;const n=e.radius+t.radius*.8,i=t.x-e.x,r=t.z-e.z,a=i*i+r*r;if(a>=n*n)continue;const o=Math.sqrt(a)||.01,l=e.x+i/o*n,c=e.z+r/o*n;s.hf.walkable(l,c)&&(t.x=l,t.z=c)}}function Td(s){const t=s.hero,e=t.weapon;t.abilityCd=e.abilityCd*s.mods.abilityCd,t.abilityT=0,s.stats.abilityUses++;const n=e.abilityDamage*(1+s.mods.dmgHero);switch(e.ability){case"whirl":s.enemyGrid.query(t.x,t.z,e.abilityRadius,i=>{if(ke(s,i,n,{src:"hero"}),i.alive&&!i.def.big){const r=i.x-t.x,a=i.z-t.z,o=Math.hypot(r,a)||1;i.x+=r/o*1.4,i.z+=a/o*1.4}}),s.events.emit("ability",{kind:"whirl",x:t.x,z:t.z,r:e.abilityRadius});break;case"volley":{const i=s.enemyGrid.nearest(t.x,t.z,16),r=i?i.x:t.x+Math.sin(t.facing)*6,a=i?i.z:t.z+Math.cos(t.facing)*6;for(let o=0;o<12;o++){const l=Math.random()*Math.PI*2,c=Math.sqrt(Math.random())*e.abilityRadius,h=ys(s,"arrow",0,t.x,t.z,null,n,2.2,r+Math.cos(l)*c,a+Math.sin(l)*c);h.splash=1.5,h.arc=.5,h.speed=20,h.delay=o*.04,h.fromHero=!0}s.events.emit("ability",{kind:"volley",x:r,z:a,r:e.abilityRadius});break}case"charge":{let i=s.input.moveX,r=s.input.moveZ;if(Math.hypot(i,r)<.1){const l=s.enemyGrid.nearest(t.x,t.z,12);l?(i=l.x-t.x,r=l.z-t.z):(i=Math.sin(t.facing),r=Math.cos(t.facing))}const o=Math.hypot(i,r)||1;t.dashX=i/o,t.dashZ=r/o,t.dashT=.3,t.dashHit.clear(),t.facing=Math.atan2(t.dashX,t.dashZ),s.events.emit("ability",{kind:"charge",x:t.x,z:t.z,r:e.abilityRadius});break}case"starfall":{const i=[];s.enemyGrid.query(t.x,t.z,e.abilityRadius,r=>{i.push(r)});for(let r=0;r<10;r++){const a=i.length?i[r%i.length]:null,o=Math.random()*Math.PI*2,l=Math.random()*e.abilityRadius,c=ys(s,"star",0,t.x+Math.cos(o)*2,t.z+Math.sin(o)*2,a,n,9,t.x+Math.cos(o)*l,t.z+Math.sin(o)*l);c.splash=1.6,c.delay=r*.07,c.fromHero=!0,c.arc=0}kc(s,t.x,t.z,e.abilityRadius,.3),s.events.emit("ability",{kind:"starfall",x:t.x,z:t.z,r:e.abilityRadius});break}}}const li={x:0,z:0,tx:0,tz:0};function Ad(s,t){s.enemyGrid.clear(),s.allyGrid.clear();for(const e of s.units)e.alive&&(e.team===1?s.enemyGrid:s.allyGrid).insert(e);for(let e=0;e<s.units.length;e++){const n=s.units[e];n.alive&&(n.age+=t,n.attackT+=t,n.hitT+=t,n.atkCd-=t,n.think-=t,!(n.burnT>0&&(n.burnT-=t,ke(s,n,n.burnDps*t,{silent:!0,src:null}),!n.alive))&&(n.slowT>0&&(n.slowT-=t),n.team===1?Rd(s,n,t):Pd(s,n,t)))}Dd(s,t)}function Vr(s,t,e,n,i){let r=null,a=1/0;for(const o of s.buildings){if(!o.alive||i&&!i(o))continue;let l;o.wall?l=Bc(t,e,o.wall.ax,o.wall.az,o.wall.bx,o.wall.bz):l=Math.hypot(o.x-t,o.z-e)-o.radius,l<n&&l<a&&(a=l,r=o)}return r}function Bc(s,t,e,n,i,r){const a=i-e,o=r-n,l=a*a+o*o;let c=l?((s-e)*a+(t-n)*o)/l:0;return c=Math.max(0,Math.min(1,c)),Math.hypot(s-(e+a*c),t-(n+o*c))}function Yi(s,t){return t.ent==="b"&&t.wall?Bc(s.x,s.z,t.wall.ax,t.wall.az,t.wall.bx,t.wall.bz)-s.radius-.4:Math.hypot(t.x-s.x,t.z-s.z)-s.radius-t.radius}function Cd(s,t){var o;const e=t.def,n=t.target;if(e.targets==="buildings")return n&&En(n)&&Yi(t,n)<4?n:Vr(s,t.x,t.z,3.5+t.radius);if(e.targets==="economy"){if(n&&En(n)&&n.ent==="b")return n;const l=Vr(s,t.x,t.z,70,c=>yo.has(c.kind));if(l)return l}const i=e.ranged?e.range+1:(o=e.aggro)!=null?o:4.2;if(n&&En(n)&&n.ent!=="b"&&Yi(t,n)<i+1.5)return n;let r=s.allyGrid.nearest(t.x,t.z,i+.5);const a=s.hero;if(a.alive){const l=Math.hypot(a.x-t.x,a.z-t.z);l<i&&(!r||l<Math.hypot(r.x-t.x,r.z-t.z))&&(r=a)}return r||(n&&En(n)&&n.ent==="b"&&Yi(t,n)<3?n:Vr(s,t.x,t.z,(e.ranged?e.range:2.2)+t.radius))}function Rd(s,t,e){var d;const n=t.def,i=t.speed*(t.slowT>0?1-t.slowAmt:1);if(n.summon&&s.phase==="night"&&(t.summonT-=e,t.summonT<=0)){t.summonT=n.summon.every;for(let f=0;f<n.summon.count;f++){const _=s.spawnEnemy(n.summon.unit,t.path,Math.max(0,t.s-1.5));_.x=t.x+s.rng.range(-2,2),_.z=t.z+s.rng.range(-2,2)}}let r=t.target;if(r&&!En(r)&&(r=t.target=null),t.think<=0){t.think=.25+Math.random()*.15;const f=r;r=t.target=(d=Cd(s,t))!=null?d:f&&f.ent==="b"&&En(f)?f:null,!r&&t.s>=s.paths[t.path].length-.5&&(r=t.target=s.castle)}if(r){const f=(n.ranged,n.range);if(Yi(t,r)<=f){t.facing=vs(t.facing,Math.atan2(r.x-t.x,r.z-t.z),Math.min(1,e*10)),t.moving=!1,t.atkCd<=0&&Fc(s,t,r);return}br(s,t,r.x,r.z,i,e),t.s=Math.max(t.s,s.paths[t.path].project(t.x,t.z).s-.5);return}const a=s.paths[t.path];if(t.s>=a.length){t.target=s.castle;return}a.sample(Math.min(a.length,t.s+1.6),li);const o=t.lat*Math.min(1,(a.length-t.s)/6),l=li.x-li.tz*o,c=li.z+li.tx*o,h=t.x,u=t.z;if(br(s,t,l,c,i,e)){const f=(t.x-h)*li.tx+(t.z-u)*li.tz;t.s+=Math.max(f,0),Math.hypot(l-t.x,c-t.z)<.6&&(t.s+=i*e*.5)}}function Pd(s,t,e){var h;const n=t.def;let i=t.holdX,r=t.holdZ;const a=s.rallyFollow&&s.hero.alive;if(a){const u=Ca(t.slotIdx+(t.owner?t.owner.id%5*3:0)),d=2.2;i=s.hero.x-Math.sin(s.hero.facing)*d+u.x*1.3,r=s.hero.z-Math.cos(s.hero.facing)*d+u.z*1.3}const o=(h=n.aggro)!=null?h:6;let l=t.target;if(l&&!En(l)&&(l=t.target=null),t.think<=0){t.think=.2+Math.random()*.15;const u=a?7:o+2.5;l&&(Math.hypot(l.x-i,l.z-r)>u+2||Yi(t,l)>o+2)&&(l=null),l||(l=s.enemyGrid.nearest(t.x,t.z,o,d=>Math.hypot(d.x-i,d.z-r)<u)),t.target=l}if(l){if(Yi(t,l)<=n.range){t.facing=vs(t.facing,Math.atan2(l.x-t.x,l.z-t.z),Math.min(1,e*10)),t.moving=!1,t.atkCd<=0&&Fc(s,t,l);return}br(s,t,l.x,l.z,t.speed*(t.slowT>0?1-t.slowAmt:1),e);return}const c=Math.hypot(i-t.x,r-t.z);if(c>.35){const u=a?c>4?2.4:1.6:c>6?1.6:1;br(s,t,i,r,t.speed*u,e)}else t.moving=!1,a&&(t.facing=vs(t.facing,s.hero.facing,Math.min(1,e*4)))}function br(s,t,e,n,i,r){const a=e-t.x,o=n-t.z,l=Math.hypot(a,o);if(l<1e-4)return t.moving=!1,!1;const c=Math.min(i*r,l),h=t.x+a/l*c,u=t.z+o/l*c;if(t.team===1&&!t.def.flying)for(const d of s.walls){const f=d.wall;if(d.alive&&Uc(t.x,t.z,h,u,f.ax,f.az,f.bx,f.bz))return t.target=d,t.moving=!1,!1}return t.x=h,t.z=u,t.facing=vs(t.facing,Math.atan2(a,o),Math.min(1,r*8)),t.moving=!0,!0}function Ld(s,t,e,n,i){for(const r of s.walls){const a=r.wall;if(r.alive&&Uc(t,e,n,i,a.ax,a.az,a.bx,a.bz))return!0}return!1}function Dd(s,t){const e=Math.min(1,t*8);for(const n of s.units){if(!n.alive||n.def.flying)continue;let i=0,r=0;const a=n.radius,o=h=>{if(h===n||h.def.flying)return;const u=n.x-h.x,d=n.z-h.z,f=a+h.radius,_=u*u+d*d;if(_>=f*f)return;const v=Math.sqrt(_)||.01,p=(f-v)/v,m=h.def.big&&!n.def.big?.9:.5;i+=u*p*m,r+=d*p*m,_<1e-6&&(i+=n.id%7*.01-.03,r+=n.id%5*.01-.02)};s.enemyGrid.query(n.x,n.z,a+2,o),s.allyGrid.query(n.x,n.z,a+2,o);for(const h of s.buildings){if(!h.alive||h.wall)continue;const u=n.x-h.x,d=n.z-h.z,f=h.radius+a,_=u*u+d*d;if(_<f*f){const v=Math.sqrt(_)||.01;i+=u/v*(f-v),r+=d/v*(f-v)}}if(i===0&&r===0)continue;const l=n.x+i*e,c=n.z+r*e;n.team===1&&Ld(s,n.x,n.z,l,c)||(n.x=l,n.z=c)}}const fl=()=>({kills:0,heroKills:0,lost:0,built:0,cleanStreak:0,bestClean:0,maxIncome:0,abilityUses:0,bossKills:0,maxArmy:0,maxCoins:0,fullUpgrades:0,castleMinHp:1});class pl{constructor(t){var n,i;this.cfg=t,this.events=new ed,this.buildings=[],this.bySlot=new Map,this.walls=[],this.units=[],this.projectiles=[],this.enemyGrid=new hl(4),this.allyGrid=new hl(4),this.unitPool=[],this.projPool=[],this.phase="day",this.phaseTime=0,this.time=0,this.night=1,this.coins=0,this.holdCoins=0,this.hold=null,this.holdLock=!1,this.choice=null,this.spawnQueue=[],this.nightTime=0,this.rallyFollow=!1,this.secondChanceUsed=!1,this.stats=fl(),this.lastIncome=null,this.input={moveX:0,moveZ:0,hold:!1,ability:!1,rally:!1,startNight:!1},this.timeScale=1,this.paused=!1,this.enemiesAlive=0,this.bossUnit=null,this.map=Dc[t.map],this.rng=new Ms(t.seed),this.hf=new dd(this.map),this.paths=this.map.paths.map(r=>new qi(r)),this.mods=cd(t.perks,t.mutators),this.hero=new od(Mr[t.weapon]);for(const r of this.map.slots){let a=(n=r.x)!=null?n:0,o=(i=r.z)!=null?i:0,l=null;if(r.kind==="wall"){const h=this.paths[r.path],u=h.sample(h.length*r.at,{x:0,z:0,tx:0,tz:0});a=u.x,o=u.z;const d=-u.tz,f=u.tx,_=3.2;l={ax:a-d*_,az:o-f*_,bx:a+d*_,bz:o+f*_,rot:Math.atan2(u.tx,u.tz)}}const c=new ad(r,a,o,_r[r.kind]);c.wall=l,this.setDefaultRally(c),this.buildings.push(c),this.bySlot.set(r.id,c),l&&this.walls.push(c)}this.castle=this.bySlot.get("castle"),this.applyNode(this.castle,gi.castle,!1),this.coins=this.map.startCoins+this.mods.startCoins;const e=t.snapshot;if(e){this.night=e.night,this.coins=e.coins,this.stats={...fl(),...e.stats},this.secondChanceUsed=e.secondChanceUsed;for(const[r,a]of Object.entries(e.nodes)){const o=this.bySlot.get(r),l=gi[a];o&&l&&l.kind===o.kind&&this.applyNode(o,l,!1,!0)}}this.hero.maxHp=Math.round(me.hero.hp*this.mods.heroHp),this.hero.hp=this.hero.maxHp,this.hero.speed=me.hero.speed*this.mods.heroSpeed,this.hero.radius=me.hero.radius,this.placeHeroAtCastle(),this.plan=this.makePlan(),this.recomputeAuras()}makePlan(){return pd(this.map,this.night,this.cfg.seed,this.cfg.endless)}get totalNights(){return this.cfg.endless?1/0:this.map.nights}get nightsSurvived(){return this.phase==="victory"?this.map.nights:this.night-1}heightAt(t,e){return this.hf.height(t,e)}placeHeroAtCastle(){this.hero.x=3.2,this.hero.z=5.2,this.hero.facing=0}setDefaultRally(t){let e={d2:1/0,x:t.x,z:t.z};for(const r of this.paths){const a=r.project(t.x,t.z);if(a.d2<e.d2){const o=r.sample(a.s,{x:0,z:0,tx:0,tz:0});e={d2:a.d2,x:o.x,z:o.z}}}const n=Math.sqrt(e.d2)||1,i=Math.min(1,(t.radius+1.6)/n);t.rallyX=t.x+(e.x-t.x)*i,t.rallyZ=t.z+(e.z-t.z)*i}nodeCost(t){let e=t.cost;return(t.kind==="tower"||t.kind==="magic")&&(e=Math.max(1,Math.round(e*this.mods.towerCost))),e}actionFor(t){if(t.kind==="wall"&&this.mods.noWalls)return null;if(!t.node){const n=gi[t.kind];return{cost:this.nodeCost(n),options:[n]}}if(t.ruined||!t.node.next.length)return null;const e=t.node.next.map(n=>gi[n]);return{cost:Math.max(...e.map(n=>this.nodeCost(n))),options:e}}activeSlot(){if(this.phase!=="day"||!this.hero.alive||this.choice)return null;let t=null,e=1/0;for(const n of this.buildings){const i=n.radius+me.hero.buildRadius,r=Ic(n.x,n.z,this.hero.x,this.hero.z);r>i*i||r>=e||this.actionFor(n)&&(e=r,t=n)}return t}applyNode(t,e,n=!0,i=!1){const r=t.node!==null;t.node=e,t.ruined=!1;let a=e.stats.hp;t.kind==="wall"&&(a*=this.mods.wallHp),t.kind==="castle"&&(a*=this.mods.castleHp),t.maxHp=Math.round(a),t.hp=t.maxHp,t.builtT=i?99:0,this.syncTroops(t,!0),this.recomputeAuras(),e.tier===2&&!i&&this.stats.fullUpgrades++,n&&(this.stats.built++,this.events.emit("built",{b:t,upgrade:r}))}recomputeAuras(){var e,n,i,r;const t=this.mods;t.dmgTroops=0,t.dmgTowers=0,t.dmgHero=0,t.hpTroops=0;for(const a of this.buildings){if(!a.alive||a.kind!=="forge")continue;const o=a.node.stats;t.dmgTroops+=(e=o.buffTroops)!=null?e:0,t.dmgTowers+=(n=o.buffTowers)!=null?n:0,t.dmgHero+=(i=o.buffHero)!=null?i:0,t.hpTroops+=(r=o.hpTroops)!=null?r:0}}syncTroops(t,e){var o;const n=(o=t.node)==null?void 0:o.stats.troops;if(!n)return;const i=Bn[n.unit],r=n.count+this.mods.extraTroops;if(e)for(const l of t.troops)l.def.id!==i.id&&(l.alive=!1,l.hp=0);t.troops=t.troops.filter(l=>l.alive);for(const l of t.troops)this.initAlly(l,i,t,l.slotIdx,!1);const a=new Set(t.troops.map(l=>l.slotIdx));for(let l=0;t.troops.length<r&&l<12;l++){if(a.has(l))continue;const c=this.allocUnit();this.initAlly(c,i,t,l,!0),t.troops.push(c),this.units.push(c),a.add(l)}this.stats.maxArmy=Math.max(this.stats.maxArmy,this.armySize())}armySize(){let t=0;for(const e of this.units)e.alive&&e.team===0&&t++;return t}initAlly(t,e,n,i,r){var l,c,h,u;const a=1+this.mods.hpTroops+((c=(l=n.node)==null?void 0:l.stats.hpTroops)!=null?c:0);if(t.def=e,t.team=0,t.owner=n,t.slotIdx=i,t.radius=e.radius,t.maxHp=Math.round(e.hp*a),t.speed=e.speed,t.damage=e.damage,t.onHitBurn=(u=(h=n.node)==null?void 0:h.stats.troopBurn)!=null?u:0,r){t.alive=!0,t.hp=t.maxHp;const d=i/6*Math.PI*2;t.x=n.x+Math.cos(d)*(n.radius+.6),t.z=n.z+Math.sin(d)*(n.radius+.6),t.target=null,t.atkCd=0,t.think=Math.random()*.3,t.slowT=0,t.burnT=0,t.age=0}else t.hp=Math.min(t.maxHp,Math.max(t.hp,t.maxHp));const o=Ca(i);t.holdX=n.rallyX+o.x,t.holdZ=n.rallyZ+o.z}allocUnit(){var e;const t=(e=this.unitPool.pop())!=null?e:new rd;return t.alive=!0,t.target=null,t.owner=null,t.attackT=9,t.hitT=9,t.age=0,t.summonT=0,t.slowT=0,t.burnT=0,t.bumpX=0,t.bumpZ=0,t}allocProjectile(){var e;const t=(e=this.projPool.pop())!=null?e:new ld;return t.alive=!0,t.hits.length=0,t.target=null,t.splash=0,t.pierce=0,t.slow=0,t.burn=0,t.armorPierce=!1,t.bonusVsBig=1,t.bldMul=1,t.traveled=0,t.heal=0,t.fromHero=!1,t.delay=0,t.arc=1,t.h0=1,this.projectiles.push(t),t}spawnEnemy(t,e,n=0,i){const r=Bn[t],a=this.allocUnit();a.def=r,a.team=1,a.path=e,a.s=n,a.lat=i!=null?i:this.rng.range(-1.4,1.4)*(r.big?.4:1);const o=this.paths[e].sample(n,{x:0,z:0,tx:0,tz:0});return a.x=o.x-o.tz*a.lat,a.z=o.z+o.tx*a.lat,a.facing=Math.atan2(o.tx,o.tz),a.maxHp=Math.round(r.hp*this.mods.enemyHp*this.plan.hpMul),a.hp=a.maxHp,a.speed=r.speed*this.mods.enemySpeed,a.damage=r.damage,a.radius=r.radius,a.think=this.rng.range(0,.3),a.atkCd=this.rng.range(0,.5),a.summonT=r.summon?r.summon.every*.6:0,this.units.push(a),this.events.emit("spawn",{u:a}),r.boss&&(this.bossUnit=a,this.events.emit("bossSpawn",{u:a})),a}setPhase(t){this.phase=t,this.phaseTime=0,this.events.emit("phase",{phase:t,night:this.night})}canStartNight(){return this.phase==="day"&&!this.choice}startNight(){if(this.canStartNight()){this.cancelHold(),this.plan=this.makePlan(),this.spawnQueue=md(this.plan),this.nightTime=-2.2;for(const t of this.buildings)t.lostThisNight=!1;this.setPhase("night"),this.events.emit("nightStart",{night:this.night})}}endNight(){var r,a;const t=[];let e=!0;for(const o of this.buildings)o.lostThisNight&&(e=!1);let n=0;for(const o of this.buildings){if(!o.alive)continue;let l=(r=o.node.stats.income)!=null?r:0;this.mods.harvest&&yo.has(o.kind)&&this.night>=4&&(l+=1),l>0&&(l=Math.max(1,Math.floor(l*this.mods.incomeMul)),t.push({b:o,n:l}),n+=l)}let i=this.mods.tithe;if(e){i+=me.economy.cleanBonus;for(const o of this.buildings)o.alive&&(i+=(a=o.node.stats.cleanBonus)!=null?a:0);this.stats.cleanStreak++,this.stats.bestClean=Math.max(this.stats.bestClean,this.stats.cleanStreak)}else this.stats.cleanStreak=0;n+=i,this.coins+=n,this.stats.maxIncome=Math.max(this.stats.maxIncome,n),this.stats.maxCoins=Math.max(this.stats.maxCoins,this.coins),this.lastIncome={total:n,clean:e},this.events.emit("income",{total:n,parts:t,clean:e,bonus:i}),this.repairAll(),this.setPhase("dawn")}repairAll(){for(const t of this.buildings)if(t.node){t.ruined&&(t.ruined=!1,t.builtT=0,this.events.emit("repaired",{b:t})),t.hp=t.maxHp,this.syncTroops(t,!1);for(const e of t.troops)e.hp=e.maxHp}this.recomputeAuras(),this.hero.alive||this.respawnHero(),this.hero.hp=this.hero.maxHp}respawnHero(){this.hero.alive=!0,this.hero.hp=this.hero.maxHp,this.hero.deadT=0,this.placeHeroAtCastle(),this.events.emit("heroRespawn",{})}secondChance(){if(this.phase!=="defeat"||this.secondChanceUsed)return!1;this.secondChanceUsed=!0;for(const t of this.units)t.team===1&&(t.alive=!1);for(const t of this.projectiles)t.alive=!1;return this.spawnQueue=[],this.bossUnit=null,this.cleanup(),this.repairAll(),this.castle.hp=this.castle.maxHp,this.setPhase("day"),!0}snapshot(){const t={};for(const e of this.buildings)e.node&&e.kind!=="castle"&&(t[e.slot.id]=e.node.id);return this.castle.node&&this.castle.node.id!=="castle"&&(t.castle=this.castle.node.id),{map:this.cfg.map,weapon:this.cfg.weapon,perks:[...this.cfg.perks],mutators:[...this.cfg.mutators],endless:this.cfg.endless,seed:this.cfg.seed,night:this.night,coins:this.coins,nodes:t,stats:{...this.stats},secondChanceUsed:this.secondChanceUsed}}cancelHold(){this.hold&&(this.events.emit("holdCancel",{b:this.hold.b}),this.hold=null,this.holdCoins=0)}updateConstruction(t){const e=this.activeSlot();if(this.input.hold||(this.holdLock=!1),!this.input.hold||!e||this.holdLock){this.hold&&this.cancelHold();return}const n=this.actionFor(e);if(this.coins<n.cost){this.hold&&this.cancelHold();return}if(!this.hold||this.hold.b!==e){this.cancelHold();const a=Vn(n.cost*me.build.secondsPerCoin,me.build.minHold,me.build.maxHold);this.hold={b:e,t:0,need:a,cost:n.cost}}const i=this.hold;i.t+=t;const r=Math.min(i.cost,Math.floor(i.t/i.need*i.cost+.999));for(;this.holdCoins<r;)this.holdCoins++,this.events.emit("coinIn",{b:e});i.t>=i.need&&(this.holdLock=!0,this.coins-=i.cost,this.hold=null,this.holdCoins=0,n.options.length===1&&!e.node?this.applyNode(e,n.options[0]):(this.choice={b:e,options:n.options,cost:n.cost},this.events.emit("choice",{b:e,options:n.options})))}chooseUpgrade(t){const e=this.choice;if(!e)return;const n=e.options[Vn(t,0,e.options.length-1)];this.choice=null,this.coins+=e.cost-this.nodeCost(n),this.applyNode(e.b,n)}cancelChoice(){this.choice&&(this.coins+=this.choice.cost,this.choice=null)}update(t){if(this.paused)return;let e=Math.min(t,.1)*this.timeScale;for(;e>0;){const n=Math.min(e,.03333333333333333);this.step(n),e-=n}}step(t){this.time+=t,this.phaseTime+=t;const e=this.input;switch(e.rally&&(e.rally=!1,this.toggleRally()),e.startNight&&(e.startNight=!1,this.startNight()),this.phase){case"day":this.updateConstruction(t);break;case"night":for(this.nightTime+=t;this.spawnQueue.length&&this.spawnQueue[0].t<=this.nightTime;){const n=this.spawnQueue.shift();this.enemiesAlive<me.maxUnits?this.spawnEnemy(n.unit,n.path):this.spawnQueue.push({...n,t:this.nightTime+2})}break;case"dawn":if(this.phaseTime>=me.dawnSeconds){if(!this.cfg.endless&&this.night>=this.map.nights){this.setPhase("victory");return}this.night++,this.plan=this.makePlan(),this.setPhase("day")}break}for(const n of this.buildings)n.builtT+=t,n.hitT+=t,n.attackT+=t;if(wd(this,t),Ad(this,t),yd(this,t),this.cleanup(),this.phase==="night"){if(this.stats.castleMinHp=Math.min(this.stats.castleMinHp,this.castle.hp/this.castle.maxHp),this.castle.ruined||this.castle.hp<=0){this.setPhase("defeat");return}!this.spawnQueue.length&&this.enemiesAlive===0&&this.nightTime>0&&this.endNight()}this.stats.maxCoins=Math.max(this.stats.maxCoins,this.coins)}toggleRally(){if(this.rallyFollow=!this.rallyFollow,!this.rallyFollow){let t=0;for(const e of this.buildings){if(!e.troops.length)continue;const n=t*2.1,i=t===0?0:1.6+t*.35;e.rallyX=this.hero.x+Math.cos(n)*i,e.rallyZ=this.hero.z+Math.sin(n)*i;for(const r of e.troops){const a=Ca(r.slotIdx);r.holdX=e.rallyX+a.x,r.holdZ=e.rallyZ+a.z}t++}}this.events.emit("rally",{follow:this.rallyFollow})}cleanup(){let t=0,e=0;for(let n=0;n<this.units.length;n++){const i=this.units[n];i.alive?(this.units[t++]=i,i.team===1&&e++):(i===this.bossUnit&&(this.bossUnit=null),this.unitPool.push(i))}this.units.length=t,this.enemiesAlive=e,t=0;for(let n=0;n<this.projectiles.length;n++){const i=this.projectiles[n];i.alive?this.projectiles[t++]=i:this.projPool.push(i)}this.projectiles.length=t}dispose(){this.events.clear(),this.units.length=0,this.projectiles.length=0,this.unitPool.length=0,this.projPool.length=0}}function Ca(s){if(s===0)return{x:0,z:0};const t=s<7?1:2,i=(t===1?s-1:s-7)/(t===1?6:10)*Math.PI*2+t*.4,r=t*1.15;return{x:Math.cos(i)*r,z:Math.sin(i)*r}}const Ra=["first_build","first_night","win_valley","win_swamp","win_pass","boss_slayer","clean5","kills500","kills5000","builder100","full_upgrade","rich50","hero50","army20","income15","mutator_win","mutator3_win","endless15","endless25","level5","level10","all_weapons","ability100","flawless"],Id={valley:100,swamp:170,pass:260};function Ud(s){let t=s.nights*(s.endless?12:15)+Math.floor(s.stats.kills/4)+s.stats.bossKills*30;return s.victory&&!s.endless&&(t+=Id[s.map]),Math.round(t*vr(s.mutators))}function Sr(s,t){const e=Hn.indexOf(t);return e===0||s.maps[Hn[e-1]].won}function Nd(s,t){const e=[];for(const n of xs)Mr[n].unlockLevel>s&&Mr[n].unlockLevel<=t&&e.push(`weapon.${n}`);for(const n of bo)n.unlockLevel>s&&n.unlockLevel<=t&&e.push(`perk.${n.id}`);return xr>s&&xr<=t&&e.push("mut.title"),e}function Fd(s,t,e=1){const n=Ud(t)*e,i=Xi(s.glory),r=Hn.map(u=>Sr(s,u));s.glory+=n;const a=Xi(s.glory),o=s.maps[t.map];let l=!1;t.endless?(t.nights>o.endlessBest&&(o.endlessBest=t.nights,l=!0),s.endlessBest=Math.max(s.endlessBest,t.nights)):(t.nights>o.best&&(o.best=t.nights,l=!0),t.victory&&(o.won=!0,o.wins++,s.totals.wins++,s.totals.weaponsWon.includes(t.weapon)||s.totals.weaponsWon.push(t.weapon))),s.totals.runs++,s.totals.kills+=t.stats.kills,s.totals.built+=t.stats.built,s.totals.abilities+=t.stats.abilityUses;const c=Hn.some((u,d)=>!r[d]&&Sr(s,u)),h=Oc(s,t);return{glory:n,levelBefore:i,levelAfter:a,unlocks:Nd(i,a),achievements:h,record:l,mapUnlocked:c}}function Oc(s,t,e){var l,c,h,u,d,f,_,v,p,m,b,T,y,E;const n=new Set(s.ach),i=[],r=(l=t==null?void 0:t.stats)!=null?l:e,a=Xi(s.glory),o={first_build:((c=r==null?void 0:r.built)!=null?c:0)>0||s.totals.built>0,first_night:((h=t==null?void 0:t.nights)!=null?h:0)>=1||s.maps.valley.best>=1,win_valley:s.maps.valley.won,win_swamp:s.maps.swamp.won,win_pass:s.maps.pass.won,boss_slayer:((u=r==null?void 0:r.bossKills)!=null?u:0)>0,clean5:((d=r==null?void 0:r.bestClean)!=null?d:0)>=5,kills500:s.totals.kills+((f=e==null?void 0:e.kills)!=null?f:0)>=500,kills5000:s.totals.kills+((_=e==null?void 0:e.kills)!=null?_:0)>=5e3,builder100:s.totals.built+((v=e==null?void 0:e.built)!=null?v:0)>=100,full_upgrade:((p=r==null?void 0:r.fullUpgrades)!=null?p:0)>0,rich50:((m=r==null?void 0:r.maxCoins)!=null?m:0)>=50,hero50:((b=r==null?void 0:r.heroKills)!=null?b:0)>=50,army20:((T=r==null?void 0:r.maxArmy)!=null?T:0)>=20,income15:((y=r==null?void 0:r.maxIncome)!=null?y:0)>=15,mutator_win:!!t&&t.victory&&!t.endless&&t.mutators.length>=1,mutator3_win:!!t&&t.victory&&!t.endless&&t.mutators.length>=3,endless15:s.endlessBest>=15,endless25:s.endlessBest>=25,level5:a>=5,level10:a>=10,all_weapons:xs.every(w=>s.totals.weaponsWon.includes(w)),ability100:s.totals.abilities+((E=e==null?void 0:e.abilityUses)!=null?E:0)>=100,flawless:!!t&&t.victory&&!t.endless&&t.stats.castleMinHp>.5};for(const w of Ra)!n.has(w)&&o[w]&&(s.ach.push(w),i.push(w));return i}function U(s,t,...e){const n=document.createElement(s);if(t)for(const[i,r]of Object.entries(t))r==null||r===!1||(i==="class"?n.className=r:i==="style"&&typeof r=="object"?Object.assign(n.style,r):i==="html"?n.innerHTML=r:i.startsWith("on")&&typeof r=="function"?n.addEventListener(i.slice(2).toLowerCase(),r):n.setAttribute(i,r===!0?"":String(r)));for(const i of e.flat())i==null||i===!1||n.appendChild(typeof i=="string"||typeof i=="number"?document.createTextNode(String(i)):i);return n}function It(s,t=""){const e=document.createElement("span");return e.className=`ic ${t}`,e.innerHTML=kd[s],e}const ae=(s,t="0 0 24 24")=>`<svg viewBox="${t}" aria-hidden="true">${s}</svg>`,kd={coin:ae('<circle cx="12" cy="12" r="9" fill="#f4c552" stroke="#b9862a" stroke-width="2"/><circle cx="12" cy="12" r="5.2" fill="none" stroke="#fff3c4" stroke-width="1.6"/>'),moon:ae('<path d="M15.5 3.5a8.5 8.5 0 1 0 5 13.6A7 7 0 0 1 15.5 3.5z" fill="#cfd7ff"/>'),sun:ae('<circle cx="12" cy="12" r="5" fill="#ffd36b"/><g stroke="#ffd36b" stroke-width="2" stroke-linecap="round"><path d="M12 2v3M12 19v3M2 12h3M19 12h3M4.9 4.9l2.1 2.1M17 17l2.1 2.1M4.9 19.1L7 17M17 7l2.1-2.1"/></g>'),pause:ae('<rect x="6" y="5" width="4" height="14" rx="1.2" fill="currentColor"/><rect x="14" y="5" width="4" height="14" rx="1.2" fill="currentColor"/>'),play:ae('<path d="M8 5l11 7-11 7z" fill="currentColor"/>'),gear:ae('<path fill="currentColor" d="M19.4 13a7.6 7.6 0 0 0 0-2l2.1-1.6-2-3.5-2.5 1a7.6 7.6 0 0 0-1.7-1L15 3.3h-4l-.4 2.6a7.6 7.6 0 0 0-1.7 1l-2.5-1-2 3.5L6.6 11a7.6 7.6 0 0 0 0 2l-2.1 1.6 2 3.5 2.5-1a7.6 7.6 0 0 0 1.7 1l.4 2.6h4l.4-2.6a7.6 7.6 0 0 0 1.7-1l2.5 1 2-3.5zM12 15.5A3.5 3.5 0 1 1 12 8.5a3.5 3.5 0 0 1 0 7z"/>'),video:ae('<rect x="2.5" y="6" width="13" height="12" rx="2.5" fill="currentColor"/><path d="M16.5 10.5l5-3v9l-5-3z" fill="currentColor"/><path d="M7.5 9.5l4 2.5-4 2.5z" fill="#fff"/>'),trophy:ae('<path fill="currentColor" d="M7 3h10v3h3a4 4 0 0 1-4 4.5A5 5 0 0 1 13 13.8V17h3v3H8v-3h3v-3.2A5 5 0 0 1 8 10.5 4 4 0 0 1 4 6h3zm0 5V8H6.1A2 2 0 0 0 7 9.4zm10 0v1.4A2 2 0 0 0 17.9 8z"/>'),crown:ae('<path fill="currentColor" d="M3 7l4.5 4L12 4l4.5 7L21 7l-2 11H5z"/>'),sword:ae('<path fill="currentColor" d="M19.5 2.5l2 2-9.8 9.8-2-2zM8.6 12.6l2.8 2.8-1.4 1.4-1-1-3.2 3.2a1.5 1.5 0 0 1-2.1-2.1L6.9 13.7l-1-1z"/>'),bow:ae('<path fill="none" stroke="currentColor" stroke-width="2.2" d="M5 3c9 2 14 7 16 16M5 3l16 16"/><path fill="currentColor" d="M3 21l5-1.5-3.5-3.5z"/>'),spear:ae('<path fill="currentColor" d="M21.5 2.5l-1.2 5.3-2.1-2zM18.5 6.5l-1 1L4 21l-1-1L16.5 6.5l1-1z"/>'),staff:ae('<path fill="currentColor" d="M6 21l-1.5-1.5 9-9 1.5 1.5z"/><circle cx="17" cy="7" r="4" fill="#ffe28a"/><path stroke="#fff6c8" stroke-width="1.5" d="M17 1.5v2M17 10.5v2M11.5 7h2M20.5 7h2"/>'),lock:ae('<rect x="5" y="10.5" width="14" height="10" rx="2" fill="currentColor"/><path d="M8 10.5V8a4 4 0 0 1 8 0v2.5" fill="none" stroke="currentColor" stroke-width="2.2"/>'),check:ae('<path d="M4.5 12.5l5 5 10-11" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>'),star:ae('<path fill="currentColor" d="M12 2.8l2.8 5.9 6.4.8-4.7 4.4 1.2 6.3L12 17.1l-5.7 3.1 1.2-6.3-4.7-4.4 6.4-.8z"/>'),hammer:ae('<path fill="currentColor" d="M13.5 3.5l6 6-2 2-1.6-1.6-8.6 8.6a1.8 1.8 0 0 1-2.6-2.6l8.6-8.6L11.7 5.6z"/>'),flag:ae('<path fill="currentColor" d="M5 2.5h2v19H5zM8 3.5h11l-2.5 4 2.5 4H8z"/>'),people:ae('<circle cx="8" cy="8" r="3.2" fill="currentColor"/><circle cx="16.5" cy="9" r="2.7" fill="currentColor"/><path fill="currentColor" d="M2.5 19.5a5.5 5.5 0 0 1 11 0zM12.8 19.5a4.6 4.6 0 0 1 8.7-1.9v1.9z"/>'),back:ae('<path d="M15 4.5L7.5 12l7.5 7.5" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>'),skull:ae('<path fill="currentColor" d="M12 2.5a8 8 0 0 0-8 8c0 2.7 1.3 4.5 3 5.6V20h10v-3.9c1.7-1.1 3-2.9 3-5.6a8 8 0 0 0-8-8zM8.7 13.5a1.9 1.9 0 1 1 0-3.8 1.9 1.9 0 0 1 0 3.8zm6.6 0a1.9 1.9 0 1 1 0-3.8 1.9 1.9 0 0 1 0 3.8z"/>'),castle:ae('<path fill="currentColor" d="M3 21V8h3v2h2V8h3v2h2V8h3v2h2V8h3v13h-7v-5a2 2 0 0 0-4 0v5z"/>'),heart:ae('<path fill="currentColor" d="M12 20.5l-1.4-1.3C5.4 14.5 2 11.4 2 7.6 2 4.5 4.4 2.2 7.4 2.2c1.7 0 3.4.8 4.6 2.1 1.2-1.3 2.9-2.1 4.6-2.1 3 0 5.4 2.3 5.4 5.4 0 3.8-3.4 6.9-8.6 11.6z"/>'),music:ae('<path fill="currentColor" d="M9 18.5a3 3 0 1 1-2-2.8V5l12-2.5v12.5a3 3 0 1 1-2-2.8V6.9L9 8.6z"/>'),sound:ae('<path fill="currentColor" d="M3 9.5h4l5-4.5v14l-5-4.5H3z"/><path d="M15.5 8.5a5 5 0 0 1 0 7M18 6a8.5 8.5 0 0 1 0 12" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>'),globe:ae('<circle cx="12" cy="12" r="9" fill="none" stroke="currentColor" stroke-width="2"/><path d="M3 12h18M12 3c3 3.2 3 14.8 0 18M12 3c-3 3.2-3 14.8 0 18" fill="none" stroke="currentColor" stroke-width="1.6"/>'),sparkle:ae('<path fill="currentColor" d="M12 2l2.2 7.8L22 12l-7.8 2.2L12 22l-2.2-7.8L2 12l7.8-2.2z"/>'),map:ae('<path fill="currentColor" d="M9 4l6 2 6-2v16l-6 2-6-2-6 2V6zm1 2.3v12.4l4 1.3V7.6z"/>')};function Bd(s,t){var e;if(s)try{(e=navigator.vibrate)==null||e.call(navigator,t)}catch{}}const Eo="186",Od=0,ml=1,zd=2,gs=1,Gd=2,ps=3,vi=0,Ve=1,wn=2,zn=0,$i=1,wr=2,gl=3,_l=4,Hd=5,Vi=100,Vd=101,Wd=102,Xd=103,qd=104,Yd=200,$d=201,Kd=202,Zd=203,zc=204,Gc=205,Jd=206,Qd=207,jd=208,tu=209,eu=210,nu=211,iu=212,su=213,ru=214,Pa=0,La=1,Da=2,bs=3,Ia=4,Ua=5,Na=6,Fa=7,To=0,au=1,ou=2,An=0,Hc=1,Vc=2,Wc=3,Xc=4,qc=5,Yc=6,$c=7,Kc=300,Mi=301,Ji=302,Wr=303,Xr=304,Ur=306,ka=1e3,On=1001,Ba=1002,Ce=1003,lu=1004,Fs=1005,Ue=1006,qr=1007,_i=1008,Ze=1009,Zc=1010,Jc=1011,Ss=1012,Ao=1013,Pn=1014,pn=1015,Ln=1016,Co=1017,Ro=1018,ws=1020,Qc=35902,jc=35899,th=1021,eh=1022,mn=1023,Wn=1026,xi=1027,Po=1028,Lo=1029,yi=1030,Do=1031,Io=1033,dr=33776,ur=33777,fr=33778,pr=33779,Oa=35840,za=35841,Ga=35842,Ha=35843,Va=36196,Wa=37492,Xa=37496,qa=37488,Ya=37489,Er=37490,$a=37491,Ka=37808,Za=37809,Ja=37810,Qa=37811,ja=37812,to=37813,eo=37814,no=37815,io=37816,so=37817,ro=37818,ao=37819,oo=37820,lo=37821,co=36492,ho=36494,uo=36495,fo=36283,po=36284,Tr=36285,mo=36286,cu=3200,go=0,hu=1,ii="",He="srgb",Ar="srgb-linear",Cr="linear",ie="srgb",Yr=7680,du=519,uu=512,fu=513,pu=514,Uo=515,mu=516,gu=517,No=518,_u=519,xu=35044,_s=35048,xl="300 es",Tn=2e3,Es=2001;function vu(s){for(let t=s.length-1;t>=0;--t)if(s[t]>=65535)return!0;return!1}function Rr(s){return document.createElementNS("http://www.w3.org/1999/xhtml",s)}function Mu(){const s=Rr("canvas");return s.style.display="block",s}const vl={};function Ml(...s){const t="THREE."+s.shift();console.log(t,...s)}function nh(s){const t=s[0];if(typeof t=="string"&&t.startsWith("TSL:")){const e=s[1];e&&e.isStackTrace?s[0]+=" "+e.getLocation():s[1]='Stack trace not available. Enable "THREE.Node.captureStackTrace" to capture stack traces.'}return s}function Ut(...s){s=nh(s);const t="THREE."+s.shift();{const e=s[0];e&&e.isStackTrace?console.warn(e.getError(t)):console.warn(t,...s)}}function Kt(...s){s=nh(s);const t="THREE."+s.shift();{const e=s[0];e&&e.isStackTrace?console.error(e.getError(t)):console.error(t,...s)}}function Ki(...s){const t=s.join(" ");t in vl||(vl[t]=!0,Ut(...s))}function yu(s,t,e){return new Promise(function(n,i){function r(){switch(s.clientWaitSync(t,s.SYNC_FLUSH_COMMANDS_BIT,0)){case s.WAIT_FAILED:i();break;case s.TIMEOUT_EXPIRED:setTimeout(r,e);break;default:n()}}setTimeout(r,e)})}const bu={[Pa]:La,[Da]:Na,[Ia]:Fa,[bs]:Ua,[La]:Pa,[Na]:Da,[Fa]:Ia,[Ua]:bs};class Si{addEventListener(t,e){this._listeners===void 0&&(this._listeners={});const n=this._listeners;n[t]===void 0&&(n[t]=[]),n[t].indexOf(e)===-1&&n[t].push(e)}hasEventListener(t,e){const n=this._listeners;return n===void 0?!1:n[t]!==void 0&&n[t].indexOf(e)!==-1}removeEventListener(t,e){const n=this._listeners;if(n===void 0)return;const i=n[t];if(i!==void 0){const r=i.indexOf(e);r!==-1&&i.splice(r,1)}}dispatchEvent(t){const e=this._listeners;if(e===void 0)return;const n=e[t.type];if(n!==void 0){t.target=this;const i=n.slice(0);for(let r=0,a=i.length;r<a;r++)i[r].call(this,t);t.target=null}}}const De=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"],$r=Math.PI/180,_o=180/Math.PI;function Cs(){const s=Math.random()*4294967295|0,t=Math.random()*4294967295|0,e=Math.random()*4294967295|0,n=Math.random()*4294967295|0;return(De[s&255]+De[s>>8&255]+De[s>>16&255]+De[s>>24&255]+"-"+De[t&255]+De[t>>8&255]+"-"+De[t>>16&15|64]+De[t>>24&255]+"-"+De[e&63|128]+De[e>>8&255]+"-"+De[e>>16&255]+De[e>>24&255]+De[n&255]+De[n>>8&255]+De[n>>16&255]+De[n>>24&255]).toLowerCase()}function qt(s,t,e){return Math.max(t,Math.min(e,s))}function Su(s,t){return(s%t+t)%t}function Kr(s,t,e){return(1-e)*s+e*t}function is(s,t){switch(t.constructor){case Float32Array:return s;case Uint32Array:return s/4294967295;case Uint16Array:return s/65535;case Uint8Array:case Uint8ClampedArray:return s/255;case Int32Array:return Math.max(s/2147483647,-1);case Int16Array:return Math.max(s/32767,-1);case Int8Array:return Math.max(s/127,-1);default:throw new Error("THREE.MathUtils: Invalid component type.")}}function Ge(s,t){switch(t.constructor){case Float32Array:return s;case Uint32Array:return Math.round(s*4294967295);case Uint16Array:return Math.round(s*65535);case Uint8Array:case Uint8ClampedArray:return Math.round(s*255);case Int32Array:return Math.round(s*2147483647);case Int16Array:return Math.round(s*32767);case Int8Array:return Math.round(s*127);default:throw new Error("THREE.MathUtils: Invalid component type.")}}const Xo=class Xo{constructor(t=0,e=0){this.x=t,this.y=e}get width(){return this.x}set width(t){this.x=t}get height(){return this.y}set height(t){this.y=t}set(t,e){return this.x=t,this.y=e,this}setScalar(t){return this.x=t,this.y=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;default:throw new Error("THREE.Vector2: index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;default:throw new Error("THREE.Vector2: index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y)}copy(t){return this.x=t.x,this.y=t.y,this}add(t){return this.x+=t.x,this.y+=t.y,this}addScalar(t){return this.x+=t,this.y+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this}subScalar(t){return this.x-=t,this.y-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this}multiply(t){return this.x*=t.x,this.y*=t.y,this}multiplyScalar(t){return this.x*=t,this.y*=t,this}divide(t){return this.x/=t.x,this.y/=t.y,this}divideScalar(t){return this.multiplyScalar(1/t)}applyMatrix3(t){const e=this.x,n=this.y,i=t.elements;return this.x=i[0]*e+i[3]*n+i[6],this.y=i[1]*e+i[4]*n+i[7],this}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this}clamp(t,e){return this.x=qt(this.x,t.x,e.x),this.y=qt(this.y,t.y,e.y),this}clampScalar(t,e){return this.x=qt(this.x,t,e),this.y=qt(this.y,t,e),this}clampLength(t,e){const n=this.length();return this.divideScalar(n||1).multiplyScalar(qt(n,t,e))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(t){return this.x*t.x+this.y*t.y}cross(t){return this.x*t.y-this.y*t.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(t){const e=Math.sqrt(this.lengthSq()*t.lengthSq());if(e===0)return Math.PI/2;const n=this.dot(t)/e;return Math.acos(qt(n,-1,1))}distanceTo(t){return Math.sqrt(this.distanceToSquared(t))}distanceToSquared(t){const e=this.x-t.x,n=this.y-t.y;return e*e+n*n}manhattanDistanceTo(t){return Math.abs(this.x-t.x)+Math.abs(this.y-t.y)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this}lerpVectors(t,e,n){return this.x=t.x+(e.x-t.x)*n,this.y=t.y+(e.y-t.y)*n,this}equals(t){return t.x===this.x&&t.y===this.y}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this}rotateAround(t,e){const n=Math.cos(e),i=Math.sin(e),r=this.x-t.x,a=this.y-t.y;return this.x=r*n-a*i+t.x,this.y=r*i+a*n+t.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}};Xo.prototype.isVector2=!0;let Bt=Xo;class sn{constructor(t=0,e=0,n=0,i=1){this.isQuaternion=!0,this._x=t,this._y=e,this._z=n,this._w=i}static slerpFlat(t,e,n,i,r,a,o){let l=n[i+0],c=n[i+1],h=n[i+2],u=n[i+3],d=r[a+0],f=r[a+1],_=r[a+2],v=r[a+3];if(u!==v||l!==d||c!==f||h!==_){let p=l*d+c*f+h*_+u*v;p<0&&(d=-d,f=-f,_=-_,v=-v,p=-p);let m=1-o;if(p<.9995){const b=Math.acos(p),T=Math.sin(b);m=Math.sin(m*b)/T,o=Math.sin(o*b)/T,l=l*m+d*o,c=c*m+f*o,h=h*m+_*o,u=u*m+v*o}else{l=l*m+d*o,c=c*m+f*o,h=h*m+_*o,u=u*m+v*o;const b=1/Math.sqrt(l*l+c*c+h*h+u*u);l*=b,c*=b,h*=b,u*=b}}t[e]=l,t[e+1]=c,t[e+2]=h,t[e+3]=u}static multiplyQuaternionsFlat(t,e,n,i,r,a){const o=n[i],l=n[i+1],c=n[i+2],h=n[i+3],u=r[a],d=r[a+1],f=r[a+2],_=r[a+3];return t[e]=o*_+h*u+l*f-c*d,t[e+1]=l*_+h*d+c*u-o*f,t[e+2]=c*_+h*f+o*d-l*u,t[e+3]=h*_-o*u-l*d-c*f,t}get x(){return this._x}set x(t){this._x=t,this._onChangeCallback()}get y(){return this._y}set y(t){this._y=t,this._onChangeCallback()}get z(){return this._z}set z(t){this._z=t,this._onChangeCallback()}get w(){return this._w}set w(t){this._w=t,this._onChangeCallback()}set(t,e,n,i){return this._x=t,this._y=e,this._z=n,this._w=i,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(t){return this._x=t.x,this._y=t.y,this._z=t.z,this._w=t.w,this._onChangeCallback(),this}setFromEuler(t,e=!0){const n=t._x,i=t._y,r=t._z,a=t._order,o=Math.cos,l=Math.sin,c=o(n/2),h=o(i/2),u=o(r/2),d=l(n/2),f=l(i/2),_=l(r/2);switch(a){case"XYZ":this._x=d*h*u+c*f*_,this._y=c*f*u-d*h*_,this._z=c*h*_+d*f*u,this._w=c*h*u-d*f*_;break;case"YXZ":this._x=d*h*u+c*f*_,this._y=c*f*u-d*h*_,this._z=c*h*_-d*f*u,this._w=c*h*u+d*f*_;break;case"ZXY":this._x=d*h*u-c*f*_,this._y=c*f*u+d*h*_,this._z=c*h*_+d*f*u,this._w=c*h*u-d*f*_;break;case"ZYX":this._x=d*h*u-c*f*_,this._y=c*f*u+d*h*_,this._z=c*h*_-d*f*u,this._w=c*h*u+d*f*_;break;case"YZX":this._x=d*h*u+c*f*_,this._y=c*f*u+d*h*_,this._z=c*h*_-d*f*u,this._w=c*h*u-d*f*_;break;case"XZY":this._x=d*h*u-c*f*_,this._y=c*f*u-d*h*_,this._z=c*h*_+d*f*u,this._w=c*h*u+d*f*_;break;default:Ut("Quaternion: .setFromEuler() encountered an unknown order: "+a)}return e===!0&&this._onChangeCallback(),this}setFromAxisAngle(t,e){const n=e/2,i=Math.sin(n);return this._x=t.x*i,this._y=t.y*i,this._z=t.z*i,this._w=Math.cos(n),this._onChangeCallback(),this}setFromRotationMatrix(t){const e=t.elements,n=e[0],i=e[4],r=e[8],a=e[1],o=e[5],l=e[9],c=e[2],h=e[6],u=e[10],d=n+o+u;if(d>0){const f=.5/Math.sqrt(d+1);this._w=.25/f,this._x=(h-l)*f,this._y=(r-c)*f,this._z=(a-i)*f}else if(n>o&&n>u){const f=2*Math.sqrt(1+n-o-u);this._w=(h-l)/f,this._x=.25*f,this._y=(i+a)/f,this._z=(r+c)/f}else if(o>u){const f=2*Math.sqrt(1+o-n-u);this._w=(r-c)/f,this._x=(i+a)/f,this._y=.25*f,this._z=(l+h)/f}else{const f=2*Math.sqrt(1+u-n-o);this._w=(a-i)/f,this._x=(r+c)/f,this._y=(l+h)/f,this._z=.25*f}return this._onChangeCallback(),this}setFromUnitVectors(t,e){let n=t.dot(e)+1;return n<1e-8?(n=0,Math.abs(t.x)>Math.abs(t.z)?(this._x=-t.y,this._y=t.x,this._z=0,this._w=n):(this._x=0,this._y=-t.z,this._z=t.y,this._w=n)):(this._x=t.y*e.z-t.z*e.y,this._y=t.z*e.x-t.x*e.z,this._z=t.x*e.y-t.y*e.x,this._w=n),this.normalize()}angleTo(t){return 2*Math.acos(Math.abs(qt(this.dot(t),-1,1)))}rotateTowards(t,e){const n=this.angleTo(t);if(n===0)return this;const i=Math.min(1,e/n);return this.slerp(t,i),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(t){return this._x*t._x+this._y*t._y+this._z*t._z+this._w*t._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let t=this.length();return t===0?(this._x=0,this._y=0,this._z=0,this._w=1):(t=1/t,this._x=this._x*t,this._y=this._y*t,this._z=this._z*t,this._w=this._w*t),this._onChangeCallback(),this}multiply(t){return this.multiplyQuaternions(this,t)}premultiply(t){return this.multiplyQuaternions(t,this)}multiplyQuaternions(t,e){const n=t._x,i=t._y,r=t._z,a=t._w,o=e._x,l=e._y,c=e._z,h=e._w;return this._x=n*h+a*o+i*c-r*l,this._y=i*h+a*l+r*o-n*c,this._z=r*h+a*c+n*l-i*o,this._w=a*h-n*o-i*l-r*c,this._onChangeCallback(),this}slerp(t,e){let n=t._x,i=t._y,r=t._z,a=t._w,o=this.dot(t);o<0&&(n=-n,i=-i,r=-r,a=-a,o=-o);let l=1-e;if(o<.9995){const c=Math.acos(o),h=Math.sin(c);l=Math.sin(l*c)/h,e=Math.sin(e*c)/h,this._x=this._x*l+n*e,this._y=this._y*l+i*e,this._z=this._z*l+r*e,this._w=this._w*l+a*e,this._onChangeCallback()}else this._x=this._x*l+n*e,this._y=this._y*l+i*e,this._z=this._z*l+r*e,this._w=this._w*l+a*e,this.normalize();return this}slerpQuaternions(t,e,n){return this.copy(t).slerp(e,n)}random(){const t=2*Math.PI*Math.random(),e=2*Math.PI*Math.random(),n=Math.random(),i=Math.sqrt(1-n),r=Math.sqrt(n);return this.set(i*Math.sin(t),i*Math.cos(t),r*Math.sin(e),r*Math.cos(e))}equals(t){return t._x===this._x&&t._y===this._y&&t._z===this._z&&t._w===this._w}fromArray(t,e=0){return this._x=t[e],this._y=t[e+1],this._z=t[e+2],this._w=t[e+3],this._onChangeCallback(),this}toArray(t=[],e=0){return t[e]=this._x,t[e+1]=this._y,t[e+2]=this._z,t[e+3]=this._w,t}fromBufferAttribute(t,e){return this._x=t.getX(e),this._y=t.getY(e),this._z=t.getZ(e),this._w=t.getW(e),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(t){return this._onChangeCallback=t,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}}const qo=class qo{constructor(t=0,e=0,n=0){this.x=t,this.y=e,this.z=n}set(t,e,n){return n===void 0&&(n=this.z),this.x=t,this.y=e,this.z=n,this}setScalar(t){return this.x=t,this.y=t,this.z=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setZ(t){return this.z=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;case 2:this.z=e;break;default:throw new Error("THREE.Vector3: index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw new Error("THREE.Vector3: index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(t){return this.x=t.x,this.y=t.y,this.z=t.z,this}add(t){return this.x+=t.x,this.y+=t.y,this.z+=t.z,this}addScalar(t){return this.x+=t,this.y+=t,this.z+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this.z=t.z+e.z,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this.z+=t.z*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this.z-=t.z,this}subScalar(t){return this.x-=t,this.y-=t,this.z-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this.z=t.z-e.z,this}multiply(t){return this.x*=t.x,this.y*=t.y,this.z*=t.z,this}multiplyScalar(t){return this.x*=t,this.y*=t,this.z*=t,this}multiplyVectors(t,e){return this.x=t.x*e.x,this.y=t.y*e.y,this.z=t.z*e.z,this}applyEuler(t){return this.applyQuaternion(yl.setFromEuler(t))}applyAxisAngle(t,e){return this.applyQuaternion(yl.setFromAxisAngle(t,e))}applyMatrix3(t){const e=this.x,n=this.y,i=this.z,r=t.elements;return this.x=r[0]*e+r[3]*n+r[6]*i,this.y=r[1]*e+r[4]*n+r[7]*i,this.z=r[2]*e+r[5]*n+r[8]*i,this}applyNormalMatrix(t){return this.applyMatrix3(t).normalize()}applyMatrix4(t){const e=this.x,n=this.y,i=this.z,r=t.elements,a=1/(r[3]*e+r[7]*n+r[11]*i+r[15]);return this.x=(r[0]*e+r[4]*n+r[8]*i+r[12])*a,this.y=(r[1]*e+r[5]*n+r[9]*i+r[13])*a,this.z=(r[2]*e+r[6]*n+r[10]*i+r[14])*a,this}applyQuaternion(t){const e=this.x,n=this.y,i=this.z,r=t.x,a=t.y,o=t.z,l=t.w,c=2*(a*i-o*n),h=2*(o*e-r*i),u=2*(r*n-a*e);return this.x=e+l*c+a*u-o*h,this.y=n+l*h+o*c-r*u,this.z=i+l*u+r*h-a*c,this}project(t){return this.applyMatrix4(t.matrixWorldInverse).applyMatrix4(t.projectionMatrix)}unproject(t){return this.applyMatrix4(t.projectionMatrixInverse).applyMatrix4(t.matrixWorld)}transformDirection(t){const e=this.x,n=this.y,i=this.z,r=t.elements;return this.x=r[0]*e+r[4]*n+r[8]*i,this.y=r[1]*e+r[5]*n+r[9]*i,this.z=r[2]*e+r[6]*n+r[10]*i,this.normalize()}divide(t){return this.x/=t.x,this.y/=t.y,this.z/=t.z,this}divideScalar(t){return this.multiplyScalar(1/t)}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this.z=Math.min(this.z,t.z),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this.z=Math.max(this.z,t.z),this}clamp(t,e){return this.x=qt(this.x,t.x,e.x),this.y=qt(this.y,t.y,e.y),this.z=qt(this.z,t.z,e.z),this}clampScalar(t,e){return this.x=qt(this.x,t,e),this.y=qt(this.y,t,e),this.z=qt(this.z,t,e),this}clampLength(t,e){const n=this.length();return this.divideScalar(n||1).multiplyScalar(qt(n,t,e))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(t){return this.x*t.x+this.y*t.y+this.z*t.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this.z+=(t.z-this.z)*e,this}lerpVectors(t,e,n){return this.x=t.x+(e.x-t.x)*n,this.y=t.y+(e.y-t.y)*n,this.z=t.z+(e.z-t.z)*n,this}cross(t){return this.crossVectors(this,t)}crossVectors(t,e){const n=t.x,i=t.y,r=t.z,a=e.x,o=e.y,l=e.z;return this.x=i*l-r*o,this.y=r*a-n*l,this.z=n*o-i*a,this}projectOnVector(t){const e=t.lengthSq();if(e===0)return this.set(0,0,0);const n=t.dot(this)/e;return this.copy(t).multiplyScalar(n)}projectOnPlane(t){return Zr.copy(this).projectOnVector(t),this.sub(Zr)}reflect(t){return this.sub(Zr.copy(t).multiplyScalar(2*this.dot(t)))}angleTo(t){const e=Math.sqrt(this.lengthSq()*t.lengthSq());if(e===0)return Math.PI/2;const n=this.dot(t)/e;return Math.acos(qt(n,-1,1))}distanceTo(t){return Math.sqrt(this.distanceToSquared(t))}distanceToSquared(t){const e=this.x-t.x,n=this.y-t.y,i=this.z-t.z;return e*e+n*n+i*i}manhattanDistanceTo(t){return Math.abs(this.x-t.x)+Math.abs(this.y-t.y)+Math.abs(this.z-t.z)}setFromSpherical(t){return this.setFromSphericalCoords(t.radius,t.phi,t.theta)}setFromSphericalCoords(t,e,n){const i=Math.sin(e)*t;return this.x=i*Math.sin(n),this.y=Math.cos(e)*t,this.z=i*Math.cos(n),this}setFromCylindrical(t){return this.setFromCylindricalCoords(t.radius,t.theta,t.y)}setFromCylindricalCoords(t,e,n){return this.x=t*Math.sin(e),this.y=n,this.z=t*Math.cos(e),this}setFromMatrixPosition(t){const e=t.elements;return this.x=e[12],this.y=e[13],this.z=e[14],this}setFromMatrixScale(t){const e=this.setFromMatrixColumn(t,0).length(),n=this.setFromMatrixColumn(t,1).length(),i=this.setFromMatrixColumn(t,2).length();return this.x=e,this.y=n,this.z=i,this}setFromMatrixColumn(t,e){return this.fromArray(t.elements,e*4)}setFromMatrix3Column(t,e){return this.fromArray(t.elements,e*3)}setFromEuler(t){return this.x=t._x,this.y=t._y,this.z=t._z,this}setFromColor(t){return this.x=t.r,this.y=t.g,this.z=t.b,this}equals(t){return t.x===this.x&&t.y===this.y&&t.z===this.z}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this.z=t[e+2],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t[e+2]=this.z,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this.z=t.getZ(e),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){const t=Math.random()*Math.PI*2,e=Math.random()*2-1,n=Math.sqrt(1-e*e);return this.x=n*Math.cos(t),this.y=e,this.z=n*Math.sin(t),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}};qo.prototype.isVector3=!0;let O=qo;const Zr=new O,yl=new sn,Yo=class Yo{constructor(t,e,n,i,r,a,o,l,c){this.elements=[1,0,0,0,1,0,0,0,1],t!==void 0&&this.set(t,e,n,i,r,a,o,l,c)}set(t,e,n,i,r,a,o,l,c){const h=this.elements;return h[0]=t,h[1]=i,h[2]=o,h[3]=e,h[4]=r,h[5]=l,h[6]=n,h[7]=a,h[8]=c,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(t){const e=this.elements,n=t.elements;return e[0]=n[0],e[1]=n[1],e[2]=n[2],e[3]=n[3],e[4]=n[4],e[5]=n[5],e[6]=n[6],e[7]=n[7],e[8]=n[8],this}extractBasis(t,e,n){return t.setFromMatrix3Column(this,0),e.setFromMatrix3Column(this,1),n.setFromMatrix3Column(this,2),this}setFromMatrix4(t){const e=t.elements;return this.set(e[0],e[4],e[8],e[1],e[5],e[9],e[2],e[6],e[10]),this}multiply(t){return this.multiplyMatrices(this,t)}premultiply(t){return this.multiplyMatrices(t,this)}multiplyMatrices(t,e){const n=t.elements,i=e.elements,r=this.elements,a=n[0],o=n[3],l=n[6],c=n[1],h=n[4],u=n[7],d=n[2],f=n[5],_=n[8],v=i[0],p=i[3],m=i[6],b=i[1],T=i[4],y=i[7],E=i[2],w=i[5],R=i[8];return r[0]=a*v+o*b+l*E,r[3]=a*p+o*T+l*w,r[6]=a*m+o*y+l*R,r[1]=c*v+h*b+u*E,r[4]=c*p+h*T+u*w,r[7]=c*m+h*y+u*R,r[2]=d*v+f*b+_*E,r[5]=d*p+f*T+_*w,r[8]=d*m+f*y+_*R,this}multiplyScalar(t){const e=this.elements;return e[0]*=t,e[3]*=t,e[6]*=t,e[1]*=t,e[4]*=t,e[7]*=t,e[2]*=t,e[5]*=t,e[8]*=t,this}determinant(){const t=this.elements,e=t[0],n=t[1],i=t[2],r=t[3],a=t[4],o=t[5],l=t[6],c=t[7],h=t[8];return e*a*h-e*o*c-n*r*h+n*o*l+i*r*c-i*a*l}invert(){const t=this.elements,e=t[0],n=t[1],i=t[2],r=t[3],a=t[4],o=t[5],l=t[6],c=t[7],h=t[8],u=h*a-o*c,d=o*l-h*r,f=c*r-a*l,_=e*u+n*d+i*f;if(_===0)return this.set(0,0,0,0,0,0,0,0,0);const v=1/_;return t[0]=u*v,t[1]=(i*c-h*n)*v,t[2]=(o*n-i*a)*v,t[3]=d*v,t[4]=(h*e-i*l)*v,t[5]=(i*r-o*e)*v,t[6]=f*v,t[7]=(n*l-c*e)*v,t[8]=(a*e-n*r)*v,this}transpose(){let t;const e=this.elements;return t=e[1],e[1]=e[3],e[3]=t,t=e[2],e[2]=e[6],e[6]=t,t=e[5],e[5]=e[7],e[7]=t,this}getNormalMatrix(t){return this.setFromMatrix4(t).invert().transpose()}transposeIntoArray(t){const e=this.elements;return t[0]=e[0],t[1]=e[3],t[2]=e[6],t[3]=e[1],t[4]=e[4],t[5]=e[7],t[6]=e[2],t[7]=e[5],t[8]=e[8],this}setUvTransform(t,e,n,i,r,a,o){const l=Math.cos(r),c=Math.sin(r);return this.set(n*l,n*c,-n*(l*a+c*o)+a+t,-i*c,i*l,-i*(-c*a+l*o)+o+e,0,0,1),this}scale(t,e){return Ki("Matrix3: .scale() is deprecated. Use .makeScale() instead."),this.premultiply(Jr.makeScale(t,e)),this}rotate(t){return Ki("Matrix3: .rotate() is deprecated. Use .makeRotation() instead."),this.premultiply(Jr.makeRotation(-t)),this}translate(t,e){return Ki("Matrix3: .translate() is deprecated. Use .makeTranslation() instead."),this.premultiply(Jr.makeTranslation(t,e)),this}makeTranslation(t,e){return t.isVector2?this.set(1,0,t.x,0,1,t.y,0,0,1):this.set(1,0,t,0,1,e,0,0,1),this}makeRotation(t){const e=Math.cos(t),n=Math.sin(t);return this.set(e,-n,0,n,e,0,0,0,1),this}makeScale(t,e){return this.set(t,0,0,0,e,0,0,0,1),this}equals(t){const e=this.elements,n=t.elements;for(let i=0;i<9;i++)if(e[i]!==n[i])return!1;return!0}fromArray(t,e=0){for(let n=0;n<9;n++)this.elements[n]=t[n+e];return this}toArray(t=[],e=0){const n=this.elements;return t[e]=n[0],t[e+1]=n[1],t[e+2]=n[2],t[e+3]=n[3],t[e+4]=n[4],t[e+5]=n[5],t[e+6]=n[6],t[e+7]=n[7],t[e+8]=n[8],t}clone(){return new this.constructor().fromArray(this.elements)}};Yo.prototype.isMatrix3=!0;let Ft=Yo;const Jr=new Ft,bl=new Ft().set(.4123908,.3575843,.1804808,.212639,.7151687,.0721923,.0193308,.1191948,.9505322),Sl=new Ft().set(3.2409699,-1.5373832,-.4986108,-.9692436,1.8759675,.0415551,.0556301,-.203977,1.0569715);function wu(){const s={enabled:!0,workingColorSpace:Ar,spaces:{},convert:function(i,r,a){return this.enabled===!1||r===a||!r||!a||(this.spaces[r].transfer===ie&&(i.r=Gn(i.r),i.g=Gn(i.g),i.b=Gn(i.b)),this.spaces[r].primaries!==this.spaces[a].primaries&&(i.applyMatrix3(this.spaces[r].toXYZ),i.applyMatrix3(this.spaces[a].fromXYZ)),this.spaces[a].transfer===ie&&(i.r=Zi(i.r),i.g=Zi(i.g),i.b=Zi(i.b))),i},workingToColorSpace:function(i,r){return this.convert(i,this.workingColorSpace,r)},colorSpaceToWorking:function(i,r){return this.convert(i,r,this.workingColorSpace)},getPrimaries:function(i){return this.spaces[i].primaries},getTransfer:function(i){return i===ii?Cr:this.spaces[i].transfer},getToneMappingMode:function(i){return this.spaces[i].outputColorSpaceConfig.toneMappingMode||"standard"},getLuminanceCoefficients:function(i,r=this.workingColorSpace){return i.fromArray(this.spaces[r].luminanceCoefficients)},define:function(i){Object.assign(this.spaces,i)},_getMatrix:function(i,r,a){return i.copy(this.spaces[r].toXYZ).multiply(this.spaces[a].fromXYZ)},_getDrawingBufferColorSpace:function(i){return this.spaces[i].outputColorSpaceConfig.drawingBufferColorSpace},_getUnpackColorSpace:function(i=this.workingColorSpace){return this.spaces[i].workingColorSpaceConfig.unpackColorSpace},fromWorkingColorSpace:function(i,r){return Ki("ColorManagement: .fromWorkingColorSpace() has been renamed to .workingToColorSpace()."),s.workingToColorSpace(i,r)},toWorkingColorSpace:function(i,r){return Ki("ColorManagement: .toWorkingColorSpace() has been renamed to .colorSpaceToWorking()."),s.colorSpaceToWorking(i,r)}},t=[.64,.33,.3,.6,.15,.06],e=[.2126,.7152,.0722],n=[.3127,.329];return s.define({[Ar]:{primaries:t,whitePoint:n,transfer:Cr,toXYZ:bl,fromXYZ:Sl,luminanceCoefficients:e,workingColorSpaceConfig:{unpackColorSpace:He},outputColorSpaceConfig:{drawingBufferColorSpace:He}},[He]:{primaries:t,whitePoint:n,transfer:ie,toXYZ:bl,fromXYZ:Sl,luminanceCoefficients:e,outputColorSpaceConfig:{drawingBufferColorSpace:He}}}),s}const Xt=wu();function Gn(s){return s<.04045?s*.0773993808:Math.pow(s*.9478672986+.0521327014,2.4)}function Zi(s){return s<.0031308?s*12.92:1.055*Math.pow(s,.41666)-.055}let Ai;class Eu{static getDataURL(t,e="image/png"){if(/^data:/i.test(t.src)||typeof HTMLCanvasElement=="undefined")return t.src;let n;if(t instanceof HTMLCanvasElement)n=t;else{Ai===void 0&&(Ai=Rr("canvas")),Ai.width=t.width,Ai.height=t.height;const i=Ai.getContext("2d");t instanceof ImageData?i.putImageData(t,0,0):i.drawImage(t,0,0,t.width,t.height),n=Ai}return n.toDataURL(e)}static sRGBToLinear(t){if(typeof HTMLImageElement!="undefined"&&t instanceof HTMLImageElement||typeof HTMLCanvasElement!="undefined"&&t instanceof HTMLCanvasElement||typeof ImageBitmap!="undefined"&&t instanceof ImageBitmap){const e=Rr("canvas");e.width=t.width,e.height=t.height;const n=e.getContext("2d");n.drawImage(t,0,0,t.width,t.height);const i=n.getImageData(0,0,t.width,t.height),r=i.data;for(let a=0;a<r.length;a++)r[a]=Gn(r[a]/255)*255;return n.putImageData(i,0,0),e}else if(t.data){const e=t.data.slice(0);for(let n=0;n<e.length;n++)e instanceof Uint8Array||e instanceof Uint8ClampedArray?e[n]=Math.floor(Gn(e[n]/255)*255):e[n]=Gn(e[n]);return{data:e,width:t.width,height:t.height}}else return Ut("ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),t}}let Tu=0;class Fo{constructor(t=null){this.isTextureSource=!0,Object.defineProperty(this,"id",{value:Tu++}),this.uuid=Cs(),this.data=t,this.dataReady=!0,this.version=0}getSize(t){const e=this.data;return typeof HTMLVideoElement!="undefined"&&e instanceof HTMLVideoElement?t.set(e.videoWidth,e.videoHeight,0):typeof VideoFrame!="undefined"&&e instanceof VideoFrame?t.set(e.displayWidth,e.displayHeight,0):e!==null?t.set(e.width,e.height,e.depth||0):t.set(0,0,0),t}set needsUpdate(t){t===!0&&this.version++}toJSON(t){const e=t===void 0||typeof t=="string";if(!e&&t.images[this.uuid]!==void 0)return t.images[this.uuid];const n={uuid:this.uuid,url:""},i=this.data;if(i!==null){let r;if(Array.isArray(i)){r=[];for(let a=0,o=i.length;a<o;a++)i[a].isDataTexture?r.push(Qr(i[a].image)):r.push(Qr(i[a]))}else r=Qr(i);n.url=r}return e||(t.images[this.uuid]=n),n}}function Qr(s){return typeof HTMLImageElement!="undefined"&&s instanceof HTMLImageElement||typeof HTMLCanvasElement!="undefined"&&s instanceof HTMLCanvasElement||typeof ImageBitmap!="undefined"&&s instanceof ImageBitmap?Eu.getDataURL(s):s.data?{data:Array.from(s.data),width:s.width,height:s.height,type:s.data.constructor.name}:(Ut("Texture: Unable to serialize Texture."),{})}let Au=0;const jr=new O;class Oe extends Si{constructor(t=Oe.DEFAULT_IMAGE,e=Oe.DEFAULT_MAPPING,n=On,i=On,r=Ue,a=_i,o=mn,l=Ze,c=Oe.DEFAULT_ANISOTROPY,h=ii){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:Au++}),this.uuid=Cs(),this.name="",this.source=new Fo(t),this.mipmaps=[],this.mapping=e,this.channel=0,this.wrapS=n,this.wrapT=i,this.magFilter=r,this.minFilter=a,this.anisotropy=c,this.format=o,this.internalFormat=null,this.type=l,this.offset=new Bt(0,0),this.repeat=new Bt(1,1),this.center=new Bt(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new Ft,this.generateMipmaps=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,this.colorSpace=h,this.userData={},this.updateRanges=[],this.version=0,this.onUpdate=null,this.renderTarget=null,this.isRenderTargetTexture=!1,this.isArrayTexture=!!(t&&t.depth&&t.depth>1),this.pmremVersion=0,this.normalized=!1}get width(){return this.source.getSize(jr).x}get height(){return this.source.getSize(jr).y}get depth(){return this.source.getSize(jr).z}get image(){return this.source.data}set image(t){this.source.data=t}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}addUpdateRange(t,e){this.updateRanges.push({start:t,count:e})}clearUpdateRanges(){this.updateRanges.length=0}clone(){return new this.constructor().copy(this)}copy(t){return this.name=t.name,this.source=t.source,this.mipmaps=t.mipmaps.slice(0),this.mapping=t.mapping,this.channel=t.channel,this.wrapS=t.wrapS,this.wrapT=t.wrapT,this.magFilter=t.magFilter,this.minFilter=t.minFilter,this.anisotropy=t.anisotropy,this.format=t.format,this.internalFormat=t.internalFormat,this.type=t.type,this.normalized=t.normalized,this.offset.copy(t.offset),this.repeat.copy(t.repeat),this.center.copy(t.center),this.rotation=t.rotation,this.matrixAutoUpdate=t.matrixAutoUpdate,this.matrix.copy(t.matrix),this.generateMipmaps=t.generateMipmaps,this.premultiplyAlpha=t.premultiplyAlpha,this.flipY=t.flipY,this.unpackAlignment=t.unpackAlignment,this.colorSpace=t.colorSpace,this.renderTarget=t.renderTarget,this.isRenderTargetTexture=t.isRenderTargetTexture,this.isArrayTexture=t.isArrayTexture,this.userData=JSON.parse(JSON.stringify(t.userData)),this.needsUpdate=!0,this}setValues(t){for(const e in t){const n=t[e];if(n===void 0){Ut(`Texture.setValues(): parameter '${e}' has value of undefined.`);continue}const i=this[e];if(i===void 0){Ut(`Texture.setValues(): property '${e}' does not exist.`);continue}i&&n&&i.isVector2&&n.isVector2||i&&n&&i.isVector3&&n.isVector3||i&&n&&i.isMatrix3&&n.isMatrix3?i.copy(n):this[e]=n}}toJSON(t){const e=t===void 0||typeof t=="string";if(!e&&t.textures[this.uuid]!==void 0)return t.textures[this.uuid];const n={metadata:{version:4.7,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(t).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,normalized:this.normalized,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(n.userData=this.userData),e||(t.textures[this.uuid]=n),n}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(t){if(this.mapping!==Kc)return t;if(t.applyMatrix3(this.matrix),t.x<0||t.x>1)switch(this.wrapS){case ka:t.x=t.x-Math.floor(t.x);break;case On:t.x=t.x<0?0:1;break;case Ba:Math.abs(Math.floor(t.x)%2)===1?t.x=Math.ceil(t.x)-t.x:t.x=t.x-Math.floor(t.x);break}if(t.y<0||t.y>1)switch(this.wrapT){case ka:t.y=t.y-Math.floor(t.y);break;case On:t.y=t.y<0?0:1;break;case Ba:Math.abs(Math.floor(t.y)%2)===1?t.y=Math.ceil(t.y)-t.y:t.y=t.y-Math.floor(t.y);break}return this.flipY&&(t.y=1-t.y),t}set needsUpdate(t){t===!0&&(this.version++,this.source.needsUpdate=!0)}set needsPMREMUpdate(t){t===!0&&this.pmremVersion++}}Oe.DEFAULT_IMAGE=null;Oe.DEFAULT_MAPPING=Kc;Oe.DEFAULT_ANISOTROPY=1;const $o=class $o{constructor(t=0,e=0,n=0,i=1){this.x=t,this.y=e,this.z=n,this.w=i}get width(){return this.z}set width(t){this.z=t}get height(){return this.w}set height(t){this.w=t}set(t,e,n,i){return this.x=t,this.y=e,this.z=n,this.w=i,this}setScalar(t){return this.x=t,this.y=t,this.z=t,this.w=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setZ(t){return this.z=t,this}setW(t){return this.w=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;case 2:this.z=e;break;case 3:this.w=e;break;default:throw new Error("THREE.Vector4: index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw new Error("THREE.Vector4: index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(t){return this.x=t.x,this.y=t.y,this.z=t.z,this.w=t.w!==void 0?t.w:1,this}add(t){return this.x+=t.x,this.y+=t.y,this.z+=t.z,this.w+=t.w,this}addScalar(t){return this.x+=t,this.y+=t,this.z+=t,this.w+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this.z=t.z+e.z,this.w=t.w+e.w,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this.z+=t.z*e,this.w+=t.w*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this.z-=t.z,this.w-=t.w,this}subScalar(t){return this.x-=t,this.y-=t,this.z-=t,this.w-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this.z=t.z-e.z,this.w=t.w-e.w,this}multiply(t){return this.x*=t.x,this.y*=t.y,this.z*=t.z,this.w*=t.w,this}multiplyScalar(t){return this.x*=t,this.y*=t,this.z*=t,this.w*=t,this}applyMatrix4(t){const e=this.x,n=this.y,i=this.z,r=this.w,a=t.elements;return this.x=a[0]*e+a[4]*n+a[8]*i+a[12]*r,this.y=a[1]*e+a[5]*n+a[9]*i+a[13]*r,this.z=a[2]*e+a[6]*n+a[10]*i+a[14]*r,this.w=a[3]*e+a[7]*n+a[11]*i+a[15]*r,this}divide(t){return this.x/=t.x,this.y/=t.y,this.z/=t.z,this.w/=t.w,this}divideScalar(t){return this.multiplyScalar(1/t)}setAxisAngleFromQuaternion(t){this.w=2*Math.acos(t.w);const e=Math.sqrt(1-t.w*t.w);return e<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=t.x/e,this.y=t.y/e,this.z=t.z/e),this}setAxisAngleFromRotationMatrix(t){let e,n,i,r;const l=t.elements,c=l[0],h=l[4],u=l[8],d=l[1],f=l[5],_=l[9],v=l[2],p=l[6],m=l[10];if(Math.abs(h-d)<.01&&Math.abs(u-v)<.01&&Math.abs(_-p)<.01){if(Math.abs(h+d)<.1&&Math.abs(u+v)<.1&&Math.abs(_+p)<.1&&Math.abs(c+f+m-3)<.1)return this.set(1,0,0,0),this;e=Math.PI;const T=(c+1)/2,y=(f+1)/2,E=(m+1)/2,w=(h+d)/4,R=(u+v)/4,x=(_+p)/4;return T>y&&T>E?T<.01?(n=0,i=.707106781,r=.707106781):(n=Math.sqrt(T),i=w/n,r=R/n):y>E?y<.01?(n=.707106781,i=0,r=.707106781):(i=Math.sqrt(y),n=w/i,r=x/i):E<.01?(n=.707106781,i=.707106781,r=0):(r=Math.sqrt(E),n=R/r,i=x/r),this.set(n,i,r,e),this}let b=Math.sqrt((p-_)*(p-_)+(u-v)*(u-v)+(d-h)*(d-h));return Math.abs(b)<.001&&(b=1),this.x=(p-_)/b,this.y=(u-v)/b,this.z=(d-h)/b,this.w=Math.acos((c+f+m-1)/2),this}setFromMatrixPosition(t){const e=t.elements;return this.x=e[12],this.y=e[13],this.z=e[14],this.w=e[15],this}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this.z=Math.min(this.z,t.z),this.w=Math.min(this.w,t.w),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this.z=Math.max(this.z,t.z),this.w=Math.max(this.w,t.w),this}clamp(t,e){return this.x=qt(this.x,t.x,e.x),this.y=qt(this.y,t.y,e.y),this.z=qt(this.z,t.z,e.z),this.w=qt(this.w,t.w,e.w),this}clampScalar(t,e){return this.x=qt(this.x,t,e),this.y=qt(this.y,t,e),this.z=qt(this.z,t,e),this.w=qt(this.w,t,e),this}clampLength(t,e){const n=this.length();return this.divideScalar(n||1).multiplyScalar(qt(n,t,e))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(t){return this.x*t.x+this.y*t.y+this.z*t.z+this.w*t.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this.z+=(t.z-this.z)*e,this.w+=(t.w-this.w)*e,this}lerpVectors(t,e,n){return this.x=t.x+(e.x-t.x)*n,this.y=t.y+(e.y-t.y)*n,this.z=t.z+(e.z-t.z)*n,this.w=t.w+(e.w-t.w)*n,this}equals(t){return t.x===this.x&&t.y===this.y&&t.z===this.z&&t.w===this.w}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this.z=t[e+2],this.w=t[e+3],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t[e+2]=this.z,t[e+3]=this.w,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this.z=t.getZ(e),this.w=t.getW(e),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}};$o.prototype.isVector4=!0;let _e=$o;class Cu extends Si{constructor(t=1,e=1,n={}){super(),n=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:Ue,depthBuffer:!0,stencilBuffer:!1,resolveColorBuffer:!0,resolveDepthBuffer:!0,resolveStencilBuffer:!0,storeMultisampledColorBuffer:!0,storeMultisampledDepthBuffer:!0,storeMultisampledStencilBuffer:!0,depthTexture:null,samples:0,count:1,depth:1,multiview:!1,useArrayDepthTexture:!1},n),this.isRenderTarget=!0,this.width=t,this.height=e,this.depth=n.depth,this.scissor=new _e(0,0,t,e),this.scissorTest=!1,this.viewport=new _e(0,0,t,e),this.textures=[];const i={width:t,height:e,depth:n.depth},r=new Oe(i),a=n.count;for(let o=0;o<a;o++)this.textures[o]=r.clone(),this.textures[o].isRenderTargetTexture=!0,this.textures[o].renderTarget=this;this._setTextureOptions(n),this.depthBuffer=n.depthBuffer,this.stencilBuffer=n.stencilBuffer,this.resolveColorBuffer=n.resolveColorBuffer,this.resolveDepthBuffer=n.resolveDepthBuffer,this.resolveStencilBuffer=n.resolveStencilBuffer,this.storeMultisampledColorBuffer=n.storeMultisampledColorBuffer,this.storeMultisampledDepthBuffer=n.storeMultisampledDepthBuffer,this.storeMultisampledStencilBuffer=n.storeMultisampledStencilBuffer,this._depthTexture=null,this.depthTexture=n.depthTexture,this.samples=n.samples,this.multiview=n.multiview,this.useArrayDepthTexture=n.useArrayDepthTexture}_setTextureOptions(t={}){const e={minFilter:Ue,generateMipmaps:!1,flipY:!1,internalFormat:null};t.mapping!==void 0&&(e.mapping=t.mapping),t.wrapS!==void 0&&(e.wrapS=t.wrapS),t.wrapT!==void 0&&(e.wrapT=t.wrapT),t.wrapR!==void 0&&(e.wrapR=t.wrapR),t.magFilter!==void 0&&(e.magFilter=t.magFilter),t.minFilter!==void 0&&(e.minFilter=t.minFilter),t.format!==void 0&&(e.format=t.format),t.type!==void 0&&(e.type=t.type),t.anisotropy!==void 0&&(e.anisotropy=t.anisotropy),t.colorSpace!==void 0&&(e.colorSpace=t.colorSpace),t.flipY!==void 0&&(e.flipY=t.flipY),t.generateMipmaps!==void 0&&(e.generateMipmaps=t.generateMipmaps),t.internalFormat!==void 0&&(e.internalFormat=t.internalFormat);for(let n=0;n<this.textures.length;n++)this.textures[n].setValues(e)}get texture(){return this.textures[0]}set texture(t){this.textures[0]=t}set depthTexture(t){this._depthTexture!==null&&this._depthTexture.renderTarget===this&&(this._depthTexture.renderTarget=null),t!==null&&t.renderTarget===null&&(t.renderTarget=this),this._depthTexture=t}get depthTexture(){return this._depthTexture}setSize(t,e,n=1){if(this.width!==t||this.height!==e||this.depth!==n){this.width=t,this.height=e,this.depth=n;for(let i=0,r=this.textures.length;i<r;i++)this.textures[i].image.width=t,this.textures[i].image.height=e,this.textures[i].image.depth=n,this.textures[i].isData3DTexture!==!0&&(this.textures[i].isArrayTexture=this.textures[i].image.depth>1);this.dispose()}this.viewport.set(0,0,t,e),this.scissor.set(0,0,t,e)}clone(){return new this.constructor().copy(this)}copy(t){this.width=t.width,this.height=t.height,this.depth=t.depth,this.scissor.copy(t.scissor),this.scissorTest=t.scissorTest,this.viewport.copy(t.viewport),this.textures.length=0;for(let e=0,n=t.textures.length;e<n;e++){this.textures[e]=t.textures[e].clone(),this.textures[e].isRenderTargetTexture=!0,this.textures[e].renderTarget=this;const i=Object.assign({},t.textures[e].image);this.textures[e].source=new Fo(i)}if(this.depthBuffer=t.depthBuffer,this.stencilBuffer=t.stencilBuffer,this.resolveColorBuffer=t.resolveColorBuffer,this.resolveDepthBuffer=t.resolveDepthBuffer,this.resolveStencilBuffer=t.resolveStencilBuffer,this.storeMultisampledColorBuffer=t.storeMultisampledColorBuffer,this.storeMultisampledDepthBuffer=t.storeMultisampledDepthBuffer,this.storeMultisampledStencilBuffer=t.storeMultisampledStencilBuffer,t.depthTexture!==null)if(t.depthTexture.renderTarget===t){const e=t.depthTexture.clone();e.renderTarget=null,this.depthTexture=e}else this.depthTexture=t.depthTexture;return this.samples=t.samples,this.multiview=t.multiview,this.useArrayDepthTexture=t.useArrayDepthTexture,this}dispose(){this.dispatchEvent({type:"dispose"})}}class gn extends Cu{constructor(t=1,e=1,n={}){super(t,e,n),this.isWebGLRenderTarget=!0}}class ih extends Oe{constructor(t=null,e=1,n=1,i=1){super(null),this.isDataArrayTexture=!0,this.image={data:t,width:e,height:n,depth:i},this.magFilter=Ce,this.minFilter=Ce,this.wrapR=On,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1,this.layerUpdates=new Set}copy(t){return super.copy(t),this.wrapR=t.wrapR,this}addLayerUpdate(t){this.layerUpdates.add(t)}clearLayerUpdates(){this.layerUpdates.clear()}}class Ru extends Oe{constructor(t=null,e=1,n=1,i=1){super(null),this.isData3DTexture=!0,this.image={data:t,width:e,height:n,depth:i},this.magFilter=Ce,this.minFilter=Ce,this.wrapR=On,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}copy(t){return super.copy(t),this.wrapR=t.wrapR,this}}const Dr=class Dr{constructor(t,e,n,i,r,a,o,l,c,h,u,d,f,_,v,p){this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],t!==void 0&&this.set(t,e,n,i,r,a,o,l,c,h,u,d,f,_,v,p)}set(t,e,n,i,r,a,o,l,c,h,u,d,f,_,v,p){const m=this.elements;return m[0]=t,m[4]=e,m[8]=n,m[12]=i,m[1]=r,m[5]=a,m[9]=o,m[13]=l,m[2]=c,m[6]=h,m[10]=u,m[14]=d,m[3]=f,m[7]=_,m[11]=v,m[15]=p,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new Dr().fromArray(this.elements)}copy(t){const e=this.elements,n=t.elements;return e[0]=n[0],e[1]=n[1],e[2]=n[2],e[3]=n[3],e[4]=n[4],e[5]=n[5],e[6]=n[6],e[7]=n[7],e[8]=n[8],e[9]=n[9],e[10]=n[10],e[11]=n[11],e[12]=n[12],e[13]=n[13],e[14]=n[14],e[15]=n[15],this}copyPosition(t){const e=this.elements,n=t.elements;return e[12]=n[12],e[13]=n[13],e[14]=n[14],this}setFromMatrix3(t){const e=t.elements;return this.set(e[0],e[3],e[6],0,e[1],e[4],e[7],0,e[2],e[5],e[8],0,0,0,0,1),this}extractBasis(t,e,n){return this.determinantAffine()===0?(t.set(1,0,0),e.set(0,1,0),n.set(0,0,1),this):(t.setFromMatrixColumn(this,0),e.setFromMatrixColumn(this,1),n.setFromMatrixColumn(this,2),this)}makeBasis(t,e,n){return this.set(t.x,e.x,n.x,0,t.y,e.y,n.y,0,t.z,e.z,n.z,0,0,0,0,1),this}extractRotation(t){if(t.determinantAffine()===0)return this.identity();const e=this.elements,n=t.elements,i=1/Ci.setFromMatrixColumn(t,0).length(),r=1/Ci.setFromMatrixColumn(t,1).length(),a=1/Ci.setFromMatrixColumn(t,2).length();return e[0]=n[0]*i,e[1]=n[1]*i,e[2]=n[2]*i,e[3]=0,e[4]=n[4]*r,e[5]=n[5]*r,e[6]=n[6]*r,e[7]=0,e[8]=n[8]*a,e[9]=n[9]*a,e[10]=n[10]*a,e[11]=0,e[12]=0,e[13]=0,e[14]=0,e[15]=1,this}makeRotationFromEuler(t){const e=this.elements,n=t.x,i=t.y,r=t.z,a=Math.cos(n),o=Math.sin(n),l=Math.cos(i),c=Math.sin(i),h=Math.cos(r),u=Math.sin(r);if(t.order==="XYZ"){const d=a*h,f=a*u,_=o*h,v=o*u;e[0]=l*h,e[4]=-l*u,e[8]=c,e[1]=f+_*c,e[5]=d-v*c,e[9]=-o*l,e[2]=v-d*c,e[6]=_+f*c,e[10]=a*l}else if(t.order==="YXZ"){const d=l*h,f=l*u,_=c*h,v=c*u;e[0]=d+v*o,e[4]=_*o-f,e[8]=a*c,e[1]=a*u,e[5]=a*h,e[9]=-o,e[2]=f*o-_,e[6]=v+d*o,e[10]=a*l}else if(t.order==="ZXY"){const d=l*h,f=l*u,_=c*h,v=c*u;e[0]=d-v*o,e[4]=-a*u,e[8]=_+f*o,e[1]=f+_*o,e[5]=a*h,e[9]=v-d*o,e[2]=-a*c,e[6]=o,e[10]=a*l}else if(t.order==="ZYX"){const d=a*h,f=a*u,_=o*h,v=o*u;e[0]=l*h,e[4]=_*c-f,e[8]=d*c+v,e[1]=l*u,e[5]=v*c+d,e[9]=f*c-_,e[2]=-c,e[6]=o*l,e[10]=a*l}else if(t.order==="YZX"){const d=a*l,f=a*c,_=o*l,v=o*c;e[0]=l*h,e[4]=v-d*u,e[8]=_*u+f,e[1]=u,e[5]=a*h,e[9]=-o*h,e[2]=-c*h,e[6]=f*u+_,e[10]=d-v*u}else if(t.order==="XZY"){const d=a*l,f=a*c,_=o*l,v=o*c;e[0]=l*h,e[4]=-u,e[8]=c*h,e[1]=d*u+v,e[5]=a*h,e[9]=f*u-_,e[2]=_*u-f,e[6]=o*h,e[10]=v*u+d}return e[3]=0,e[7]=0,e[11]=0,e[12]=0,e[13]=0,e[14]=0,e[15]=1,this}makeRotationFromQuaternion(t){return this.compose(Pu,t,Lu)}lookAt(t,e,n){const i=this.elements;return qe.subVectors(t,e),qe.lengthSq()===0&&(qe.z=1),qe.normalize(),$n.crossVectors(n,qe),$n.lengthSq()===0&&(Math.abs(n.z)===1?qe.x+=1e-4:qe.z+=1e-4,qe.normalize(),$n.crossVectors(n,qe)),$n.normalize(),ks.crossVectors(qe,$n),i[0]=$n.x,i[4]=ks.x,i[8]=qe.x,i[1]=$n.y,i[5]=ks.y,i[9]=qe.y,i[2]=$n.z,i[6]=ks.z,i[10]=qe.z,this}multiply(t){return this.multiplyMatrices(this,t)}premultiply(t){return this.multiplyMatrices(t,this)}multiplyMatrices(t,e){const n=t.elements,i=e.elements,r=this.elements,a=n[0],o=n[4],l=n[8],c=n[12],h=n[1],u=n[5],d=n[9],f=n[13],_=n[2],v=n[6],p=n[10],m=n[14],b=n[3],T=n[7],y=n[11],E=n[15],w=i[0],R=i[4],x=i[8],S=i[12],C=i[1],P=i[5],D=i[9],z=i[13],L=i[2],F=i[6],X=i[10],W=i[14],tt=i[3],$=i[7],et=i[11],Z=i[15];return r[0]=a*w+o*C+l*L+c*tt,r[4]=a*R+o*P+l*F+c*$,r[8]=a*x+o*D+l*X+c*et,r[12]=a*S+o*z+l*W+c*Z,r[1]=h*w+u*C+d*L+f*tt,r[5]=h*R+u*P+d*F+f*$,r[9]=h*x+u*D+d*X+f*et,r[13]=h*S+u*z+d*W+f*Z,r[2]=_*w+v*C+p*L+m*tt,r[6]=_*R+v*P+p*F+m*$,r[10]=_*x+v*D+p*X+m*et,r[14]=_*S+v*z+p*W+m*Z,r[3]=b*w+T*C+y*L+E*tt,r[7]=b*R+T*P+y*F+E*$,r[11]=b*x+T*D+y*X+E*et,r[15]=b*S+T*z+y*W+E*Z,this}multiplyScalar(t){const e=this.elements;return e[0]*=t,e[4]*=t,e[8]*=t,e[12]*=t,e[1]*=t,e[5]*=t,e[9]*=t,e[13]*=t,e[2]*=t,e[6]*=t,e[10]*=t,e[14]*=t,e[3]*=t,e[7]*=t,e[11]*=t,e[15]*=t,this}determinant(){const t=this.elements,e=t[0],n=t[4],i=t[8],r=t[12],a=t[1],o=t[5],l=t[9],c=t[13],h=t[2],u=t[6],d=t[10],f=t[14],_=t[3],v=t[7],p=t[11],m=t[15],b=l*f-c*d,T=o*f-c*u,y=o*d-l*u,E=a*f-c*h,w=a*d-l*h,R=a*u-o*h;return e*(v*b-p*T+m*y)-n*(_*b-p*E+m*w)+i*(_*T-v*E+m*R)-r*(_*y-v*w+p*R)}determinantAffine(){const t=this.elements,e=t[0],n=t[4],i=t[8],r=t[1],a=t[5],o=t[9],l=t[2],c=t[6],h=t[10];return e*(a*h-o*c)-n*(r*h-o*l)+i*(r*c-a*l)}transpose(){const t=this.elements;let e;return e=t[1],t[1]=t[4],t[4]=e,e=t[2],t[2]=t[8],t[8]=e,e=t[6],t[6]=t[9],t[9]=e,e=t[3],t[3]=t[12],t[12]=e,e=t[7],t[7]=t[13],t[13]=e,e=t[11],t[11]=t[14],t[14]=e,this}setPosition(t,e,n){const i=this.elements;return t.isVector3?(i[12]=t.x,i[13]=t.y,i[14]=t.z):(i[12]=t,i[13]=e,i[14]=n),this}invert(){const t=this.elements,e=t[0],n=t[1],i=t[2],r=t[3],a=t[4],o=t[5],l=t[6],c=t[7],h=t[8],u=t[9],d=t[10],f=t[11],_=t[12],v=t[13],p=t[14],m=t[15],b=e*o-n*a,T=e*l-i*a,y=e*c-r*a,E=n*l-i*o,w=n*c-r*o,R=i*c-r*l,x=h*v-u*_,S=h*p-d*_,C=h*m-f*_,P=u*p-d*v,D=u*m-f*v,z=d*m-f*p,L=b*z-T*D+y*P+E*C-w*S+R*x;if(L===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);const F=1/L;return t[0]=(o*z-l*D+c*P)*F,t[1]=(i*D-n*z-r*P)*F,t[2]=(v*R-p*w+m*E)*F,t[3]=(d*w-u*R-f*E)*F,t[4]=(l*C-a*z-c*S)*F,t[5]=(e*z-i*C+r*S)*F,t[6]=(p*y-_*R-m*T)*F,t[7]=(h*R-d*y+f*T)*F,t[8]=(a*D-o*C+c*x)*F,t[9]=(n*C-e*D-r*x)*F,t[10]=(_*w-v*y+m*b)*F,t[11]=(u*y-h*w-f*b)*F,t[12]=(o*S-a*P-l*x)*F,t[13]=(e*P-n*S+i*x)*F,t[14]=(v*T-_*E-p*b)*F,t[15]=(h*E-u*T+d*b)*F,this}scale(t){const e=this.elements,n=t.x,i=t.y,r=t.z;return e[0]*=n,e[4]*=i,e[8]*=r,e[1]*=n,e[5]*=i,e[9]*=r,e[2]*=n,e[6]*=i,e[10]*=r,e[3]*=n,e[7]*=i,e[11]*=r,this}getMaxScaleOnAxis(){const t=this.elements,e=t[0]*t[0]+t[1]*t[1]+t[2]*t[2],n=t[4]*t[4]+t[5]*t[5]+t[6]*t[6],i=t[8]*t[8]+t[9]*t[9]+t[10]*t[10];return Math.sqrt(Math.max(e,n,i))}makeTranslation(t,e,n){return t.isVector3?this.set(1,0,0,t.x,0,1,0,t.y,0,0,1,t.z,0,0,0,1):this.set(1,0,0,t,0,1,0,e,0,0,1,n,0,0,0,1),this}makeRotationX(t){const e=Math.cos(t),n=Math.sin(t);return this.set(1,0,0,0,0,e,-n,0,0,n,e,0,0,0,0,1),this}makeRotationY(t){const e=Math.cos(t),n=Math.sin(t);return this.set(e,0,n,0,0,1,0,0,-n,0,e,0,0,0,0,1),this}makeRotationZ(t){const e=Math.cos(t),n=Math.sin(t);return this.set(e,-n,0,0,n,e,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(t,e){const n=Math.cos(e),i=Math.sin(e),r=1-n,a=t.x,o=t.y,l=t.z,c=r*a,h=r*o;return this.set(c*a+n,c*o-i*l,c*l+i*o,0,c*o+i*l,h*o+n,h*l-i*a,0,c*l-i*o,h*l+i*a,r*l*l+n,0,0,0,0,1),this}makeScale(t,e,n){return this.set(t,0,0,0,0,e,0,0,0,0,n,0,0,0,0,1),this}makeShear(t,e,n,i,r,a){return this.set(1,n,r,0,t,1,a,0,e,i,1,0,0,0,0,1),this}compose(t,e,n){const i=this.elements,r=e._x,a=e._y,o=e._z,l=e._w,c=r+r,h=a+a,u=o+o,d=r*c,f=r*h,_=r*u,v=a*h,p=a*u,m=o*u,b=l*c,T=l*h,y=l*u,E=n.x,w=n.y,R=n.z;return i[0]=(1-(v+m))*E,i[1]=(f+y)*E,i[2]=(_-T)*E,i[3]=0,i[4]=(f-y)*w,i[5]=(1-(d+m))*w,i[6]=(p+b)*w,i[7]=0,i[8]=(_+T)*R,i[9]=(p-b)*R,i[10]=(1-(d+v))*R,i[11]=0,i[12]=t.x,i[13]=t.y,i[14]=t.z,i[15]=1,this}decompose(t,e,n){const i=this.elements;t.x=i[12],t.y=i[13],t.z=i[14];const r=this.determinantAffine();if(r===0)return n.set(1,1,1),e.identity(),this;let a=Ci.set(i[0],i[1],i[2]).length();const o=Ci.set(i[4],i[5],i[6]).length(),l=Ci.set(i[8],i[9],i[10]).length();r<0&&(a=-a),ln.copy(this);const c=1/a,h=1/o,u=1/l;return ln.elements[0]*=c,ln.elements[1]*=c,ln.elements[2]*=c,ln.elements[4]*=h,ln.elements[5]*=h,ln.elements[6]*=h,ln.elements[8]*=u,ln.elements[9]*=u,ln.elements[10]*=u,e.setFromRotationMatrix(ln),n.x=a,n.y=o,n.z=l,this}makePerspective(t,e,n,i,r,a,o=Tn,l=!1){const c=this.elements,h=2*r/(e-t),u=2*r/(n-i),d=(e+t)/(e-t),f=(n+i)/(n-i);let _,v;if(l)_=r/(a-r),v=a*r/(a-r);else if(o===Tn)_=-(a+r)/(a-r),v=-2*a*r/(a-r);else if(o===Es)_=-a/(a-r),v=-a*r/(a-r);else throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+o);return c[0]=h,c[4]=0,c[8]=d,c[12]=0,c[1]=0,c[5]=u,c[9]=f,c[13]=0,c[2]=0,c[6]=0,c[10]=_,c[14]=v,c[3]=0,c[7]=0,c[11]=-1,c[15]=0,this}makeOrthographic(t,e,n,i,r,a,o=Tn,l=!1){const c=this.elements,h=2/(e-t),u=2/(n-i),d=-(e+t)/(e-t),f=-(n+i)/(n-i);let _,v;if(l)_=1/(a-r),v=a/(a-r);else if(o===Tn)_=-2/(a-r),v=-(a+r)/(a-r);else if(o===Es)_=-1/(a-r),v=-r/(a-r);else throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+o);return c[0]=h,c[4]=0,c[8]=0,c[12]=d,c[1]=0,c[5]=u,c[9]=0,c[13]=f,c[2]=0,c[6]=0,c[10]=_,c[14]=v,c[3]=0,c[7]=0,c[11]=0,c[15]=1,this}equals(t){const e=this.elements,n=t.elements;for(let i=0;i<16;i++)if(e[i]!==n[i])return!1;return!0}fromArray(t,e=0){for(let n=0;n<16;n++)this.elements[n]=t[n+e];return this}toArray(t=[],e=0){const n=this.elements;return t[e]=n[0],t[e+1]=n[1],t[e+2]=n[2],t[e+3]=n[3],t[e+4]=n[4],t[e+5]=n[5],t[e+6]=n[6],t[e+7]=n[7],t[e+8]=n[8],t[e+9]=n[9],t[e+10]=n[10],t[e+11]=n[11],t[e+12]=n[12],t[e+13]=n[13],t[e+14]=n[14],t[e+15]=n[15],t}};Dr.prototype.isMatrix4=!0;let Zt=Dr;const Ci=new O,ln=new Zt,Pu=new O(0,0,0),Lu=new O(1,1,1),$n=new O,ks=new O,qe=new O,wl=new Zt,El=new sn;class nn{constructor(t=0,e=0,n=0,i=nn.DEFAULT_ORDER){this.isEuler=!0,this._x=t,this._y=e,this._z=n,this._order=i}get x(){return this._x}set x(t){this._x=t,this._onChangeCallback()}get y(){return this._y}set y(t){this._y=t,this._onChangeCallback()}get z(){return this._z}set z(t){this._z=t,this._onChangeCallback()}get order(){return this._order}set order(t){this._order=t,this._onChangeCallback()}set(t,e,n,i=this._order){return this._x=t,this._y=e,this._z=n,this._order=i,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(t){return this._x=t._x,this._y=t._y,this._z=t._z,this._order=t._order,this._onChangeCallback(),this}setFromRotationMatrix(t,e=this._order,n=!0){const i=t.elements,r=i[0],a=i[4],o=i[8],l=i[1],c=i[5],h=i[9],u=i[2],d=i[6],f=i[10];switch(e){case"XYZ":this._y=Math.asin(qt(o,-1,1)),Math.abs(o)<.9999999?(this._x=Math.atan2(-h,f),this._z=Math.atan2(-a,r)):(this._x=Math.atan2(d,c),this._z=0);break;case"YXZ":this._x=Math.asin(-qt(h,-1,1)),Math.abs(h)<.9999999?(this._y=Math.atan2(o,f),this._z=Math.atan2(l,c)):(this._y=Math.atan2(-u,r),this._z=0);break;case"ZXY":this._x=Math.asin(qt(d,-1,1)),Math.abs(d)<.9999999?(this._y=Math.atan2(-u,f),this._z=Math.atan2(-a,c)):(this._y=0,this._z=Math.atan2(l,r));break;case"ZYX":this._y=Math.asin(-qt(u,-1,1)),Math.abs(u)<.9999999?(this._x=Math.atan2(d,f),this._z=Math.atan2(l,r)):(this._x=0,this._z=Math.atan2(-a,c));break;case"YZX":this._z=Math.asin(qt(l,-1,1)),Math.abs(l)<.9999999?(this._x=Math.atan2(-h,c),this._y=Math.atan2(-u,r)):(this._x=0,this._y=Math.atan2(o,f));break;case"XZY":this._z=Math.asin(-qt(a,-1,1)),Math.abs(a)<.9999999?(this._x=Math.atan2(d,c),this._y=Math.atan2(o,r)):(this._x=Math.atan2(-h,f),this._y=0);break;default:Ut("Euler: .setFromRotationMatrix() encountered an unknown order: "+e)}return this._order=e,n===!0&&this._onChangeCallback(),this}setFromQuaternion(t,e,n){return wl.makeRotationFromQuaternion(t),this.setFromRotationMatrix(wl,e,n)}setFromVector3(t,e=this._order){return this.set(t.x,t.y,t.z,e)}reorder(t){return El.setFromEuler(this),this.setFromQuaternion(El,t)}equals(t){return t._x===this._x&&t._y===this._y&&t._z===this._z&&t._order===this._order}fromArray(t){return this._x=t[0],this._y=t[1],this._z=t[2],t[3]!==void 0&&(this._order=t[3]),this._onChangeCallback(),this}toArray(t=[],e=0){return t[e]=this._x,t[e+1]=this._y,t[e+2]=this._z,t[e+3]=this._order,t}_onChange(t){return this._onChangeCallback=t,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}}nn.DEFAULT_ORDER="XYZ";class ko{constructor(){this.mask=1}set(t){this.mask=(1<<t|0)>>>0}enable(t){this.mask|=1<<t|0}enableAll(){this.mask=-1}toggle(t){this.mask^=1<<t|0}disable(t){this.mask&=~(1<<t|0)}disableAll(){this.mask=0}test(t){return(this.mask&t.mask)!==0}isEnabled(t){return(this.mask&(1<<t|0))!==0}}let Du=0;const Tl=new O,Ri=new sn,Dn=new Zt,Bs=new O,ss=new O,Iu=new O,Uu=new sn,Al=new O(1,0,0),Cl=new O(0,1,0),Rl=new O(0,0,1),Pl={type:"added"},Nu={type:"removed"},Pi={type:"childadded",child:null},ta={type:"childremoved",child:null};class Re extends Si{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:Du++}),this.uuid=Cs(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=Re.DEFAULT_UP.clone();const t=new O,e=new nn,n=new sn,i=new O(1,1,1);function r(){n.setFromEuler(e,!1)}function a(){e.setFromQuaternion(n,void 0,!1)}e._onChange(r),n._onChange(a),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:t},rotation:{configurable:!0,enumerable:!0,value:e},quaternion:{configurable:!0,enumerable:!0,value:n},scale:{configurable:!0,enumerable:!0,value:i},modelViewMatrix:{value:new Zt},normalMatrix:{value:new Ft}}),this.matrix=new Zt,this.matrixWorld=new Zt,this.matrixAutoUpdate=Re.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=Re.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new ko,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.customDepthMaterial=void 0,this.customDistanceMaterial=void 0,this.static=!1,this.userData={},this.pivot=null}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(t){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(t),this.matrix.decompose(this.position,this.quaternion,this.scale)}applyQuaternion(t){return this.quaternion.premultiply(t),this}setRotationFromAxisAngle(t,e){this.quaternion.setFromAxisAngle(t,e)}setRotationFromEuler(t){this.quaternion.setFromEuler(t,!0)}setRotationFromMatrix(t){this.quaternion.setFromRotationMatrix(t)}setRotationFromQuaternion(t){this.quaternion.copy(t)}rotateOnAxis(t,e){return Ri.setFromAxisAngle(t,e),this.quaternion.multiply(Ri),this}rotateOnWorldAxis(t,e){return Ri.setFromAxisAngle(t,e),this.quaternion.premultiply(Ri),this}rotateX(t){return this.rotateOnAxis(Al,t)}rotateY(t){return this.rotateOnAxis(Cl,t)}rotateZ(t){return this.rotateOnAxis(Rl,t)}translateOnAxis(t,e){return Tl.copy(t).applyQuaternion(this.quaternion),this.position.add(Tl.multiplyScalar(e)),this}translateX(t){return this.translateOnAxis(Al,t)}translateY(t){return this.translateOnAxis(Cl,t)}translateZ(t){return this.translateOnAxis(Rl,t)}localToWorld(t){return this.updateWorldMatrix(!0,!1),t.applyMatrix4(this.matrixWorld)}worldToLocal(t){return this.updateWorldMatrix(!0,!1),t.applyMatrix4(Dn.copy(this.matrixWorld).invert())}lookAt(t,e,n){t.isVector3?Bs.copy(t):Bs.set(t,e,n);const i=this.parent;this.updateWorldMatrix(!0,!1),ss.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?Dn.lookAt(ss,Bs,this.up):Dn.lookAt(Bs,ss,this.up),this.quaternion.setFromRotationMatrix(Dn),i&&(Dn.extractRotation(i.matrixWorld),Ri.setFromRotationMatrix(Dn),this.quaternion.premultiply(Ri.invert()))}add(t){if(arguments.length>1){for(let e=0;e<arguments.length;e++)this.add(arguments[e]);return this}return t===this?(Kt("Object3D.add: object can't be added as a child of itself.",t),this):(t&&t.isObject3D?(t.removeFromParent(),t.parent=this,this.children.push(t),t.dispatchEvent(Pl),Pi.child=t,this.dispatchEvent(Pi),Pi.child=null):Kt("Object3D.add: object not an instance of THREE.Object3D.",t),this)}remove(t){if(arguments.length>1){for(let n=0;n<arguments.length;n++)this.remove(arguments[n]);return this}const e=this.children.indexOf(t);return e!==-1&&(t.parent=null,this.children.splice(e,1),t.dispatchEvent(Nu),ta.child=t,this.dispatchEvent(ta),ta.child=null),this}removeFromParent(){const t=this.parent;return t!==null&&t.remove(this),this}clear(){return this.remove(...this.children)}attach(t){return this.updateWorldMatrix(!0,!1),Dn.copy(this.matrixWorld).invert(),t.parent!==null&&(t.parent.updateWorldMatrix(!0,!1),Dn.multiply(t.parent.matrixWorld)),t.applyMatrix4(Dn),t.removeFromParent(),t.parent=this,this.children.push(t),t.updateWorldMatrix(!1,!0),t.dispatchEvent(Pl),Pi.child=t,this.dispatchEvent(Pi),Pi.child=null,this}getObjectById(t){return this.getObjectByProperty("id",t)}getObjectByName(t){return this.getObjectByProperty("name",t)}getObjectByProperty(t,e){if(this[t]===e)return this;for(let n=0,i=this.children.length;n<i;n++){const a=this.children[n].getObjectByProperty(t,e);if(a!==void 0)return a}}getObjectsByProperty(t,e,n=[]){this[t]===e&&n.push(this);const i=this.children;for(let r=0,a=i.length;r<a;r++)i[r].getObjectsByProperty(t,e,n);return n}getWorldPosition(t){return this.updateWorldMatrix(!0,!1),t.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(t){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(ss,t,Iu),t}getWorldScale(t){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(ss,Uu,t),t}getWorldDirection(t){this.updateWorldMatrix(!0,!1);const e=this.matrixWorld.elements;return t.set(e[8],e[9],e[10]).normalize()}raycast(){}intersectsFrustum(){}traverse(t){t(this);const e=this.children;for(let n=0,i=e.length;n<i;n++)e[n].traverse(t)}traverseVisible(t){if(this.visible===!1)return;t(this);const e=this.children;for(let n=0,i=e.length;n<i;n++)e[n].traverseVisible(t)}traverseAncestors(t){const e=this.parent;e!==null&&(t(e),e.traverseAncestors(t))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale);const t=this.pivot;if(t!==null){const e=t.x,n=t.y,i=t.z,r=this.matrix.elements;r[12]+=e-r[0]*e-r[4]*n-r[8]*i,r[13]+=n-r[1]*e-r[5]*n-r[9]*i,r[14]+=i-r[2]*e-r[6]*n-r[10]*i}this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(t){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||t)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,t=!0);const e=this.children;for(let n=0,i=e.length;n<i;n++)e[n].updateMatrixWorld(t)}updateWorldMatrix(t,e,n=!1){const i=this.parent;if(t===!0&&i!==null&&i.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||n)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,n=!0),e===!0){const r=this.children;for(let a=0,o=r.length;a<o;a++)r[a].updateWorldMatrix(!1,!0,n)}}toJSON(t){const e=t===void 0||typeof t=="string",n={};e&&(t={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},n.metadata={version:4.7,type:"Object",generator:"Object3D.toJSON"});const i={};i.uuid=this.uuid,i.type=this.type,i.name=this.name,i.castShadow=this.castShadow,i.receiveShadow=this.receiveShadow,i.visible=this.visible,i.frustumCulled=this.frustumCulled,i.renderOrder=this.renderOrder,i.static=this.static,i.matrixAutoUpdate=this.matrixAutoUpdate,Object.keys(this.userData).length>0&&(i.userData=this.userData),i.layers=this.layers.mask,i.matrix=this.matrix.toArray(),i.up=this.up.toArray(),this.pivot!==null&&(i.pivot=this.pivot.toArray()),this.morphTargetDictionary!==void 0&&(i.morphTargetDictionary=Object.assign({},this.morphTargetDictionary)),this.morphTargetInfluences!==void 0&&(i.morphTargetInfluences=this.morphTargetInfluences.slice()),this.isInstancedMesh&&(i.type="InstancedMesh",i.count=this.count,i.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(i.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(i.type="BatchedMesh",i.perObjectFrustumCulled=this.perObjectFrustumCulled,i.sortObjects=this.sortObjects,i.drawRanges=this._drawRanges,i.reservedRanges=this._reservedRanges,i.geometryInfo=this._geometryInfo.map(o=>({...o,boundingBox:o.boundingBox?o.boundingBox.toJSON():void 0,boundingSphere:o.boundingSphere?o.boundingSphere.toJSON():void 0})),i.instanceInfo=this._instanceInfo.map(o=>({...o})),i.availableInstanceIds=this._availableInstanceIds.slice(),i.availableGeometryIds=this._availableGeometryIds.slice(),i.nextIndexStart=this._nextIndexStart,i.nextVertexStart=this._nextVertexStart,i.geometryCount=this._geometryCount,i.maxInstanceCount=this._maxInstanceCount,i.maxVertexCount=this._maxVertexCount,i.maxIndexCount=this._maxIndexCount,i.geometryInitialized=this._geometryInitialized,i.matricesTexture=this._matricesTexture.toJSON(t),i.indirectTexture=this._indirectTexture.toJSON(t),this._colorsTexture!==null&&(i.colorsTexture=this._colorsTexture.toJSON(t)),this.boundingSphere!==null&&(i.boundingSphere=this.boundingSphere.toJSON()),this.boundingBox!==null&&(i.boundingBox=this.boundingBox.toJSON()));function r(o,l){return o[l.uuid]===void 0&&(o[l.uuid]=l.toJSON(t)),l.uuid}if(this.isScene)this.background&&(this.background.isColor?i.background=this.background.toJSON():this.background.isTexture&&(i.background=this.background.toJSON(t).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(i.environment=this.environment.toJSON(t).uuid);else if(this.isMesh||this.isLine||this.isPoints){i.geometry=r(t.geometries,this.geometry);const o=this.geometry.parameters;if(o!==void 0&&o.shapes!==void 0){const l=o.shapes;if(Array.isArray(l))for(let c=0,h=l.length;c<h;c++){const u=l[c];r(t.shapes,u)}else r(t.shapes,l)}}if(this.isSkinnedMesh&&(i.bindMode=this.bindMode,i.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(r(t.skeletons,this.skeleton),i.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){const o=[];for(let l=0,c=this.material.length;l<c;l++)o.push(r(t.materials,this.material[l]));i.material=o}else i.material=r(t.materials,this.material);if(this.children.length>0){i.children=[];for(let o=0;o<this.children.length;o++)i.children.push(this.children[o].toJSON(t).object)}if(this.animations.length>0){i.animations=[];for(let o=0;o<this.animations.length;o++){const l=this.animations[o];i.animations.push(r(t.animations,l))}}if(e){const o=a(t.geometries),l=a(t.materials),c=a(t.textures),h=a(t.images),u=a(t.shapes),d=a(t.skeletons),f=a(t.animations),_=a(t.nodes);o.length>0&&(n.geometries=o),l.length>0&&(n.materials=l),c.length>0&&(n.textures=c),h.length>0&&(n.images=h),u.length>0&&(n.shapes=u),d.length>0&&(n.skeletons=d),f.length>0&&(n.animations=f),_.length>0&&(n.nodes=_)}return n.object=i,n;function a(o){const l=[];for(const c in o){const h=o[c];delete h.metadata,l.push(h)}return l}}clone(t){return new this.constructor().copy(this,t)}copy(t,e=!0){if(this.name=t.name,this.up.copy(t.up),this.position.copy(t.position),this.rotation.order=t.rotation.order,this.quaternion.copy(t.quaternion),this.scale.copy(t.scale),this.pivot=t.pivot!==null?t.pivot.clone():null,this.matrix.copy(t.matrix),this.matrixWorld.copy(t.matrixWorld),this.matrixAutoUpdate=t.matrixAutoUpdate,this.matrixWorldAutoUpdate=t.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=t.matrixWorldNeedsUpdate,this.layers.mask=t.layers.mask,this.visible=t.visible,this.castShadow=t.castShadow,this.receiveShadow=t.receiveShadow,this.frustumCulled=t.frustumCulled,this.renderOrder=t.renderOrder,this.static=t.static,this.animations=t.animations.slice(),this.userData=JSON.parse(JSON.stringify(t.userData)),e===!0)for(let n=0;n<t.children.length;n++){const i=t.children[n];this.add(i.clone())}return this}dispose(){this.dispatchEvent({type:"dispose"})}}Re.DEFAULT_UP=new O(0,1,0);Re.DEFAULT_MATRIX_AUTO_UPDATE=!0;Re.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;class en extends Re{constructor(){super(),this.isGroup=!0,this.type="Group"}}const Fu={type:"move"};class ea{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new en,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new en,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new O,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new O),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new en,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new O,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new O,this._grip.eventsEnabled=!1),this._grip}dispatchEvent(t){return this._targetRay!==null&&this._targetRay.dispatchEvent(t),this._grip!==null&&this._grip.dispatchEvent(t),this._hand!==null&&this._hand.dispatchEvent(t),this}connect(t){if(t&&t.hand){const e=this._hand;if(e)for(const n of t.hand.values())this._getHandJoint(e,n)}return this.dispatchEvent({type:"connected",data:t}),this}disconnect(t){return this.dispatchEvent({type:"disconnected",data:t}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(t,e,n){let i=null,r=null,a=null;const o=this._targetRay,l=this._grip,c=this._hand;if(t&&e.session.visibilityState!=="visible-blurred"){if(c&&t.hand){a=!0;for(const v of t.hand.values()){const p=e.getJointPose(v,n),m=this._getHandJoint(c,v);p!==null&&(m.matrix.fromArray(p.transform.matrix),m.matrix.decompose(m.position,m.rotation,m.scale),m.matrixWorldNeedsUpdate=!0,m.jointRadius=p.radius),m.visible=p!==null}const h=c.joints["index-finger-tip"],u=c.joints["thumb-tip"],d=h.position.distanceTo(u.position),f=.02,_=.005;c.inputState.pinching&&d>f+_?(c.inputState.pinching=!1,this.dispatchEvent({type:"pinchend",handedness:t.handedness,target:this})):!c.inputState.pinching&&d<=f-_&&(c.inputState.pinching=!0,this.dispatchEvent({type:"pinchstart",handedness:t.handedness,target:this}))}else l!==null&&t.gripSpace&&(r=e.getPose(t.gripSpace,n),r!==null&&(l.matrix.fromArray(r.transform.matrix),l.matrix.decompose(l.position,l.rotation,l.scale),l.matrixWorldNeedsUpdate=!0,r.linearVelocity?(l.hasLinearVelocity=!0,l.linearVelocity.copy(r.linearVelocity)):l.hasLinearVelocity=!1,r.angularVelocity?(l.hasAngularVelocity=!0,l.angularVelocity.copy(r.angularVelocity)):l.hasAngularVelocity=!1,l.eventsEnabled&&l.dispatchEvent({type:"gripUpdated",data:t,target:this})));o!==null&&(i=e.getPose(t.targetRaySpace,n),i===null&&r!==null&&(i=r),i!==null&&(o.matrix.fromArray(i.transform.matrix),o.matrix.decompose(o.position,o.rotation,o.scale),o.matrixWorldNeedsUpdate=!0,i.linearVelocity?(o.hasLinearVelocity=!0,o.linearVelocity.copy(i.linearVelocity)):o.hasLinearVelocity=!1,i.angularVelocity?(o.hasAngularVelocity=!0,o.angularVelocity.copy(i.angularVelocity)):o.hasAngularVelocity=!1,this.dispatchEvent(Fu)))}return o!==null&&(o.visible=i!==null),l!==null&&(l.visible=r!==null),c!==null&&(c.visible=a!==null),this}_getHandJoint(t,e){if(t.joints[e.jointName]===void 0){const n=new en;n.matrixAutoUpdate=!1,n.visible=!1,t.joints[e.jointName]=n,t.add(n)}return t.joints[e.jointName]}}const sh={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},Kn={h:0,s:0,l:0},Os={h:0,s:0,l:0};function na(s,t,e){return e<0&&(e+=1),e>1&&(e-=1),e<1/6?s+(t-s)*6*e:e<1/2?t:e<2/3?s+(t-s)*6*(2/3-e):s}class At{constructor(t,e,n){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(t,e,n)}set(t,e,n){if(e===void 0&&n===void 0){const i=t;i&&i.isColor?this.copy(i):typeof i=="number"?this.setHex(i):typeof i=="string"&&this.setStyle(i)}else this.setRGB(t,e,n);return this}setScalar(t){return this.r=t,this.g=t,this.b=t,this}setHex(t,e=He){return t=Math.floor(t),this.r=(t>>16&255)/255,this.g=(t>>8&255)/255,this.b=(t&255)/255,Xt.colorSpaceToWorking(this,e),this}setRGB(t,e,n,i=Xt.workingColorSpace){return this.r=t,this.g=e,this.b=n,Xt.colorSpaceToWorking(this,i),this}setHSL(t,e,n,i=Xt.workingColorSpace){if(t=Su(t,1),e=qt(e,0,1),n=qt(n,0,1),e===0)this.r=this.g=this.b=n;else{const r=n<=.5?n*(1+e):n+e-n*e,a=2*n-r;this.r=na(a,r,t+1/3),this.g=na(a,r,t),this.b=na(a,r,t-1/3)}return Xt.colorSpaceToWorking(this,i),this}setStyle(t,e=He){function n(r){r!==void 0&&parseFloat(r)<1&&Ut("Color: Alpha component of "+t+" will be ignored.")}let i;if(i=/^(\w+)\(([^\)]*)\)/.exec(t)){let r;const a=i[1],o=i[2];switch(a){case"rgb":case"rgba":if(r=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return n(r[4]),this.setRGB(Math.min(255,parseInt(r[1],10))/255,Math.min(255,parseInt(r[2],10))/255,Math.min(255,parseInt(r[3],10))/255,e);if(r=/^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return n(r[4]),this.setRGB(Math.min(100,parseInt(r[1],10))/100,Math.min(100,parseInt(r[2],10))/100,Math.min(100,parseInt(r[3],10))/100,e);break;case"hsl":case"hsla":if(r=/^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return n(r[4]),this.setHSL(parseFloat(r[1])/360,parseFloat(r[2])/100,parseFloat(r[3])/100,e);break;default:Ut("Color: Unknown color model "+t)}}else if(i=/^\#([A-Fa-f\d]+)$/.exec(t)){const r=i[1],a=r.length;if(a===3)return this.setRGB(parseInt(r.charAt(0),16)/15,parseInt(r.charAt(1),16)/15,parseInt(r.charAt(2),16)/15,e);if(a===6)return this.setHex(parseInt(r,16),e);Ut("Color: Invalid hex color "+t)}else if(t&&t.length>0)return this.setColorName(t,e);return this}setColorName(t,e=He){const n=sh[t.toLowerCase()];return n!==void 0?this.setHex(n,e):Ut("Color: Unknown color "+t),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(t){return this.r=t.r,this.g=t.g,this.b=t.b,this}copySRGBToLinear(t){return this.r=Gn(t.r),this.g=Gn(t.g),this.b=Gn(t.b),this}copyLinearToSRGB(t){return this.r=Zi(t.r),this.g=Zi(t.g),this.b=Zi(t.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(t=He){return Xt.workingToColorSpace(Ie.copy(this),t),Math.round(qt(Ie.r*255,0,255))*65536+Math.round(qt(Ie.g*255,0,255))*256+Math.round(qt(Ie.b*255,0,255))}getHexString(t=He){return("000000"+this.getHex(t).toString(16)).slice(-6)}getHSL(t,e=Xt.workingColorSpace){Xt.workingToColorSpace(Ie.copy(this),e);const n=Ie.r,i=Ie.g,r=Ie.b,a=Math.max(n,i,r),o=Math.min(n,i,r);let l,c;const h=(o+a)/2;if(o===a)l=0,c=0;else{const u=a-o;switch(c=h<=.5?u/(a+o):u/(2-a-o),a){case n:l=(i-r)/u+(i<r?6:0);break;case i:l=(r-n)/u+2;break;case r:l=(n-i)/u+4;break}l/=6}return t.h=l,t.s=c,t.l=h,t}getRGB(t,e=Xt.workingColorSpace){return Xt.workingToColorSpace(Ie.copy(this),e),t.r=Ie.r,t.g=Ie.g,t.b=Ie.b,t}getStyle(t=He){Xt.workingToColorSpace(Ie.copy(this),t);const e=Ie.r,n=Ie.g,i=Ie.b;return t!==He?`color(${t} ${e.toFixed(3)} ${n.toFixed(3)} ${i.toFixed(3)})`:`rgb(${Math.round(e*255)},${Math.round(n*255)},${Math.round(i*255)})`}offsetHSL(t,e,n){return this.getHSL(Kn),this.setHSL(Kn.h+t,Kn.s+e,Kn.l+n)}add(t){return this.r+=t.r,this.g+=t.g,this.b+=t.b,this}addColors(t,e){return this.r=t.r+e.r,this.g=t.g+e.g,this.b=t.b+e.b,this}addScalar(t){return this.r+=t,this.g+=t,this.b+=t,this}sub(t){return this.r=Math.max(0,this.r-t.r),this.g=Math.max(0,this.g-t.g),this.b=Math.max(0,this.b-t.b),this}multiply(t){return this.r*=t.r,this.g*=t.g,this.b*=t.b,this}multiplyScalar(t){return this.r*=t,this.g*=t,this.b*=t,this}lerp(t,e){return this.r+=(t.r-this.r)*e,this.g+=(t.g-this.g)*e,this.b+=(t.b-this.b)*e,this}lerpColors(t,e,n){return this.r=t.r+(e.r-t.r)*n,this.g=t.g+(e.g-t.g)*n,this.b=t.b+(e.b-t.b)*n,this}lerpHSL(t,e){this.getHSL(Kn),t.getHSL(Os);const n=Kr(Kn.h,Os.h,e),i=Kr(Kn.s,Os.s,e),r=Kr(Kn.l,Os.l,e);return this.setHSL(n,i,r),this}setFromVector3(t){return this.r=t.x,this.g=t.y,this.b=t.z,this}applyMatrix3(t){const e=this.r,n=this.g,i=this.b,r=t.elements;return this.r=r[0]*e+r[3]*n+r[6]*i,this.g=r[1]*e+r[4]*n+r[7]*i,this.b=r[2]*e+r[5]*n+r[8]*i,this}equals(t){return t.r===this.r&&t.g===this.g&&t.b===this.b}fromArray(t,e=0){return this.r=t[e],this.g=t[e+1],this.b=t[e+2],this}toArray(t=[],e=0){return t[e]=this.r,t[e+1]=this.g,t[e+2]=this.b,t}fromBufferAttribute(t,e){return this.r=t.getX(e),this.g=t.getY(e),this.b=t.getZ(e),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}}const Ie=new At;At.NAMES=sh;class Bo{constructor(t,e=1,n=1e3){this.isFog=!0,this.name="",this.color=new At(t),this.near=e,this.far=n}clone(){return new Bo(this.color,this.near,this.far)}toJSON(){return{type:"Fog",name:this.name,color:this.color.getHex(),near:this.near,far:this.far}}}class rh extends Re{constructor(){super(),this.isScene=!0,this.type="Scene",this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.backgroundRotation=new nn,this.environmentIntensity=1,this.environmentRotation=new nn,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__!="undefined"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}copy(t,e){return super.copy(t,e),t.background!==null&&(this.background=t.background.clone()),t.environment!==null&&(this.environment=t.environment.clone()),t.fog!==null&&(this.fog=t.fog.clone()),this.backgroundBlurriness=t.backgroundBlurriness,this.backgroundIntensity=t.backgroundIntensity,this.backgroundRotation.copy(t.backgroundRotation),this.environmentIntensity=t.environmentIntensity,this.environmentRotation.copy(t.environmentRotation),t.overrideMaterial!==null&&(this.overrideMaterial=t.overrideMaterial.clone()),this.matrixAutoUpdate=t.matrixAutoUpdate,this}toJSON(t){const e=super.toJSON(t);return this.fog!==null&&(e.object.fog=this.fog.toJSON()),e.object.backgroundBlurriness=this.backgroundBlurriness,e.object.backgroundIntensity=this.backgroundIntensity,e.object.backgroundRotation=this.backgroundRotation.toArray(),e.object.environmentIntensity=this.environmentIntensity,e.object.environmentRotation=this.environmentRotation.toArray(),e}}const cn=new O,In=new O,ia=new O,Un=new O,Li=new O,Di=new O,Ll=new O,sa=new O,ra=new O,aa=new O,oa=new _e,la=new _e,ca=new _e;class fn{constructor(t=new O,e=new O,n=new O){this.a=t,this.b=e,this.c=n}static getNormal(t,e,n,i){i.subVectors(n,e),cn.subVectors(t,e),i.cross(cn);const r=i.lengthSq();return r>0?i.multiplyScalar(1/Math.sqrt(r)):i.set(0,0,0)}static getBarycoord(t,e,n,i,r){cn.subVectors(i,e),In.subVectors(n,e),ia.subVectors(t,e);const a=cn.dot(cn),o=cn.dot(In),l=cn.dot(ia),c=In.dot(In),h=In.dot(ia),u=a*c-o*o;if(u===0)return r.set(0,0,0),null;const d=1/u,f=(c*l-o*h)*d,_=(a*h-o*l)*d;return r.set(1-f-_,_,f)}static containsPoint(t,e,n,i){return this.getBarycoord(t,e,n,i,Un)===null?!1:Un.x>=0&&Un.y>=0&&Un.x+Un.y<=1}static getInterpolation(t,e,n,i,r,a,o,l){return this.getBarycoord(t,e,n,i,Un)===null?(l.x=0,l.y=0,"z"in l&&(l.z=0),"w"in l&&(l.w=0),null):(l.setScalar(0),l.addScaledVector(r,Un.x),l.addScaledVector(a,Un.y),l.addScaledVector(o,Un.z),l)}static getInterpolatedAttribute(t,e,n,i,r,a){return oa.setScalar(0),la.setScalar(0),ca.setScalar(0),oa.fromBufferAttribute(t,e),la.fromBufferAttribute(t,n),ca.fromBufferAttribute(t,i),a.setScalar(0),a.addScaledVector(oa,r.x),a.addScaledVector(la,r.y),a.addScaledVector(ca,r.z),a}static isFrontFacing(t,e,n,i){return cn.subVectors(n,e),In.subVectors(t,e),cn.cross(In).dot(i)<0}set(t,e,n){return this.a.copy(t),this.b.copy(e),this.c.copy(n),this}setFromPointsAndIndices(t,e,n,i){return this.a.copy(t[e]),this.b.copy(t[n]),this.c.copy(t[i]),this}setFromAttributeAndIndices(t,e,n,i){return this.a.fromBufferAttribute(t,e),this.b.fromBufferAttribute(t,n),this.c.fromBufferAttribute(t,i),this}clone(){return new this.constructor().copy(this)}copy(t){return this.a.copy(t.a),this.b.copy(t.b),this.c.copy(t.c),this}getArea(){return cn.subVectors(this.c,this.b),In.subVectors(this.a,this.b),cn.cross(In).length()*.5}getMidpoint(t){return t.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(t){return fn.getNormal(this.a,this.b,this.c,t)}getPlane(t){return t.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(t,e){return fn.getBarycoord(t,this.a,this.b,this.c,e)}getInterpolation(t,e,n,i,r){return fn.getInterpolation(t,this.a,this.b,this.c,e,n,i,r)}containsPoint(t){return fn.containsPoint(t,this.a,this.b,this.c)}isFrontFacing(t){return fn.isFrontFacing(this.a,this.b,this.c,t)}intersectsBox(t){return t.intersectsTriangle(this)}closestPointToPoint(t,e){const n=this.a,i=this.b,r=this.c;let a,o;Li.subVectors(i,n),Di.subVectors(r,n),sa.subVectors(t,n);const l=Li.dot(sa),c=Di.dot(sa);if(l<=0&&c<=0)return e.copy(n);ra.subVectors(t,i);const h=Li.dot(ra),u=Di.dot(ra);if(h>=0&&u<=h)return e.copy(i);const d=l*u-h*c;if(d<=0&&l>=0&&h<=0)return a=l/(l-h),e.copy(n).addScaledVector(Li,a);aa.subVectors(t,r);const f=Li.dot(aa),_=Di.dot(aa);if(_>=0&&f<=_)return e.copy(r);const v=f*c-l*_;if(v<=0&&c>=0&&_<=0)return o=c/(c-_),e.copy(n).addScaledVector(Di,o);const p=h*_-f*u;if(p<=0&&u-h>=0&&f-_>=0)return Ll.subVectors(r,i),o=(u-h)/(u-h+(f-_)),e.copy(i).addScaledVector(Ll,o);const m=1/(p+v+d);return a=v*m,o=d*m,e.copy(n).addScaledVector(Li,a).addScaledVector(Di,o)}equals(t){return t.a.equals(this.a)&&t.b.equals(this.b)&&t.c.equals(this.c)}}class wi{constructor(t=new O(1/0,1/0,1/0),e=new O(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=t,this.max=e}set(t,e){return this.min.copy(t),this.max.copy(e),this}setFromArray(t){this.makeEmpty();for(let e=0,n=t.length;e<n;e+=3)this.expandByPoint(hn.fromArray(t,e));return this}setFromBufferAttribute(t){this.makeEmpty();for(let e=0,n=t.count;e<n;e++)this.expandByPoint(hn.fromBufferAttribute(t,e));return this}setFromPoints(t){this.makeEmpty();for(let e=0,n=t.length;e<n;e++)this.expandByPoint(t[e]);return this}setFromCenterAndSize(t,e){const n=hn.copy(e).multiplyScalar(.5);return this.min.copy(t).sub(n),this.max.copy(t).add(n),this}setFromObject(t,e=!1){return this.makeEmpty(),this.expandByObject(t,e)}clone(){return new this.constructor().copy(this)}copy(t){return this.min.copy(t.min),this.max.copy(t.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(t){return this.isEmpty()?t.set(0,0,0):t.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(t){return this.isEmpty()?t.set(0,0,0):t.subVectors(this.max,this.min)}expandByPoint(t){return this.min.min(t),this.max.max(t),this}expandByVector(t){return this.min.sub(t),this.max.add(t),this}expandByScalar(t){return this.min.addScalar(-t),this.max.addScalar(t),this}expandByObject(t,e=!1){t.updateWorldMatrix(!1,!1);const n=t.geometry;if(n!==void 0){const r=n.getAttribute("position");if(e===!0&&r!==void 0&&t.isInstancedMesh!==!0)for(let a=0,o=r.count;a<o;a++)t.isMesh===!0?t.getVertexPosition(a,hn):hn.fromBufferAttribute(r,a),hn.applyMatrix4(t.matrixWorld),this.expandByPoint(hn);else t.boundingBox!==void 0?(t.boundingBox===null&&t.computeBoundingBox(),zs.copy(t.boundingBox)):(n.boundingBox===null&&n.computeBoundingBox(),zs.copy(n.boundingBox)),zs.applyMatrix4(t.matrixWorld),this.union(zs)}const i=t.children;for(let r=0,a=i.length;r<a;r++)this.expandByObject(i[r],e);return this}containsPoint(t){return t.x>=this.min.x&&t.x<=this.max.x&&t.y>=this.min.y&&t.y<=this.max.y&&t.z>=this.min.z&&t.z<=this.max.z}containsBox(t){return this.min.x<=t.min.x&&t.max.x<=this.max.x&&this.min.y<=t.min.y&&t.max.y<=this.max.y&&this.min.z<=t.min.z&&t.max.z<=this.max.z}getParameter(t,e){return e.set((t.x-this.min.x)/(this.max.x-this.min.x),(t.y-this.min.y)/(this.max.y-this.min.y),(t.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(t){return t.max.x>=this.min.x&&t.min.x<=this.max.x&&t.max.y>=this.min.y&&t.min.y<=this.max.y&&t.max.z>=this.min.z&&t.min.z<=this.max.z}intersectsSphere(t){return this.clampPoint(t.center,hn),hn.distanceToSquared(t.center)<=t.radius*t.radius}intersectsPlane(t){let e,n;return t.normal.x>0?(e=t.normal.x*this.min.x,n=t.normal.x*this.max.x):(e=t.normal.x*this.max.x,n=t.normal.x*this.min.x),t.normal.y>0?(e+=t.normal.y*this.min.y,n+=t.normal.y*this.max.y):(e+=t.normal.y*this.max.y,n+=t.normal.y*this.min.y),t.normal.z>0?(e+=t.normal.z*this.min.z,n+=t.normal.z*this.max.z):(e+=t.normal.z*this.max.z,n+=t.normal.z*this.min.z),e<=-t.constant&&n>=-t.constant}intersectsTriangle(t){if(this.isEmpty())return!1;this.getCenter(rs),Gs.subVectors(this.max,rs),Ii.subVectors(t.a,rs),Ui.subVectors(t.b,rs),Ni.subVectors(t.c,rs),Zn.subVectors(Ui,Ii),Jn.subVectors(Ni,Ui),ci.subVectors(Ii,Ni);let e=[0,-Zn.z,Zn.y,0,-Jn.z,Jn.y,0,-ci.z,ci.y,Zn.z,0,-Zn.x,Jn.z,0,-Jn.x,ci.z,0,-ci.x,-Zn.y,Zn.x,0,-Jn.y,Jn.x,0,-ci.y,ci.x,0];return!ha(e,Ii,Ui,Ni,Gs)||(e=[1,0,0,0,1,0,0,0,1],!ha(e,Ii,Ui,Ni,Gs))?!1:(Hs.crossVectors(Zn,Jn),e=[Hs.x,Hs.y,Hs.z],ha(e,Ii,Ui,Ni,Gs))}clampPoint(t,e){return e.copy(t).clamp(this.min,this.max)}distanceToPoint(t){return this.clampPoint(t,hn).distanceTo(t)}getBoundingSphere(t){return this.isEmpty()?t.makeEmpty():(this.getCenter(t.center),t.radius=this.getSize(hn).length()*.5),t}intersect(t){return this.min.max(t.min),this.max.min(t.max),this.isEmpty()&&this.makeEmpty(),this}union(t){return this.min.min(t.min),this.max.max(t.max),this}applyMatrix4(t){return this.isEmpty()?this:(Nn[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(t),Nn[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(t),Nn[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(t),Nn[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(t),Nn[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(t),Nn[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(t),Nn[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(t),Nn[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(t),this.setFromPoints(Nn),this)}translate(t){return this.min.add(t),this.max.add(t),this}equals(t){return t.min.equals(this.min)&&t.max.equals(this.max)}toJSON(){return{min:this.min.toArray(),max:this.max.toArray()}}fromJSON(t){return this.min.fromArray(t.min),this.max.fromArray(t.max),this}}const Nn=[new O,new O,new O,new O,new O,new O,new O,new O],hn=new O,zs=new wi,Ii=new O,Ui=new O,Ni=new O,Zn=new O,Jn=new O,ci=new O,rs=new O,Gs=new O,Hs=new O,hi=new O;function ha(s,t,e,n,i){for(let r=0,a=s.length-3;r<=a;r+=3){hi.fromArray(s,r);const o=i.x*Math.abs(hi.x)+i.y*Math.abs(hi.y)+i.z*Math.abs(hi.z),l=t.dot(hi),c=e.dot(hi),h=n.dot(hi);if(Math.max(-Math.max(l,c,h),Math.min(l,c,h))>o)return!1}return!0}const ye=new O,Vs=new Bt;let ku=0;class Cn extends Si{constructor(t,e,n=!1){if(super(),Array.isArray(t))throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,Object.defineProperty(this,"id",{value:ku++}),this.name="",this.array=t,this.itemSize=e,this.count=t!==void 0?t.length/e:0,this.normalized=n,this.usage=xu,this.updateRanges=[],this.gpuType=pn,this.version=0}onUploadCallback(){}set needsUpdate(t){t===!0&&this.version++}setUsage(t){return this.usage=t,this}addUpdateRange(t,e){this.updateRanges.push({start:t,count:e})}clearUpdateRanges(){this.updateRanges.length=0}copy(t){return this.name=t.name,this.array=new t.array.constructor(t.array),this.itemSize=t.itemSize,this.count=t.count,this.normalized=t.normalized,this.usage=t.usage,this.gpuType=t.gpuType,this}copyAt(t,e,n){t*=this.itemSize,n*=e.itemSize;for(let i=0,r=this.itemSize;i<r;i++)this.array[t+i]=e.array[n+i];return this}copyArray(t){return this.array.set(t),this}applyMatrix3(t){if(this.itemSize===2)for(let e=0,n=this.count;e<n;e++)Vs.fromBufferAttribute(this,e),Vs.applyMatrix3(t),this.setXY(e,Vs.x,Vs.y);else if(this.itemSize===3)for(let e=0,n=this.count;e<n;e++)ye.fromBufferAttribute(this,e),ye.applyMatrix3(t),this.setXYZ(e,ye.x,ye.y,ye.z);return this}applyMatrix4(t){for(let e=0,n=this.count;e<n;e++)ye.fromBufferAttribute(this,e),ye.applyMatrix4(t),this.setXYZ(e,ye.x,ye.y,ye.z);return this}applyNormalMatrix(t){for(let e=0,n=this.count;e<n;e++)ye.fromBufferAttribute(this,e),ye.applyNormalMatrix(t),this.setXYZ(e,ye.x,ye.y,ye.z);return this}transformDirection(t){for(let e=0,n=this.count;e<n;e++)ye.fromBufferAttribute(this,e),ye.transformDirection(t),this.setXYZ(e,ye.x,ye.y,ye.z);return this}set(t,e=0){return this.array.set(t,e),this}getComponent(t,e){let n=this.array[t*this.itemSize+e];return this.normalized&&(n=is(n,this.array)),n}setComponent(t,e,n){return this.normalized&&(n=Ge(n,this.array)),this.array[t*this.itemSize+e]=n,this}getX(t){let e=this.array[t*this.itemSize];return this.normalized&&(e=is(e,this.array)),e}setX(t,e){return this.normalized&&(e=Ge(e,this.array)),this.array[t*this.itemSize]=e,this}getY(t){let e=this.array[t*this.itemSize+1];return this.normalized&&(e=is(e,this.array)),e}setY(t,e){return this.normalized&&(e=Ge(e,this.array)),this.array[t*this.itemSize+1]=e,this}getZ(t){let e=this.array[t*this.itemSize+2];return this.normalized&&(e=is(e,this.array)),e}setZ(t,e){return this.normalized&&(e=Ge(e,this.array)),this.array[t*this.itemSize+2]=e,this}getW(t){let e=this.array[t*this.itemSize+3];return this.normalized&&(e=is(e,this.array)),e}setW(t,e){return this.normalized&&(e=Ge(e,this.array)),this.array[t*this.itemSize+3]=e,this}setXY(t,e,n){return t*=this.itemSize,this.normalized&&(e=Ge(e,this.array),n=Ge(n,this.array)),this.array[t+0]=e,this.array[t+1]=n,this}setXYZ(t,e,n,i){return t*=this.itemSize,this.normalized&&(e=Ge(e,this.array),n=Ge(n,this.array),i=Ge(i,this.array)),this.array[t+0]=e,this.array[t+1]=n,this.array[t+2]=i,this}setXYZW(t,e,n,i,r){return t*=this.itemSize,this.normalized&&(e=Ge(e,this.array),n=Ge(n,this.array),i=Ge(i,this.array),r=Ge(r,this.array)),this.array[t+0]=e,this.array[t+1]=n,this.array[t+2]=i,this.array[t+3]=r,this}onUpload(t){return this.onUploadCallback=t,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){const t={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return t.name=this.name,t.usage=this.usage,t.gpuType=this.gpuType,t}dispose(){this.dispatchEvent({type:"dispose"})}}class ah extends Cn{constructor(t,e,n){super(new Uint16Array(t),e,n)}}class oh extends Cn{constructor(t,e,n){super(new Uint32Array(t),e,n)}}class ee extends Cn{constructor(t,e,n){super(new Float32Array(t),e,n)}}const Bu=new wi,as=new O,da=new O;class Rs{constructor(t=new O,e=-1){this.isSphere=!0,this.center=t,this.radius=e}set(t,e){return this.center.copy(t),this.radius=e,this}setFromPoints(t,e){const n=this.center;e!==void 0?n.copy(e):Bu.setFromPoints(t).getCenter(n);let i=0;for(let r=0,a=t.length;r<a;r++)i=Math.max(i,n.distanceToSquared(t[r]));return this.radius=Math.sqrt(i),this}copy(t){return this.center.copy(t.center),this.radius=t.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(t){return t.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(t){return t.distanceTo(this.center)-this.radius}intersectsSphere(t){const e=this.radius+t.radius;return t.center.distanceToSquared(this.center)<=e*e}intersectsBox(t){return t.intersectsSphere(this)}intersectsPlane(t){return Math.abs(t.distanceToPoint(this.center))<=this.radius}clampPoint(t,e){const n=this.center.distanceToSquared(t);return e.copy(t),n>this.radius*this.radius&&(e.sub(this.center).normalize(),e.multiplyScalar(this.radius).add(this.center)),e}getBoundingBox(t){return this.isEmpty()?(t.makeEmpty(),t):(t.set(this.center,this.center),t.expandByScalar(this.radius),t)}applyMatrix4(t){return this.center.applyMatrix4(t),this.radius=this.radius*t.getMaxScaleOnAxis(),this}translate(t){return this.center.add(t),this}expandByPoint(t){if(this.isEmpty())return this.center.copy(t),this.radius=0,this;as.subVectors(t,this.center);const e=as.lengthSq();if(e>this.radius*this.radius){const n=Math.sqrt(e),i=(n-this.radius)*.5;this.center.addScaledVector(as,i/n),this.radius+=i}return this}union(t){return t.isEmpty()?this:this.isEmpty()?(this.copy(t),this):(this.center.equals(t.center)===!0?this.radius=Math.max(this.radius,t.radius):(da.subVectors(t.center,this.center).setLength(t.radius),this.expandByPoint(as.copy(t.center).add(da)),this.expandByPoint(as.copy(t.center).sub(da))),this)}equals(t){return t.center.equals(this.center)&&t.radius===this.radius}clone(){return new this.constructor().copy(this)}toJSON(){return{radius:this.radius,center:this.center.toArray()}}fromJSON(t){return this.radius=t.radius,this.center.fromArray(t.center),this}}let Ou=0;const Qe=new Zt,ua=new Re,Fi=new O,Ye=new wi,os=new wi,Te=new O;class Ae extends Si{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:Ou++}),this.uuid=Cs(),this.name="",this.type="BufferGeometry",this.index=null,this.indirect=null,this.indirectOffset=0,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={},this._transformed=!1}getIndex(){return this.index}setIndex(t){return Array.isArray(t)?this.index=new(vu(t)?oh:ah)(t,1):this.index=t,this}setIndirect(t,e=0){return this.indirect=t,this.indirectOffset=e,this}getIndirect(){return this.indirect}getAttribute(t){return this.attributes[t]}setAttribute(t,e){return this.attributes[t]=e,this}deleteAttribute(t){return delete this.attributes[t],this}hasAttribute(t){return this.attributes[t]!==void 0}addGroup(t,e,n=0){this.groups.push({start:t,count:e,materialIndex:n})}clearGroups(){this.groups=[]}setDrawRange(t,e){this.drawRange.start=t,this.drawRange.count=e}applyMatrix4(t){const e=this.attributes.position;e!==void 0&&(e.applyMatrix4(t),e.needsUpdate=!0);const n=this.attributes.normal;if(n!==void 0){const r=new Ft().getNormalMatrix(t);n.applyNormalMatrix(r),n.needsUpdate=!0}const i=this.attributes.tangent;return i!==void 0&&(i.transformDirection(t),i.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this._transformed=!0,this}applyQuaternion(t){return Qe.makeRotationFromQuaternion(t),this.applyMatrix4(Qe),this}rotateX(t){return Qe.makeRotationX(t),this.applyMatrix4(Qe),this}rotateY(t){return Qe.makeRotationY(t),this.applyMatrix4(Qe),this}rotateZ(t){return Qe.makeRotationZ(t),this.applyMatrix4(Qe),this}translate(t,e,n){return Qe.makeTranslation(t,e,n),this.applyMatrix4(Qe),this}scale(t,e,n){return Qe.makeScale(t,e,n),this.applyMatrix4(Qe),this}lookAt(t){return ua.lookAt(t),ua.updateMatrix(),this.applyMatrix4(ua.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(Fi).negate(),this.translate(Fi.x,Fi.y,Fi.z),this}setFromPoints(t){const e=this.getAttribute("position");if(e===void 0){const n=[];for(let i=0,r=t.length;i<r;i++){const a=t[i];n.push(a.x,a.y,a.z||0)}this.setAttribute("position",new ee(n,3))}else{const n=Math.min(t.length,e.count);for(let i=0;i<n;i++){const r=t[i];e.setXYZ(i,r.x,r.y,r.z||0)}t.length>e.count&&Ut("BufferGeometry: Buffer size too small for points data. Use .dispose() and create a new geometry."),e.needsUpdate=!0}return this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new wi);const t=this.attributes.position,e=this.morphAttributes.position;if(t&&t.isGLBufferAttribute){Kt("BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box.",this),this.boundingBox.set(new O(-1/0,-1/0,-1/0),new O(1/0,1/0,1/0));return}if(t!==void 0){if(this.boundingBox.setFromBufferAttribute(t),e)for(let n=0,i=e.length;n<i;n++){const r=e[n];Ye.setFromBufferAttribute(r),this.morphTargetsRelative?(Te.addVectors(this.boundingBox.min,Ye.min),this.boundingBox.expandByPoint(Te),Te.addVectors(this.boundingBox.max,Ye.max),this.boundingBox.expandByPoint(Te)):(this.boundingBox.expandByPoint(Ye.min),this.boundingBox.expandByPoint(Ye.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&Kt('BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new Rs);const t=this.attributes.position,e=this.morphAttributes.position;if(t&&t.isGLBufferAttribute){Kt("BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere.",this),this.boundingSphere.set(new O,1/0);return}if(t){const n=this.boundingSphere.center;if(Ye.setFromBufferAttribute(t),e)for(let r=0,a=e.length;r<a;r++){const o=e[r];os.setFromBufferAttribute(o),this.morphTargetsRelative?(Te.addVectors(Ye.min,os.min),Ye.expandByPoint(Te),Te.addVectors(Ye.max,os.max),Ye.expandByPoint(Te)):(Ye.expandByPoint(os.min),Ye.expandByPoint(os.max))}Ye.getCenter(n);let i=0;for(let r=0,a=t.count;r<a;r++)Te.fromBufferAttribute(t,r),i=Math.max(i,n.distanceToSquared(Te));if(e)for(let r=0,a=e.length;r<a;r++){const o=e[r],l=this.morphTargetsRelative;for(let c=0,h=o.count;c<h;c++)Te.fromBufferAttribute(o,c),l&&(Fi.fromBufferAttribute(t,c),Te.add(Fi)),i=Math.max(i,n.distanceToSquared(Te))}this.boundingSphere.radius=Math.sqrt(i),isNaN(this.boundingSphere.radius)&&Kt('BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){const t=this.index,e=this.attributes;if(t===null||e.position===void 0||e.normal===void 0||e.uv===void 0){Kt("BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");return}const n=e.position,i=e.normal,r=e.uv;let a=this.getAttribute("tangent");(a===void 0||a.count!==n.count)&&(a=new Cn(new Float32Array(4*n.count),4),this.setAttribute("tangent",a));const o=[],l=[];for(let x=0;x<n.count;x++)o[x]=new O,l[x]=new O;const c=new O,h=new O,u=new O,d=new Bt,f=new Bt,_=new Bt,v=new O,p=new O;function m(x,S,C){c.fromBufferAttribute(n,x),h.fromBufferAttribute(n,S),u.fromBufferAttribute(n,C),d.fromBufferAttribute(r,x),f.fromBufferAttribute(r,S),_.fromBufferAttribute(r,C),h.sub(c),u.sub(c),f.sub(d),_.sub(d);const P=1/(f.x*_.y-_.x*f.y);isFinite(P)&&(v.copy(h).multiplyScalar(_.y).addScaledVector(u,-f.y).multiplyScalar(P),p.copy(u).multiplyScalar(f.x).addScaledVector(h,-_.x).multiplyScalar(P),o[x].add(v),o[S].add(v),o[C].add(v),l[x].add(p),l[S].add(p),l[C].add(p))}let b=this.groups;b.length===0&&(b=[{start:0,count:t.count}]);for(let x=0,S=b.length;x<S;++x){const C=b[x],P=C.start,D=C.count;for(let z=P,L=P+D;z<L;z+=3)m(t.getX(z+0),t.getX(z+1),t.getX(z+2))}const T=new O,y=new O,E=new O,w=new O;function R(x){E.fromBufferAttribute(i,x),w.copy(E);const S=o[x];T.copy(S),T.sub(E.multiplyScalar(E.dot(S))).normalize(),y.crossVectors(w,S);const P=y.dot(l[x])<0?-1:1;a.setXYZW(x,T.x,T.y,T.z,P)}for(let x=0,S=b.length;x<S;++x){const C=b[x],P=C.start,D=C.count;for(let z=P,L=P+D;z<L;z+=3)R(t.getX(z+0)),R(t.getX(z+1)),R(t.getX(z+2))}this._transformed=!0}computeVertexNormals(){const t=this.index,e=this.getAttribute("position");if(e!==void 0){let n=this.getAttribute("normal");if(n===void 0||n.count!==e.count)n=new Cn(new Float32Array(e.count*3),3),this.setAttribute("normal",n);else for(let d=0,f=n.count;d<f;d++)n.setXYZ(d,0,0,0);const i=new O,r=new O,a=new O,o=new O,l=new O,c=new O,h=new O,u=new O;if(t)for(let d=0,f=t.count;d<f;d+=3){const _=t.getX(d+0),v=t.getX(d+1),p=t.getX(d+2);i.fromBufferAttribute(e,_),r.fromBufferAttribute(e,v),a.fromBufferAttribute(e,p),h.subVectors(a,r),u.subVectors(i,r),h.cross(u),o.fromBufferAttribute(n,_),l.fromBufferAttribute(n,v),c.fromBufferAttribute(n,p),o.add(h),l.add(h),c.add(h),n.setXYZ(_,o.x,o.y,o.z),n.setXYZ(v,l.x,l.y,l.z),n.setXYZ(p,c.x,c.y,c.z)}else for(let d=0,f=e.count;d<f;d+=3)i.fromBufferAttribute(e,d+0),r.fromBufferAttribute(e,d+1),a.fromBufferAttribute(e,d+2),h.subVectors(a,r),u.subVectors(i,r),h.cross(u),n.setXYZ(d+0,h.x,h.y,h.z),n.setXYZ(d+1,h.x,h.y,h.z),n.setXYZ(d+2,h.x,h.y,h.z);this.normalizeNormals(),n.needsUpdate=!0}}normalizeNormals(){const t=this.attributes.normal;for(let e=0,n=t.count;e<n;e++)Te.fromBufferAttribute(t,e),Te.normalize(),t.setXYZ(e,Te.x,Te.y,Te.z)}toNonIndexed(){function t(o,l){const c=o.array,h=o.itemSize,u=o.normalized,d=new c.constructor(l.length*h);let f=0,_=0;for(let v=0,p=l.length;v<p;v++){o.isInterleavedBufferAttribute?f=l[v]*o.data.stride+o.offset:f=l[v]*h;for(let m=0;m<h;m++)d[_++]=c[f++]}return new Cn(d,h,u)}if(this.index===null)return Ut("BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;const e=new Ae,n=this.index.array,i=this.attributes;for(const o in i){const l=i[o],c=t(l,n);e.setAttribute(o,c)}const r=this.morphAttributes;for(const o in r){const l=[],c=r[o];for(let h=0,u=c.length;h<u;h++){const d=c[h],f=t(d,n);l.push(f)}e.morphAttributes[o]=l}e.morphTargetsRelative=this.morphTargetsRelative;const a=this.groups;for(let o=0,l=a.length;o<l;o++){const c=a[o];e.addGroup(c.start,c.count,c.materialIndex)}return e}toJSON(){const t={metadata:{version:4.7,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(t.uuid=this.uuid,t.type=this.parameters!==void 0&&this._transformed===!0?"BufferGeometry":this.type,t.name=this.name,Object.keys(this.userData).length>0&&(t.userData=this.userData),this.parameters!==void 0&&this._transformed!==!0){const l=this.parameters;for(const c in l)l[c]!==void 0&&(t[c]=l[c]);return t}t.data={attributes:{}};const e=this.index;e!==null&&(t.data.index={type:e.array.constructor.name,array:Array.prototype.slice.call(e.array)});const n=this.attributes;for(const l in n){const c=n[l];t.data.attributes[l]=c.toJSON(t.data)}const i={};let r=!1;for(const l in this.morphAttributes){const c=this.morphAttributes[l],h=[];for(let u=0,d=c.length;u<d;u++){const f=c[u];h.push(f.toJSON(t.data))}h.length>0&&(i[l]=h,r=!0)}r&&(t.data.morphAttributes=i,t.data.morphTargetsRelative=this.morphTargetsRelative);const a=this.groups;a.length>0&&(t.data.groups=JSON.parse(JSON.stringify(a)));const o=this.boundingSphere;return o!==null&&(t.data.boundingSphere=o.toJSON()),t}clone(){return new this.constructor().copy(this)}copy(t){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;const e={};this.name=t.name;const n=t.index;n!==null&&this.setIndex(n.clone());const i=t.attributes;for(const c in i){const h=i[c];this.setAttribute(c,h.clone(e))}const r=t.morphAttributes;for(const c in r){const h=[],u=r[c];for(let d=0,f=u.length;d<f;d++)h.push(u[d].clone(e));this.morphAttributes[c]=h}this.morphTargetsRelative=t.morphTargetsRelative;const a=t.groups;for(let c=0,h=a.length;c<h;c++){const u=a[c];this.addGroup(u.start,u.count,u.materialIndex)}const o=t.boundingBox;o!==null&&(this.boundingBox=o.clone());const l=t.boundingSphere;return l!==null&&(this.boundingSphere=l.clone()),this.drawRange.start=t.drawRange.start,this.drawRange.count=t.drawRange.count,this.userData=t.userData,this._transformed=t._transformed,this}dispose(){this.dispatchEvent({type:"dispose"})}}const fa=new O,zu=new O,Gu=new Ft;class ni{constructor(t=new O(1,0,0),e=0){this.isPlane=!0,this.normal=t,this.constant=e}set(t,e){return this.normal.copy(t),this.constant=e,this}setComponents(t,e,n,i){return this.normal.set(t,e,n),this.constant=i,this}setFromNormalAndCoplanarPoint(t,e){return this.normal.copy(t),this.constant=-e.dot(this.normal),this}setFromCoplanarPoints(t,e,n){const i=fa.subVectors(n,e).cross(zu.subVectors(t,e)).normalize();return this.setFromNormalAndCoplanarPoint(i,t),this}copy(t){return this.normal.copy(t.normal),this.constant=t.constant,this}normalize(){const t=1/this.normal.length();return this.normal.multiplyScalar(t),this.constant*=t,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(t){return this.normal.dot(t)+this.constant}distanceToSphere(t){return this.distanceToPoint(t.center)-t.radius}projectPoint(t,e){return e.copy(t).addScaledVector(this.normal,-this.distanceToPoint(t))}intersectLine(t,e,n=!0){const i=t.delta(fa),r=this.normal.dot(i);if(r===0)return this.distanceToPoint(t.start)===0?e.copy(t.start):null;const a=-(t.start.dot(this.normal)+this.constant)/r;return n===!0&&(a<0||a>1)?null:e.copy(t.start).addScaledVector(i,a)}intersectsLine(t){const e=this.distanceToPoint(t.start),n=this.distanceToPoint(t.end);return e<0&&n>0||n<0&&e>0}intersectsBox(t){return t.intersectsPlane(this)}intersectsSphere(t){return t.intersectsPlane(this)}coplanarPoint(t){return t.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(t,e){const n=e||Gu.getNormalMatrix(t),i=this.coplanarPoint(fa).applyMatrix4(t),r=this.normal.applyMatrix3(n).normalize();return this.constant=-i.dot(r),this}translate(t){return this.constant-=t.dot(this.normal),this}equals(t){return t.normal.equals(this.normal)&&t.constant===this.constant}clone(){return new this.constructor().copy(this)}toJSON(){return{normal:this.normal.toArray(),constant:this.constant}}fromJSON(t){return this.normal.fromArray(t.normal),this.constant=t.constant,this}}let Hu=0;class Ps extends Si{constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:Hu++}),this.uuid=Cs(),this.name="",this.type="Material",this.blending=$i,this.side=vi,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=zc,this.blendDst=Gc,this.blendEquation=Vi,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new At(0,0,0),this.blendAlpha=0,this.depthFunc=bs,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=du,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=Yr,this.stencilZFail=Yr,this.stencilZPass=Yr,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.allowOverride=!0,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(t){this._alphaTest>0!=t>0&&this.version++,this._alphaTest=t}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(t){if(t!==void 0)for(const e in t){const n=t[e];if(n===void 0){Ut(`Material: parameter '${e}' has value of undefined.`);continue}const i=this[e];if(i===void 0){Ut(`Material: '${e}' is not a property of THREE.${this.type}.`);continue}i&&i.isColor?i.set(n):i&&i.isVector2&&n&&n.isVector2||i&&i.isEuler&&n&&n.isEuler||i&&i.isVector3&&n&&n.isVector3?i.copy(n):this[e]=n}}toJSON(t){const e=t===void 0||typeof t=="string";e&&(t={textures:{},images:{}});const n={metadata:{version:4.7,type:"Material",generator:"Material.toJSON"}};n.uuid=this.uuid,n.type=this.type,n.blending=this.blending,n.side=this.side,n.shadowSide=this.shadowSide,n.vertexColors=this.vertexColors,n.opacity=this.opacity,n.transparent=this.transparent,n.blendSrc=this.blendSrc,n.blendDst=this.blendDst,n.blendEquation=this.blendEquation,n.blendSrcAlpha=this.blendSrcAlpha,n.blendDstAlpha=this.blendDstAlpha,n.blendEquationAlpha=this.blendEquationAlpha,n.blendColor=this.blendColor.getHex(),n.blendAlpha=this.blendAlpha,n.depthFunc=this.depthFunc,n.depthTest=this.depthTest,n.depthWrite=this.depthWrite,n.colorWrite=this.colorWrite,n.clipIntersection=this.clipIntersection,n.clipShadows=this.clipShadows,n.stencilWriteMask=this.stencilWriteMask,n.stencilFunc=this.stencilFunc,n.stencilRef=this.stencilRef,n.stencilFuncMask=this.stencilFuncMask,n.stencilFail=this.stencilFail,n.stencilZFail=this.stencilZFail,n.stencilZPass=this.stencilZPass,n.stencilWrite=this.stencilWrite,n.polygonOffset=this.polygonOffset,n.polygonOffsetFactor=this.polygonOffsetFactor,n.polygonOffsetUnits=this.polygonOffsetUnits,n.dithering=this.dithering,n.alphaTest=this.alphaTest,n.alphaHash=this.alphaHash,n.alphaToCoverage=this.alphaToCoverage,n.premultipliedAlpha=this.premultipliedAlpha,n.forceSinglePass=this.forceSinglePass,n.allowOverride=this.allowOverride,n.visible=this.visible,n.toneMapped=this.toneMapped,n.name=this.name,this.color&&this.color.isColor&&(n.color=this.color.getHex()),this.roughness!==void 0&&(n.roughness=this.roughness),this.metalness!==void 0&&(n.metalness=this.metalness),this.sheen!==void 0&&(n.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(n.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(n.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(n.emissive=this.emissive.getHex()),this.emissiveIntensity!==void 0&&(n.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(n.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(n.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(n.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(n.shininess=this.shininess),this.clearcoat!==void 0&&(n.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(n.clearcoatRoughness=this.clearcoatRoughness),this.clearcoatMap&&this.clearcoatMap.isTexture&&(n.clearcoatMap=this.clearcoatMap.toJSON(t).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(n.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(t).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(n.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(t).uuid,n.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.sheenColorMap&&this.sheenColorMap.isTexture&&(n.sheenColorMap=this.sheenColorMap.toJSON(t).uuid),this.sheenRoughnessMap&&this.sheenRoughnessMap.isTexture&&(n.sheenRoughnessMap=this.sheenRoughnessMap.toJSON(t).uuid),this.dispersion!==void 0&&(n.dispersion=this.dispersion),this.retroreflectivity!==void 0&&(n.retroreflectivity=this.retroreflectivity),this.iridescence!==void 0&&(n.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(n.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessRange!==void 0&&(n.iridescenceThicknessRange=this.iridescenceThicknessRange),this.iridescenceMap&&this.iridescenceMap.isTexture&&(n.iridescenceMap=this.iridescenceMap.toJSON(t).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(n.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(t).uuid),this.anisotropy!==void 0&&(n.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(n.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(n.anisotropyMap=this.anisotropyMap.toJSON(t).uuid),this.map&&this.map.isTexture&&(n.map=this.map.toJSON(t).uuid),this.matcap&&this.matcap.isTexture&&(n.matcap=this.matcap.toJSON(t).uuid),this.alphaMap&&this.alphaMap.isTexture&&(n.alphaMap=this.alphaMap.toJSON(t).uuid),this.lightMap&&this.lightMap.isTexture&&(n.lightMap=this.lightMap.toJSON(t).uuid,n.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(n.aoMap=this.aoMap.toJSON(t).uuid,n.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(n.bumpMap=this.bumpMap.toJSON(t).uuid,n.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(n.normalMap=this.normalMap.toJSON(t).uuid,n.normalMapType=this.normalMapType,n.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(n.displacementMap=this.displacementMap.toJSON(t).uuid,n.displacementScale=this.displacementScale,n.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(n.roughnessMap=this.roughnessMap.toJSON(t).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(n.metalnessMap=this.metalnessMap.toJSON(t).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(n.emissiveMap=this.emissiveMap.toJSON(t).uuid),this.specularMap&&this.specularMap.isTexture&&(n.specularMap=this.specularMap.toJSON(t).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(n.specularIntensityMap=this.specularIntensityMap.toJSON(t).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(n.specularColorMap=this.specularColorMap.toJSON(t).uuid),this.envMap&&this.envMap.isTexture&&(n.envMap=this.envMap.toJSON(t).uuid,this.combine!==void 0&&(n.combine=this.combine)),this.envMapRotation!==void 0&&(n.envMapRotation=this.envMapRotation.toArray()),this.envMapIntensity!==void 0&&(n.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(n.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(n.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(n.gradientMap=this.gradientMap.toJSON(t).uuid),this.transmission!==void 0&&(n.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(n.transmissionMap=this.transmissionMap.toJSON(t).uuid),this.thickness!==void 0&&(n.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(n.thicknessMap=this.thicknessMap.toJSON(t).uuid),this.attenuationDistance!==void 0&&(n.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(n.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(n.size=this.size),this.sizeAttenuation!==void 0&&(n.sizeAttenuation=this.sizeAttenuation),Array.isArray(this.clippingPlanes)&&this.clippingPlanes.length>0&&(n.clippingPlanes=this.clippingPlanes.map(r=>r.toJSON())),this.rotation!==void 0&&(n.rotation=this.rotation),this.depthPacking!==void 0&&(n.depthPacking=this.depthPacking),this.linewidth!==void 0&&(n.linewidth=this.linewidth),this.linecap!==void 0&&(n.linecap=this.linecap),this.linejoin!==void 0&&(n.linejoin=this.linejoin),this.dashSize!==void 0&&(n.dashSize=this.dashSize),this.gapSize!==void 0&&(n.gapSize=this.gapSize),this.scale!==void 0&&(n.scale=this.scale),this.wireframe!==void 0&&(n.wireframe=this.wireframe),this.wireframeLinewidth!==void 0&&(n.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!==void 0&&(n.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!==void 0&&(n.wireframeLinejoin=this.wireframeLinejoin),this.flatShading!==void 0&&(n.flatShading=this.flatShading),this.fog!==void 0&&(n.fog=this.fog),Object.keys(this.userData).length>0&&(n.userData=this.userData);function i(r){const a=[];for(const o in r){const l=r[o];delete l.metadata,a.push(l)}return a}if(e){const r=i(t.textures),a=i(t.images);r.length>0&&(n.textures=r),a.length>0&&(n.images=a)}return n}fromJSON(t,e){if(t.uuid!==void 0&&(this.uuid=t.uuid),t.name!==void 0&&(this.name=t.name),t.color!==void 0&&this.color!==void 0&&this.color.setHex(t.color),t.roughness!==void 0&&(this.roughness=t.roughness),t.metalness!==void 0&&(this.metalness=t.metalness),t.sheen!==void 0&&(this.sheen=t.sheen),t.sheenColor!==void 0&&(this.sheenColor=new At().setHex(t.sheenColor)),t.sheenRoughness!==void 0&&(this.sheenRoughness=t.sheenRoughness),t.emissive!==void 0&&this.emissive!==void 0&&this.emissive.setHex(t.emissive),t.specular!==void 0&&this.specular!==void 0&&this.specular.setHex(t.specular),t.specularIntensity!==void 0&&(this.specularIntensity=t.specularIntensity),t.specularColor!==void 0&&this.specularColor!==void 0&&this.specularColor.setHex(t.specularColor),t.shininess!==void 0&&(this.shininess=t.shininess),t.clearcoat!==void 0&&(this.clearcoat=t.clearcoat),t.clearcoatRoughness!==void 0&&(this.clearcoatRoughness=t.clearcoatRoughness),t.dispersion!==void 0&&(this.dispersion=t.dispersion),t.retroreflectivity!==void 0&&(this.retroreflectivity=t.retroreflectivity),t.iridescence!==void 0&&(this.iridescence=t.iridescence),t.iridescenceIOR!==void 0&&(this.iridescenceIOR=t.iridescenceIOR),t.iridescenceThicknessRange!==void 0&&(this.iridescenceThicknessRange=t.iridescenceThicknessRange),t.transmission!==void 0&&(this.transmission=t.transmission),t.thickness!==void 0&&(this.thickness=t.thickness),t.attenuationDistance!==void 0&&(this.attenuationDistance=t.attenuationDistance),t.attenuationColor!==void 0&&this.attenuationColor!==void 0&&this.attenuationColor.setHex(t.attenuationColor),t.anisotropy!==void 0&&(this.anisotropy=t.anisotropy),t.anisotropyRotation!==void 0&&(this.anisotropyRotation=t.anisotropyRotation),t.fog!==void 0&&(this.fog=t.fog),t.flatShading!==void 0&&(this.flatShading=t.flatShading),t.blending!==void 0&&(this.blending=t.blending),t.combine!==void 0&&(this.combine=t.combine),t.side!==void 0&&(this.side=t.side),t.shadowSide!==void 0&&(this.shadowSide=t.shadowSide),t.opacity!==void 0&&(this.opacity=t.opacity),t.transparent!==void 0&&(this.transparent=t.transparent),t.alphaTest!==void 0&&(this.alphaTest=t.alphaTest),t.alphaHash!==void 0&&(this.alphaHash=t.alphaHash),t.depthFunc!==void 0&&(this.depthFunc=t.depthFunc),t.depthTest!==void 0&&(this.depthTest=t.depthTest),t.depthWrite!==void 0&&(this.depthWrite=t.depthWrite),t.colorWrite!==void 0&&(this.colorWrite=t.colorWrite),t.clippingPlanes!==void 0&&(this.clippingPlanes=t.clippingPlanes.map(n=>new ni().fromJSON(n))),t.clipIntersection!==void 0&&(this.clipIntersection=t.clipIntersection),t.clipShadows!==void 0&&(this.clipShadows=t.clipShadows),t.depthPacking!==void 0&&(this.depthPacking=t.depthPacking),t.blendSrc!==void 0&&(this.blendSrc=t.blendSrc),t.blendDst!==void 0&&(this.blendDst=t.blendDst),t.blendEquation!==void 0&&(this.blendEquation=t.blendEquation),t.blendSrcAlpha!==void 0&&(this.blendSrcAlpha=t.blendSrcAlpha),t.blendDstAlpha!==void 0&&(this.blendDstAlpha=t.blendDstAlpha),t.blendEquationAlpha!==void 0&&(this.blendEquationAlpha=t.blendEquationAlpha),t.blendColor!==void 0&&this.blendColor!==void 0&&this.blendColor.setHex(t.blendColor),t.blendAlpha!==void 0&&(this.blendAlpha=t.blendAlpha),t.stencilWriteMask!==void 0&&(this.stencilWriteMask=t.stencilWriteMask),t.stencilFunc!==void 0&&(this.stencilFunc=t.stencilFunc),t.stencilRef!==void 0&&(this.stencilRef=t.stencilRef),t.stencilFuncMask!==void 0&&(this.stencilFuncMask=t.stencilFuncMask),t.stencilFail!==void 0&&(this.stencilFail=t.stencilFail),t.stencilZFail!==void 0&&(this.stencilZFail=t.stencilZFail),t.stencilZPass!==void 0&&(this.stencilZPass=t.stencilZPass),t.stencilWrite!==void 0&&(this.stencilWrite=t.stencilWrite),t.wireframe!==void 0&&(this.wireframe=t.wireframe),t.wireframeLinewidth!==void 0&&(this.wireframeLinewidth=t.wireframeLinewidth),t.wireframeLinecap!==void 0&&(this.wireframeLinecap=t.wireframeLinecap),t.wireframeLinejoin!==void 0&&(this.wireframeLinejoin=t.wireframeLinejoin),t.rotation!==void 0&&(this.rotation=t.rotation),t.linewidth!==void 0&&(this.linewidth=t.linewidth),t.linecap!==void 0&&(this.linecap=t.linecap),t.linejoin!==void 0&&(this.linejoin=t.linejoin),t.dashSize!==void 0&&(this.dashSize=t.dashSize),t.gapSize!==void 0&&(this.gapSize=t.gapSize),t.scale!==void 0&&(this.scale=t.scale),t.polygonOffset!==void 0&&(this.polygonOffset=t.polygonOffset),t.polygonOffsetFactor!==void 0&&(this.polygonOffsetFactor=t.polygonOffsetFactor),t.polygonOffsetUnits!==void 0&&(this.polygonOffsetUnits=t.polygonOffsetUnits),t.dithering!==void 0&&(this.dithering=t.dithering),t.alphaToCoverage!==void 0&&(this.alphaToCoverage=t.alphaToCoverage),t.premultipliedAlpha!==void 0&&(this.premultipliedAlpha=t.premultipliedAlpha),t.forceSinglePass!==void 0&&(this.forceSinglePass=t.forceSinglePass),t.allowOverride!==void 0&&(this.allowOverride=t.allowOverride),t.visible!==void 0&&(this.visible=t.visible),t.toneMapped!==void 0&&(this.toneMapped=t.toneMapped),t.userData!==void 0&&(this.userData=t.userData),t.vertexColors!==void 0&&(typeof t.vertexColors=="number"?this.vertexColors=t.vertexColors>0:this.vertexColors=t.vertexColors),t.size!==void 0&&(this.size=t.size),t.sizeAttenuation!==void 0&&(this.sizeAttenuation=t.sizeAttenuation),t.map!==void 0&&(this.map=e[t.map]||null),t.matcap!==void 0&&(this.matcap=e[t.matcap]||null),t.alphaMap!==void 0&&(this.alphaMap=e[t.alphaMap]||null),t.bumpMap!==void 0&&(this.bumpMap=e[t.bumpMap]||null),t.bumpScale!==void 0&&(this.bumpScale=t.bumpScale),t.normalMap!==void 0&&(this.normalMap=e[t.normalMap]||null),t.normalMapType!==void 0&&(this.normalMapType=t.normalMapType),t.normalScale!==void 0){let n=t.normalScale;Array.isArray(n)===!1&&(n=[n,n]),this.normalScale=new Bt().fromArray(n)}return t.displacementMap!==void 0&&(this.displacementMap=e[t.displacementMap]||null),t.displacementScale!==void 0&&(this.displacementScale=t.displacementScale),t.displacementBias!==void 0&&(this.displacementBias=t.displacementBias),t.roughnessMap!==void 0&&(this.roughnessMap=e[t.roughnessMap]||null),t.metalnessMap!==void 0&&(this.metalnessMap=e[t.metalnessMap]||null),t.emissiveMap!==void 0&&(this.emissiveMap=e[t.emissiveMap]||null),t.emissiveIntensity!==void 0&&(this.emissiveIntensity=t.emissiveIntensity),t.specularMap!==void 0&&(this.specularMap=e[t.specularMap]||null),t.specularIntensityMap!==void 0&&(this.specularIntensityMap=e[t.specularIntensityMap]||null),t.specularColorMap!==void 0&&(this.specularColorMap=e[t.specularColorMap]||null),t.envMap!==void 0&&(this.envMap=e[t.envMap]||null),t.envMapRotation!==void 0&&this.envMapRotation.fromArray(t.envMapRotation),t.envMapIntensity!==void 0&&(this.envMapIntensity=t.envMapIntensity),t.reflectivity!==void 0&&(this.reflectivity=t.reflectivity),t.refractionRatio!==void 0&&(this.refractionRatio=t.refractionRatio),t.lightMap!==void 0&&(this.lightMap=e[t.lightMap]||null),t.lightMapIntensity!==void 0&&(this.lightMapIntensity=t.lightMapIntensity),t.aoMap!==void 0&&(this.aoMap=e[t.aoMap]||null),t.aoMapIntensity!==void 0&&(this.aoMapIntensity=t.aoMapIntensity),t.gradientMap!==void 0&&(this.gradientMap=e[t.gradientMap]||null),t.clearcoatMap!==void 0&&(this.clearcoatMap=e[t.clearcoatMap]||null),t.clearcoatRoughnessMap!==void 0&&(this.clearcoatRoughnessMap=e[t.clearcoatRoughnessMap]||null),t.clearcoatNormalMap!==void 0&&(this.clearcoatNormalMap=e[t.clearcoatNormalMap]||null),t.clearcoatNormalScale!==void 0&&(this.clearcoatNormalScale=new Bt().fromArray(t.clearcoatNormalScale)),t.iridescenceMap!==void 0&&(this.iridescenceMap=e[t.iridescenceMap]||null),t.iridescenceThicknessMap!==void 0&&(this.iridescenceThicknessMap=e[t.iridescenceThicknessMap]||null),t.transmissionMap!==void 0&&(this.transmissionMap=e[t.transmissionMap]||null),t.thicknessMap!==void 0&&(this.thicknessMap=e[t.thicknessMap]||null),t.anisotropyMap!==void 0&&(this.anisotropyMap=e[t.anisotropyMap]||null),t.sheenColorMap!==void 0&&(this.sheenColorMap=e[t.sheenColorMap]||null),t.sheenRoughnessMap!==void 0&&(this.sheenRoughnessMap=e[t.sheenRoughnessMap]||null),this}clone(){return new this.constructor().copy(this)}copy(t){this.name=t.name,this.blending=t.blending,this.side=t.side,this.vertexColors=t.vertexColors,this.opacity=t.opacity,this.transparent=t.transparent,this.blendSrc=t.blendSrc,this.blendDst=t.blendDst,this.blendEquation=t.blendEquation,this.blendSrcAlpha=t.blendSrcAlpha,this.blendDstAlpha=t.blendDstAlpha,this.blendEquationAlpha=t.blendEquationAlpha,this.blendColor.copy(t.blendColor),this.blendAlpha=t.blendAlpha,this.depthFunc=t.depthFunc,this.depthTest=t.depthTest,this.depthWrite=t.depthWrite,this.stencilWriteMask=t.stencilWriteMask,this.stencilFunc=t.stencilFunc,this.stencilRef=t.stencilRef,this.stencilFuncMask=t.stencilFuncMask,this.stencilFail=t.stencilFail,this.stencilZFail=t.stencilZFail,this.stencilZPass=t.stencilZPass,this.stencilWrite=t.stencilWrite;const e=t.clippingPlanes;let n=null;if(e!==null){const i=e.length;n=new Array(i);for(let r=0;r!==i;++r)n[r]=e[r].clone()}return this.clippingPlanes=n,this.clipIntersection=t.clipIntersection,this.clipShadows=t.clipShadows,this.shadowSide=t.shadowSide,this.colorWrite=t.colorWrite,this.precision=t.precision,this.polygonOffset=t.polygonOffset,this.polygonOffsetFactor=t.polygonOffsetFactor,this.polygonOffsetUnits=t.polygonOffsetUnits,this.dithering=t.dithering,this.alphaTest=t.alphaTest,this.alphaHash=t.alphaHash,this.alphaToCoverage=t.alphaToCoverage,this.premultipliedAlpha=t.premultipliedAlpha,this.forceSinglePass=t.forceSinglePass,this.allowOverride=t.allowOverride,this.visible=t.visible,this.toneMapped=t.toneMapped,this.userData=JSON.parse(JSON.stringify(t.userData)),this}dispose(){this.dispatchEvent({type:"dispose"})}set needsUpdate(t){t===!0&&this.version++}}const Fn=new O,pa=new O,Ws=new O,Xs=new O;class lh{constructor(t=new O,e=new O(0,0,-1)){this.origin=t,this.direction=e}set(t,e){return this.origin.copy(t),this.direction.copy(e),this}copy(t){return this.origin.copy(t.origin),this.direction.copy(t.direction),this}at(t,e){return e.copy(this.origin).addScaledVector(this.direction,t)}lookAt(t){return this.direction.copy(t).sub(this.origin).normalize(),this}recast(t){return this.origin.copy(this.at(t,Fn)),this}closestPointToPoint(t,e){e.subVectors(t,this.origin);const n=e.dot(this.direction);return n<0?e.copy(this.origin):e.copy(this.origin).addScaledVector(this.direction,n)}distanceToPoint(t){return Math.sqrt(this.distanceSqToPoint(t))}distanceSqToPoint(t){const e=Fn.subVectors(t,this.origin).dot(this.direction);return e<0?this.origin.distanceToSquared(t):(Fn.copy(this.origin).addScaledVector(this.direction,e),Fn.distanceToSquared(t))}distanceSqToSegment(t,e,n,i){pa.copy(t).add(e).multiplyScalar(.5),Ws.copy(e).sub(t).normalize(),Xs.copy(this.origin).sub(pa);const r=t.distanceTo(e)*.5,a=-this.direction.dot(Ws),o=Xs.dot(this.direction),l=-Xs.dot(Ws),c=Xs.lengthSq(),h=Math.abs(1-a*a);let u,d,f,_;if(h>0)if(u=a*l-o,d=a*o-l,_=r*h,u>=0)if(d>=-_)if(d<=_){const v=1/h;u*=v,d*=v,f=u*(u+a*d+2*o)+d*(a*u+d+2*l)+c}else d=r,u=Math.max(0,-(a*d+o)),f=-u*u+d*(d+2*l)+c;else d=-r,u=Math.max(0,-(a*d+o)),f=-u*u+d*(d+2*l)+c;else d<=-_?(u=Math.max(0,-(-a*r+o)),d=u>0?-r:Math.min(Math.max(-r,-l),r),f=-u*u+d*(d+2*l)+c):d<=_?(u=0,d=Math.min(Math.max(-r,-l),r),f=d*(d+2*l)+c):(u=Math.max(0,-(a*r+o)),d=u>0?r:Math.min(Math.max(-r,-l),r),f=-u*u+d*(d+2*l)+c);else d=a>0?-r:r,u=Math.max(0,-(a*d+o)),f=-u*u+d*(d+2*l)+c;return n&&n.copy(this.origin).addScaledVector(this.direction,u),i&&i.copy(pa).addScaledVector(Ws,d),f}intersectSphere(t,e){if(t.radius<0)return null;Fn.subVectors(t.center,this.origin);const n=Fn.dot(this.direction),i=Fn.dot(Fn)-n*n,r=t.radius*t.radius;if(i>r)return null;const a=Math.sqrt(r-i),o=n-a,l=n+a;return l<0?null:o<0?this.at(l,e):this.at(o,e)}intersectsSphere(t){return t.radius<0?!1:this.distanceSqToPoint(t.center)<=t.radius*t.radius}distanceToPlane(t){const e=t.normal.dot(this.direction);if(e===0)return t.distanceToPoint(this.origin)===0?0:null;const n=-(this.origin.dot(t.normal)+t.constant)/e;return n>=0?n:null}intersectPlane(t,e){const n=this.distanceToPlane(t);return n===null?null:this.at(n,e)}intersectsPlane(t){const e=t.distanceToPoint(this.origin);return e===0||t.normal.dot(this.direction)*e<0}intersectBox(t,e){let n,i,r,a,o,l;const c=1/this.direction.x,h=1/this.direction.y,u=1/this.direction.z,d=this.origin;return c>=0?(n=(t.min.x-d.x)*c,i=(t.max.x-d.x)*c):(n=(t.max.x-d.x)*c,i=(t.min.x-d.x)*c),h>=0?(r=(t.min.y-d.y)*h,a=(t.max.y-d.y)*h):(r=(t.max.y-d.y)*h,a=(t.min.y-d.y)*h),n>a||r>i||((r>n||isNaN(n))&&(n=r),(a<i||isNaN(i))&&(i=a),u>=0?(o=(t.min.z-d.z)*u,l=(t.max.z-d.z)*u):(o=(t.max.z-d.z)*u,l=(t.min.z-d.z)*u),n>l||o>i)||((o>n||n!==n)&&(n=o),(l<i||i!==i)&&(i=l),i<0)?null:this.at(n>=0?n:i,e)}intersectsBox(t){return this.intersectBox(t,Fn)!==null}intersectTriangle(t,e,n,i,r){const a=this.origin,o=this.direction,l=o.x,c=o.y,h=o.z,u=t.x-a.x,d=t.y-a.y,f=t.z-a.z,_=e.x-a.x,v=e.y-a.y,p=e.z-a.z,m=n.x-a.x,b=n.y-a.y,T=n.z-a.z,y=Math.abs(l),E=Math.abs(c),w=Math.abs(h);let R,x,S,C,P,D,z,L,F,X,W,tt;if(y>=E&&y>=w?(S=l,D=u,F=_,tt=m,l>=0?(R=c,x=h,C=d,P=f,z=v,L=p,X=b,W=T):(R=h,x=c,C=f,P=d,z=p,L=v,X=T,W=b)):E>=w?(S=c,D=d,F=v,tt=b,c>=0?(R=h,x=l,C=f,P=u,z=p,L=_,X=T,W=m):(R=l,x=h,C=u,P=f,z=_,L=p,X=m,W=T)):(S=h,D=f,F=p,tt=T,h>=0?(R=l,x=c,C=u,P=d,z=_,L=v,X=m,W=b):(R=c,x=l,C=d,P=u,z=v,L=_,X=b,W=m)),S===0)return null;const $=R/S,et=x/S,Z=1/S,_t=C-$*D,Tt=P-et*D,se=z-$*F,Yt=L-et*F,Qt=X-$*tt,Q=W-et*tt,st=Qt*Yt-Q*se,yt=_t*Q-Tt*Qt,Nt=se*Tt-Yt*_t;if(i){if(st<0||yt<0||Nt<0)return null}else if((st<0||yt<0||Nt<0)&&(st>0||yt>0||Nt>0))return null;const vt=st+yt+Nt;if(vt===0)return null;const Gt=Z*(st*D+yt*F+Nt*tt);return(vt>0?Gt<0:Gt>0)?null:this.at(Gt/vt,r)}applyMatrix4(t){return this.origin.applyMatrix4(t),this.direction.transformDirection(t),this}equals(t){return t.origin.equals(this.origin)&&t.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}}class si extends Ps{constructor(t){super(),this.isMeshBasicMaterial=!0,this.type="MeshBasicMaterial",this.color=new At(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new nn,this.combine=To,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.lightMap=t.lightMap,this.lightMapIntensity=t.lightMapIntensity,this.aoMap=t.aoMap,this.aoMapIntensity=t.aoMapIntensity,this.specularMap=t.specularMap,this.alphaMap=t.alphaMap,this.envMap=t.envMap,this.envMapRotation.copy(t.envMapRotation),this.combine=t.combine,this.reflectivity=t.reflectivity,this.refractionRatio=t.refractionRatio,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.wireframeLinecap=t.wireframeLinecap,this.wireframeLinejoin=t.wireframeLinejoin,this.fog=t.fog,this}}const Dl=new Zt,di=new lh,qs=new Rs,Il=new O,Ys=new O,$s=new O,Ks=new O,ma=new O,Zs=new O,Ul=new O,Js=new O;class le extends Re{constructor(t=new Ae,e=new si){super(),this.isMesh=!0,this.type="Mesh",this.geometry=t,this.material=e,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.count=1,this.updateMorphTargets()}copy(t,e){return super.copy(t,e),t.morphTargetInfluences!==void 0&&(this.morphTargetInfluences=t.morphTargetInfluences.slice()),t.morphTargetDictionary!==void 0&&(this.morphTargetDictionary=Object.assign({},t.morphTargetDictionary)),this.material=Array.isArray(t.material)?t.material.slice():t.material,this.geometry=t.geometry,this}updateMorphTargets(){const e=this.geometry.morphAttributes,n=Object.keys(e);if(n.length>0){const i=e[n[0]];if(i!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let r=0,a=i.length;r<a;r++){const o=i[r].name||String(r);this.morphTargetInfluences.push(0),this.morphTargetDictionary[o]=r}}}}getVertexPosition(t,e){const n=this.geometry,i=n.attributes.position,r=n.morphAttributes.position,a=n.morphTargetsRelative;e.fromBufferAttribute(i,t);const o=this.morphTargetInfluences;if(r&&o){Zs.set(0,0,0);for(let l=0,c=r.length;l<c;l++){const h=o[l],u=r[l];h!==0&&(ma.fromBufferAttribute(u,t),a?Zs.addScaledVector(ma,h):Zs.addScaledVector(ma.sub(e),h))}e.add(Zs)}return e}intersectsFrustum(t){return t.intersectsObject(this)}raycast(t,e){const n=this.geometry,i=this.material,r=this.matrixWorld;i!==void 0&&(n.boundingSphere===null&&n.computeBoundingSphere(),qs.copy(n.boundingSphere),qs.applyMatrix4(r),di.copy(t.ray).recast(t.near),!(qs.containsPoint(di.origin)===!1&&(di.intersectSphere(qs,Il)===null||di.origin.distanceToSquared(Il)>(t.far-t.near)**2))&&(Dl.copy(r).invert(),di.copy(t.ray).applyMatrix4(Dl),!(n.boundingBox!==null&&di.intersectsBox(n.boundingBox)===!1)&&this._computeIntersections(t,e,di)))}_computeIntersections(t,e,n){let i;const r=this.geometry,a=this.material,o=r.index,l=r.attributes.position,c=r.attributes.uv,h=r.attributes.uv1,u=r.attributes.normal,d=r.groups,f=r.drawRange;if(o!==null)if(Array.isArray(a))for(let _=0,v=d.length;_<v;_++){const p=d[_],m=a[p.materialIndex],b=Math.max(p.start,f.start),T=Math.min(o.count,Math.min(p.start+p.count,f.start+f.count));for(let y=b,E=T;y<E;y+=3){const w=o.getX(y),R=o.getX(y+1),x=o.getX(y+2);i=Qs(this,m,t,n,c,h,u,w,R,x),i&&(i.faceIndex=Math.floor(y/3),i.face.materialIndex=p.materialIndex,e.push(i))}}else{const _=Math.max(0,f.start),v=Math.min(o.count,f.start+f.count);for(let p=_,m=v;p<m;p+=3){const b=o.getX(p),T=o.getX(p+1),y=o.getX(p+2);i=Qs(this,a,t,n,c,h,u,b,T,y),i&&(i.faceIndex=Math.floor(p/3),e.push(i))}}else if(l!==void 0)if(Array.isArray(a))for(let _=0,v=d.length;_<v;_++){const p=d[_],m=a[p.materialIndex],b=Math.max(p.start,f.start),T=Math.min(l.count,Math.min(p.start+p.count,f.start+f.count));for(let y=b,E=T;y<E;y+=3){const w=y,R=y+1,x=y+2;i=Qs(this,m,t,n,c,h,u,w,R,x),i&&(i.faceIndex=Math.floor(y/3),i.face.materialIndex=p.materialIndex,e.push(i))}}else{const _=Math.max(0,f.start),v=Math.min(l.count,f.start+f.count);for(let p=_,m=v;p<m;p+=3){const b=p,T=p+1,y=p+2;i=Qs(this,a,t,n,c,h,u,b,T,y),i&&(i.faceIndex=Math.floor(p/3),e.push(i))}}}}function Vu(s,t,e,n,i,r,a,o){let l;if(t.side===Ve?l=n.intersectTriangle(a,r,i,!0,o):l=n.intersectTriangle(i,r,a,t.side===vi,o),l===null)return null;Js.copy(o),Js.applyMatrix4(s.matrixWorld);const c=e.ray.origin.distanceTo(Js);return c<e.near||c>e.far?null:{distance:c,point:Js.clone(),object:s}}function Qs(s,t,e,n,i,r,a,o,l,c){s.getVertexPosition(o,Ys),s.getVertexPosition(l,$s),s.getVertexPosition(c,Ks);const h=Vu(s,t,e,n,Ys,$s,Ks,Ul);if(h){const u=new O;fn.getBarycoord(Ul,Ys,$s,Ks,u),i&&(h.uv=fn.getInterpolatedAttribute(i,o,l,c,u,new Bt)),r&&(h.uv1=fn.getInterpolatedAttribute(r,o,l,c,u,new Bt)),a&&(h.normal=fn.getInterpolatedAttribute(a,o,l,c,u,new O),h.normal.dot(n.direction)>0&&h.normal.multiplyScalar(-1));const d={a:o,b:l,c,normal:new O,materialIndex:0};fn.getNormal(Ys,$s,Ks,d.normal),h.face=d,h.barycoord=u}return h}class ch extends Oe{constructor(t=null,e=1,n=1,i,r,a,o,l,c=Ce,h=Ce,u,d){super(null,a,o,l,c,h,i,r,u,d),this.isDataTexture=!0,this.image={data:t,width:e,height:n},this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}class Nl extends Cn{constructor(t,e,n,i=1){super(t,e,n),this.isInstancedBufferAttribute=!0,this.meshPerAttribute=i}copy(t){return super.copy(t),this.meshPerAttribute=t.meshPerAttribute,this}toJSON(){const t=super.toJSON();return t.meshPerAttribute=this.meshPerAttribute,t.isInstancedBufferAttribute=!0,t}}const ki=new Zt,Fl=new Zt,js=[],kl=new wi,Wu=new Zt,ls=new le,cs=new Rs;class ri extends le{constructor(t,e,n){super(t,e),this.isInstancedMesh=!0,this.instanceMatrix=new Nl(new Float32Array(n*16),16),this.instanceColor=null,this.morphTexture=null,this.count=n,this.boundingBox=null,this.boundingSphere=null;for(let i=0;i<n;i++)this.setMatrixAt(i,Wu)}computeBoundingBox(){const t=this.geometry,e=this.count;this.boundingBox===null&&(this.boundingBox=new wi),t.boundingBox===null&&t.computeBoundingBox(),this.boundingBox.makeEmpty();for(let n=0;n<e;n++)this.getMatrixAt(n,ki),kl.copy(t.boundingBox).applyMatrix4(ki),this.boundingBox.union(kl)}computeBoundingSphere(){const t=this.geometry,e=this.count;this.boundingSphere===null&&(this.boundingSphere=new Rs),t.boundingSphere===null&&t.computeBoundingSphere(),this.boundingSphere.makeEmpty();for(let n=0;n<e;n++)this.getMatrixAt(n,ki),cs.copy(t.boundingSphere).applyMatrix4(ki),this.boundingSphere.union(cs)}copy(t,e){return super.copy(t,e),this.instanceMatrix.copy(t.instanceMatrix),t.morphTexture!==null&&(this.morphTexture=t.morphTexture.clone()),t.instanceColor!==null&&(this.instanceColor=t.instanceColor.clone()),this.count=t.count,t.boundingBox!==null&&(this.boundingBox=t.boundingBox.clone()),t.boundingSphere!==null&&(this.boundingSphere=t.boundingSphere.clone()),this}getColorAt(t,e){return this.instanceColor===null?e.setRGB(1,1,1):e.fromArray(this.instanceColor.array,t*3)}getMatrixAt(t,e){return e.fromArray(this.instanceMatrix.array,t*16)}getMorphAt(t,e){const n=e.morphTargetInfluences,i=this.morphTexture.source.data.data,r=n.length+1,a=t*r+1;for(let o=0;o<n.length;o++)n[o]=i[a+o]}raycast(t,e){const n=this.matrixWorld,i=this.count;if(ls.geometry=this.geometry,ls.material=this.material,ls.material!==void 0&&(this.boundingSphere===null&&this.computeBoundingSphere(),cs.copy(this.boundingSphere),cs.applyMatrix4(n),t.ray.intersectsSphere(cs)!==!1))for(let r=0;r<i;r++){this.getMatrixAt(r,ki),Fl.multiplyMatrices(n,ki),ls.matrixWorld=Fl,ls.raycast(t,js);for(let a=0,o=js.length;a<o;a++){const l=js[a];l.instanceId=r,l.object=this,e.push(l)}js.length=0}}setColorAt(t,e){return this.instanceColor===null&&(this.instanceColor=new Nl(new Float32Array(this.instanceMatrix.count*3).fill(1),3)),e.toArray(this.instanceColor.array,t*3),this}setMatrixAt(t,e){return e.toArray(this.instanceMatrix.array,t*16),this}setMorphAt(t,e){const n=e.morphTargetInfluences,i=n.length+1;this.morphTexture===null&&(this.morphTexture=new ch(new Float32Array(i*this.count),i,this.count,Po,pn));const r=this.morphTexture.source.data.data;let a=0;for(let c=0;c<n.length;c++)a+=n[c];const o=this.geometry.morphTargetsRelative?1:1-a,l=i*t;return r[l]=o,r.set(n,l+1),this}updateMorphTargets(){}dispose(){super.dispose(),this.morphTexture!==null&&(this.morphTexture.dispose(),this.morphTexture=null)}}const ui=new Rs,Xu=new Bt(.5,.5),tr=new O;class Oo{constructor(t=new ni,e=new ni,n=new ni,i=new ni,r=new ni,a=new ni){this.planes=[t,e,n,i,r,a]}set(t,e,n,i,r,a){const o=this.planes;return o[0].copy(t),o[1].copy(e),o[2].copy(n),o[3].copy(i),o[4].copy(r),o[5].copy(a),this}copy(t){const e=this.planes;for(let n=0;n<6;n++)e[n].copy(t.planes[n]);return this}setFromProjectionMatrix(t,e=Tn,n=!1){const i=this.planes,r=t.elements,a=r[0],o=r[1],l=r[2],c=r[3],h=r[4],u=r[5],d=r[6],f=r[7],_=r[8],v=r[9],p=r[10],m=r[11],b=r[12],T=r[13],y=r[14],E=r[15];if(i[0].setComponents(c-a,f-h,m-_,E-b).normalize(),i[1].setComponents(c+a,f+h,m+_,E+b).normalize(),i[2].setComponents(c+o,f+u,m+v,E+T).normalize(),i[3].setComponents(c-o,f-u,m-v,E-T).normalize(),n)i[4].setComponents(l,d,p,y).normalize(),i[5].setComponents(c-l,f-d,m-p,E-y).normalize();else if(i[4].setComponents(c-l,f-d,m-p,E-y).normalize(),e===Tn)i[5].setComponents(c+l,f+d,m+p,E+y).normalize();else if(e===Es)i[5].setComponents(l,d,p,y).normalize();else throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: "+e);return this}intersectsObject(t){if(t.boundingSphere!==void 0)t.boundingSphere===null&&t.computeBoundingSphere(),ui.copy(t.boundingSphere).applyMatrix4(t.matrixWorld);else{const e=t.geometry;e.boundingSphere===null&&e.computeBoundingSphere(),ui.copy(e.boundingSphere).applyMatrix4(t.matrixWorld)}return this.intersectsSphere(ui)}intersectsSprite(t){ui.center.set(0,0,0);const e=Xu.distanceTo(t.center);return ui.radius=.7071067811865476+e,ui.applyMatrix4(t.matrixWorld),this.intersectsSphere(ui)}intersectsSphere(t){const e=this.planes,n=t.center,i=-t.radius;for(let r=0;r<6;r++)if(e[r].distanceToPoint(n)<i)return!1;return!0}intersectsBox(t){const e=this.planes;for(let n=0;n<6;n++){const i=e[n];if(tr.x=i.normal.x>0?t.max.x:t.min.x,tr.y=i.normal.y>0?t.max.y:t.min.y,tr.z=i.normal.z>0?t.max.z:t.min.z,i.distanceToPoint(tr)<0)return!1}return!0}containsPoint(t){const e=this.planes;for(let n=0;n<6;n++)if(e[n].distanceToPoint(t)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}}class hh extends Oe{constructor(t=[],e=Mi,n,i,r,a,o,l,c,h){super(t,e,n,i,r,a,o,l,c,h),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(t){this.image=t}}class Ts extends Oe{constructor(t,e,n=Pn,i,r,a,o=Ce,l=Ce,c,h=Wn,u=1){if(h!==Wn&&h!==xi)throw new Error("THREE.DepthTexture: format must be either THREE.DepthFormat or THREE.DepthStencilFormat");const d={width:t,height:e,depth:u};super(d,i,r,a,o,l,h,n,c),this.isDepthTexture=!0,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(t){return super.copy(t),this.source=new Fo(Object.assign({},t.image)),this.compareFunction=t.compareFunction,this}toJSON(t){const e=super.toJSON(t);return e.compareFunction=this.compareFunction,e}}class qu extends Ts{constructor(t,e=Pn,n=Mi,i,r,a=Ce,o=Ce,l,c=Wn){const h={width:t,height:t,depth:1},u=[h,h,h,h,h,h];super(t,t,e,n,i,r,a,o,l,c),this.image=u,this.isCubeDepthTexture=!0,this.isCubeTexture=!0}get images(){return this.image}set images(t){this.image=t}}class dh extends Oe{constructor(t=null){super(),this.sourceTexture=t,this.isExternalTexture=!0}copy(t){return super.copy(t),this.sourceTexture=t.sourceTexture,this}}class ts extends Ae{constructor(t=1,e=1,n=1,i=1,r=1,a=1){super(),this.type="BoxGeometry",this.parameters={width:t,height:e,depth:n,widthSegments:i,heightSegments:r,depthSegments:a};const o=this;i=Math.floor(i),r=Math.floor(r),a=Math.floor(a);const l=[],c=[],h=[],u=[];let d=0,f=0;_("z","y","x",-1,-1,n,e,t,a,r,0),_("z","y","x",1,-1,n,e,-t,a,r,1),_("x","z","y",1,1,t,n,e,i,a,2),_("x","z","y",1,-1,t,n,-e,i,a,3),_("x","y","z",1,-1,t,e,n,i,r,4),_("x","y","z",-1,-1,t,e,-n,i,r,5),this.setIndex(l),this.setAttribute("position",new ee(c,3)),this.setAttribute("normal",new ee(h,3)),this.setAttribute("uv",new ee(u,2));function _(v,p,m,b,T,y,E,w,R,x,S){const C=y/R,P=E/x,D=y/2,z=E/2,L=w/2,F=R+1,X=x+1;let W=0,tt=0;const $=new O;for(let et=0;et<X;et++){const Z=et*P-z;for(let _t=0;_t<F;_t++){const Tt=_t*C-D;$[v]=Tt*b,$[p]=Z*T,$[m]=L,c.push($.x,$.y,$.z),$[v]=0,$[p]=0,$[m]=w>0?1:-1,h.push($.x,$.y,$.z),u.push(_t/R),u.push(1-et/x),W+=1}}for(let et=0;et<x;et++)for(let Z=0;Z<R;Z++){const _t=d+Z+F*et,Tt=d+Z+F*(et+1),se=d+(Z+1)+F*(et+1),Yt=d+(Z+1)+F*et;l.push(_t,Tt,Yt),l.push(Tt,se,Yt),tt+=6}o.addGroup(f,tt,S),f+=tt,d+=W}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new ts(t.width,t.height,t.depth,t.widthSegments,t.heightSegments,t.depthSegments)}}class Pr extends Ae{constructor(t=1,e=32,n=0,i=Math.PI*2){super(),this.type="CircleGeometry",this.parameters={radius:t,segments:e,thetaStart:n,thetaLength:i},e=Math.max(3,e);const r=[],a=[],o=[],l=[],c=new O,h=new Bt;a.push(0,0,0),o.push(0,0,1),l.push(.5,.5);for(let u=0,d=3;u<=e;u++,d+=3){const f=n+u/e*i;c.x=t*Math.cos(f),c.y=t*Math.sin(f),a.push(c.x,c.y,c.z),o.push(0,0,1),h.x=(a[d]/t+1)/2,h.y=(a[d+1]/t+1)/2,l.push(h.x,h.y)}for(let u=1;u<=e;u++)r.push(u,u+1,0);this.setIndex(r),this.setAttribute("position",new ee(a,3)),this.setAttribute("normal",new ee(o,3)),this.setAttribute("uv",new ee(l,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new Pr(t.radius,t.segments,t.thetaStart,t.thetaLength)}}class As extends Ae{constructor(t=1,e=1,n=1,i=32,r=1,a=!1,o=0,l=Math.PI*2){super(),this.type="CylinderGeometry",this.parameters={radiusTop:t,radiusBottom:e,height:n,radialSegments:i,heightSegments:r,openEnded:a,thetaStart:o,thetaLength:l};const c=this;i=Math.floor(i),r=Math.floor(r);const h=[],u=[],d=[],f=[];let _=0;const v=[],p=n/2;let m=0;b(),a===!1&&(t>0&&T(!0),e>0&&T(!1)),this.setIndex(h),this.setAttribute("position",new ee(u,3)),this.setAttribute("normal",new ee(d,3)),this.setAttribute("uv",new ee(f,2));function b(){const y=new O,E=new O;let w=0;const R=(e-t)/n;for(let x=0;x<=r;x++){const S=[],C=x/r,P=C*(e-t)+t;for(let D=0;D<=i;D++){const z=D/i,L=z*l+o,F=Math.sin(L),X=Math.cos(L);E.x=P*F,E.y=-C*n+p,E.z=P*X,u.push(E.x,E.y,E.z),y.set(F,R,X).normalize(),d.push(y.x,y.y,y.z),f.push(z,1-C),S.push(_++)}v.push(S)}for(let x=0;x<i;x++)for(let S=0;S<r;S++){const C=v[S][x],P=v[S+1][x],D=v[S+1][x+1],z=v[S][x+1];(t>0||S!==0)&&(h.push(C,P,z),w+=3),(e>0||S!==r-1)&&(h.push(P,D,z),w+=3)}c.addGroup(m,w,0),m+=w}function T(y){const E=_,w=new Bt,R=new O;let x=0;const S=y===!0?t:e,C=y===!0?1:-1;for(let D=1;D<=i;D++)u.push(0,p*C,0),d.push(0,C,0),f.push(.5,.5),_++;const P=_;for(let D=0;D<=i;D++){const L=D/i*l+o,F=Math.cos(L),X=Math.sin(L);R.x=S*X,R.y=p*C,R.z=S*F,u.push(R.x,R.y,R.z),d.push(0,C,0),w.x=F*.5+.5,w.y=X*.5*C+.5,f.push(w.x,w.y),_++}for(let D=0;D<i;D++){const z=E+D,L=P+D;y===!0?h.push(L,L+1,z):h.push(L+1,L,z),x+=3}c.addGroup(m,x,y===!0?1:2),m+=x}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new As(t.radiusTop,t.radiusBottom,t.height,t.radialSegments,t.heightSegments,t.openEnded,t.thetaStart,t.thetaLength)}}class zo extends As{constructor(t=1,e=1,n=32,i=1,r=!1,a=0,o=Math.PI*2){super(0,t,e,n,i,r,a,o),this.type="ConeGeometry",this.parameters={radius:t,height:e,radialSegments:n,heightSegments:i,openEnded:r,thetaStart:a,thetaLength:o}}static fromJSON(t){return new zo(t.radius,t.height,t.radialSegments,t.heightSegments,t.openEnded,t.thetaStart,t.thetaLength)}}class Ls extends Ae{constructor(t=[],e=[],n=1,i=0){super(),this.type="PolyhedronGeometry",this.parameters={vertices:t,indices:e,radius:n,detail:i};const r=[],a=[];o(i),c(n),h(),this.setAttribute("position",new ee(r,3)),this.setAttribute("normal",new ee(r.slice(),3)),this.setAttribute("uv",new ee(a,2)),i===0?this.computeVertexNormals():this.normalizeNormals();function o(b){const T=new O,y=new O,E=new O;for(let w=0;w<e.length;w+=3)f(e[w+0],T),f(e[w+1],y),f(e[w+2],E),l(T,y,E,b)}function l(b,T,y,E){const w=E+1,R=[];for(let x=0;x<=w;x++){R[x]=[];const S=b.clone().lerp(y,x/w),C=T.clone().lerp(y,x/w),P=w-x;for(let D=0;D<=P;D++)D===0&&x===w?R[x][D]=S:R[x][D]=S.clone().lerp(C,D/P)}for(let x=0;x<w;x++)for(let S=0;S<2*(w-x)-1;S++){const C=Math.floor(S/2);S%2===0?(d(R[x][C+1]),d(R[x+1][C]),d(R[x][C])):(d(R[x][C+1]),d(R[x+1][C+1]),d(R[x+1][C]))}}function c(b){const T=new O;for(let y=0;y<r.length;y+=3)T.x=r[y+0],T.y=r[y+1],T.z=r[y+2],T.normalize().multiplyScalar(b),r[y+0]=T.x,r[y+1]=T.y,r[y+2]=T.z}function h(){const b=new O;for(let T=0;T<r.length;T+=3){b.x=r[T+0],b.y=r[T+1],b.z=r[T+2];const y=p(b)/2/Math.PI+.5,E=m(b)/Math.PI+.5;a.push(y,1-E)}_(),u()}function u(){for(let b=0;b<a.length;b+=6){const T=a[b+0],y=a[b+2],E=a[b+4],w=Math.max(T,y,E),R=Math.min(T,y,E);w>.9&&R<.1&&(T<.2&&(a[b+0]+=1),y<.2&&(a[b+2]+=1),E<.2&&(a[b+4]+=1))}}function d(b){r.push(b.x,b.y,b.z)}function f(b,T){const y=b*3;T.x=t[y+0],T.y=t[y+1],T.z=t[y+2]}function _(){const b=new O,T=new O,y=new O,E=new O,w=new Bt,R=new Bt,x=new Bt;for(let S=0,C=0;S<r.length;S+=9,C+=6){b.set(r[S+0],r[S+1],r[S+2]),T.set(r[S+3],r[S+4],r[S+5]),y.set(r[S+6],r[S+7],r[S+8]),w.set(a[C+0],a[C+1]),R.set(a[C+2],a[C+3]),x.set(a[C+4],a[C+5]),E.copy(b).add(T).add(y).divideScalar(3);const P=p(E);v(w,C+0,b,P),v(R,C+2,T,P),v(x,C+4,y,P)}}function v(b,T,y,E){E<0&&b.x===1&&(a[T]=b.x-1),y.x===0&&y.z===0&&(a[T]=E/2/Math.PI+.5)}function p(b){return Math.atan2(b.z,-b.x)}function m(b){return Math.atan2(-b.y,Math.sqrt(b.x*b.x+b.z*b.z))}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new Ls(t.vertices,t.indices,t.radius,t.detail)}}class Go extends Ls{constructor(t=1,e=0){const n=(1+Math.sqrt(5))/2,i=1/n,r=[-1,-1,-1,-1,-1,1,-1,1,-1,-1,1,1,1,-1,-1,1,-1,1,1,1,-1,1,1,1,0,-i,-n,0,-i,n,0,i,-n,0,i,n,-i,-n,0,-i,n,0,i,-n,0,i,n,0,-n,0,-i,n,0,-i,-n,0,i,n,0,i],a=[3,11,7,3,7,15,3,15,13,7,19,17,7,17,6,7,6,15,17,4,8,17,8,10,17,10,6,8,0,16,8,16,2,8,2,10,0,12,1,0,1,18,0,18,16,6,10,2,6,2,13,6,13,15,2,16,18,2,18,3,2,3,13,18,1,9,18,9,11,18,11,3,4,14,12,4,12,0,4,0,8,11,9,5,11,5,19,11,19,7,19,5,14,19,14,4,19,4,17,1,12,14,1,14,5,1,5,9];super(r,a,t,e),this.type="DodecahedronGeometry",this.parameters={radius:t,detail:e}}static fromJSON(t){return new Go(t.radius,t.detail)}}class Ho extends Ls{constructor(t=1,e=0){const n=(1+Math.sqrt(5))/2,i=[-1,n,0,1,n,0,-1,-n,0,1,-n,0,0,-1,n,0,1,n,0,-1,-n,0,1,-n,n,0,-1,n,0,1,-n,0,-1,-n,0,1],r=[0,11,5,0,5,1,0,1,7,0,7,10,0,10,11,1,5,9,5,11,4,11,10,2,10,7,6,7,1,8,3,9,4,3,4,2,3,2,6,3,6,8,3,8,9,4,9,5,2,4,11,6,2,10,8,6,7,9,8,1];super(i,r,t,e),this.type="IcosahedronGeometry",this.parameters={radius:t,detail:e}}static fromJSON(t){return new Ho(t.radius,t.detail)}}class Nr extends Ls{constructor(t=1,e=0){const n=[1,0,0,-1,0,0,0,1,0,0,-1,0,0,0,1,0,0,-1],i=[0,2,4,0,4,3,0,3,5,0,5,2,1,2,5,1,5,3,1,3,4,1,4,2];super(n,i,t,e),this.type="OctahedronGeometry",this.parameters={radius:t,detail:e}}static fromJSON(t){return new Nr(t.radius,t.detail)}}class bi extends Ae{constructor(t=1,e=1,n=1,i=1){super(),this.type="PlaneGeometry",this.parameters={width:t,height:e,widthSegments:n,heightSegments:i};const r=t/2,a=e/2,o=Math.floor(n),l=Math.floor(i),c=o+1,h=l+1,u=t/o,d=e/l,f=[],_=[],v=[],p=[];for(let m=0;m<h;m++){const b=m*d-a;for(let T=0;T<c;T++){const y=T*u-r;_.push(y,-b,0),v.push(0,0,1),p.push(T/o),p.push(1-m/l)}}for(let m=0;m<l;m++)for(let b=0;b<o;b++){const T=b+c*m,y=b+c*(m+1),E=b+1+c*(m+1),w=b+1+c*m;f.push(T,y,w),f.push(y,E,w)}this.setIndex(f),this.setAttribute("position",new ee(_,3)),this.setAttribute("normal",new ee(v,3)),this.setAttribute("uv",new ee(p,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new bi(t.width,t.height,t.widthSegments,t.heightSegments)}}class Fr extends Ae{constructor(t=.5,e=1,n=32,i=1,r=0,a=Math.PI*2){super(),this.type="RingGeometry",this.parameters={innerRadius:t,outerRadius:e,thetaSegments:n,phiSegments:i,thetaStart:r,thetaLength:a},n=Math.max(3,n),i=Math.max(1,i);const o=[],l=[],c=[],h=[];let u=t;const d=(e-t)/i,f=new O,_=new Bt;for(let v=0;v<=i;v++){for(let p=0;p<=n;p++){const m=r+p/n*a;f.x=u*Math.cos(m),f.y=u*Math.sin(m),l.push(f.x,f.y,f.z),c.push(0,0,1),_.x=(f.x/e+1)/2,_.y=(f.y/e+1)/2,h.push(_.x,_.y)}u+=d}for(let v=0;v<i;v++){const p=v*(n+1);for(let m=0;m<n;m++){const b=m+p,T=b,y=b+n+1,E=b+n+2,w=b+1;o.push(T,y,w),o.push(y,E,w)}}this.setIndex(o),this.setAttribute("position",new ee(l,3)),this.setAttribute("normal",new ee(c,3)),this.setAttribute("uv",new ee(h,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new Fr(t.innerRadius,t.outerRadius,t.thetaSegments,t.phiSegments,t.thetaStart,t.thetaLength)}}function Qi(s){const t={};for(const e in s){t[e]={};for(const n in s[e]){const i=s[e][n];if(Bl(i))i.isRenderTargetTexture?(Ut("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),t[e][n]=null):t[e][n]=i.clone();else if(Array.isArray(i))if(Bl(i[0])){const r=[];for(let a=0,o=i.length;a<o;a++)r[a]=i[a].clone();t[e][n]=r}else t[e][n]=i.slice();else t[e][n]=i}}return t}function Fe(s){const t={};for(let e=0;e<s.length;e++){const n=Qi(s[e]);for(const i in n)t[i]=n[i]}return t}function Bl(s){return s&&(s.isColor||s.isMatrix3||s.isMatrix4||s.isVector2||s.isVector3||s.isVector4||s.isTexture||s.isQuaternion)}function Yu(s){const t=[];for(let e=0;e<s.length;e++)t.push(s[e].clone());return t}function uh(s){const t=s.getRenderTarget();return t===null?s.outputColorSpace:t.isXRRenderTarget===!0?t.texture.colorSpace:Xt.workingColorSpace}const $u={clone:Qi,merge:Fe};var Ku=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,Zu=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`;class _n extends Ps{constructor(t){super(),this.isShaderMaterial=!0,this.type="ShaderMaterial",this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=Ku,this.fragmentShader=Zu,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={clipCullDistance:!1,multiDraw:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,t!==void 0&&this.setValues(t)}copy(t){return super.copy(t),this.fragmentShader=t.fragmentShader,this.vertexShader=t.vertexShader,this.uniforms=Qi(t.uniforms),this.uniformsGroups=Yu(t.uniformsGroups),this.defines=Object.assign({},t.defines),this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.fog=t.fog,this.lights=t.lights,this.clipping=t.clipping,this.extensions=Object.assign({},t.extensions),this.glslVersion=t.glslVersion,this.defaultAttributeValues=Object.assign({},t.defaultAttributeValues),this.index0AttributeName=t.index0AttributeName,this.uniformsNeedUpdate=t.uniformsNeedUpdate,this}toJSON(t){const e=super.toJSON(t);e.glslVersion=this.glslVersion,e.uniforms={};for(const i in this.uniforms){const a=this.uniforms[i].value;a&&a.isTexture?e.uniforms[i]={type:"t",value:a.toJSON(t).uuid}:a&&a.isColor?e.uniforms[i]={type:"c",value:a.getHex()}:a&&a.isVector2?e.uniforms[i]={type:"v2",value:a.toArray()}:a&&a.isVector3?e.uniforms[i]={type:"v3",value:a.toArray()}:a&&a.isVector4?e.uniforms[i]={type:"v4",value:a.toArray()}:a&&a.isMatrix3?e.uniforms[i]={type:"m3",value:a.toArray()}:a&&a.isMatrix4?e.uniforms[i]={type:"m4",value:a.toArray()}:e.uniforms[i]={value:a}}Object.keys(this.defines).length>0&&(e.defines=this.defines),e.vertexShader=this.vertexShader,e.fragmentShader=this.fragmentShader,e.lights=this.lights,e.clipping=this.clipping;const n={};for(const i in this.extensions)this.extensions[i]===!0&&(n[i]=!0);return Object.keys(n).length>0&&(e.extensions=n),e}fromJSON(t,e){if(super.fromJSON(t,e),t.uniforms!==void 0)for(const n in t.uniforms){const i=t.uniforms[n];switch(this.uniforms[n]={},i.type){case"t":this.uniforms[n].value=e[i.value]||null;break;case"c":this.uniforms[n].value=new At().setHex(i.value);break;case"v2":this.uniforms[n].value=new Bt().fromArray(i.value);break;case"v3":this.uniforms[n].value=new O().fromArray(i.value);break;case"v4":this.uniforms[n].value=new _e().fromArray(i.value);break;case"m3":this.uniforms[n].value=new Ft().fromArray(i.value);break;case"m4":this.uniforms[n].value=new Zt().fromArray(i.value);break;default:this.uniforms[n].value=i.value}}if(t.defines!==void 0&&(this.defines=t.defines),t.vertexShader!==void 0&&(this.vertexShader=t.vertexShader),t.fragmentShader!==void 0&&(this.fragmentShader=t.fragmentShader),t.glslVersion!==void 0&&(this.glslVersion=t.glslVersion),t.extensions!==void 0)for(const n in t.extensions)this.extensions[n]=t.extensions[n];return t.lights!==void 0&&(this.lights=t.lights),t.clipping!==void 0&&(this.clipping=t.clipping),this}}class Ju extends _n{constructor(t){super(t),this.isRawShaderMaterial=!0,this.type="RawShaderMaterial"}}class fh extends Ps{constructor(t){super(),this.isMeshLambertMaterial=!0,this.type="MeshLambertMaterial",this.color=new At(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new At(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=go,this.normalScale=new Bt(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new nn,this.combine=To,this.reflectivity=1,this.envMapIntensity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.flatShading=!1,this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.lightMap=t.lightMap,this.lightMapIntensity=t.lightMapIntensity,this.aoMap=t.aoMap,this.aoMapIntensity=t.aoMapIntensity,this.emissive.copy(t.emissive),this.emissiveMap=t.emissiveMap,this.emissiveIntensity=t.emissiveIntensity,this.bumpMap=t.bumpMap,this.bumpScale=t.bumpScale,this.normalMap=t.normalMap,this.normalMapType=t.normalMapType,this.normalScale.copy(t.normalScale),this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this.specularMap=t.specularMap,this.alphaMap=t.alphaMap,this.envMap=t.envMap,this.envMapRotation.copy(t.envMapRotation),this.combine=t.combine,this.reflectivity=t.reflectivity,this.envMapIntensity=t.envMapIntensity,this.refractionRatio=t.refractionRatio,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.wireframeLinecap=t.wireframeLinecap,this.wireframeLinejoin=t.wireframeLinejoin,this.flatShading=t.flatShading,this.fog=t.fog,this}}class Qu extends Ps{constructor(t){super(),this.isMeshDepthMaterial=!0,this.type="MeshDepthMaterial",this.depthPacking=cu,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(t)}copy(t){return super.copy(t),this.depthPacking=t.depthPacking,this.map=t.map,this.alphaMap=t.alphaMap,this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this}}class ju extends Ps{constructor(t){super(),this.isMeshDistanceMaterial=!0,this.type="MeshDistanceMaterial",this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(t)}copy(t){return super.copy(t),this.map=t.map,this.alphaMap=t.alphaMap,this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this}}class ph extends Re{constructor(t,e=1){super(),this.isLight=!0,this.type="Light",this.color=new At(t),this.intensity=e}copy(t,e){return super.copy(t,e),this.color.copy(t.color),this.intensity=t.intensity,this}toJSON(t){const e=super.toJSON(t);return e.object.color=this.color.getHex(),e.object.intensity=this.intensity,e}}class mh extends ph{constructor(t,e,n){super(t,n),this.isHemisphereLight=!0,this.type="HemisphereLight",this.position.copy(Re.DEFAULT_UP),this.updateMatrix(),this.groundColor=new At(e)}copy(t,e){return super.copy(t,e),this.groundColor.copy(t.groundColor),this}toJSON(t){const e=super.toJSON(t);return e.object.groundColor=this.groundColor.getHex(),e}}const ga=new Zt,Ol=new O,zl=new O;class tf{constructor(t){this.camera=t,this.intensity=1,this.bias=0,this.biasNode=null,this.normalBias=0,this.radius=1,this.blurSamples=8,this.mapSize=new Bt(512,512),this.mapType=Ze,this.map=null,this.mapPass=null,this.matrix=new Zt,this.autoUpdate=!0,this.needsUpdate=!1,this._frustum=new Oo,this._frameExtents=new Bt(1,1),this._viewportCount=1,this._viewports=[new _e(0,0,1,1)]}getViewportCount(){return this._viewportCount}getCamera(){return this.camera}getFrustum(){return this._frustum}updateMatrices(t){const e=this.camera;Ol.setFromMatrixPosition(t.matrixWorld),e.position.copy(Ol),zl.setFromMatrixPosition(t.target.matrixWorld),e.lookAt(zl),e.updateMatrixWorld(),this._updateMatrix(e,this.matrix,this._frustum)}_updateMatrix(t,e,n,i){ga.multiplyMatrices(t.projectionMatrix,t.matrixWorldInverse),n.setFromProjectionMatrix(ga,t.coordinateSystem,t.reversedDepth);const r=this._frameExtents,a=i?i.z/r.x:1,o=i?i.w/r.y:1,l=i?i.x/r.x:0,c=i?i.y/r.y:0;t.coordinateSystem===Es||t.reversedDepth?e.set(.5*a,0,0,.5*a+l,0,.5*o,0,.5*o+c,0,0,1,0,0,0,0,1):e.set(.5*a,0,0,.5*a+l,0,.5*o,0,.5*o+c,0,0,.5,.5,0,0,0,1),e.multiply(ga)}getViewport(t){return this._viewports[t]}getFrameExtents(){return this._frameExtents}dispose(){this.map&&this.map.dispose(),this.mapPass&&this.mapPass.dispose()}copy(t){return this.camera=t.camera.clone(),this.intensity=t.intensity,this.bias=t.bias,this.radius=t.radius,this.autoUpdate=t.autoUpdate,this.needsUpdate=t.needsUpdate,this.normalBias=t.normalBias,this.blurSamples=t.blurSamples,this.mapSize.copy(t.mapSize),this.biasNode=t.biasNode,this}clone(){return new this.constructor().copy(this)}toJSON(){const t={};return t.intensity=this.intensity,t.bias=this.bias,t.normalBias=this.normalBias,t.radius=this.radius,t.blurSamples=this.blurSamples,t.mapSize=this.mapSize.toArray(),t.camera=this.camera.toJSON(!1).object,delete t.camera.matrix,t}}const er=new O,nr=new sn,Mn=new O;class gh extends Re{constructor(){super(),this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new Zt,this.projectionMatrix=new Zt,this.projectionMatrixInverse=new Zt,this.coordinateSystem=Tn,this._reversedDepth=!1}get reversedDepth(){return this._reversedDepth}copy(t,e){return super.copy(t,e),this.matrixWorldInverse.copy(t.matrixWorldInverse),this.projectionMatrix.copy(t.projectionMatrix),this.projectionMatrixInverse.copy(t.projectionMatrixInverse),this.coordinateSystem=t.coordinateSystem,this}getWorldDirection(t){return super.getWorldDirection(t).negate()}updateMatrixWorld(t){super.updateMatrixWorld(t),this.matrixWorld.decompose(er,nr,Mn),Mn.x===1&&Mn.y===1&&Mn.z===1?this.matrixWorldInverse.copy(this.matrixWorld).invert():this.matrixWorldInverse.compose(er,nr,Mn.set(1,1,1)).invert()}updateWorldMatrix(t,e,n=!1){super.updateWorldMatrix(t,e,n),this.matrixWorld.decompose(er,nr,Mn),Mn.x===1&&Mn.y===1&&Mn.z===1?this.matrixWorldInverse.copy(this.matrixWorld).invert():this.matrixWorldInverse.compose(er,nr,Mn.set(1,1,1)).invert()}clone(){return new this.constructor().copy(this)}}const Qn=new O,Gl=new Bt,Hl=new Bt;class Ke extends gh{constructor(t=50,e=1,n=.1,i=2e3){super(),this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=t,this.zoom=1,this.near=n,this.far=i,this.focus=10,this.aspect=e,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(t,e){return super.copy(t,e),this.fov=t.fov,this.zoom=t.zoom,this.near=t.near,this.far=t.far,this.focus=t.focus,this.aspect=t.aspect,this.view=t.view===null?null:Object.assign({},t.view),this.filmGauge=t.filmGauge,this.filmOffset=t.filmOffset,this}setFocalLength(t){const e=.5*this.getFilmHeight()/t;this.fov=_o*2*Math.atan(e),this.updateProjectionMatrix()}getFocalLength(){const t=Math.tan($r*.5*this.fov);return .5*this.getFilmHeight()/t}getEffectiveFOV(){return _o*2*Math.atan(Math.tan($r*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}getViewBounds(t,e,n){Qn.set(-1,-1,.5).applyMatrix4(this.projectionMatrixInverse),e.set(Qn.x,Qn.y).multiplyScalar(-t/Qn.z),Qn.set(1,1,.5).applyMatrix4(this.projectionMatrixInverse),n.set(Qn.x,Qn.y).multiplyScalar(-t/Qn.z)}getViewSize(t,e){return this.getViewBounds(t,Gl,Hl),e.subVectors(Hl,Gl)}setViewOffset(t,e,n,i,r,a){this.aspect=t/e,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=t,this.view.fullHeight=e,this.view.offsetX=n,this.view.offsetY=i,this.view.width=r,this.view.height=a,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const t=this.near;let e=t*Math.tan($r*.5*this.fov)/this.zoom,n=2*e,i=this.aspect*n,r=-.5*i;const a=this.view;if(this.view!==null&&this.view.enabled){const l=a.fullWidth,c=a.fullHeight;r+=a.offsetX*i/l,e-=a.offsetY*n/c,i*=a.width/l,n*=a.height/c}const o=this.filmOffset;o!==0&&(r+=t*o/this.getFilmWidth()),this.projectionMatrix.makePerspective(r,r+i,e,e-n,t,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(t){const e=super.toJSON(t);return e.object.fov=this.fov,e.object.zoom=this.zoom,e.object.near=this.near,e.object.far=this.far,e.object.focus=this.focus,e.object.aspect=this.aspect,this.view!==null&&(e.object.view=Object.assign({},this.view)),e.object.filmGauge=this.filmGauge,e.object.filmOffset=this.filmOffset,e}}class Vo extends gh{constructor(t=-1,e=1,n=1,i=-1,r=.1,a=2e3){super(),this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=t,this.right=e,this.top=n,this.bottom=i,this.near=r,this.far=a,this.updateProjectionMatrix()}copy(t,e){return super.copy(t,e),this.left=t.left,this.right=t.right,this.top=t.top,this.bottom=t.bottom,this.near=t.near,this.far=t.far,this.zoom=t.zoom,this.view=t.view===null?null:Object.assign({},t.view),this}setViewOffset(t,e,n,i,r,a){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=t,this.view.fullHeight=e,this.view.offsetX=n,this.view.offsetY=i,this.view.width=r,this.view.height=a,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const t=(this.right-this.left)/(2*this.zoom),e=(this.top-this.bottom)/(2*this.zoom),n=(this.right+this.left)/2,i=(this.top+this.bottom)/2;let r=n-t,a=n+t,o=i+e,l=i-e;if(this.view!==null&&this.view.enabled){const c=(this.right-this.left)/this.view.fullWidth/this.zoom,h=(this.top-this.bottom)/this.view.fullHeight/this.zoom;r+=c*this.view.offsetX,a=r+c*this.view.width,o-=h*this.view.offsetY,l=o-h*this.view.height}this.projectionMatrix.makeOrthographic(r,a,o,l,this.near,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(t){const e=super.toJSON(t);return e.object.zoom=this.zoom,e.object.left=this.left,e.object.right=this.right,e.object.top=this.top,e.object.bottom=this.bottom,e.object.near=this.near,e.object.far=this.far,this.view!==null&&(e.object.view=Object.assign({},this.view)),e}}class ef extends tf{constructor(){super(new Vo(-5,5,5,-5,.5,500)),this.isDirectionalLightShadow=!0}}class _h extends ph{constructor(t,e){super(t,e),this.isDirectionalLight=!0,this.type="DirectionalLight",this.position.copy(Re.DEFAULT_UP),this.updateMatrix(),this.target=new Re,this.shadow=new ef}dispose(){super.dispose(),this.shadow.dispose()}copy(t){return super.copy(t),this.target=t.target.clone(),this.shadow=t.shadow.clone(),this}toJSON(t){const e=super.toJSON(t);return e.object.shadow=this.shadow.toJSON(),e.object.target=this.target.uuid,e}}const Bi=-90,Oi=1;class nf extends Re{constructor(t,e,n){super(),this.type="CubeCamera",this.renderTarget=n,this.coordinateSystem=null,this.activeMipmapLevel=0;const i=new Ke(Bi,Oi,t,e);i.layers=this.layers,this.add(i);const r=new Ke(Bi,Oi,t,e);r.layers=this.layers,this.add(r);const a=new Ke(Bi,Oi,t,e);a.layers=this.layers,this.add(a);const o=new Ke(Bi,Oi,t,e);o.layers=this.layers,this.add(o);const l=new Ke(Bi,Oi,t,e);l.layers=this.layers,this.add(l);const c=new Ke(Bi,Oi,t,e);c.layers=this.layers,this.add(c)}updateCoordinateSystem(){const t=this.coordinateSystem,e=this.children.concat(),[n,i,r,a,o,l]=e;for(const c of e)this.remove(c);if(t===Tn)n.up.set(0,1,0),n.lookAt(1,0,0),i.up.set(0,1,0),i.lookAt(-1,0,0),r.up.set(0,0,-1),r.lookAt(0,1,0),a.up.set(0,0,1),a.lookAt(0,-1,0),o.up.set(0,1,0),o.lookAt(0,0,1),l.up.set(0,1,0),l.lookAt(0,0,-1);else if(t===Es)n.up.set(0,-1,0),n.lookAt(-1,0,0),i.up.set(0,-1,0),i.lookAt(1,0,0),r.up.set(0,0,1),r.lookAt(0,1,0),a.up.set(0,0,-1),a.lookAt(0,-1,0),o.up.set(0,-1,0),o.lookAt(0,0,1),l.up.set(0,-1,0),l.lookAt(0,0,-1);else throw new Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: "+t);for(const c of e)this.add(c),c.updateMatrixWorld()}update(t,e){this.parent===null&&this.updateMatrixWorld();const{renderTarget:n,activeMipmapLevel:i}=this;this.coordinateSystem!==t.coordinateSystem&&(this.coordinateSystem=t.coordinateSystem,this.updateCoordinateSystem());const[r,a,o,l,c,h]=this.children,u=t.getRenderTarget(),d=t.getActiveCubeFace(),f=t.getActiveMipmapLevel(),_=t.xr.enabled;t.xr.enabled=!1;const v=n.texture.generateMipmaps;n.texture.generateMipmaps=!1;let p=!1;t.isWebGLRenderer===!0?p=t.state.buffers.depth.getReversed():p=t.reversedDepthBuffer,t.setRenderTarget(n,0,i),p&&t.autoClear===!1&&t.clearDepth(),t.render(e,r),t.setRenderTarget(n,1,i),p&&t.autoClear===!1&&t.clearDepth(),t.render(e,a),t.setRenderTarget(n,2,i),p&&t.autoClear===!1&&t.clearDepth(),t.render(e,o),t.setRenderTarget(n,3,i),p&&t.autoClear===!1&&t.clearDepth(),t.render(e,l),t.setRenderTarget(n,4,i),p&&t.autoClear===!1&&t.clearDepth(),t.render(e,c),n.texture.generateMipmaps=v,t.setRenderTarget(n,5,i),p&&t.autoClear===!1&&t.clearDepth(),t.render(e,h),t.setRenderTarget(u,d,f),t.xr.enabled=_,n.texture.needsPMREMUpdate=!0}}class sf extends Ke{constructor(t=[]){super(),this.isArrayCamera=!0,this.isMultiViewCamera=!1,this.cameras=t}}const Vl=new Zt;class rf{constructor(t,e,n=0,i=1/0){this.ray=new lh(t,e),this.near=n,this.far=i,this.camera=null,this.layers=new ko,this.params={Mesh:{},Line:{threshold:1},LOD:{},Points:{threshold:1},Sprite:{}}}set(t,e){this.ray.set(t,e)}setFromCamera(t,e){e.isPerspectiveCamera?(this.ray.origin.setFromMatrixPosition(e.matrixWorld),this.ray.direction.set(t.x,t.y,.5).unproject(e).sub(this.ray.origin).normalize(),this.camera=e):e.isOrthographicCamera?(this.ray.origin.set(t.x,t.y,e.projectionMatrix.elements[14]).unproject(e),this.ray.direction.set(0,0,-1).transformDirection(e.matrixWorld),this.camera=e):Kt("Raycaster: Unsupported camera type: "+e.type)}setFromXRController(t){return Vl.identity().extractRotation(t.matrixWorld),this.ray.origin.setFromMatrixPosition(t.matrixWorld),this.ray.direction.set(0,0,-1).applyMatrix4(Vl),this}intersectObject(t,e=!0,n=[]){return xo(t,this,n,e),n.sort(Wl),n}intersectObjects(t,e=!0,n=[]){for(let i=0,r=t.length;i<r;i++)xo(t[i],this,n,e);return n.sort(Wl),n}}function Wl(s,t){return s.distance-t.distance}function xo(s,t,e,n){let i=!0;if(s.layers.test(t.layers)&&s.raycast(t,e)===!1&&(i=!1),i===!0&&n===!0){const r=s.children;for(let a=0,o=r.length;a<o;a++)xo(r[a],t,e,!0)}}const Ko=class Ko{constructor(t,e,n,i){this.elements=[1,0,0,1],t!==void 0&&this.set(t,e,n,i)}identity(){return this.set(1,0,0,1),this}fromArray(t,e=0){for(let n=0;n<4;n++)this.elements[n]=t[n+e];return this}set(t,e,n,i){const r=this.elements;return r[0]=t,r[2]=e,r[1]=n,r[3]=i,this}};Ko.prototype.isMatrix2=!0;let Xl=Ko;function ql(s,t,e,n){const i=af(n);switch(e){case th:return s*t;case Po:return s*t/i.components*i.byteLength;case Lo:return s*t/i.components*i.byteLength;case yi:return s*t*2/i.components*i.byteLength;case Do:return s*t*2/i.components*i.byteLength;case eh:return s*t*3/i.components*i.byteLength;case mn:return s*t*4/i.components*i.byteLength;case Io:return s*t*4/i.components*i.byteLength;case dr:case ur:return Math.floor((s+3)/4)*Math.floor((t+3)/4)*8;case fr:case pr:return Math.floor((s+3)/4)*Math.floor((t+3)/4)*16;case za:case Ha:return Math.max(s,16)*Math.max(t,8)/4;case Oa:case Ga:return Math.max(s,8)*Math.max(t,8)/2;case Va:case Wa:case qa:case Ya:return Math.floor((s+3)/4)*Math.floor((t+3)/4)*8;case Xa:case Er:case $a:return Math.floor((s+3)/4)*Math.floor((t+3)/4)*16;case Ka:return Math.floor((s+3)/4)*Math.floor((t+3)/4)*16;case Za:return Math.floor((s+4)/5)*Math.floor((t+3)/4)*16;case Ja:return Math.floor((s+4)/5)*Math.floor((t+4)/5)*16;case Qa:return Math.floor((s+5)/6)*Math.floor((t+4)/5)*16;case ja:return Math.floor((s+5)/6)*Math.floor((t+5)/6)*16;case to:return Math.floor((s+7)/8)*Math.floor((t+4)/5)*16;case eo:return Math.floor((s+7)/8)*Math.floor((t+5)/6)*16;case no:return Math.floor((s+7)/8)*Math.floor((t+7)/8)*16;case io:return Math.floor((s+9)/10)*Math.floor((t+4)/5)*16;case so:return Math.floor((s+9)/10)*Math.floor((t+5)/6)*16;case ro:return Math.floor((s+9)/10)*Math.floor((t+7)/8)*16;case ao:return Math.floor((s+9)/10)*Math.floor((t+9)/10)*16;case oo:return Math.floor((s+11)/12)*Math.floor((t+9)/10)*16;case lo:return Math.floor((s+11)/12)*Math.floor((t+11)/12)*16;case co:case ho:case uo:return Math.ceil(s/4)*Math.ceil(t/4)*16;case fo:case po:return Math.ceil(s/4)*Math.ceil(t/4)*8;case Tr:case mo:return Math.ceil(s/4)*Math.ceil(t/4)*16}throw new Error(`Unable to determine texture byte length for ${e} format.`)}function af(s){switch(s){case Ze:case Zc:return{byteLength:1,components:1};case Ss:case Jc:case Ln:return{byteLength:2,components:1};case Co:case Ro:return{byteLength:2,components:4};case Pn:case Ao:case pn:return{byteLength:4,components:1};case Qc:case jc:return{byteLength:4,components:3}}throw new Error(`THREE.TextureUtils: Unknown texture type ${s}.`)}typeof __THREE_DEVTOOLS__!="undefined"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:Eo}}));typeof window!="undefined"&&(window.__THREE__?Ut("WARNING: Multiple instances of Three.js being imported."):window.__THREE__=Eo);function xh(){let s=null,t=!1,e=null,n=null;function i(r,a){n=s.requestAnimationFrame(i),e(r,a)}return{start:function(){t!==!0&&e!==null&&s!==null&&(n=s.requestAnimationFrame(i),t=!0)},stop:function(){s!==null&&s.cancelAnimationFrame(n),t=!1},setAnimationLoop:function(r){e=r},setContext:function(r){s=r}}}function of(s){const t=new WeakMap;function e(o,l){const c=o.array,h=o.usage,u=c.byteLength,d=s.createBuffer();s.bindBuffer(l,d),s.bufferData(l,c,h),o.onUploadCallback();let f;if(c instanceof Float32Array)f=s.FLOAT;else if(typeof Float16Array!="undefined"&&c instanceof Float16Array)f=s.HALF_FLOAT;else if(c instanceof Uint16Array)o.isFloat16BufferAttribute?f=s.HALF_FLOAT:f=s.UNSIGNED_SHORT;else if(c instanceof Int16Array)f=s.SHORT;else if(c instanceof Uint32Array)f=s.UNSIGNED_INT;else if(c instanceof Int32Array)f=s.INT;else if(c instanceof Int8Array)f=s.BYTE;else if(c instanceof Uint8Array)f=s.UNSIGNED_BYTE;else if(c instanceof Uint8ClampedArray)f=s.UNSIGNED_BYTE;else throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: "+c);return{buffer:d,type:f,bytesPerElement:c.BYTES_PER_ELEMENT,version:o.version,size:u}}function n(o,l,c){const h=l.array,u=l.updateRanges;if(s.bindBuffer(c,o),u.length===0)s.bufferSubData(c,0,h);else{u.sort((f,_)=>f.start-_.start);let d=0;for(let f=1;f<u.length;f++){const _=u[d],v=u[f];v.start<=_.start+_.count+1?_.count=Math.max(_.count,v.start+v.count-_.start):(++d,u[d]=v)}u.length=d+1;for(let f=0,_=u.length;f<_;f++){const v=u[f];s.bufferSubData(c,v.start*h.BYTES_PER_ELEMENT,h,v.start,v.count)}l.clearUpdateRanges()}l.onUploadCallback()}function i(o){return o.isInterleavedBufferAttribute&&(o=o.data),t.get(o)}function r(o){o.isInterleavedBufferAttribute&&(o=o.data);const l=t.get(o);l&&(s.deleteBuffer(l.buffer),t.delete(o))}function a(o,l){if(o.isInterleavedBufferAttribute&&(o=o.data),o.isGLBufferAttribute){const h=t.get(o);(!h||h.version<o.version)&&t.set(o,{buffer:o.buffer,type:o.type,bytesPerElement:o.elementSize,version:o.version});return}const c=t.get(o);if(c===void 0)t.set(o,e(o,l));else if(c.version<o.version){if(c.size!==o.array.byteLength)throw new Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");n(c.buffer,o,l),c.version=o.version}}return{get:i,remove:r,update:a}}var lf=`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,cf=`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,hf=`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,df=`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,uf=`#ifdef USE_ALPHATEST
	#ifdef ALPHA_TO_COVERAGE
	diffuseColor.a = smoothstep( alphaTest, alphaTest + fwidth( diffuseColor.a ), diffuseColor.a );
	if ( diffuseColor.a == 0.0 ) discard;
	#else
	if ( diffuseColor.a < alphaTest ) discard;
	#endif
#endif`,ff=`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,pf=`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,mf=`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,gf=`#ifdef USE_BATCHING
	#if ! defined( GL_ANGLE_multi_draw )
	#define gl_DrawID _gl_DrawID
	uniform int _gl_DrawID;
	#endif
	uniform highp sampler2D batchingTexture;
	uniform highp usampler2D batchingIdTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
	float getIndirectIndex( const in int i ) {
		int size = textureSize( batchingIdTexture, 0 ).x;
		int x = i % size;
		int y = i / size;
		return float( texelFetch( batchingIdTexture, ivec2( x, y ), 0 ).r );
	}
#endif
#ifdef USE_BATCHING_COLOR
	uniform sampler2D batchingColorTexture;
	vec4 getBatchingColor( const in float i ) {
		int size = textureSize( batchingColorTexture, 0 ).x;
		int j = int( i );
		int x = j % size;
		int y = j / size;
		return texelFetch( batchingColorTexture, ivec2( x, y ), 0 );
	}
#endif`,_f=`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( getIndirectIndex( gl_DrawID ) );
#endif`,xf=`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,vf=`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,Mf=`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,yf=`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,bf=`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,Sf=`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#ifdef ALPHA_TO_COVERAGE
		float distanceToPlane, distanceGradient;
		float clipOpacity = 1.0;
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
			distanceGradient = fwidth( distanceToPlane ) / 2.0;
			clipOpacity *= smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			if ( clipOpacity == 0.0 ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			float unionClipOpacity = 1.0;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
				distanceGradient = fwidth( distanceToPlane ) / 2.0;
				unionClipOpacity *= 1.0 - smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			}
			#pragma unroll_loop_end
			clipOpacity *= 1.0 - unionClipOpacity;
		#endif
		diffuseColor.a *= clipOpacity;
		if ( diffuseColor.a == 0.0 ) discard;
	#else
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			bool clipped = true;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
			}
			#pragma unroll_loop_end
			if ( clipped ) discard;
		#endif
	#endif
#endif`,wf=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,Ef=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,Tf=`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,Af=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#endif`,Cf=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#endif`,Rf=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	varying vec4 vColor;
#endif`,Pf=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	vColor = vec4( 1.0 );
#endif
#ifdef USE_COLOR_ALPHA
	vColor *= color;
#elif defined( USE_COLOR )
	vColor.rgb *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.rgb *= instanceColor.rgb;
#endif
#ifdef USE_BATCHING_COLOR
	vColor *= getBatchingColor( getIndirectIndex( gl_DrawID ) );
#endif`,Lf=`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
#define inverseTransformDirection transformDirectionByInverseViewMatrix
vec3 transformNormalByInverseViewMatrix( in vec3 normal, in mat4 viewMatrix ) {
	return normalize( ( vec4( normal, 0.0 ) * viewMatrix ).xyz );
}
vec3 transformDirectionByInverseViewMatrix( in vec3 dir, in mat4 viewMatrix ) {
	return normalize( ( vec4( dir, 0.0 ) * viewMatrix ).xyz );
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,Df=`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,If=`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
#endif`,Uf=`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,Nf=`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,Ff=`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	#ifdef DECODE_VIDEO_TEXTURE_EMISSIVE
		emissiveColor = sRGBTransferEOTF( emissiveColor );
	#endif
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,kf=`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,Bf="gl_FragColor = linearToOutputTexel( gl_FragColor );",Of=`vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferEOTF( in vec4 value ) {
	return vec4( mix( pow( value.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), value.rgb * 0.0773993808, vec3( lessThanEqual( value.rgb, vec3( 0.04045 ) ) ) ), value.a );
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}`,zf=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, envMapRotation * reflectVec );
		#ifdef ENVMAP_BLENDING_MULTIPLY
			outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
		#elif defined( ENVMAP_BLENDING_MIX )
			outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
		#elif defined( ENVMAP_BLENDING_ADD )
			outgoingLight += envColor.xyz * specularStrength * reflectivity;
		#endif
	#endif
#endif`,Gf=`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform mat3 envMapRotation;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
#endif`,Hf=`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,Vf=`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,Wf=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = transformNormalByInverseViewMatrix( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,Xf=`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,qf=`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,Yf=`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,$f=`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,Kf=`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,Zf=`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,Jf=`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,Qf=`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,jf=`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
	if ( cutoffDistance > 0.0 ) {
		distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
	}
	return distanceFalloff;
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_SUN_LIGHTS > 0
	struct SunLight {
		vec3 direction;
		vec3 color;
	};
	uniform SunLight sunLights[ NUM_SUN_LIGHTS ];
	void getSunLightInfo( const in SunLight sunLight, out IncidentLight light ) {
		light.color = sunLight.color;
		light.direction = sunLight.direction;
		light.visible = true;
	}
#endif
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif
#include <lightprobes_pars_fragment>`,tp=`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, pow4( roughness ) ) );
			reflectVec = transformDirectionByInverseViewMatrix( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_RETROREFLECTION
		vec3 getIBLRetroRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 retroVec = normalize( mix( viewDir, normal, pow4( roughness ) ) );
				retroVec = transformDirectionByInverseViewMatrix( retroVec, viewMatrix );
				vec4 envMapColor = textureCubeUV( envMap, envMapRotation * retroVec, roughness );
				return envMapColor.rgb * envMapIntensity;
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
		#ifdef USE_RETROREFLECTION
			vec3 getIBLAnisotropyRetroRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
				#ifdef ENVMAP_TYPE_CUBE_UV
					vec3 bentNormal = cross( bitangent, viewDir );
					bentNormal = normalize( cross( bentNormal, bitangent ) );
					bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
					return getIBLRetroRadiance( viewDir, bentNormal, roughness );
				#else
					return vec3( 0.0 );
				#endif
			}
		#endif
	#endif
#endif`,ep=`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,np=`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,ip=`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,sp=`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,rp=`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.diffuseContribution = diffuseColor.rgb * ( 1.0 - metalnessFactor );
material.metalness = metalnessFactor;
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor;
	material.specularColorBlended = mix( material.specularColor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = vec3( 0.04 );
	material.specularColorBlended = mix( material.specularColor, diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_DISPERSION
	material.dispersion = dispersion;
#endif
#ifdef USE_RETROREFLECTION
	material.retroreflectivity = retroreflectivity;
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.0001, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,ap=`uniform sampler2D dfgLUT;
struct PhysicalMaterial {
	vec3 diffuseColor;
	vec3 diffuseContribution;
	vec3 specularColor;
	vec3 specularColorBlended;
	float roughness;
	float metalness;
	float specularF90;
	float dispersion;
	vec2 dfg;
	vec3 multiScatteringCompensation;
	#ifdef USE_RETROREFLECTION
		float retroreflectivity;
	#endif
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0Dielectric;
		vec3 iridescenceF0Metallic;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		return 0.5 / max( gv + gl, EPSILON );
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColorBlended;
	float f90 = material.specularF90;
	float roughness = material.roughness;
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transpose( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float rInv = 1.0 / ( roughness + 0.1 );
	float a = -1.9362 + 1.0678 * roughness + 0.4573 * r2 - 0.8469 * rInv;
	float b = -0.6014 + 0.5538 * roughness - 0.4670 * r2 - 0.1255 * rInv;
	float DG = exp( a * dotNV + b );
	return saturate( DG );
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 fab = texture2D( dfgLUT, vec2( roughness, dotNV ) ).rg;
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec2 fab, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec2 fab, const in vec3 specularColor, const in float specularF90, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColorBlended * t2.x + ( material.specularF90 - material.specularColorBlended ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseContribution * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
		#ifdef USE_CLEARCOAT
			vec3 Ncc = geometryClearcoatNormal;
			vec2 uvClearcoat = LTC_Uv( Ncc, viewDir, material.clearcoatRoughness );
			vec4 t1Clearcoat = texture2D( ltc_1, uvClearcoat );
			vec4 t2Clearcoat = texture2D( ltc_2, uvClearcoat );
			mat3 mInvClearcoat = mat3(
				vec3( t1Clearcoat.x, 0, t1Clearcoat.y ),
				vec3(             0, 1,             0 ),
				vec3( t1Clearcoat.z, 0, t1Clearcoat.w )
			);
			vec3 fresnelClearcoat = material.clearcoatF0 * t2Clearcoat.x + ( material.clearcoatF90 - material.clearcoatF0 ) * t2Clearcoat.y;
			clearcoatSpecularDirect += lightColor * fresnelClearcoat * LTC_Evaluate( Ncc, viewDir, position, mInvClearcoat, rectCoords );
		#endif
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
 
 		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
 
 		float sheenAlbedoV = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
 		float sheenAlbedoL = IBLSheenBRDF( geometryNormal, directLight.direction, material.sheenRoughness );
 
 		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * max( sheenAlbedoV, sheenAlbedoL );
 
 		irradiance *= sheenEnergyComp;
 
 	#endif
	vec3 specularBRDF = BRDF_GGX( directLight.direction, geometryViewDir, geometryNormal, material );
	#ifdef USE_RETROREFLECTION
		vec3 retroViewDir = reflect( - geometryViewDir, geometryNormal );
		vec3 retroSpecularBRDF = BRDF_GGX( directLight.direction, retroViewDir, geometryNormal, material );
		specularBRDF = mix( specularBRDF, retroSpecularBRDF, saturate( material.retroreflectivity ) );
	#endif
	reflectedLight.directSpecular += irradiance * specularBRDF * material.multiScatteringCompensation;
	vec3 halfDir = normalize( directLight.direction + geometryViewDir );
	float dotVH = saturate( dot( geometryViewDir, halfDir ) );
	vec3 F = F_Schlick( material.specularColor, material.specularF90, dotVH );
	#ifdef USE_RETROREFLECTION
		vec3 retroHalfDir = normalize( directLight.direction + retroViewDir );
		float dotRetroVH = saturate( dot( retroViewDir, retroHalfDir ) );
		vec3 retroF = F_Schlick( material.specularColor, material.specularF90, dotRetroVH );
		F = mix( F, retroF, saturate( material.retroreflectivity ) );
	#endif
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseContribution ) * ( 1.0 - F );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 singleScattering = vec3( 0.0 );
	vec3 multiScattering = vec3( 0.0 );
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( material.dfg, material.specularColor, material.specularF90, material.iridescence, material.iridescenceF0Dielectric, singleScattering, multiScattering );
	#else
		computeMultiscattering( material.dfg, material.specularColor, material.specularF90, singleScattering, multiScattering );
	#endif
	vec3 diffuse = irradiance * BRDF_Lambert( material.diffuseContribution ) * ( 1.0 - singleScattering - multiScattering );
	#ifdef USE_SHEEN
		float sheenAlbedo = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
		sheenSpecularIndirect += irradiance * material.sheenColor * sheenAlbedo * RECIPROCAL_PI;
		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * sheenAlbedo;
		diffuse *= sheenEnergyComp;
	#endif
	reflectedLight.indirectDiffuse += diffuse;
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness ) * RECIPROCAL_PI;
 	#endif
	vec3 singleScatteringDielectric = vec3( 0.0 );
	vec3 multiScatteringDielectric = vec3( 0.0 );
	vec3 singleScatteringMetallic = vec3( 0.0 );
	vec3 multiScatteringMetallic = vec3( 0.0 );
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( material.dfg, material.specularColor, material.specularF90, material.iridescence, material.iridescenceF0Dielectric, singleScatteringDielectric, multiScatteringDielectric );
		computeMultiscatteringIridescence( material.dfg, material.diffuseColor, material.specularF90, material.iridescence, material.iridescenceF0Metallic, singleScatteringMetallic, multiScatteringMetallic );
	#else
		computeMultiscattering( material.dfg, material.specularColor, material.specularF90, singleScatteringDielectric, multiScatteringDielectric );
		computeMultiscattering( material.dfg, material.diffuseColor, material.specularF90, singleScatteringMetallic, multiScatteringMetallic );
	#endif
	vec3 singleScattering = mix( singleScatteringDielectric, singleScatteringMetallic, material.metalness );
	vec3 multiScattering = mix( multiScatteringDielectric, multiScatteringMetallic, material.metalness );
	vec3 totalScatteringDielectric = singleScatteringDielectric + multiScatteringDielectric;
	vec3 diffuse = material.diffuseContribution * ( 1.0 - totalScatteringDielectric );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	vec3 indirectSpecular = radiance * singleScattering;
	indirectSpecular += multiScattering * cosineWeightedIrradiance;
	vec3 indirectDiffuse = diffuse * cosineWeightedIrradiance;
	#ifdef USE_SHEEN
		float sheenAlbedo = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * sheenAlbedo;
		indirectSpecular *= sheenEnergyComp;
		indirectDiffuse *= sheenEnergyComp;
	#endif
	reflectedLight.indirectSpecular += indirectSpecular;
	reflectedLight.indirectDiffuse += indirectDiffuse;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,op=`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		vec3 iridescenceFresnelDielectric = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		vec3 iridescenceFresnelMetallic = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.diffuseColor );
		material.iridescenceFresnel = mix( iridescenceFresnelDielectric, iridescenceFresnelMetallic, material.metalness );
		material.iridescenceF0Dielectric = Schlick_to_F0( iridescenceFresnelDielectric, 1.0, dotNVi );
		material.iridescenceF0Metallic = Schlick_to_F0( iridescenceFresnelMetallic, 1.0, dotNVi );
	}
#endif
#ifdef STANDARD
	float dotNVms = saturate( dot( geometryNormal, geometryViewDir ) );
	material.dfg = texture2D( dfgLUT, vec2( material.roughness, dotNVms ) ).rg;
	#if ( NUM_SUN_LIGHTS > 0 || NUM_DIR_LIGHTS > 0 || NUM_POINT_LIGHTS > 0 || NUM_SPOT_LIGHTS > 0 )
		float EssMs = material.dfg.x + material.dfg.y;
		material.multiScatteringCompensation = 1.0 + material.specularColorBlended * ( 1.0 / EssMs - 1.0 );
	#endif
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS ) && ( defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_BASIC ) )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowIntensity, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowIntensity, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SUN_LIGHTS > 0 ) && defined( RE_Direct )
	SunLight sunLight;
	#if defined( USE_SHADOWMAP ) && NUM_SUN_LIGHT_SHADOWS > 0
	SunLightShadow sunLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SUN_LIGHTS; i ++ ) {
		sunLight = sunLights[ i ];
		getSunLightInfo( sunLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SUN_LIGHT_SHADOWS )
		sunLightShadow = sunLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getSunShadow( sunShadowMap[ i ], sunLightShadow, UNROLLED_LOOP_INDEX ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowIntensity, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
	#ifdef USE_LIGHT_PROBES_GRID
		vec3 probeWorldPos = ( ( vec4( geometryPosition, 1.0 ) - viewMatrix[ 3 ] ) * viewMatrix ).xyz;
		vec3 probeWorldNormal = transformNormalByInverseViewMatrix( geometryNormal, viewMatrix );
		irradiance += getLightProbeGridIrradiance( probeWorldPos, probeWorldNormal );
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,lp=`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( ENVMAP_TYPE_CUBE_UV )
		#if defined( STANDARD ) || defined( LAMBERT ) || defined( PHONG )
			iblIrradiance += getIBLIrradiance( geometryNormal );
		#endif
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		vec3 iblRadiance = getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		vec3 iblRadiance = getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_RETROREFLECTION
		#ifdef USE_ANISOTROPY
			vec3 retroIBLRadiance = getIBLAnisotropyRetroRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
		#else
			vec3 retroIBLRadiance = getIBLRetroRadiance( geometryViewDir, geometryNormal, material.roughness );
		#endif
		iblRadiance = mix( iblRadiance, retroIBLRadiance, saturate( material.retroreflectivity ) );
	#endif
	radiance += iblRadiance;
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,cp=`#if defined( RE_IndirectDiffuse )
	#if defined( LAMBERT ) || defined( PHONG )
		irradiance += iblIrradiance;
	#endif
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,hp=`#ifdef USE_LIGHT_PROBES_GRID
uniform highp sampler3D probesSH;
uniform vec3 probesMin;
uniform vec3 probesMax;
uniform vec3 probesResolution;
vec3 getLightProbeGridIrradiance( vec3 worldPos, vec3 worldNormal ) {
	vec3 res = probesResolution;
	vec3 gridRange = probesMax - probesMin;
	vec3 resMinusOne = res - 1.0;
	vec3 probeSpacing = gridRange / resMinusOne;
	vec3 samplePos = worldPos + worldNormal * probeSpacing * 0.5;
	vec3 uvw = clamp( ( samplePos - probesMin ) / gridRange, 0.0, 1.0 );
	uvw = uvw * resMinusOne / res + 0.5 / res;
	float nz          = res.z;
	float paddedSlices = nz + 2.0;
	float atlasDepth  = 7.0 * paddedSlices;
	float uvZBase     = uvw.z * nz + 1.0;
	vec4 s0 = texture( probesSH, vec3( uvw.xy, ( uvZBase                       ) / atlasDepth ) );
	vec4 s1 = texture( probesSH, vec3( uvw.xy, ( uvZBase +       paddedSlices   ) / atlasDepth ) );
	vec4 s2 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 2.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s3 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 3.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s4 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 4.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s5 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 5.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s6 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 6.0 * paddedSlices   ) / atlasDepth ) );
	vec3 c0 = s0.xyz;
	vec3 c1 = vec3( s0.w, s1.xy );
	vec3 c2 = vec3( s1.zw, s2.x );
	vec3 c3 = s2.yzw;
	vec3 c4 = s3.xyz;
	vec3 c5 = vec3( s3.w, s4.xy );
	vec3 c6 = vec3( s4.zw, s5.x );
	vec3 c7 = s5.yzw;
	vec3 c8 = s6.xyz;
	float x = worldNormal.x, y = worldNormal.y, z = worldNormal.z;
	vec3 result = c0 * 0.886227;
	result += c1 * 2.0 * 0.511664 * y;
	result += c2 * 2.0 * 0.511664 * z;
	result += c3 * 2.0 * 0.511664 * x;
	result += c4 * 2.0 * 0.429043 * x * y;
	result += c5 * 2.0 * 0.429043 * y * z;
	result += c6 * ( 0.743125 * z * z - 0.247708 );
	result += c7 * 2.0 * 0.429043 * x * z;
	result += c8 * 0.429043 * ( x * x - y * y );
	return max( result, vec3( 0.0 ) );
}
#endif`,dp=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	gl_FragDepth = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,up=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,fp=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,pp=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	vFragDepth = 1.0 + gl_Position.w;
	vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
#endif`,mp=`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = sRGBTransferEOTF( sampledDiffuseColor );
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,gp=`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,_p=`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,xp=`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,vp=`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,Mp=`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,yp=`#ifdef USE_INSTANCING_MORPH
	float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	float morphTargetBaseInfluence = texelFetch( morphTexture, ivec2( 0, gl_InstanceID ), 0 ).r;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		morphTargetInfluences[i] =  texelFetch( morphTexture, ivec2( i + 1, gl_InstanceID ), 0 ).r;
	}
#endif`,bp=`#if defined( USE_MORPHCOLORS )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,Sp=`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,wp=`#ifdef USE_MORPHTARGETS
	#ifndef USE_INSTANCING_MORPH
		uniform float morphTargetBaseInfluence;
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	#endif
	uniform sampler2DArray morphTargetsTexture;
	uniform ivec2 morphTargetsTextureSize;
	vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
		int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
		int y = texelIndex / morphTargetsTextureSize.x;
		int x = texelIndex - y * morphTargetsTextureSize.x;
		ivec3 morphUV = ivec3( x, y, morphTargetIndex );
		return texelFetch( morphTargetsTexture, morphUV, 0 );
	}
#endif`,Ep=`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,Tp=`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#ifdef DOUBLE_SIDED
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#ifdef DOUBLE_SIDED
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,Ap=`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#if defined( USE_PACKED_NORMALMAP )
		mapN = vec3( mapN.xy, sqrt( saturate( 1.0 - dot( mapN.xy, mapN.xy ) ) ) );
	#endif
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,Cp=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,Rp=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,Pp=`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
		#ifdef FLIP_SIDED
			vBitangent = - vBitangent;
		#endif
	#endif
#endif`,Lp=`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,Dp=`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,Ip=`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,Up=`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,Np=`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,Fp=`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,kp=`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;const float ShiftRight8 = 1. / 256.;
const float Inv255 = 1. / 255.;
const vec4 PackFactors = vec4( 1.0, 256.0, 256.0 * 256.0, 256.0 * 256.0 * 256.0 );
const vec2 UnpackFactors2 = vec2( UnpackDownscale, 1.0 / PackFactors.g );
const vec3 UnpackFactors3 = vec3( UnpackDownscale / PackFactors.rg, 1.0 / PackFactors.b );
const vec4 UnpackFactors4 = vec4( UnpackDownscale / PackFactors.rgb, 1.0 / PackFactors.a );
vec4 packDepthToRGBA( const in float v ) {
	if( v <= 0.0 )
		return vec4( 0., 0., 0., 0. );
	if( v >= 1.0 )
		return vec4( 1., 1., 1., 1. );
	float vuf;
	float af = modf( v * PackFactors.a, vuf );
	float bf = modf( vuf * ShiftRight8, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec4( vuf * Inv255, gf * PackUpscale, bf * PackUpscale, af );
}
vec3 packDepthToRGB( const in float v ) {
	if( v <= 0.0 )
		return vec3( 0., 0., 0. );
	if( v >= 1.0 )
		return vec3( 1., 1., 1. );
	float vuf;
	float bf = modf( v * PackFactors.b, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec3( vuf * Inv255, gf * PackUpscale, bf );
}
vec2 packDepthToRG( const in float v ) {
	if( v <= 0.0 )
		return vec2( 0., 0. );
	if( v >= 1.0 )
		return vec2( 1., 1. );
	float vuf;
	float gf = modf( v * 256., vuf );
	return vec2( vuf * Inv255, gf );
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors4 );
}
float unpackRGBToDepth( const in vec3 v ) {
	return dot( v, UnpackFactors3 );
}
float unpackRGToDepth( const in vec2 v ) {
	return v.r * UnpackFactors2.r + v.g * UnpackFactors2.g;
}
vec4 pack2HalfToRGBA( const in vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( const in vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	#ifdef USE_REVERSED_DEPTH_BUFFER
	
		return depth * ( far - near ) - far;
	#else
		return depth * ( near - far ) - near;
	#endif
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	
	#ifdef USE_REVERSED_DEPTH_BUFFER
		return ( near * far ) / ( ( near - far ) * depth - near );
	#else
		return ( near * far ) / ( ( far - near ) * depth - far );
	#endif
}`,Bp=`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,Op=`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,zp=`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,Gp=`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,Hp=`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,Vp=`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,Wp=`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_SUN_LIGHT_SHADOWS > 0
		#define SUN_LIGHT_CASCADES 2
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow sunShadowMap[ NUM_SUN_LIGHT_SHADOWS ];
		#else
			uniform sampler2D sunShadowMap[ NUM_SUN_LIGHT_SHADOWS ];
		#endif
		uniform mat4 sunShadowMatrix[ NUM_SUN_LIGHT_SHADOWS * SUN_LIGHT_CASCADES ];
		uniform vec4 sunShadowCascade[ NUM_SUN_LIGHT_SHADOWS * SUN_LIGHT_CASCADES ];
		varying vec4 vSunShadowWorldPosition;
		varying vec3 vSunShadowWorldNormal;
		struct SunLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SunLightShadow sunLightShadows[ NUM_SUN_LIGHT_SHADOWS ];
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		#else
			uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		#endif
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		#else
			uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		#endif
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform samplerCubeShadow pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		#elif defined( SHADOWMAP_TYPE_BASIC )
			uniform samplerCube pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		#endif
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	#if defined( SHADOWMAP_TYPE_PCF )
		float interleavedGradientNoise( vec2 position ) {
			return fract( 52.9829189 * fract( dot( position, vec2( 0.06711056, 0.00583715 ) ) ) );
		}
		vec2 vogelDiskSample( int sampleIndex, int samplesCount, float phi ) {
			const float goldenAngle = 2.399963229728653;
			float r = sqrt( ( float( sampleIndex ) + 0.5 ) / float( samplesCount ) );
			float theta = float( sampleIndex ) * goldenAngle + phi;
			return vec2( cos( theta ), sin( theta ) ) * r;
		}
	#endif
	#if defined( SHADOWMAP_TYPE_PCF )
		float getShadow( sampler2DShadow shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			shadowCoord.z += shadowBias;
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
				float radius = shadowRadius * texelSize.x;
				float phi = interleavedGradientNoise( gl_FragCoord.xy ) * PI2;
				shadow = (
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 0, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 1, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 2, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 3, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 4, 5, phi ) * radius, shadowCoord.z ) )
				) * 0.2;
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#elif defined( SHADOWMAP_TYPE_VSM )
		float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadowCoord.z -= shadowBias;
			#else
				shadowCoord.z += shadowBias;
			#endif
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				vec2 distribution = texture2D( shadowMap, shadowCoord.xy ).rg;
				float mean = distribution.x;
				float variance = distribution.y * distribution.y;
				#ifdef USE_REVERSED_DEPTH_BUFFER
					float hard_shadow = step( mean, shadowCoord.z );
				#else
					float hard_shadow = step( shadowCoord.z, mean );
				#endif
				
				if ( hard_shadow == 1.0 ) {
					shadow = 1.0;
				} else {
					variance = max( variance, 0.0000001 );
					float d = shadowCoord.z - mean;
					float p_max = variance / ( variance + d * d );
					p_max = clamp( ( p_max - 0.3 ) / 0.65, 0.0, 1.0 );
					shadow = max( hard_shadow, p_max );
				}
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#else
		float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadowCoord.z -= shadowBias;
			#else
				shadowCoord.z += shadowBias;
			#endif
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				float depth = texture2D( shadowMap, shadowCoord.xy ).r;
				#ifdef USE_REVERSED_DEPTH_BUFFER
					shadow = step( depth, shadowCoord.z );
				#else
					shadow = step( shadowCoord.z, depth );
				#endif
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#endif
	#if NUM_SUN_LIGHT_SHADOWS > 0
		float getSunShadow(
			#if defined( SHADOWMAP_TYPE_PCF )
				sampler2DShadow shadowMap,
			#else
				sampler2D shadowMap,
			#endif
			SunLightShadow sunLightShadow,
			int shadowIndex
		) {
			vec4 shadowWorldPosition = vec4( vSunShadowWorldPosition.xyz + vSunShadowWorldNormal * sunLightShadow.shadowNormalBias, 1.0 );
			float viewDepth = vSunShadowWorldPosition.w;
			int cascadeOffset = shadowIndex * SUN_LIGHT_CASCADES;
			float shadow = 1.0;
			for ( int i = SUN_LIGHT_CASCADES - 1; i >= 0; i -- ) {
				vec4 cascade = sunShadowCascade[ cascadeOffset + i ];
				if ( viewDepth >= cascade.x && viewDepth < cascade.y ) {
					float cascadeShadow = getShadow(
						shadowMap,
						sunLightShadow.shadowMapSize,
						sunLightShadow.shadowIntensity,
						sunLightShadow.shadowBias,
						sunLightShadow.shadowRadius,
						sunShadowMatrix[ cascadeOffset + i ] * shadowWorldPosition
					);
					shadow = mix( cascadeShadow, shadow, smoothstep( cascade.z, cascade.y, viewDepth ) );
				}
			}
			return shadow;
		}
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	#if defined( SHADOWMAP_TYPE_PCF )
	float getPointShadow( samplerCubeShadow shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		vec3 bd3D = normalize( lightToPosition );
		vec3 absVec = abs( lightToPosition );
		float viewSpaceZ = max( max( absVec.x, absVec.y ), absVec.z );
		if ( viewSpaceZ - shadowCameraFar <= 0.0 && viewSpaceZ - shadowCameraNear >= 0.0 ) {
			#ifdef USE_REVERSED_DEPTH_BUFFER
				float dp = ( shadowCameraNear * ( shadowCameraFar - viewSpaceZ ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
				dp -= shadowBias;
			#else
				float dp = ( shadowCameraFar * ( viewSpaceZ - shadowCameraNear ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
				dp += shadowBias;
			#endif
			float texelSize = shadowRadius / shadowMapSize.x;
			vec3 absDir = abs( bd3D );
			vec3 tangent = absDir.x > absDir.z ? vec3( 0.0, 1.0, 0.0 ) : vec3( 1.0, 0.0, 0.0 );
			tangent = normalize( cross( bd3D, tangent ) );
			vec3 bitangent = cross( bd3D, tangent );
			float phi = interleavedGradientNoise( gl_FragCoord.xy ) * PI2;
			vec2 sample0 = vogelDiskSample( 0, 5, phi );
			vec2 sample1 = vogelDiskSample( 1, 5, phi );
			vec2 sample2 = vogelDiskSample( 2, 5, phi );
			vec2 sample3 = vogelDiskSample( 3, 5, phi );
			vec2 sample4 = vogelDiskSample( 4, 5, phi );
			shadow = (
				texture( shadowMap, vec4( bd3D + ( tangent * sample0.x + bitangent * sample0.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample1.x + bitangent * sample1.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample2.x + bitangent * sample2.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample3.x + bitangent * sample3.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample4.x + bitangent * sample4.y ) * texelSize, dp ) )
			) * 0.2;
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	#elif defined( SHADOWMAP_TYPE_BASIC )
	float getPointShadow( samplerCube shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		vec3 absVec = abs( lightToPosition );
		float viewSpaceZ = max( max( absVec.x, absVec.y ), absVec.z );
		if ( viewSpaceZ - shadowCameraFar <= 0.0 && viewSpaceZ - shadowCameraNear >= 0.0 ) {
			float dp = ( shadowCameraFar * ( viewSpaceZ - shadowCameraNear ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
			dp += shadowBias;
			vec3 bd3D = normalize( lightToPosition );
			float depth = textureCube( shadowMap, bd3D ).r;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				depth = 1.0 - depth;
			#endif
			shadow = step( dp, depth );
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	#endif
	#endif
#endif`,Xp=`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_SUN_LIGHT_SHADOWS > 0
		varying vec4 vSunShadowWorldPosition;
		varying vec3 vSunShadowWorldNormal;
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,qp=`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_SUN_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	#ifdef HAS_NORMAL
		vec3 shadowWorldNormal = transformNormalByInverseViewMatrix( transformedNormal, viewMatrix );
	#else
		vec3 shadowWorldNormal = vec3( 0.0 );
	#endif
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_SUN_LIGHT_SHADOWS > 0
		vSunShadowWorldPosition = vec4( worldPosition.xyz, - mvPosition.z );
		vSunShadowWorldNormal = shadowWorldNormal;
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,Yp=`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_SUN_LIGHT_SHADOWS > 0
	SunLightShadow sunLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SUN_LIGHT_SHADOWS; i ++ ) {
		sunLight = sunLightShadows[ i ];
		shadow *= receiveShadow ? getSunShadow( sunShadowMap[ i ], sunLight, UNROLLED_LOOP_INDEX ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowIntensity, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowIntensity, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0 && ( defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_BASIC ) )
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowIntensity, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,$p=`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,Kp=`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,Zp=`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,Jp=`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,Qp=`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,jp=`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,tm=`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,em=`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 CineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color *= toneMappingExposure;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	color = clamp( color, 0.0, 1.0 );
	return color;
}
vec3 NeutralToneMapping( vec3 color ) {
	const float StartCompression = 0.8 - 0.04;
	const float Desaturation = 0.15;
	color *= toneMappingExposure;
	float x = min( color.r, min( color.g, color.b ) );
	float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;
	color -= offset;
	float peak = max( color.r, max( color.g, color.b ) );
	if ( peak < StartCompression ) return color;
	float d = 1. - StartCompression;
	float newPeak = 1. - d * d / ( peak + d - StartCompression );
	color *= newPeak / peak;
	float g = 1. - 1. / ( Desaturation * ( peak - newPeak ) + 1. );
	return mix( color, vec3( newPeak ), g );
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,nm=`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = transformNormalByInverseViewMatrix( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseContribution, material.specularColorBlended, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.dispersion, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,im=`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float dispersion, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec4 transmittedLight;
		vec3 transmittance;
		#ifdef USE_DISPERSION
			float halfSpread = ( ior - 1.0 ) * 0.025 * dispersion;
			vec3 iors = vec3( ior - halfSpread, ior, ior + halfSpread );
			for ( int i = 0; i < 3; i ++ ) {
				vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, iors[ i ], modelMatrix );
				vec3 refractedRayExit = position + transmissionRay;
				vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
				vec2 refractionCoords = ndcPos.xy / ndcPos.w;
				refractionCoords += 1.0;
				refractionCoords /= 2.0;
				vec4 transmissionSample = getTransmissionSample( refractionCoords, roughness, iors[ i ] );
				transmittedLight[ i ] = transmissionSample[ i ];
				transmittedLight.a += transmissionSample.a;
				transmittance[ i ] = diffuseColor[ i ] * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance )[ i ];
			}
			transmittedLight.a /= 3.0;
		#else
			vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
			vec3 refractedRayExit = position + transmissionRay;
			vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
			vec2 refractionCoords = ndcPos.xy / ndcPos.w;
			refractionCoords += 1.0;
			refractionCoords /= 2.0;
			transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
			transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		#endif
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,sm=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,rm=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,am=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,om=`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`;const lm=`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,cm=`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,hm=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,dm=`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
uniform mat3 backgroundRotation;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, backgroundRotation * vWorldDirection );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, backgroundRotation * vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,um=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,fm=`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,pm=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,mm=`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	#ifdef USE_REVERSED_DEPTH_BUFFER
		float fragCoordZ = vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ];
	#else
		float fragCoordZ = 0.5 * vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ] + 0.5;
	#endif
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#elif DEPTH_PACKING == 3202
		gl_FragColor = vec4( packDepthToRGB( fragCoordZ ), 1.0 );
	#elif DEPTH_PACKING == 3203
		gl_FragColor = vec4( packDepthToRG( fragCoordZ ), 0.0, 1.0 );
	#endif
}`,gm=`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,_m=`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = vec4( dist, 0.0, 0.0, 1.0 );
}`,xm=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,vm=`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Mm=`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,ym=`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,bm=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,Sm=`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,wm=`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Em=`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Tm=`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,Am=`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Cm=`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,Rm=`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 0.0, 0.0, 0.0, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( normalize( normal ) * 0.5 + 0.5, diffuseColor.a );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,Pm=`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Lm=`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Dm=`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,Im=`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_DISPERSION
	uniform float dispersion;
#endif
#ifdef USE_RETROREFLECTION
	uniform float retroreflectivity;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
 
		outgoingLight = outgoingLight + sheenSpecularDirect + sheenSpecularIndirect;
 
 	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Um=`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Nm=`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Fm=`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,km=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,Bm=`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Om=`uniform vec3 color;
uniform float opacity;
#include <common>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,zm=`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix[ 3 ];
	vec2 scale = vec2( length( modelMatrix[ 0 ].xyz ), length( modelMatrix[ 1 ].xyz ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,Gm=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,zt={alphahash_fragment:lf,alphahash_pars_fragment:cf,alphamap_fragment:hf,alphamap_pars_fragment:df,alphatest_fragment:uf,alphatest_pars_fragment:ff,aomap_fragment:pf,aomap_pars_fragment:mf,batching_pars_vertex:gf,batching_vertex:_f,begin_vertex:xf,beginnormal_vertex:vf,bsdfs:Mf,iridescence_fragment:yf,bumpmap_pars_fragment:bf,clipping_planes_fragment:Sf,clipping_planes_pars_fragment:wf,clipping_planes_pars_vertex:Ef,clipping_planes_vertex:Tf,color_fragment:Af,color_pars_fragment:Cf,color_pars_vertex:Rf,color_vertex:Pf,common:Lf,cube_uv_reflection_fragment:Df,defaultnormal_vertex:If,displacementmap_pars_vertex:Uf,displacementmap_vertex:Nf,emissivemap_fragment:Ff,emissivemap_pars_fragment:kf,colorspace_fragment:Bf,colorspace_pars_fragment:Of,envmap_fragment:zf,envmap_common_pars_fragment:Gf,envmap_pars_fragment:Hf,envmap_pars_vertex:Vf,envmap_physical_pars_fragment:tp,envmap_vertex:Wf,fog_vertex:Xf,fog_pars_vertex:qf,fog_fragment:Yf,fog_pars_fragment:$f,gradientmap_pars_fragment:Kf,lightmap_pars_fragment:Zf,lights_lambert_fragment:Jf,lights_lambert_pars_fragment:Qf,lights_pars_begin:jf,lights_toon_fragment:ep,lights_toon_pars_fragment:np,lights_phong_fragment:ip,lights_phong_pars_fragment:sp,lights_physical_fragment:rp,lights_physical_pars_fragment:ap,lights_fragment_begin:op,lights_fragment_maps:lp,lights_fragment_end:cp,lightprobes_pars_fragment:hp,logdepthbuf_fragment:dp,logdepthbuf_pars_fragment:up,logdepthbuf_pars_vertex:fp,logdepthbuf_vertex:pp,map_fragment:mp,map_pars_fragment:gp,map_particle_fragment:_p,map_particle_pars_fragment:xp,metalnessmap_fragment:vp,metalnessmap_pars_fragment:Mp,morphinstance_vertex:yp,morphcolor_vertex:bp,morphnormal_vertex:Sp,morphtarget_pars_vertex:wp,morphtarget_vertex:Ep,normal_fragment_begin:Tp,normal_fragment_maps:Ap,normal_pars_fragment:Cp,normal_pars_vertex:Rp,normal_vertex:Pp,normalmap_pars_fragment:Lp,clearcoat_normal_fragment_begin:Dp,clearcoat_normal_fragment_maps:Ip,clearcoat_pars_fragment:Up,iridescence_pars_fragment:Np,opaque_fragment:Fp,packing:kp,premultiplied_alpha_fragment:Bp,project_vertex:Op,dithering_fragment:zp,dithering_pars_fragment:Gp,roughnessmap_fragment:Hp,roughnessmap_pars_fragment:Vp,shadowmap_pars_fragment:Wp,shadowmap_pars_vertex:Xp,shadowmap_vertex:qp,shadowmask_pars_fragment:Yp,skinbase_vertex:$p,skinning_pars_vertex:Kp,skinning_vertex:Zp,skinnormal_vertex:Jp,specularmap_fragment:Qp,specularmap_pars_fragment:jp,tonemapping_fragment:tm,tonemapping_pars_fragment:em,transmission_fragment:nm,transmission_pars_fragment:im,uv_pars_fragment:sm,uv_pars_vertex:rm,uv_vertex:am,worldpos_vertex:om,background_vert:lm,background_frag:cm,backgroundCube_vert:hm,backgroundCube_frag:dm,cube_vert:um,cube_frag:fm,depth_vert:pm,depth_frag:mm,distance_vert:gm,distance_frag:_m,equirect_vert:xm,equirect_frag:vm,linedashed_vert:Mm,linedashed_frag:ym,meshbasic_vert:bm,meshbasic_frag:Sm,meshlambert_vert:wm,meshlambert_frag:Em,meshmatcap_vert:Tm,meshmatcap_frag:Am,meshnormal_vert:Cm,meshnormal_frag:Rm,meshphong_vert:Pm,meshphong_frag:Lm,meshphysical_vert:Dm,meshphysical_frag:Im,meshtoon_vert:Um,meshtoon_frag:Nm,points_vert:Fm,points_frag:km,shadow_vert:Bm,shadow_frag:Om,sprite_vert:zm,sprite_frag:Gm},ft={common:{diffuse:{value:new At(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new Ft},alphaMap:{value:null},alphaMapTransform:{value:new Ft},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new Ft}},envmap:{envMap:{value:null},envMapRotation:{value:new Ft},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98},dfgLUT:{value:null}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new Ft}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new Ft}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new Ft},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new Ft},normalScale:{value:new Bt(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new Ft},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new Ft}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new Ft}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new Ft}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new At(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},sunLights:{value:[],properties:{direction:{},color:{}}},sunLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},sunShadowMatrix:{value:[]},sunShadowCascade:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null},probesSH:{value:null},probesMin:{value:new O},probesMax:{value:new O},probesResolution:{value:new O}},points:{diffuse:{value:new At(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new Ft},alphaTest:{value:0},uvTransform:{value:new Ft}},sprite:{diffuse:{value:new At(16777215)},opacity:{value:1},center:{value:new Bt(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new Ft},alphaMap:{value:null},alphaMapTransform:{value:new Ft},alphaTest:{value:0}}},Sn={basic:{uniforms:Fe([ft.common,ft.specularmap,ft.envmap,ft.aomap,ft.lightmap,ft.fog]),vertexShader:zt.meshbasic_vert,fragmentShader:zt.meshbasic_frag},lambert:{uniforms:Fe([ft.common,ft.specularmap,ft.envmap,ft.aomap,ft.lightmap,ft.emissivemap,ft.bumpmap,ft.normalmap,ft.displacementmap,ft.fog,ft.lights,{emissive:{value:new At(0)},envMapIntensity:{value:1}}]),vertexShader:zt.meshlambert_vert,fragmentShader:zt.meshlambert_frag},phong:{uniforms:Fe([ft.common,ft.specularmap,ft.envmap,ft.aomap,ft.lightmap,ft.emissivemap,ft.bumpmap,ft.normalmap,ft.displacementmap,ft.fog,ft.lights,{emissive:{value:new At(0)},specular:{value:new At(1118481)},shininess:{value:30},envMapIntensity:{value:1}}]),vertexShader:zt.meshphong_vert,fragmentShader:zt.meshphong_frag},standard:{uniforms:Fe([ft.common,ft.envmap,ft.aomap,ft.lightmap,ft.emissivemap,ft.bumpmap,ft.normalmap,ft.displacementmap,ft.roughnessmap,ft.metalnessmap,ft.fog,ft.lights,{emissive:{value:new At(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:zt.meshphysical_vert,fragmentShader:zt.meshphysical_frag},toon:{uniforms:Fe([ft.common,ft.aomap,ft.lightmap,ft.emissivemap,ft.bumpmap,ft.normalmap,ft.displacementmap,ft.gradientmap,ft.fog,ft.lights,{emissive:{value:new At(0)}}]),vertexShader:zt.meshtoon_vert,fragmentShader:zt.meshtoon_frag},matcap:{uniforms:Fe([ft.common,ft.bumpmap,ft.normalmap,ft.displacementmap,ft.fog,{matcap:{value:null}}]),vertexShader:zt.meshmatcap_vert,fragmentShader:zt.meshmatcap_frag},points:{uniforms:Fe([ft.points,ft.fog]),vertexShader:zt.points_vert,fragmentShader:zt.points_frag},dashed:{uniforms:Fe([ft.common,ft.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:zt.linedashed_vert,fragmentShader:zt.linedashed_frag},depth:{uniforms:Fe([ft.common,ft.displacementmap]),vertexShader:zt.depth_vert,fragmentShader:zt.depth_frag},normal:{uniforms:Fe([ft.common,ft.bumpmap,ft.normalmap,ft.displacementmap,{opacity:{value:1}}]),vertexShader:zt.meshnormal_vert,fragmentShader:zt.meshnormal_frag},sprite:{uniforms:Fe([ft.sprite,ft.fog]),vertexShader:zt.sprite_vert,fragmentShader:zt.sprite_frag},background:{uniforms:{uvTransform:{value:new Ft},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:zt.background_vert,fragmentShader:zt.background_frag},backgroundCube:{uniforms:{envMap:{value:null},backgroundBlurriness:{value:0},backgroundIntensity:{value:1},backgroundRotation:{value:new Ft}},vertexShader:zt.backgroundCube_vert,fragmentShader:zt.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:zt.cube_vert,fragmentShader:zt.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:zt.equirect_vert,fragmentShader:zt.equirect_frag},distance:{uniforms:Fe([ft.common,ft.displacementmap,{referencePosition:{value:new O},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:zt.distance_vert,fragmentShader:zt.distance_frag},shadow:{uniforms:Fe([ft.lights,ft.fog,{color:{value:new At(0)},opacity:{value:1}}]),vertexShader:zt.shadow_vert,fragmentShader:zt.shadow_frag}};Sn.physical={uniforms:Fe([Sn.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new Ft},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new Ft},clearcoatNormalScale:{value:new Bt(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new Ft},dispersion:{value:0},retroreflectivity:{value:0},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new Ft},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new Ft},sheen:{value:0},sheenColor:{value:new At(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new Ft},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new Ft},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new Ft},transmissionSamplerSize:{value:new Bt},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new Ft},attenuationDistance:{value:0},attenuationColor:{value:new At(0)},specularColor:{value:new At(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new Ft},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new Ft},anisotropyVector:{value:new Bt},anisotropyMap:{value:null},anisotropyMapTransform:{value:new Ft}}]),vertexShader:zt.meshphysical_vert,fragmentShader:zt.meshphysical_frag};const ir={r:0,b:0,g:0},Hm=new Zt,vh=new Ft;vh.set(-1,0,0,0,1,0,0,0,1);function Vm(s,t,e,n,i,r){const a=new At(0);let o=i===!0?0:1,l,c,h=null,u=0,d=null;function f(b){let T=b.isScene===!0?b.background:null;if(T&&T.isTexture){const y=b.backgroundBlurriness>0;T=t.get(T,y)}return T}function _(b){let T=!1;const y=f(b);y===null?p(a,o):y&&y.isColor&&(p(y,1),T=!0);const E=s.xr.getEnvironmentBlendMode();E==="additive"?e.buffers.color.setClear(0,0,0,1,r):E==="alpha-blend"&&e.buffers.color.setClear(0,0,0,0,r),(s.autoClear||T)&&(e.buffers.depth.setTest(!0),e.buffers.depth.setMask(!0),e.buffers.color.setMask(!0),s.clear(s.autoClearColor,s.autoClearDepth,s.autoClearStencil))}function v(b,T){const y=f(T);y&&(y.isCubeTexture||y.mapping===Ur)?(c===void 0&&(c=new le(new ts(1,1,1),new _n({name:"BackgroundCubeMaterial",uniforms:Qi(Sn.backgroundCube.uniforms),vertexShader:Sn.backgroundCube.vertexShader,fragmentShader:Sn.backgroundCube.fragmentShader,side:Ve,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),c.geometry.deleteAttribute("normal"),c.geometry.deleteAttribute("uv"),c.onBeforeRender=function(E,w,R){this.matrixWorld.copyPosition(R.matrixWorld)},Object.defineProperty(c.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),n.update(c)),c.material.uniforms.envMap.value=y,c.material.uniforms.backgroundBlurriness.value=T.backgroundBlurriness,c.material.uniforms.backgroundIntensity.value=T.backgroundIntensity,c.material.uniforms.backgroundRotation.value.setFromMatrix4(Hm.makeRotationFromEuler(T.backgroundRotation)).transpose(),y.isCubeTexture&&y.isRenderTargetTexture===!1&&c.material.uniforms.backgroundRotation.value.premultiply(vh),c.material.toneMapped=Xt.getTransfer(y.colorSpace)!==ie,(h!==y||u!==y.version||d!==s.toneMapping)&&(c.material.needsUpdate=!0,h=y,u=y.version,d=s.toneMapping),c.layers.enableAll(),b.unshift(c,c.geometry,c.material,0,0,null)):y&&y.isTexture&&(l===void 0&&(l=new le(new bi(2,2),new _n({name:"BackgroundMaterial",uniforms:Qi(Sn.background.uniforms),vertexShader:Sn.background.vertexShader,fragmentShader:Sn.background.fragmentShader,side:vi,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),l.geometry.deleteAttribute("normal"),Object.defineProperty(l.material,"map",{get:function(){return this.uniforms.t2D.value}}),n.update(l)),l.material.uniforms.t2D.value=y,l.material.uniforms.backgroundIntensity.value=T.backgroundIntensity,l.material.toneMapped=Xt.getTransfer(y.colorSpace)!==ie,y.matrixAutoUpdate===!0&&y.updateMatrix(),l.material.uniforms.uvTransform.value.copy(y.matrix),(h!==y||u!==y.version||d!==s.toneMapping)&&(l.material.needsUpdate=!0,h=y,u=y.version,d=s.toneMapping),l.layers.enableAll(),b.unshift(l,l.geometry,l.material,0,0,null))}function p(b,T){b.getRGB(ir,uh(s)),e.buffers.color.setClear(ir.r,ir.g,ir.b,T,r)}function m(){c!==void 0&&(c.geometry.dispose(),c.material.dispose(),c=void 0),l!==void 0&&(l.geometry.dispose(),l.material.dispose(),l=void 0)}return{getClearColor:function(){return a},setClearColor:function(b,T=1){a.set(b),o=T,p(a,o)},getClearAlpha:function(){return o},setClearAlpha:function(b){o=b,p(a,o)},render:_,addToRenderList:v,dispose:m}}function Wm(s,t){const e=s.getParameter(s.MAX_VERTEX_ATTRIBS),n={},i=d(null);let r=i,a=!1;function o(P,D,z,L,F){let X=!1;const W=u(P,L,z,D);r!==W&&(r=W,c(r.object)),X=f(P,L,z,F),X&&_(P,L,z,F),F!==null&&t.update(F,s.ELEMENT_ARRAY_BUFFER),(X||a)&&(a=!1,y(P,D,z,L),F!==null&&s.bindBuffer(s.ELEMENT_ARRAY_BUFFER,t.get(F).buffer))}function l(){return s.createVertexArray()}function c(P){return s.bindVertexArray(P)}function h(P){return s.deleteVertexArray(P)}function u(P,D,z,L){const F=L.wireframe===!0;let X=n[D.id];X===void 0&&(X={},n[D.id]=X);const W=P.isInstancedMesh===!0?P.id:0;let tt=X[W];tt===void 0&&(tt={},X[W]=tt);let $=tt[z.id];$===void 0&&($={},tt[z.id]=$);let et=$[F];return et===void 0&&(et=d(l()),$[F]=et),et}function d(P){const D=[],z=[],L=[];for(let F=0;F<e;F++)D[F]=0,z[F]=0,L[F]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:D,enabledAttributes:z,attributeDivisors:L,object:P,attributes:{},index:null}}function f(P,D,z,L){const F=r.attributes,X=D.attributes;let W=0;const tt=z.getAttributes();for(const $ in tt)if(tt[$].location>=0){const Z=F[$];let _t=X[$];if(_t===void 0&&($==="instanceMatrix"&&P.instanceMatrix&&(_t=P.instanceMatrix),$==="instanceColor"&&P.instanceColor&&(_t=P.instanceColor)),Z===void 0||Z.attribute!==_t||_t&&Z.data!==_t.data)return!0;W++}return r.attributesNum!==W||r.index!==L}function _(P,D,z,L){const F={},X=D.attributes;let W=0;const tt=z.getAttributes();for(const $ in tt)if(tt[$].location>=0){let Z=X[$];Z===void 0&&($==="instanceMatrix"&&P.instanceMatrix&&(Z=P.instanceMatrix),$==="instanceColor"&&P.instanceColor&&(Z=P.instanceColor));const _t={};_t.attribute=Z,Z&&Z.data&&(_t.data=Z.data),F[$]=_t,W++}r.attributes=F,r.attributesNum=W,r.index=L}function v(){const P=r.newAttributes;for(let D=0,z=P.length;D<z;D++)P[D]=0}function p(P){m(P,0)}function m(P,D){const z=r.newAttributes,L=r.enabledAttributes,F=r.attributeDivisors;z[P]=1,L[P]===0&&(s.enableVertexAttribArray(P),L[P]=1),F[P]!==D&&(s.vertexAttribDivisor(P,D),F[P]=D)}function b(){const P=r.newAttributes,D=r.enabledAttributes;for(let z=0,L=D.length;z<L;z++)D[z]!==P[z]&&(s.disableVertexAttribArray(z),D[z]=0)}function T(P,D,z,L,F,X,W){W===!0?s.vertexAttribIPointer(P,D,z,F,X):s.vertexAttribPointer(P,D,z,L,F,X)}function y(P,D,z,L){v();const F=L.attributes,X=z.getAttributes(),W=D.defaultAttributeValues;for(const tt in X){const $=X[tt];if($.location>=0){let et=F[tt];if(et===void 0&&(tt==="instanceMatrix"&&P.instanceMatrix&&(et=P.instanceMatrix),tt==="instanceColor"&&P.instanceColor&&(et=P.instanceColor)),et!==void 0){const Z=et.normalized,_t=et.itemSize,Tt=t.get(et);if(Tt===void 0)continue;const se=Tt.buffer,Yt=Tt.type,Qt=Tt.bytesPerElement,Q=Yt===s.INT||Yt===s.UNSIGNED_INT||et.gpuType===Ao;if(et.isInterleavedBufferAttribute){const st=et.data,yt=st.stride,Nt=et.offset;if(st.isInstancedInterleavedBuffer){for(let vt=0;vt<$.locationSize;vt++)m($.location+vt,st.meshPerAttribute);P.isInstancedMesh!==!0&&L._maxInstanceCount===void 0&&(L._maxInstanceCount=st.meshPerAttribute*st.count)}else for(let vt=0;vt<$.locationSize;vt++)p($.location+vt);s.bindBuffer(s.ARRAY_BUFFER,se);for(let vt=0;vt<$.locationSize;vt++)T($.location+vt,_t/$.locationSize,Yt,Z,yt*Qt,(Nt+_t/$.locationSize*vt)*Qt,Q)}else{if(et.isInstancedBufferAttribute){for(let st=0;st<$.locationSize;st++)m($.location+st,et.meshPerAttribute);P.isInstancedMesh!==!0&&L._maxInstanceCount===void 0&&(L._maxInstanceCount=et.meshPerAttribute*et.count)}else for(let st=0;st<$.locationSize;st++)p($.location+st);s.bindBuffer(s.ARRAY_BUFFER,se);for(let st=0;st<$.locationSize;st++)T($.location+st,_t/$.locationSize,Yt,Z,_t*Qt,_t/$.locationSize*st*Qt,Q)}}else if(W!==void 0){const Z=W[tt];if(Z!==void 0)switch(Z.length){case 2:s.vertexAttrib2fv($.location,Z);break;case 3:s.vertexAttrib3fv($.location,Z);break;case 4:s.vertexAttrib4fv($.location,Z);break;default:s.vertexAttrib1fv($.location,Z)}}}}b()}function E(){S();for(const P in n){const D=n[P];for(const z in D){const L=D[z];for(const F in L){const X=L[F];for(const W in X)h(X[W].object),delete X[W];delete L[F]}}delete n[P]}}function w(P){if(n[P.id]===void 0)return;const D=n[P.id];for(const z in D){const L=D[z];for(const F in L){const X=L[F];for(const W in X)h(X[W].object),delete X[W];delete L[F]}}delete n[P.id]}function R(P){for(const D in n){const z=n[D];for(const L in z){const F=z[L];if(F[P.id]===void 0)continue;const X=F[P.id];for(const W in X)h(X[W].object),delete X[W];delete F[P.id]}}}function x(P){for(const D in n){const z=n[D],L=P.isInstancedMesh===!0?P.id:0,F=z[L];if(F!==void 0){for(const X in F){const W=F[X];for(const tt in W)h(W[tt].object),delete W[tt];delete F[X]}delete z[L],Object.keys(z).length===0&&delete n[D]}}}function S(){C(),a=!0,r!==i&&(r=i,c(r.object))}function C(){i.geometry=null,i.program=null,i.wireframe=!1}return{setup:o,reset:S,resetDefaultState:C,dispose:E,releaseStatesOfGeometry:w,releaseStatesOfObject:x,releaseStatesOfProgram:R,initAttributes:v,enableAttribute:p,disableUnusedAttributes:b}}function Xm(s,t,e){let n;function i(l){n=l}function r(l,c){s.drawArrays(n,l,c),e.update(c,n,1)}function a(l,c,h){h!==0&&(s.drawArraysInstanced(n,l,c,h),e.update(c,n,h))}function o(l,c,h){if(h===0)return;t.get("WEBGL_multi_draw").multiDrawArraysWEBGL(n,l,0,c,0,h);let d=0;for(let f=0;f<h;f++)d+=c[f];e.update(d,n,1)}this.setMode=i,this.render=r,this.renderInstances=a,this.renderMultiDraw=o}function qm(s,t,e,n){let i;function r(){if(i!==void 0)return i;if(t.has("EXT_texture_filter_anisotropic")===!0){const R=t.get("EXT_texture_filter_anisotropic");i=s.getParameter(R.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else i=0;return i}function a(R){return!(R!==mn&&n.convert(R)!==s.getParameter(s.IMPLEMENTATION_COLOR_READ_FORMAT))}function o(R){const x=R===Ln&&(t.has("EXT_color_buffer_half_float")||t.has("EXT_color_buffer_float"));return!(R!==Ze&&R!==pn&&!x&&n.convert(R)!==s.getParameter(s.IMPLEMENTATION_COLOR_READ_TYPE))}function l(R){if(R==="highp"){if(s.getShaderPrecisionFormat(s.VERTEX_SHADER,s.HIGH_FLOAT).precision>0&&s.getShaderPrecisionFormat(s.FRAGMENT_SHADER,s.HIGH_FLOAT).precision>0)return"highp";R="mediump"}return R==="mediump"&&s.getShaderPrecisionFormat(s.VERTEX_SHADER,s.MEDIUM_FLOAT).precision>0&&s.getShaderPrecisionFormat(s.FRAGMENT_SHADER,s.MEDIUM_FLOAT).precision>0?"mediump":"lowp"}let c=e.precision!==void 0?e.precision:"highp";const h=l(c);h!==c&&(Ut("WebGLRenderer:",c,"not supported, using",h,"instead."),c=h);const u=e.logarithmicDepthBuffer===!0,d=e.reversedDepthBuffer===!0&&t.has("EXT_clip_control");e.reversedDepthBuffer===!0&&d===!1&&Ut("WebGLRenderer: Unable to use reversed depth buffer due to missing EXT_clip_control extension. Fallback to default depth buffer.");const f=s.getParameter(s.MAX_TEXTURE_IMAGE_UNITS),_=s.getParameter(s.MAX_VERTEX_TEXTURE_IMAGE_UNITS),v=s.getParameter(s.MAX_TEXTURE_SIZE),p=s.getParameter(s.MAX_CUBE_MAP_TEXTURE_SIZE),m=s.getParameter(s.MAX_VERTEX_ATTRIBS),b=s.getParameter(s.MAX_VERTEX_UNIFORM_VECTORS),T=s.getParameter(s.MAX_VARYING_VECTORS),y=s.getParameter(s.MAX_FRAGMENT_UNIFORM_VECTORS),E=s.getParameter(s.MAX_SAMPLES),w=s.getParameter(s.SAMPLES);return{isWebGL2:!0,getMaxAnisotropy:r,getMaxPrecision:l,textureFormatReadable:a,textureTypeReadable:o,precision:c,logarithmicDepthBuffer:u,reversedDepthBuffer:d,maxTextures:f,maxVertexTextures:_,maxTextureSize:v,maxCubemapSize:p,maxAttributes:m,maxVertexUniforms:b,maxVaryings:T,maxFragmentUniforms:y,maxSamples:E,samples:w}}function Ym(s){const t=this;let e=null,n=0,i=!1,r=!1;const a=new ni,o=new Ft,l={value:null,needsUpdate:!1};this.uniform=l,this.numPlanes=0,this.numIntersection=0,this.init=function(u,d){const f=u.length!==0||d||n!==0||i;return i=d,n=u.length,f},this.beginShadows=function(){r=!0,h(null)},this.endShadows=function(){r=!1},this.setGlobalState=function(u,d){e=h(u,d,0)},this.setState=function(u,d,f){const _=u.clippingPlanes,v=u.clipIntersection,p=u.clipShadows,m=s.get(u);if(!i||_===null||_.length===0||r&&!p)r?h(null):c();else{const b=r?0:n,T=b*4;let y=m.clippingState||null;l.value=y,y=h(_,d,T,f);for(let E=0;E!==T;++E)y[E]=e[E];m.clippingState=y,this.numIntersection=v?this.numPlanes:0,this.numPlanes+=b}};function c(){l.value!==e&&(l.value=e,l.needsUpdate=n>0),t.numPlanes=n,t.numIntersection=0}function h(u,d,f,_){const v=u!==null?u.length:0;let p=null;if(v!==0){if(p=l.value,_!==!0||p===null){const m=f+v*4,b=d.matrixWorldInverse;o.getNormalMatrix(b),(p===null||p.length<m)&&(p=new Float32Array(m));for(let T=0,y=f;T!==v;++T,y+=4)a.copy(u[T]).applyMatrix4(b,o),a.normal.toArray(p,y),p[y+3]=a.constant}l.value=p,l.needsUpdate=!0}return t.numPlanes=v,t.numIntersection=0,p}}const Wi=4,$m=6,Km=20,Zm=256,hs=new Vo,Yl=new At;let _a=null,xa=0,va=0,Ma=!1;const Jm=new O,fi=new O;class $l{constructor(t){this._renderer=t,this._pingPongRenderTarget=null,this._lodMax=0,this._cubeSize=0,this._sizeLods=[],this._lodMeshes=[],this._backgroundBox=null,this._cubemapMaterial=null,this._equirectMaterial=null,this._blurMaterial=null,this._ggxMaterial=null}fromScene(t,e=0,n=.1,i=100,r={}){const{size:a=256,position:o=Jm}=r;_a=this._renderer.getRenderTarget(),xa=this._renderer.getActiveCubeFace(),va=this._renderer.getActiveMipmapLevel(),Ma=this._renderer.xr.enabled,this._renderer.xr.enabled=!1,this._setSize(a);const l=this._allocateTargets();return l.depthBuffer=!0,this._sceneToCubeUV(t,n,i,l,o),e>0&&this._blur(l,0,0,e),this._applyPMREM(l),this._cleanup(l),l}fromEquirectangular(t,e=null){return this._fromTexture(t,e)}fromCubemap(t,e=null){return this._fromTexture(t,e)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=Jl(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=Zl(),this._compileMaterial(this._equirectMaterial))}dispose(){this._dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose(),this._backgroundBox!==null&&(this._backgroundBox.geometry.dispose(),this._backgroundBox.material.dispose())}_setSize(t){this._lodMax=Math.floor(Math.log2(t)),this._cubeSize=Math.pow(2,this._lodMax)}_dispose(){this._blurMaterial!==null&&this._blurMaterial.dispose(),this._ggxMaterial!==null&&this._ggxMaterial.dispose(),this._pingPongRenderTarget!==null&&this._pingPongRenderTarget.dispose();for(let t=0;t<this._lodMeshes.length;t++)this._lodMeshes[t].geometry.dispose()}_cleanup(t){this._renderer.setRenderTarget(_a,xa,va),this._renderer.xr.enabled=Ma,t.scissorTest=!1,zi(t,0,0,t.width,t.height)}_fromTexture(t,e){t.mapping===Mi||t.mapping===Ji?this._setSize(t.image.length===0?16:t.image[0].width||t.image[0].image.width):this._setSize(t.image.width/4),_a=this._renderer.getRenderTarget(),xa=this._renderer.getActiveCubeFace(),va=this._renderer.getActiveMipmapLevel(),Ma=this._renderer.xr.enabled,this._renderer.xr.enabled=!1;const n=e||this._allocateTargets();return this._textureToCubeUV(t,n),this._applyPMREM(n),this._cleanup(n),n}_allocateTargets(){const t=3*Math.max(this._cubeSize,112),e=4*this._cubeSize,n={magFilter:Ue,minFilter:Ue,generateMipmaps:!1,type:Ln,format:mn,colorSpace:Ar,depthBuffer:!1},i=Kl(t,e,n);if(this._pingPongRenderTarget===null||this._pingPongRenderTarget.width!==t||this._pingPongRenderTarget.height!==e){this._pingPongRenderTarget!==null&&this._dispose(),this._pingPongRenderTarget=Kl(t,e,n);const{_lodMax:r}=this;({lodMeshes:this._lodMeshes,sizeLods:this._sizeLods}=Qm(r)),this._blurMaterial=t0(r,t,e),this._ggxMaterial=jm(r,t,e)}return i}_compileMaterial(t){const e=new le(new Ae,t);this._renderer.compile(e,hs)}_sceneToCubeUV(t,e,n,i,r){const l=new Ke(90,1,e,n),c=[1,-1,1,1,1,1],h=[1,1,1,-1,-1,-1],u=this._renderer,d=u.autoClear,f=u.toneMapping;u.getClearColor(Yl),u.toneMapping=An,u.autoClear=!1,u.state.buffers.depth.getReversed()&&(u.setRenderTarget(i),u.clearDepth(),u.setRenderTarget(null)),this._backgroundBox===null&&(this._backgroundBox=new le(new ts,new si({name:"PMREM.Background",side:Ve,depthWrite:!1,depthTest:!1})));const v=this._backgroundBox,p=v.material;let m=!1;const b=t.background;b?b.isColor&&(p.color.copy(b),t.background=null,m=!0):(p.color.copy(Yl),m=!0);for(let T=0;T<6;T++){const y=T%3;y===0?(l.up.set(0,c[T],0),l.position.set(r.x,r.y,r.z),l.lookAt(r.x+h[T],r.y,r.z)):y===1?(l.up.set(0,0,c[T]),l.position.set(r.x,r.y,r.z),l.lookAt(r.x,r.y+h[T],r.z)):(l.up.set(0,c[T],0),l.position.set(r.x,r.y,r.z),l.lookAt(r.x,r.y,r.z+h[T]));const E=this._cubeSize;zi(i,y*E,T>2?E:0,E,E),u.setRenderTarget(i),m&&u.render(v,l),u.render(t,l)}u.toneMapping=f,u.autoClear=d,t.background=b}_textureToCubeUV(t,e){const n=this._renderer,i=t.mapping===Mi||t.mapping===Ji;i?(this._cubemapMaterial===null&&(this._cubemapMaterial=Jl()),this._cubemapMaterial.uniforms.flipEnvMap.value=t.isRenderTargetTexture===!1?-1:1):this._equirectMaterial===null&&(this._equirectMaterial=Zl());const r=i?this._cubemapMaterial:this._equirectMaterial,a=this._lodMeshes[0];a.material=r;const o=r.uniforms;o.envMap.value=t;const l=this._cubeSize;zi(e,0,0,3*l,2*l),n.setRenderTarget(e),n.render(a,hs)}_applyPMREM(t){const e=this._renderer,n=e.autoClear;e.autoClear=!1;const i=this._lodMeshes.length;for(let r=1;r<i;r++)this._applyGGXFilter(t,r-1,r);e.autoClear=n}_applyGGXFilter(t,e,n){const i=this._renderer,r=this._pingPongRenderTarget,a=this._ggxMaterial,o=this._lodMeshes[n];o.material=a;const l=a.uniforms,c=n/(this._lodMeshes.length-1),h=e/(this._lodMeshes.length-1),u=Math.sqrt(c*c-h*h),d=c*1.25,f=u*d,{_lodMax:_}=this,v=this._sizeLods[n],p=3*v*(n>_-Wi?n-_+Wi:0),m=4*(this._cubeSize-v);l.envMap.value=t.texture,l.roughness.value=f,l.mipInt.value=_-e,zi(r,p,m,3*v,2*v),i.setRenderTarget(r),i.render(o,hs),l.envMap.value=r.texture,l.roughness.value=0,l.mipInt.value=_-n,zi(t,p,m,3*v,2*v),i.setRenderTarget(t),i.render(o,hs)}_blur(t,e,n,i){const r=this._pingPongRenderTarget,a=Math.min(i,Math.PI)/Math.SQRT2;this._blurPass(t,r,e,n,a),this._blurPass(r,t,n,n,a)}_blurPass(t,e,n,i,r){const a=this._renderer,o=this._blurMaterial,l=this._lodMeshes[i];l.material=o;const c=o.uniforms;c.envMap.value=t.texture,c.sigma.value=r,c.mipInt.value=this._lodMax-n;const h=this._sizeLods[i],u=3*h*(i>this._lodMax-Wi?i-this._lodMax+Wi:0),d=4*(this._cubeSize-h);zi(e,u,d,3*h,2*h),a.setRenderTarget(e),a.render(l,hs)}}function Qm(s){const t=[],e=[];let n=s;const i=s-Wi+1+$m;for(let r=0;r<i;r++){const a=Math.pow(2,n);t.push(a);const o=1/(a-2),l=-o,c=1+o,h=[l,l,c,l,c,c,l,l,c,c,l,c],u=6,d=6,f=3,_=new Float32Array(f*d*u),v=new Float32Array(f*d*u);for(let m=0;m<u;m++){const b=m%3*2/3-1,T=m>2?0:-1,y=[b,T,0,b+2/3,T,0,b+2/3,T+1,0,b,T,0,b+2/3,T+1,0,b,T+1,0];_.set(y,f*d*m);for(let E=0;E<d;E++){const w=h[E*2]*2-1,R=h[E*2+1]*2-1;m===0?fi.set(1,R,w):m===1?fi.set(-w,1,-R):m===2?fi.set(-w,R,1):m===3?fi.set(-1,R,-w):m===4?fi.set(-w,-1,R):fi.set(w,R,-1),fi.toArray(v,(m*d+E)*f)}}const p=new Ae;p.setAttribute("position",new Cn(_,f)),p.setAttribute("outputDirection",new Cn(v,f)),e.push(new le(p,null)),n>Wi&&n--}return{lodMeshes:e,sizeLods:t}}function Kl(s,t,e){const n=new gn(s,t,e);return n.texture.mapping=Ur,n.texture.name="PMREM.cubeUv",n.scissorTest=!0,n}function zi(s,t,e,n,i){s.viewport.set(t,e,n,i),s.scissor.set(t,e,n,i)}function jm(s,t,e){return new _n({name:"PMREMGGXConvolution",defines:{GGX_SAMPLES:Zm,CUBEUV_TEXEL_WIDTH:1/t,CUBEUV_TEXEL_HEIGHT:1/e,CUBEUV_MAX_MIP:`${s}.0`},uniforms:{envMap:{value:null},roughness:{value:0},mipInt:{value:0}},vertexShader:kr(),fragmentShader:`

			precision highp float;
			precision highp int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform float roughness;
			uniform float mipInt;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			#define PI 3.14159265359

			// Van der Corput radical inverse
			float radicalInverse_VdC(uint bits) {
				bits = (bits << 16u) | (bits >> 16u);
				bits = ((bits & 0x55555555u) << 1u) | ((bits & 0xAAAAAAAAu) >> 1u);
				bits = ((bits & 0x33333333u) << 2u) | ((bits & 0xCCCCCCCCu) >> 2u);
				bits = ((bits & 0x0F0F0F0Fu) << 4u) | ((bits & 0xF0F0F0F0u) >> 4u);
				bits = ((bits & 0x00FF00FFu) << 8u) | ((bits & 0xFF00FF00u) >> 8u);
				return float(bits) * 2.3283064365386963e-10; // / 0x100000000
			}

			// Hammersley sequence
			vec2 hammersley(uint i, uint N) {
				return vec2(float(i) / float(N), radicalInverse_VdC(i));
			}

			// GGX VNDF importance sampling (Eric Heitz 2018)
			// "Sampling the GGX Distribution of Visible Normals"
			// https://jcgt.org/published/0007/04/01/
			vec3 importanceSampleGGX_VNDF(vec2 Xi, vec3 V, float roughness) {
				float alpha = roughness * roughness;

				// Section 4.1: Orthonormal basis
				vec3 T1 = vec3(1.0, 0.0, 0.0);
				vec3 T2 = cross(V, T1);

				// Section 4.2: Parameterization of projected area
				float r = sqrt(Xi.x);
				float phi = 2.0 * PI * Xi.y;
				float t1 = r * cos(phi);
				float t2 = r * sin(phi);
				float s = 0.5 * (1.0 + V.z);
				t2 = (1.0 - s) * sqrt(1.0 - t1 * t1) + s * t2;

				// Section 4.3: Reprojection onto hemisphere
				vec3 Nh = t1 * T1 + t2 * T2 + sqrt(max(0.0, 1.0 - t1 * t1 - t2 * t2)) * V;

				// Section 3.4: Transform back to ellipsoid configuration
				return normalize(vec3(alpha * Nh.x, alpha * Nh.y, max(0.0, Nh.z)));
			}

			void main() {
				vec3 N = normalize(vOutputDirection);
				vec3 V = N; // Assume view direction equals normal for pre-filtering

				vec3 prefilteredColor = vec3(0.0);
				float totalWeight = 0.0;

				// For very low roughness, just sample the environment directly
				if (roughness < 0.001) {
					gl_FragColor = vec4(bilinearCubeUV(envMap, N, mipInt), 1.0);
					return;
				}

				// Tangent space basis for VNDF sampling
				vec3 up = abs(N.z) < 0.999 ? vec3(0.0, 0.0, 1.0) : vec3(1.0, 0.0, 0.0);
				vec3 tangent = normalize(cross(up, N));
				vec3 bitangent = cross(N, tangent);

				for(uint i = 0u; i < uint(GGX_SAMPLES); i++) {
					vec2 Xi = hammersley(i, uint(GGX_SAMPLES));

					// For PMREM, V = N, so in tangent space V is always (0, 0, 1)
					vec3 H_tangent = importanceSampleGGX_VNDF(Xi, vec3(0.0, 0.0, 1.0), roughness);

					// Transform H back to world space
					vec3 H = normalize(tangent * H_tangent.x + bitangent * H_tangent.y + N * H_tangent.z);
					vec3 L = normalize(2.0 * dot(V, H) * H - V);

					float NdotL = max(dot(N, L), 0.0);

					if(NdotL > 0.0) {
						// Sample environment at fixed mip level
						// VNDF importance sampling handles the distribution filtering
						vec3 sampleColor = bilinearCubeUV(envMap, L, mipInt);

						// Weight by NdotL for the split-sum approximation
						// VNDF PDF naturally accounts for the visible microfacet distribution
						prefilteredColor += sampleColor * NdotL;
						totalWeight += NdotL;
					}
				}

				if (totalWeight > 0.0) {
					prefilteredColor = prefilteredColor / totalWeight;
				}

				gl_FragColor = vec4(prefilteredColor, 1.0);
			}
		`,blending:zn,depthTest:!1,depthWrite:!1})}function t0(s,t,e){return new _n({name:"SphericalGaussianBlur",defines:{SAMPLES:Km,CUBEUV_TEXEL_WIDTH:1/t,CUBEUV_TEXEL_HEIGHT:1/e,CUBEUV_MAX_MIP:`${s}.0`},uniforms:{envMap:{value:null},sigma:{value:0},mipInt:{value:0}},vertexShader:kr(),fragmentShader:`

			precision highp float;
			precision highp int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform float sigma;
			uniform float mipInt;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			#define PI 3.14159265359
			#define GOLDEN_ANGLE 2.39996322973

			void main() {

				if ( sigma == 0.0 ) {

					gl_FragColor = vec4( bilinearCubeUV( envMap, vOutputDirection, mipInt ), 1.0 );
					return;

				}

				vec3 outputDirection = normalize( vOutputDirection );

				vec3 up = abs( outputDirection.z ) < 0.999 ? vec3( 0.0, 0.0, 1.0 ) : vec3( 1.0, 0.0, 0.0 );
				vec3 tangent = normalize( cross( up, outputDirection ) );
				vec3 bitangent = cross( outputDirection, tangent );

				// Truncate the kernel at three standard deviations or at the antipode.
				float thetaMax = min( 3.0 * sigma, PI );
				float truncation = 1.0 - exp( - 0.5 * thetaMax * thetaMax / ( sigma * sigma ) );

				vec3 accumColor = vec3( 0.0 );
				float accumWeight = 0.0;

				for ( int i = 0; i < SAMPLES; i ++ ) {

					// Stratified inverse-CDF sampling of the Gaussian, placed on a golden-angle spiral.
					float stratum = ( float( i ) + 0.5 ) / float( SAMPLES );
					float theta = sigma * sqrt( - 2.0 * log( 1.0 - stratum * truncation ) );
					float phi = float( i ) * GOLDEN_ANGLE;

					vec3 offset = cos( phi ) * tangent + sin( phi ) * bitangent;
					vec3 sampleDirection = cos( theta ) * outputDirection + sin( theta ) * offset;

					// Correct the planar sample density to solid angle.
					float weight = sin( theta ) / theta;

					accumColor += weight * bilinearCubeUV( envMap, sampleDirection, mipInt );
					accumWeight += weight;

				}

				gl_FragColor = vec4( accumColor / accumWeight, 1.0 );

			}
		`,blending:zn,depthTest:!1,depthWrite:!1})}function Zl(){return new _n({name:"EquirectangularToCubeUV",uniforms:{envMap:{value:null}},vertexShader:kr(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,blending:zn,depthTest:!1,depthWrite:!1})}function Jl(){return new _n({name:"CubemapToCubeUV",uniforms:{envMap:{value:null},flipEnvMap:{value:-1}},vertexShader:kr(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,blending:zn,depthTest:!1,depthWrite:!1})}function kr(){return`

		precision mediump float;
		precision mediump int;

		attribute vec3 outputDirection;

		varying vec3 vOutputDirection;

		void main() {

			vOutputDirection = outputDirection;
			gl_Position = vec4( position, 1.0 );

		}
	`}class Mh extends gn{constructor(t=1,e={}){super(t,t,e),this.isWebGLCubeRenderTarget=!0;const n={width:t,height:t,depth:1},i=[n,n,n,n,n,n];this.texture=new hh(i),this._setTextureOptions(e),this.texture.isRenderTargetTexture=!0}fromEquirectangularTexture(t,e){this.texture.type=e.type,this.texture.colorSpace=e.colorSpace,this.texture.generateMipmaps=e.generateMipmaps,this.texture.minFilter=e.minFilter,this.texture.magFilter=e.magFilter;const n={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},i=new ts(5,5,5),r=new _n({name:"CubemapFromEquirect",uniforms:Qi(n.uniforms),vertexShader:n.vertexShader,fragmentShader:n.fragmentShader,side:Ve,blending:zn});r.uniforms.tEquirect.value=e;const a=new le(i,r),o=e.minFilter;return e.minFilter===_i&&(e.minFilter=Ue),new nf(1,10,this).update(t,a),e.minFilter=o,a.geometry.dispose(),a.material.dispose(),this}clear(t,e=!0,n=!0,i=!0){const r=t.getRenderTarget();for(let a=0;a<6;a++)t.setRenderTarget(this,a),t.clear(e,n,i);t.setRenderTarget(r)}}function e0(s){let t=new WeakMap,e=new WeakMap,n=null;function i(d,f=!1){return d==null?null:f?a(d):r(d)}function r(d){if(d&&d.isTexture){const f=d.mapping;if(f===Wr||f===Xr)if(t.has(d)){const _=t.get(d).texture;return o(_,d.mapping)}else{const _=d.image;if(_&&_.height>0){const v=new Mh(_.height);return v.fromEquirectangularTexture(s,d),t.set(d,v),d.addEventListener("dispose",c),o(v.texture,d.mapping)}else return null}}return d}function a(d){if(d&&d.isTexture){const f=d.mapping,_=f===Wr||f===Xr,v=f===Mi||f===Ji;if(_||v){let p=e.get(d);const m=p!==void 0?p.texture.pmremVersion:0;if(d.isRenderTargetTexture&&d.pmremVersion!==m)return n===null&&(n=new $l(s)),p=_?n.fromEquirectangular(d,p):n.fromCubemap(d,p),p.texture.pmremVersion=d.pmremVersion,e.set(d,p),p.texture;if(p!==void 0)return p.texture;{const b=d.image;return _&&b&&b.height>0||v&&b&&l(b)?(n===null&&(n=new $l(s)),p=_?n.fromEquirectangular(d):n.fromCubemap(d),p.texture.pmremVersion=d.pmremVersion,e.set(d,p),d.addEventListener("dispose",h),p.texture):null}}}return d}function o(d,f){return f===Wr?d.mapping=Mi:f===Xr&&(d.mapping=Ji),d}function l(d){let f=0;const _=6;for(let v=0;v<_;v++)d[v]!==void 0&&f++;return f===_}function c(d){const f=d.target;f.removeEventListener("dispose",c);const _=t.get(f);_!==void 0&&(t.delete(f),_.dispose())}function h(d){const f=d.target;f.removeEventListener("dispose",h);const _=e.get(f);_!==void 0&&(e.delete(f),_.dispose())}function u(){t=new WeakMap,e=new WeakMap,n!==null&&(n.dispose(),n=null)}return{get:i,dispose:u}}function n0(s){const t={};function e(n){if(t[n]!==void 0)return t[n];const i=s.getExtension(n);return t[n]=i,i}return{has:function(n){return e(n)!==null},init:function(){e("EXT_color_buffer_float"),e("WEBGL_clip_cull_distance"),e("OES_texture_float_linear"),e("EXT_color_buffer_half_float"),e("WEBGL_multisampled_render_to_texture"),e("WEBGL_render_shared_exponent")},get:function(n){const i=e(n);return i===null&&Ki("WebGLRenderer: "+n+" extension not supported."),i}}}function i0(s,t,e,n){const i={},r=new WeakMap;function a(u){const d=u.target;d.index!==null&&t.remove(d.index);for(const _ in d.attributes)t.remove(d.attributes[_]);d.removeEventListener("dispose",a),delete i[d.id];const f=r.get(d);f&&(t.remove(f),r.delete(d)),n.releaseStatesOfGeometry(d),d.isInstancedBufferGeometry===!0&&delete d._maxInstanceCount,e.memory.geometries--}function o(u,d){return i[d.id]===!0||(d.addEventListener("dispose",a),i[d.id]=!0,e.memory.geometries++),d}function l(u){const d=u.attributes;for(const f in d)t.update(d[f],s.ARRAY_BUFFER)}function c(u){const d=[],f=u.index,_=u.attributes.position;let v=0;if(_===void 0)return;if(f!==null){const b=f.array;v=f.version;for(let T=0,y=b.length;T<y;T+=3){const E=b[T+0],w=b[T+1],R=b[T+2];d.push(E,w,w,R,R,E)}}else{const b=_.array;v=_.version;for(let T=0,y=b.length/3-1;T<y;T+=3){const E=T+0,w=T+1,R=T+2;d.push(E,w,w,R,R,E)}}const p=new(_.count>=65535?oh:ah)(d,1);p.version=v;const m=r.get(u);m&&t.remove(m),r.set(u,p)}function h(u){const d=r.get(u);if(d){const f=u.index;f!==null&&d.version<f.version&&c(u)}else c(u);return r.get(u)}return{get:o,update:l,getWireframeAttribute:h}}function s0(s,t,e){let n;function i(u){n=u}let r,a;function o(u){r=u.type,a=u.bytesPerElement}function l(u,d){s.drawElements(n,d,r,u*a),e.update(d,n,1)}function c(u,d,f){f!==0&&(s.drawElementsInstanced(n,d,r,u*a,f),e.update(d,n,f))}function h(u,d,f){if(f===0)return;t.get("WEBGL_multi_draw").multiDrawElementsWEBGL(n,d,0,r,u,0,f);let v=0;for(let p=0;p<f;p++)v+=d[p];e.update(v,n,1)}this.setMode=i,this.setIndex=o,this.render=l,this.renderInstances=c,this.renderMultiDraw=h}function r0(s){const t={geometries:0,textures:0},e={frame:0,calls:0,triangles:0,points:0,lines:0};function n(r,a,o){switch(e.calls++,a){case s.TRIANGLES:e.triangles+=o*(r/3);break;case s.LINES:e.lines+=o*(r/2);break;case s.LINE_STRIP:e.lines+=o*(r-1);break;case s.LINE_LOOP:e.lines+=o*r;break;case s.POINTS:e.points+=o*r;break;default:Kt("WebGLInfo: Unknown draw mode:",a);break}}function i(){e.calls=0,e.triangles=0,e.points=0,e.lines=0}return{memory:t,render:e,programs:null,autoReset:!0,reset:i,update:n}}function a0(s,t,e){const n=new WeakMap,i=new _e;function r(a,o,l){const c=a.morphTargetInfluences,h=o.morphAttributes.position||o.morphAttributes.normal||o.morphAttributes.color,u=h!==void 0?h.length:0;let d=n.get(o);if(d===void 0||d.count!==u){let C=function(){x.dispose(),n.delete(o),o.removeEventListener("dispose",C)};var f=C;d!==void 0&&d.texture.dispose();const _=o.morphAttributes.position!==void 0,v=o.morphAttributes.normal!==void 0,p=o.morphAttributes.color!==void 0,m=o.morphAttributes.position||[],b=o.morphAttributes.normal||[],T=o.morphAttributes.color||[];let y=0;_===!0&&(y=1),v===!0&&(y=2),p===!0&&(y=3);let E=o.attributes.position.count*y,w=1;E>t.maxTextureSize&&(w=Math.ceil(E/t.maxTextureSize),E=t.maxTextureSize);const R=new Float32Array(E*w*4*u),x=new ih(R,E,w,u);x.type=pn,x.needsUpdate=!0;const S=y*4;for(let P=0;P<u;P++){const D=m[P],z=b[P],L=T[P],F=E*w*4*P;for(let X=0;X<D.count;X++){const W=X*S;_===!0&&(i.fromBufferAttribute(D,X),R[F+W+0]=i.x,R[F+W+1]=i.y,R[F+W+2]=i.z,R[F+W+3]=0),v===!0&&(i.fromBufferAttribute(z,X),R[F+W+4]=i.x,R[F+W+5]=i.y,R[F+W+6]=i.z,R[F+W+7]=0),p===!0&&(i.fromBufferAttribute(L,X),R[F+W+8]=i.x,R[F+W+9]=i.y,R[F+W+10]=i.z,R[F+W+11]=L.itemSize===4?i.w:1)}}d={count:u,texture:x,size:new Bt(E,w)},n.set(o,d),o.addEventListener("dispose",C)}if(a.isInstancedMesh===!0&&a.morphTexture!==null)l.getUniforms().setValue(s,"morphTexture",a.morphTexture,e);else{let _=0;for(let p=0;p<c.length;p++)_+=c[p];const v=o.morphTargetsRelative?1:1-_;l.getUniforms().setValue(s,"morphTargetBaseInfluence",v),l.getUniforms().setValue(s,"morphTargetInfluences",c)}l.getUniforms().setValue(s,"morphTargetsTexture",d.texture,e),l.getUniforms().setValue(s,"morphTargetsTextureSize",d.size)}return{update:r}}function o0(s,t,e,n,i){let r=new WeakMap;function a(c){const h=i.render.frame,u=c.geometry,d=t.get(c,u);if(r.get(d)!==h&&(t.update(d),r.set(d,h)),c.isInstancedMesh&&(c.hasEventListener("dispose",l)===!1&&c.addEventListener("dispose",l),r.get(c)!==h&&(e.update(c.instanceMatrix,s.ARRAY_BUFFER),c.instanceColor!==null&&e.update(c.instanceColor,s.ARRAY_BUFFER),r.set(c,h))),c.isSkinnedMesh){const f=c.skeleton;r.get(f)!==h&&(f.update(),r.set(f,h))}return d}function o(){r=new WeakMap}function l(c){const h=c.target;h.removeEventListener("dispose",l),n.releaseStatesOfObject(h),e.remove(h.instanceMatrix),h.instanceColor!==null&&e.remove(h.instanceColor)}return{update:a,dispose:o}}const l0={[Hc]:"LINEAR_TONE_MAPPING",[Vc]:"REINHARD_TONE_MAPPING",[Wc]:"CINEON_TONE_MAPPING",[Xc]:"ACES_FILMIC_TONE_MAPPING",[Yc]:"AGX_TONE_MAPPING",[$c]:"NEUTRAL_TONE_MAPPING",[qc]:"CUSTOM_TONE_MAPPING"};function c0(s,t,e,n,i,r){const a=new gn(t,e,{type:s,depthBuffer:i,stencilBuffer:r,samples:n?4:0,storeMultisampledDepthBuffer:!1,storeMultisampledStencilBuffer:!1,resolveDepthBuffer:!1,resolveStencilBuffer:!1});let o=null,l=null;const c=new Ae;c.setAttribute("position",new ee([-1,3,0,-1,-1,0,3,-1,0],3)),c.setAttribute("uv",new ee([0,2,0,0,2,0],2));const h=new Ju({uniforms:{tDiffuse:{value:null}},vertexShader:`
			precision highp float;

			uniform mat4 modelViewMatrix;
			uniform mat4 projectionMatrix;

			attribute vec3 position;
			attribute vec2 uv;

			varying vec2 vUv;

			void main() {
				vUv = uv;
				gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
			}`,fragmentShader:`
			precision highp float;

			uniform sampler2D tDiffuse;

			varying vec2 vUv;

			#include <tonemapping_pars_fragment>
			#include <colorspace_pars_fragment>

			void main() {
				gl_FragColor = texture2D( tDiffuse, vUv );

				#ifdef LINEAR_TONE_MAPPING
					gl_FragColor.rgb = LinearToneMapping( gl_FragColor.rgb );
				#elif defined( REINHARD_TONE_MAPPING )
					gl_FragColor.rgb = ReinhardToneMapping( gl_FragColor.rgb );
				#elif defined( CINEON_TONE_MAPPING )
					gl_FragColor.rgb = CineonToneMapping( gl_FragColor.rgb );
				#elif defined( ACES_FILMIC_TONE_MAPPING )
					gl_FragColor.rgb = ACESFilmicToneMapping( gl_FragColor.rgb );
				#elif defined( AGX_TONE_MAPPING )
					gl_FragColor.rgb = AgXToneMapping( gl_FragColor.rgb );
				#elif defined( NEUTRAL_TONE_MAPPING )
					gl_FragColor.rgb = NeutralToneMapping( gl_FragColor.rgb );
				#elif defined( CUSTOM_TONE_MAPPING )
					gl_FragColor.rgb = CustomToneMapping( gl_FragColor.rgb );
				#endif

				#ifdef SRGB_TRANSFER
					gl_FragColor = sRGBTransferOETF( gl_FragColor );
				#endif
			}`,depthTest:!1,depthWrite:!1}),u=new le(c,h),d=new Vo(-1,1,1,-1,0,1);let f=null,_=null,v=!1,p,m=null,b=[],T=!1;this.setSize=function(y,E){a.setSize(y,E),o!==null&&o.setSize(y,E),l!==null&&l.setSize(y,E);for(let w=0;w<b.length;w++){const R=b[w];R.setSize&&R.setSize(y,E)}},this.setEffects=function(y){b=y,T=b.length>0&&b[0].isRenderPass===!0;const E=a.width,w=a.height;b.length>0&&o===null&&(o=new gn(E,w,{type:Ln,depthBuffer:!1,stencilBuffer:!1}),l=new gn(E,w,{type:Ln,depthBuffer:!1,stencilBuffer:!1}));for(let R=0;R<b.length;R++){const x=b[R];x.setSize&&x.setSize(E,w)}},this.begin=function(y,E){if(v||y.toneMapping===An&&b.length===0)return!1;if(m=E,E!==null){const w=E.width,R=E.height;(a.width!==w||a.height!==R)&&this.setSize(w,R)}return T===!1&&y.setRenderTarget(a),p=y.toneMapping,y.toneMapping=An,!0},this.hasRenderPass=function(){return T},this.end=function(y,E){y.toneMapping=p,v=!0;let w=a,R=o;for(let x=0;x<b.length;x++){const S=b[x];S.enabled!==!1&&(S.render(y,R,w,E),S.needsSwap!==!1&&(w=R,R=R===o?l:o))}if(f!==y.outputColorSpace||_!==y.toneMapping){f=y.outputColorSpace,_=y.toneMapping,h.defines={},Xt.getTransfer(f)===ie&&(h.defines.SRGB_TRANSFER="");const x=l0[_];x&&(h.defines[x]=""),h.needsUpdate=!0}h.uniforms.tDiffuse.value=w.texture,y.setRenderTarget(m),y.render(u,d),m=null,v=!1},this.isCompositing=function(){return v},this.dispose=function(){a.dispose(),o!==null&&o.dispose(),l!==null&&l.dispose(),c.dispose(),h.dispose()}}const yh=new Oe,vo=new Ts(1,1),bh=new ih,Sh=new Ru,wh=new hh,Ql=[],jl=[],tc=new Float32Array(16),ec=new Float32Array(9),nc=new Float32Array(4);function es(s,t,e){const n=s[0];if(n<=0||n>0)return s;const i=t*e;let r=Ql[i];if(r===void 0&&(r=new Float32Array(i),Ql[i]=r),t!==0){n.toArray(r,0);for(let a=1,o=0;a!==t;++a)o+=e,s[a].toArray(r,o)}return r}function Se(s,t){if(s.length!==t.length)return!1;for(let e=0,n=s.length;e<n;e++)if(s[e]!==t[e])return!1;return!0}function we(s,t){for(let e=0,n=t.length;e<n;e++)s[e]=t[e]}function Br(s,t){let e=jl[t];e===void 0&&(e=new Int32Array(t),jl[t]=e);for(let n=0;n!==t;++n)e[n]=s.allocateTextureUnit();return e}function h0(s,t){const e=this.cache;e[0]!==t&&(s.uniform1f(this.addr,t),e[0]=t)}function d0(s,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(s.uniform2f(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if(Se(e,t))return;s.uniform2fv(this.addr,t),we(e,t)}}function u0(s,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(s.uniform3f(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else if(t.r!==void 0)(e[0]!==t.r||e[1]!==t.g||e[2]!==t.b)&&(s.uniform3f(this.addr,t.r,t.g,t.b),e[0]=t.r,e[1]=t.g,e[2]=t.b);else{if(Se(e,t))return;s.uniform3fv(this.addr,t),we(e,t)}}function f0(s,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(s.uniform4f(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if(Se(e,t))return;s.uniform4fv(this.addr,t),we(e,t)}}function p0(s,t){const e=this.cache,n=t.elements;if(n===void 0){if(Se(e,t))return;s.uniformMatrix2fv(this.addr,!1,t),we(e,t)}else{if(Se(e,n))return;nc.set(n),s.uniformMatrix2fv(this.addr,!1,nc),we(e,n)}}function m0(s,t){const e=this.cache,n=t.elements;if(n===void 0){if(Se(e,t))return;s.uniformMatrix3fv(this.addr,!1,t),we(e,t)}else{if(Se(e,n))return;ec.set(n),s.uniformMatrix3fv(this.addr,!1,ec),we(e,n)}}function g0(s,t){const e=this.cache,n=t.elements;if(n===void 0){if(Se(e,t))return;s.uniformMatrix4fv(this.addr,!1,t),we(e,t)}else{if(Se(e,n))return;tc.set(n),s.uniformMatrix4fv(this.addr,!1,tc),we(e,n)}}function _0(s,t){const e=this.cache;e[0]!==t&&(s.uniform1i(this.addr,t),e[0]=t)}function x0(s,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(s.uniform2i(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if(Se(e,t))return;s.uniform2iv(this.addr,t),we(e,t)}}function v0(s,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(s.uniform3i(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else{if(Se(e,t))return;s.uniform3iv(this.addr,t),we(e,t)}}function M0(s,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(s.uniform4i(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if(Se(e,t))return;s.uniform4iv(this.addr,t),we(e,t)}}function y0(s,t){const e=this.cache;e[0]!==t&&(s.uniform1ui(this.addr,t),e[0]=t)}function b0(s,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(s.uniform2ui(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if(Se(e,t))return;s.uniform2uiv(this.addr,t),we(e,t)}}function S0(s,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(s.uniform3ui(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else{if(Se(e,t))return;s.uniform3uiv(this.addr,t),we(e,t)}}function w0(s,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(s.uniform4ui(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if(Se(e,t))return;s.uniform4uiv(this.addr,t),we(e,t)}}function E0(s,t,e){const n=this.cache,i=e.allocateTextureUnit();n[0]!==i&&(s.uniform1i(this.addr,i),n[0]=i);let r;this.type===s.SAMPLER_2D_SHADOW?(vo.compareFunction=e.isReversedDepthBuffer()?No:Uo,r=vo):r=yh,e.setTexture2D(t||r,i)}function T0(s,t,e){const n=this.cache,i=e.allocateTextureUnit();n[0]!==i&&(s.uniform1i(this.addr,i),n[0]=i),e.setTexture3D(t||Sh,i)}function A0(s,t,e){const n=this.cache,i=e.allocateTextureUnit();n[0]!==i&&(s.uniform1i(this.addr,i),n[0]=i),e.setTextureCube(t||wh,i)}function C0(s,t,e){const n=this.cache,i=e.allocateTextureUnit();n[0]!==i&&(s.uniform1i(this.addr,i),n[0]=i),e.setTexture2DArray(t||bh,i)}function R0(s){switch(s){case 5126:return h0;case 35664:return d0;case 35665:return u0;case 35666:return f0;case 35674:return p0;case 35675:return m0;case 35676:return g0;case 5124:case 35670:return _0;case 35667:case 35671:return x0;case 35668:case 35672:return v0;case 35669:case 35673:return M0;case 5125:return y0;case 36294:return b0;case 36295:return S0;case 36296:return w0;case 35678:case 36198:case 36298:case 36306:case 35682:return E0;case 35679:case 36299:case 36307:return T0;case 35680:case 36300:case 36308:case 36293:return A0;case 36289:case 36303:case 36311:case 36292:return C0}}function P0(s,t){s.uniform1fv(this.addr,t)}function L0(s,t){const e=es(t,this.size,2);s.uniform2fv(this.addr,e)}function D0(s,t){const e=es(t,this.size,3);s.uniform3fv(this.addr,e)}function I0(s,t){const e=es(t,this.size,4);s.uniform4fv(this.addr,e)}function U0(s,t){const e=es(t,this.size,4);s.uniformMatrix2fv(this.addr,!1,e)}function N0(s,t){const e=es(t,this.size,9);s.uniformMatrix3fv(this.addr,!1,e)}function F0(s,t){const e=es(t,this.size,16);s.uniformMatrix4fv(this.addr,!1,e)}function k0(s,t){s.uniform1iv(this.addr,t)}function B0(s,t){s.uniform2iv(this.addr,t)}function O0(s,t){s.uniform3iv(this.addr,t)}function z0(s,t){s.uniform4iv(this.addr,t)}function G0(s,t){s.uniform1uiv(this.addr,t)}function H0(s,t){s.uniform2uiv(this.addr,t)}function V0(s,t){s.uniform3uiv(this.addr,t)}function W0(s,t){s.uniform4uiv(this.addr,t)}function X0(s,t,e){const n=this.cache,i=t.length,r=Br(e,i);Se(n,r)||(s.uniform1iv(this.addr,r),we(n,r));let a;this.type===s.SAMPLER_2D_SHADOW?a=vo:a=yh;for(let o=0;o!==i;++o)e.setTexture2D(t[o]||a,r[o])}function q0(s,t,e){const n=this.cache,i=t.length,r=Br(e,i);Se(n,r)||(s.uniform1iv(this.addr,r),we(n,r));for(let a=0;a!==i;++a)e.setTexture3D(t[a]||Sh,r[a])}function Y0(s,t,e){const n=this.cache,i=t.length,r=Br(e,i);Se(n,r)||(s.uniform1iv(this.addr,r),we(n,r));for(let a=0;a!==i;++a)e.setTextureCube(t[a]||wh,r[a])}function $0(s,t,e){const n=this.cache,i=t.length,r=Br(e,i);Se(n,r)||(s.uniform1iv(this.addr,r),we(n,r));for(let a=0;a!==i;++a)e.setTexture2DArray(t[a]||bh,r[a])}function K0(s){switch(s){case 5126:return P0;case 35664:return L0;case 35665:return D0;case 35666:return I0;case 35674:return U0;case 35675:return N0;case 35676:return F0;case 5124:case 35670:return k0;case 35667:case 35671:return B0;case 35668:case 35672:return O0;case 35669:case 35673:return z0;case 5125:return G0;case 36294:return H0;case 36295:return V0;case 36296:return W0;case 35678:case 36198:case 36298:case 36306:case 35682:return X0;case 35679:case 36299:case 36307:return q0;case 35680:case 36300:case 36308:case 36293:return Y0;case 36289:case 36303:case 36311:case 36292:return $0}}class Z0{constructor(t,e,n){this.id=t,this.addr=n,this.cache=[],this.type=e.type,this.setValue=R0(e.type)}}class J0{constructor(t,e,n){this.id=t,this.addr=n,this.cache=[],this.type=e.type,this.size=e.size,this.setValue=K0(e.type)}}class Q0{constructor(t){this.id=t,this.seq=[],this.map={}}setValue(t,e,n){const i=this.seq;for(let r=0,a=i.length;r!==a;++r){const o=i[r];o.setValue(t,e[o.id],n)}}}const ya=/(\w+)(\])?(\[|\.)?/g;function ic(s,t){s.seq.push(t),s.map[t.id]=t}function j0(s,t,e){const n=s.name,i=n.length;for(ya.lastIndex=0;;){const r=ya.exec(n),a=ya.lastIndex;let o=r[1];const l=r[2]==="]",c=r[3];if(l&&(o=o|0),c===void 0||c==="["&&a+2===i){ic(e,c===void 0?new Z0(o,s,t):new J0(o,s,t));break}else{let u=e.map[o];u===void 0&&(u=new Q0(o),ic(e,u)),e=u}}}class mr{constructor(t,e){this.seq=[],this.map={};const n=t.getProgramParameter(e,t.ACTIVE_UNIFORMS);for(let a=0;a<n;++a){const o=t.getActiveUniform(e,a),l=t.getUniformLocation(e,o.name);j0(o,l,this)}const i=[],r=[];for(const a of this.seq)a.type===t.SAMPLER_2D_SHADOW||a.type===t.SAMPLER_CUBE_SHADOW||a.type===t.SAMPLER_2D_ARRAY_SHADOW?i.push(a):r.push(a);i.length>0&&(this.seq=i.concat(r))}setValue(t,e,n,i){const r=this.map[e];r!==void 0&&r.setValue(t,n,i)}setOptional(t,e,n){const i=e[n];i!==void 0&&this.setValue(t,n,i)}static upload(t,e,n,i){for(let r=0,a=e.length;r!==a;++r){const o=e[r],l=n[o.id];l.needsUpdate!==!1&&o.setValue(t,l.value,i)}}static seqWithValue(t,e){const n=[];for(let i=0,r=t.length;i!==r;++i){const a=t[i];a.id in e&&n.push(a)}return n}}function sc(s,t,e){const n=s.createShader(t);return s.shaderSource(n,e),s.compileShader(n),n}const tg=37297;let eg=0;function ng(s,t){const e=s.split(`
`),n=[],i=Math.max(t-6,0),r=Math.min(t+6,e.length);for(let a=i;a<r;a++){const o=a+1;n.push(`${o===t?">":" "} ${o}: ${e[a]}`)}return n.join(`
`)}const rc=new Ft;function ig(s){Xt._getMatrix(rc,Xt.workingColorSpace,s);const t=`mat3( ${rc.elements.map(e=>e.toFixed(4))} )`;switch(Xt.getTransfer(s)){case Cr:return[t,"LinearTransferOETF"];case ie:return[t,"sRGBTransferOETF"];default:return Ut("WebGLProgram: Unsupported color space: ",s),[t,"LinearTransferOETF"]}}function ac(s,t,e){const n=s.getShaderParameter(t,s.COMPILE_STATUS),r=(s.getShaderInfoLog(t)||"").trim();if(n&&r==="")return"";const a=/ERROR: 0:(\d+)/.exec(r);if(a){const o=parseInt(a[1]);return e.toUpperCase()+`

`+r+`

`+ng(s.getShaderSource(t),o)}else return r}function sg(s,t){const e=ig(t);return[`vec4 ${s}( vec4 value ) {`,`	return ${e[1]}( vec4( value.rgb * ${e[0]}, value.a ) );`,"}"].join(`
`)}const rg={[Hc]:"Linear",[Vc]:"Reinhard",[Wc]:"Cineon",[Xc]:"ACESFilmic",[Yc]:"AgX",[$c]:"Neutral",[qc]:"Custom"};function ag(s,t){const e=rg[t];return e===void 0?(Ut("WebGLProgram: Unsupported toneMapping:",t),"vec3 "+s+"( vec3 color ) { return LinearToneMapping( color ); }"):"vec3 "+s+"( vec3 color ) { return "+e+"ToneMapping( color ); }"}const sr=new O;function og(){Xt.getLuminanceCoefficients(sr);const s=sr.x.toFixed(4),t=sr.y.toFixed(4),e=sr.z.toFixed(4);return["float luminance( const in vec3 rgb ) {",`	const vec3 weights = vec3( ${s}, ${t}, ${e} );`,"	return dot( weights, rgb );","}"].join(`
`)}function lg(s){return[s.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":"",s.extensionMultiDraw?"#extension GL_ANGLE_multi_draw : require":""].filter(ms).join(`
`)}function cg(s){const t=[];for(const e in s){const n=s[e];n!==!1&&t.push("#define "+e+" "+n)}return t.join(`
`)}function hg(s,t){const e={},n=s.getProgramParameter(t,s.ACTIVE_ATTRIBUTES);for(let i=0;i<n;i++){const r=s.getActiveAttrib(t,i),a=r.name;let o=1;r.type===s.FLOAT_MAT2&&(o=2),r.type===s.FLOAT_MAT3&&(o=3),r.type===s.FLOAT_MAT4&&(o=4),e[a]={type:r.type,location:s.getAttribLocation(t,a),locationSize:o}}return e}function ms(s){return s!==""}function oc(s,t){const e=t.numSpotLightShadows+t.numSpotLightMaps-t.numSpotLightShadowsWithMaps;return s.replace(/NUM_SUN_LIGHTS/g,t.numSunLights).replace(/NUM_DIR_LIGHTS/g,t.numDirLights).replace(/NUM_SPOT_LIGHTS/g,t.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,t.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,e).replace(/NUM_RECT_AREA_LIGHTS/g,t.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,t.numPointLights).replace(/NUM_HEMI_LIGHTS/g,t.numHemiLights).replace(/NUM_SUN_LIGHT_SHADOWS/g,t.numSunLightShadows).replace(/NUM_DIR_LIGHT_SHADOWS/g,t.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,t.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,t.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,t.numPointLightShadows)}function lc(s,t){return s.replace(/NUM_CLIPPING_PLANES/g,t.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,t.numClippingPlanes-t.numClipIntersection)}const dg=/^[ \t]*#include +<([\w\d./]+)>/gm;function Mo(s){return s.replace(dg,fg)}const ug=new Map;function fg(s,t){let e=zt[t];if(e===void 0){const n=ug.get(t);if(n!==void 0)e=zt[n],Ut('WebGLRenderer: Shader chunk "%s" has been deprecated. Use "%s" instead.',t,n);else throw new Error("THREE.WebGLProgram: Can not resolve #include <"+t+">")}return Mo(e)}const pg=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function cc(s){return s.replace(pg,mg)}function mg(s,t,e,n){let i="";for(let r=parseInt(t);r<parseInt(e);r++)i+=n.replace(/\[\s*i\s*\]/g,"[ "+r+" ]").replace(/UNROLLED_LOOP_INDEX/g,r);return i}function hc(s){let t=`precision ${s.precision} float;
	precision ${s.precision} int;
	precision ${s.precision} sampler2D;
	precision ${s.precision} samplerCube;
	precision ${s.precision} sampler3D;
	precision ${s.precision} sampler2DArray;
	precision ${s.precision} sampler2DShadow;
	precision ${s.precision} samplerCubeShadow;
	precision ${s.precision} sampler2DArrayShadow;
	precision ${s.precision} isampler2D;
	precision ${s.precision} isampler3D;
	precision ${s.precision} isamplerCube;
	precision ${s.precision} isampler2DArray;
	precision ${s.precision} usampler2D;
	precision ${s.precision} usampler3D;
	precision ${s.precision} usamplerCube;
	precision ${s.precision} usampler2DArray;
	`;return s.precision==="highp"?t+=`
#define HIGH_PRECISION`:s.precision==="mediump"?t+=`
#define MEDIUM_PRECISION`:s.precision==="lowp"&&(t+=`
#define LOW_PRECISION`),t}const gg={[gs]:"SHADOWMAP_TYPE_PCF",[ps]:"SHADOWMAP_TYPE_VSM"};function _g(s){return gg[s.shadowMapType]||"SHADOWMAP_TYPE_BASIC"}const xg={[Mi]:"ENVMAP_TYPE_CUBE",[Ji]:"ENVMAP_TYPE_CUBE",[Ur]:"ENVMAP_TYPE_CUBE_UV"};function vg(s){return s.envMap===!1?"ENVMAP_TYPE_CUBE":xg[s.envMapMode]||"ENVMAP_TYPE_CUBE"}const Mg={[Ji]:"ENVMAP_MODE_REFRACTION"};function yg(s){return s.envMap===!1?"ENVMAP_MODE_REFLECTION":Mg[s.envMapMode]||"ENVMAP_MODE_REFLECTION"}const bg={[To]:"ENVMAP_BLENDING_MULTIPLY",[au]:"ENVMAP_BLENDING_MIX",[ou]:"ENVMAP_BLENDING_ADD"};function Sg(s){return s.envMap===!1?"ENVMAP_BLENDING_NONE":bg[s.combine]||"ENVMAP_BLENDING_NONE"}function wg(s){const t=s.envMapCubeUVHeight;if(t===null)return null;const e=Math.log2(t)-2,n=1/t;return{texelWidth:1/(3*Math.max(Math.pow(2,e),112)),texelHeight:n,maxMip:e}}function Eg(s,t,e,n){const i=s.getContext(),r=e.defines;let a=e.vertexShader,o=e.fragmentShader;const l=_g(e),c=vg(e),h=yg(e),u=Sg(e),d=wg(e),f=lg(e),_=cg(r),v=i.createProgram();let p,m,b=e.glslVersion?"#version "+e.glslVersion+`
`:"";e.isRawShaderMaterial?(p=["#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,_].filter(ms).join(`
`),p.length>0&&(p+=`
`),m=["#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,_].filter(ms).join(`
`),m.length>0&&(m+=`
`)):(p=[hc(e),"#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,_,e.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",e.batching?"#define USE_BATCHING":"",e.batchingColor?"#define USE_BATCHING_COLOR":"",e.instancing?"#define USE_INSTANCING":"",e.instancingColor?"#define USE_INSTANCING_COLOR":"",e.instancingMorph?"#define USE_INSTANCING_MORPH":"",e.useFog&&e.fog?"#define USE_FOG":"",e.useFog&&e.fogExp2?"#define FOG_EXP2":"",e.map?"#define USE_MAP":"",e.envMap?"#define USE_ENVMAP":"",e.envMap?"#define "+h:"",e.lightMap?"#define USE_LIGHTMAP":"",e.aoMap?"#define USE_AOMAP":"",e.bumpMap?"#define USE_BUMPMAP":"",e.normalMap?"#define USE_NORMALMAP":"",e.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",e.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",e.displacementMap?"#define USE_DISPLACEMENTMAP":"",e.emissiveMap?"#define USE_EMISSIVEMAP":"",e.anisotropy?"#define USE_ANISOTROPY":"",e.anisotropyMap?"#define USE_ANISOTROPYMAP":"",e.clearcoatMap?"#define USE_CLEARCOATMAP":"",e.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",e.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",e.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",e.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",e.specularMap?"#define USE_SPECULARMAP":"",e.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",e.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",e.roughnessMap?"#define USE_ROUGHNESSMAP":"",e.metalnessMap?"#define USE_METALNESSMAP":"",e.alphaMap?"#define USE_ALPHAMAP":"",e.alphaHash?"#define USE_ALPHAHASH":"",e.transmission?"#define USE_TRANSMISSION":"",e.transmissionMap?"#define USE_TRANSMISSIONMAP":"",e.thicknessMap?"#define USE_THICKNESSMAP":"",e.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",e.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",e.mapUv?"#define MAP_UV "+e.mapUv:"",e.alphaMapUv?"#define ALPHAMAP_UV "+e.alphaMapUv:"",e.lightMapUv?"#define LIGHTMAP_UV "+e.lightMapUv:"",e.aoMapUv?"#define AOMAP_UV "+e.aoMapUv:"",e.emissiveMapUv?"#define EMISSIVEMAP_UV "+e.emissiveMapUv:"",e.bumpMapUv?"#define BUMPMAP_UV "+e.bumpMapUv:"",e.normalMapUv?"#define NORMALMAP_UV "+e.normalMapUv:"",e.displacementMapUv?"#define DISPLACEMENTMAP_UV "+e.displacementMapUv:"",e.metalnessMapUv?"#define METALNESSMAP_UV "+e.metalnessMapUv:"",e.roughnessMapUv?"#define ROUGHNESSMAP_UV "+e.roughnessMapUv:"",e.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+e.anisotropyMapUv:"",e.clearcoatMapUv?"#define CLEARCOATMAP_UV "+e.clearcoatMapUv:"",e.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+e.clearcoatNormalMapUv:"",e.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+e.clearcoatRoughnessMapUv:"",e.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+e.iridescenceMapUv:"",e.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+e.iridescenceThicknessMapUv:"",e.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+e.sheenColorMapUv:"",e.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+e.sheenRoughnessMapUv:"",e.specularMapUv?"#define SPECULARMAP_UV "+e.specularMapUv:"",e.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+e.specularColorMapUv:"",e.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+e.specularIntensityMapUv:"",e.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+e.transmissionMapUv:"",e.thicknessMapUv?"#define THICKNESSMAP_UV "+e.thicknessMapUv:"",e.vertexTangents&&e.flatShading===!1?"#define USE_TANGENT":"",e.vertexNormals?"#define HAS_NORMAL":"",e.vertexColors?"#define USE_COLOR":"",e.vertexAlphas?"#define USE_COLOR_ALPHA":"",e.vertexUv1s?"#define USE_UV1":"",e.vertexUv2s?"#define USE_UV2":"",e.vertexUv3s?"#define USE_UV3":"",e.pointsUvs?"#define USE_POINTS_UV":"",e.flatShading?"#define FLAT_SHADED":"",e.skinning?"#define USE_SKINNING":"",e.morphTargets?"#define USE_MORPHTARGETS":"",e.morphNormals&&e.flatShading===!1?"#define USE_MORPHNORMALS":"",e.morphColors?"#define USE_MORPHCOLORS":"",e.morphTargetsCount>0?"#define MORPHTARGETS_TEXTURE_STRIDE "+e.morphTextureStride:"",e.morphTargetsCount>0?"#define MORPHTARGETS_COUNT "+e.morphTargetsCount:"",e.doubleSided?"#define DOUBLE_SIDED":"",e.flipSided?"#define FLIP_SIDED":"",e.shadowMapEnabled?"#define USE_SHADOWMAP":"",e.shadowMapEnabled?"#define "+l:"",e.sizeAttenuation?"#define USE_SIZEATTENUATION":"",e.numLightProbes>0?"#define USE_LIGHT_PROBES":"",e.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",e.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","#ifdef USE_INSTANCING_MORPH","	uniform sampler2D morphTexture;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","	attribute vec2 uv1;","#endif","#ifdef USE_UV2","	attribute vec2 uv2;","#endif","#ifdef USE_UV3","	attribute vec2 uv3;","#endif","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif",`
`].filter(ms).join(`
`),m=[hc(e),"#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,_,e.useFog&&e.fog?"#define USE_FOG":"",e.useFog&&e.fogExp2?"#define FOG_EXP2":"",e.alphaToCoverage?"#define ALPHA_TO_COVERAGE":"",e.map?"#define USE_MAP":"",e.matcap?"#define USE_MATCAP":"",e.envMap?"#define USE_ENVMAP":"",e.envMap?"#define "+c:"",e.envMap?"#define "+h:"",e.envMap?"#define "+u:"",d?"#define CUBEUV_TEXEL_WIDTH "+d.texelWidth:"",d?"#define CUBEUV_TEXEL_HEIGHT "+d.texelHeight:"",d?"#define CUBEUV_MAX_MIP "+d.maxMip+".0":"",e.lightMap?"#define USE_LIGHTMAP":"",e.aoMap?"#define USE_AOMAP":"",e.bumpMap?"#define USE_BUMPMAP":"",e.normalMap?"#define USE_NORMALMAP":"",e.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",e.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",e.packedNormalMap?"#define USE_PACKED_NORMALMAP":"",e.emissiveMap?"#define USE_EMISSIVEMAP":"",e.anisotropy?"#define USE_ANISOTROPY":"",e.anisotropyMap?"#define USE_ANISOTROPYMAP":"",e.clearcoat?"#define USE_CLEARCOAT":"",e.clearcoatMap?"#define USE_CLEARCOATMAP":"",e.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",e.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",e.dispersion?"#define USE_DISPERSION":"",e.retroreflection?"#define USE_RETROREFLECTION":"",e.iridescence?"#define USE_IRIDESCENCE":"",e.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",e.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",e.specularMap?"#define USE_SPECULARMAP":"",e.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",e.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",e.roughnessMap?"#define USE_ROUGHNESSMAP":"",e.metalnessMap?"#define USE_METALNESSMAP":"",e.alphaMap?"#define USE_ALPHAMAP":"",e.alphaTest?"#define USE_ALPHATEST":"",e.alphaHash?"#define USE_ALPHAHASH":"",e.sheen?"#define USE_SHEEN":"",e.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",e.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",e.transmission?"#define USE_TRANSMISSION":"",e.transmissionMap?"#define USE_TRANSMISSIONMAP":"",e.thicknessMap?"#define USE_THICKNESSMAP":"",e.vertexTangents&&e.flatShading===!1?"#define USE_TANGENT":"",e.vertexColors||e.instancingColor?"#define USE_COLOR":"",e.vertexAlphas||e.batchingColor?"#define USE_COLOR_ALPHA":"",e.vertexUv1s?"#define USE_UV1":"",e.vertexUv2s?"#define USE_UV2":"",e.vertexUv3s?"#define USE_UV3":"",e.pointsUvs?"#define USE_POINTS_UV":"",e.gradientMap?"#define USE_GRADIENTMAP":"",e.flatShading?"#define FLAT_SHADED":"",e.doubleSided?"#define DOUBLE_SIDED":"",e.flipSided?"#define FLIP_SIDED":"",e.shadowMapEnabled?"#define USE_SHADOWMAP":"",e.shadowMapEnabled?"#define "+l:"",e.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",e.numLightProbes>0?"#define USE_LIGHT_PROBES":"",e.numLightProbeGrids>0?"#define USE_LIGHT_PROBES_GRID":"",e.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",e.decodeVideoTextureEmissive?"#define DECODE_VIDEO_TEXTURE_EMISSIVE":"",e.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",e.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",e.toneMapping!==An?"#define TONE_MAPPING":"",e.toneMapping!==An?zt.tonemapping_pars_fragment:"",e.toneMapping!==An?ag("toneMapping",e.toneMapping):"",e.dithering?"#define DITHERING":"",e.opaque?"#define OPAQUE":"",zt.colorspace_pars_fragment,sg("linearToOutputTexel",e.outputColorSpace),og(),e.useDepthPacking?"#define DEPTH_PACKING "+e.depthPacking:"",`
`].filter(ms).join(`
`)),a=Mo(a),a=oc(a,e),a=lc(a,e),o=Mo(o),o=oc(o,e),o=lc(o,e),a=cc(a),o=cc(o),e.isRawShaderMaterial!==!0&&(b=`#version 300 es
`,p=[f,"#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+p,m=["#define varying in",e.glslVersion===xl?"":"layout(location = 0) out highp vec4 pc_fragColor;",e.glslVersion===xl?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+m);const T=b+p+a,y=b+m+o,E=sc(i,i.VERTEX_SHADER,T),w=sc(i,i.FRAGMENT_SHADER,y);i.attachShader(v,E),i.attachShader(v,w),e.index0AttributeName!==void 0?i.bindAttribLocation(v,0,e.index0AttributeName):e.hasPositionAttribute===!0&&i.bindAttribLocation(v,0,"position"),i.linkProgram(v);function R(P){if(s.debug.checkShaderErrors){const D=i.getProgramInfoLog(v)||"",z=i.getShaderInfoLog(E)||"",L=i.getShaderInfoLog(w)||"",F=D.trim(),X=z.trim(),W=L.trim();let tt=!0,$=!0;if(i.getProgramParameter(v,i.LINK_STATUS)===!1)if(tt=!1,typeof s.debug.onShaderError=="function")s.debug.onShaderError(i,v,E,w);else{const et=ac(i,E,"vertex"),Z=ac(i,w,"fragment");Kt("WebGLProgram: Shader Error "+i.getError()+" - VALIDATE_STATUS "+i.getProgramParameter(v,i.VALIDATE_STATUS)+`

Material Name: `+P.name+`
Material Type: `+P.type+`

Program Info Log: `+F+`
`+et+`
`+Z)}else F!==""?Ut("WebGLProgram: Program Info Log:",F):(X===""||W==="")&&($=!1);$&&(P.diagnostics={runnable:tt,programLog:F,vertexShader:{log:X,prefix:p},fragmentShader:{log:W,prefix:m}})}i.deleteShader(E),i.deleteShader(w),x=new mr(i,v),S=hg(i,v)}let x;this.getUniforms=function(){return x===void 0&&R(this),x};let S;this.getAttributes=function(){return S===void 0&&R(this),S};let C=e.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return C===!1&&(C=i.getProgramParameter(v,tg)),C},this.destroy=function(){n.releaseStatesOfProgram(this),i.deleteProgram(v),this.program=void 0},this.type=e.shaderType,this.name=e.shaderName,this.id=eg++,this.cacheKey=t,this.usedTimes=1,this.program=v,this.vertexShader=E,this.fragmentShader=w,this}let Tg=0;class Ag{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(t,e,n){const i=this._getShaderCacheForMaterial(t);return i.has(e)===!1&&(i.add(e),e.usedTimes++),i.has(n)===!1&&(i.add(n),n.usedTimes++),this}remove(t){const e=this.materialCache.get(t);for(const n of e)n.usedTimes--,n.usedTimes===0&&this.shaderCache.delete(n.code);return this.materialCache.delete(t),this}getVertexShaderStage(t){return this._getShaderStage(t.vertexShader)}getFragmentShaderStage(t){return this._getShaderStage(t.fragmentShader)}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(t){const e=this.materialCache;let n=e.get(t);return n===void 0&&(n=new Set,e.set(t,n)),n}_getShaderStage(t){const e=this.shaderCache;let n=e.get(t);return n===void 0&&(n=new Cg(t),e.set(t,n)),n}}class Cg{constructor(t){this.id=Tg++,this.code=t,this.usedTimes=0}}function Rg(s){return s===yi||s===Er||s===Tr}function Pg(s,t,e,n,i,r){const a=new ko,o=new Ag,l=new Set,c=[],h=new Map,u=n.logarithmicDepthBuffer;let d=n.precision;const f={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distance",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function _(x){return l.add(x),x===0?"uv":`uv${x}`}function v(x,S,C,P,D,z){const L=P.fog,F=D.geometry,X=x.isMeshStandardMaterial||x.isMeshLambertMaterial||x.isMeshPhongMaterial?P.environment:null,W=x.isMeshStandardMaterial||x.isMeshLambertMaterial&&!x.envMap||x.isMeshPhongMaterial&&!x.envMap,tt=t.get(x.envMap||X,W),$=tt&&tt.mapping===Ur?tt.image.height:null,et=f[x.type];x.precision!==null&&(d=n.getMaxPrecision(x.precision),d!==x.precision&&Ut("WebGLProgram.getParameters:",x.precision,"not supported, using",d,"instead."));const Z=F.morphAttributes.position||F.morphAttributes.normal||F.morphAttributes.color,_t=Z!==void 0?Z.length:0;let Tt=0;F.morphAttributes.position!==void 0&&(Tt=1),F.morphAttributes.normal!==void 0&&(Tt=2),F.morphAttributes.color!==void 0&&(Tt=3);let se,Yt,Qt,Q;if(et){const he=Sn[et];se=he.vertexShader,Yt=he.fragmentShader}else{se=x.vertexShader,Yt=x.fragmentShader;const he=o.getVertexShaderStage(x),jt=o.getFragmentShaderStage(x);o.update(x,he,jt),Qt=he.id,Q=jt.id}const st=s.getRenderTarget(),yt=s.state.buffers.depth.getReversed(),Nt=D.isInstancedMesh===!0,vt=D.isBatchedMesh===!0,Gt=!!x.map,be=!!x.matcap,Ht=!!tt,Jt=!!x.aoMap,ce=!!x.lightMap,Wt=!!x.bumpMap&&x.wireframe===!1,pe=!!x.normalMap,Ee=!!x.displacementMap,ze=!!x.emissiveMap,ge=!!x.metalnessMap,ve=!!x.roughnessMap,B=x.anisotropy>0,Pe=x.clearcoat>0,ne=x.dispersion>0,A=x.retroreflectivity>0,g=x.iridescence>0,G=x.sheen>0,q=x.transmission>0,J=B&&!!x.anisotropyMap,at=Pe&&!!x.clearcoatMap,ot=Pe&&!!x.clearcoatNormalMap,j=Pe&&!!x.clearcoatRoughnessMap,it=g&&!!x.iridescenceMap,lt=g&&!!x.iridescenceThicknessMap,Ct=G&&!!x.sheenColorMap,ut=G&&!!x.sheenRoughnessMap,ct=!!x.specularMap,Rt=!!x.specularColorMap,Dt=!!x.specularIntensityMap,kt=q&&!!x.transmissionMap,k=q&&!!x.thicknessMap,ht=!!x.gradientMap,nt=!!x.alphaMap,dt=x.alphaTest>0,gt=!!x.alphaHash,rt=!!x.extensions;let Pt=An;x.toneMapped&&(st===null||st.isXRRenderTarget===!0)&&(Pt=s.toneMapping);const wt={shaderID:et,shaderType:x.type,shaderName:x.name,vertexShader:se,fragmentShader:Yt,defines:x.defines,customVertexShaderID:Qt,customFragmentShaderID:Q,isRawShaderMaterial:x.isRawShaderMaterial===!0,glslVersion:x.glslVersion,precision:d,batching:vt,batchingColor:vt&&D._colorsTexture!==null,instancing:Nt,instancingColor:Nt&&D.instanceColor!==null,instancingMorph:Nt&&D.morphTexture!==null,outputColorSpace:st===null?s.outputColorSpace:st.isXRRenderTarget===!0?st.texture.colorSpace:Xt.workingColorSpace,alphaToCoverage:!!x.alphaToCoverage,map:Gt,matcap:be,envMap:Ht,envMapMode:Ht&&tt.mapping,envMapCubeUVHeight:$,aoMap:Jt,lightMap:ce,bumpMap:Wt,normalMap:pe,displacementMap:Ee,emissiveMap:ze,normalMapObjectSpace:pe&&x.normalMapType===hu,normalMapTangentSpace:pe&&x.normalMapType===go,packedNormalMap:pe&&x.normalMapType===go&&Rg(x.normalMap.format),metalnessMap:ge,roughnessMap:ve,anisotropy:B,anisotropyMap:J,clearcoat:Pe,clearcoatMap:at,clearcoatNormalMap:ot,clearcoatRoughnessMap:j,dispersion:ne,retroreflection:A,iridescence:g,iridescenceMap:it,iridescenceThicknessMap:lt,sheen:G,sheenColorMap:Ct,sheenRoughnessMap:ut,specularMap:ct,specularColorMap:Rt,specularIntensityMap:Dt,transmission:q,transmissionMap:kt,thicknessMap:k,gradientMap:ht,opaque:x.transparent===!1&&x.blending===$i&&x.alphaToCoverage===!1,alphaMap:nt,alphaTest:dt,alphaHash:gt,combine:x.combine,mapUv:Gt&&_(x.map.channel),aoMapUv:Jt&&_(x.aoMap.channel),lightMapUv:ce&&_(x.lightMap.channel),bumpMapUv:Wt&&_(x.bumpMap.channel),normalMapUv:pe&&_(x.normalMap.channel),displacementMapUv:Ee&&_(x.displacementMap.channel),emissiveMapUv:ze&&_(x.emissiveMap.channel),metalnessMapUv:ge&&_(x.metalnessMap.channel),roughnessMapUv:ve&&_(x.roughnessMap.channel),anisotropyMapUv:J&&_(x.anisotropyMap.channel),clearcoatMapUv:at&&_(x.clearcoatMap.channel),clearcoatNormalMapUv:ot&&_(x.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:j&&_(x.clearcoatRoughnessMap.channel),iridescenceMapUv:it&&_(x.iridescenceMap.channel),iridescenceThicknessMapUv:lt&&_(x.iridescenceThicknessMap.channel),sheenColorMapUv:Ct&&_(x.sheenColorMap.channel),sheenRoughnessMapUv:ut&&_(x.sheenRoughnessMap.channel),specularMapUv:ct&&_(x.specularMap.channel),specularColorMapUv:Rt&&_(x.specularColorMap.channel),specularIntensityMapUv:Dt&&_(x.specularIntensityMap.channel),transmissionMapUv:kt&&_(x.transmissionMap.channel),thicknessMapUv:k&&_(x.thicknessMap.channel),alphaMapUv:nt&&_(x.alphaMap.channel),vertexTangents:!!F.attributes.tangent&&(pe||B),vertexNormals:!!F.attributes.normal,vertexColors:x.vertexColors,vertexAlphas:x.vertexColors===!0&&!!F.attributes.color&&F.attributes.color.itemSize===4,pointsUvs:D.isPoints===!0&&!!F.attributes.uv&&(Gt||nt),fog:!!L,useFog:x.fog===!0,fogExp2:!!L&&L.isFogExp2,flatShading:x.wireframe===!1&&(x.flatShading===!0||F.attributes.normal===void 0&&pe===!1&&(x.isMeshLambertMaterial||x.isMeshPhongMaterial||x.isMeshStandardMaterial||x.isMeshPhysicalMaterial)),sizeAttenuation:x.sizeAttenuation===!0,logarithmicDepthBuffer:u,reversedDepthBuffer:yt,skinning:D.isSkinnedMesh===!0,hasPositionAttribute:F.attributes.position!==void 0,morphTargets:F.morphAttributes.position!==void 0,morphNormals:F.morphAttributes.normal!==void 0,morphColors:F.morphAttributes.color!==void 0,morphTargetsCount:_t,morphTextureStride:Tt,numSunLights:S.sun.length,numDirLights:S.directional.length,numPointLights:S.point.length,numSpotLights:S.spot.length,numSpotLightMaps:S.spotLightMap.length,numRectAreaLights:S.rectArea.length,numHemiLights:S.hemi.length,numSunLightShadows:S.sunShadowMap.length,numDirLightShadows:S.directionalShadowMap.length,numPointLightShadows:S.pointShadowMap.length,numSpotLightShadows:S.spotShadowMap.length,numSpotLightShadowsWithMaps:S.numSpotLightShadowsWithMaps,numLightProbes:S.numLightProbes,numLightProbeGrids:z.length,numClippingPlanes:r.numPlanes,numClipIntersection:r.numIntersection,dithering:x.dithering,shadowMapEnabled:s.shadowMap.enabled&&C.length>0,shadowMapType:s.shadowMap.type,toneMapping:Pt,decodeVideoTexture:Gt&&x.map.isVideoTexture===!0&&Xt.getTransfer(x.map.colorSpace)===ie,decodeVideoTextureEmissive:ze&&x.emissiveMap.isVideoTexture===!0&&Xt.getTransfer(x.emissiveMap.colorSpace)===ie,premultipliedAlpha:x.premultipliedAlpha,doubleSided:x.side===wn,flipSided:x.side===Ve,useDepthPacking:x.depthPacking>=0,depthPacking:x.depthPacking||0,index0AttributeName:x.index0AttributeName,extensionClipCullDistance:rt&&x.extensions.clipCullDistance===!0&&e.has("WEBGL_clip_cull_distance"),extensionMultiDraw:(rt&&x.extensions.multiDraw===!0||vt)&&e.has("WEBGL_multi_draw"),rendererExtensionParallelShaderCompile:e.has("KHR_parallel_shader_compile"),customProgramCacheKey:x.customProgramCacheKey()};return wt.vertexUv1s=l.has(1),wt.vertexUv2s=l.has(2),wt.vertexUv3s=l.has(3),l.clear(),wt}function p(x){const S=[];if(x.shaderID?S.push(x.shaderID):(S.push(x.customVertexShaderID),S.push(x.customFragmentShaderID)),x.defines!==void 0)for(const C in x.defines)S.push(C),S.push(x.defines[C]);return x.isRawShaderMaterial===!1&&(m(S,x),b(S,x),S.push(s.outputColorSpace)),S.push(x.customProgramCacheKey),S.join()}function m(x,S){x.push(S.precision),x.push(S.outputColorSpace),x.push(S.envMapMode),x.push(S.envMapCubeUVHeight),x.push(S.mapUv),x.push(S.alphaMapUv),x.push(S.lightMapUv),x.push(S.aoMapUv),x.push(S.bumpMapUv),x.push(S.normalMapUv),x.push(S.displacementMapUv),x.push(S.emissiveMapUv),x.push(S.metalnessMapUv),x.push(S.roughnessMapUv),x.push(S.anisotropyMapUv),x.push(S.clearcoatMapUv),x.push(S.clearcoatNormalMapUv),x.push(S.clearcoatRoughnessMapUv),x.push(S.iridescenceMapUv),x.push(S.iridescenceThicknessMapUv),x.push(S.sheenColorMapUv),x.push(S.sheenRoughnessMapUv),x.push(S.specularMapUv),x.push(S.specularColorMapUv),x.push(S.specularIntensityMapUv),x.push(S.transmissionMapUv),x.push(S.thicknessMapUv),x.push(S.combine),x.push(S.fogExp2),x.push(S.sizeAttenuation),x.push(S.morphTargetsCount),x.push(S.morphAttributeCount),x.push(S.numSunLights),x.push(S.numDirLights),x.push(S.numPointLights),x.push(S.numSpotLights),x.push(S.numSpotLightMaps),x.push(S.numHemiLights),x.push(S.numRectAreaLights),x.push(S.numSunLightShadows),x.push(S.numDirLightShadows),x.push(S.numPointLightShadows),x.push(S.numSpotLightShadows),x.push(S.numSpotLightShadowsWithMaps),x.push(S.numLightProbes),x.push(S.shadowMapType),x.push(S.toneMapping),x.push(S.numClippingPlanes),x.push(S.numClipIntersection),x.push(S.depthPacking)}function b(x,S){a.disableAll(),S.instancing&&a.enable(0),S.instancingColor&&a.enable(1),S.instancingMorph&&a.enable(2),S.matcap&&a.enable(3),S.envMap&&a.enable(4),S.normalMapObjectSpace&&a.enable(5),S.normalMapTangentSpace&&a.enable(6),S.clearcoat&&a.enable(7),S.iridescence&&a.enable(8),S.alphaTest&&a.enable(9),S.vertexColors&&a.enable(10),S.vertexAlphas&&a.enable(11),S.vertexUv1s&&a.enable(12),S.vertexUv2s&&a.enable(13),S.vertexUv3s&&a.enable(14),S.vertexTangents&&a.enable(15),S.anisotropy&&a.enable(16),S.alphaHash&&a.enable(17),S.batching&&a.enable(18),S.dispersion&&a.enable(19),S.retroreflection&&a.enable(24),S.batchingColor&&a.enable(20),S.gradientMap&&a.enable(21),S.packedNormalMap&&a.enable(22),S.vertexNormals&&a.enable(23),x.push(a.mask),a.disableAll(),S.fog&&a.enable(0),S.useFog&&a.enable(1),S.flatShading&&a.enable(2),S.logarithmicDepthBuffer&&a.enable(3),S.reversedDepthBuffer&&a.enable(4),S.skinning&&a.enable(5),S.morphTargets&&a.enable(6),S.morphNormals&&a.enable(7),S.morphColors&&a.enable(8),S.premultipliedAlpha&&a.enable(9),S.shadowMapEnabled&&a.enable(10),S.doubleSided&&a.enable(11),S.flipSided&&a.enable(12),S.useDepthPacking&&a.enable(13),S.dithering&&a.enable(14),S.transmission&&a.enable(15),S.sheen&&a.enable(16),S.opaque&&a.enable(17),S.pointsUvs&&a.enable(18),S.decodeVideoTexture&&a.enable(19),S.decodeVideoTextureEmissive&&a.enable(20),S.alphaToCoverage&&a.enable(21),S.numLightProbeGrids>0&&a.enable(22),S.hasPositionAttribute&&a.enable(23),x.push(a.mask)}function T(x){const S=f[x.type];let C;if(S){const P=Sn[S];C=$u.clone(P.uniforms)}else C=x.uniforms;return C}function y(x,S){let C=h.get(S);return C!==void 0?++C.usedTimes:(C=new Eg(s,S,x,i),c.push(C),h.set(S,C)),C}function E(x){if(--x.usedTimes===0){const S=c.indexOf(x);c[S]=c[c.length-1],c.pop(),h.delete(x.cacheKey),x.destroy()}}function w(x){o.remove(x)}function R(){o.dispose()}return{getParameters:v,getProgramCacheKey:p,getUniforms:T,acquireProgram:y,releaseProgram:E,releaseShaderCache:w,programs:c,dispose:R}}function Lg(){let s=new WeakMap;function t(a){return s.has(a)}function e(a){let o=s.get(a);return o===void 0&&(o={},s.set(a,o)),o}function n(a){s.delete(a)}function i(a,o,l){s.get(a)[o]=l}function r(){s=new WeakMap}return{has:t,get:e,remove:n,update:i,dispose:r}}function Dg(s,t){return s.groupOrder!==t.groupOrder?s.groupOrder-t.groupOrder:s.renderOrder!==t.renderOrder?s.renderOrder-t.renderOrder:s.material.id!==t.material.id?s.material.id-t.material.id:s.materialVariant!==t.materialVariant?s.materialVariant-t.materialVariant:s.z!==t.z?s.z-t.z:s.id-t.id}function dc(s,t){return s.groupOrder!==t.groupOrder?s.groupOrder-t.groupOrder:s.renderOrder!==t.renderOrder?s.renderOrder-t.renderOrder:s.z!==t.z?t.z-s.z:s.id-t.id}function uc(){const s=[];let t=0;const e=[],n=[],i=[];function r(){t=0,e.length=0,n.length=0,i.length=0}function a(d){let f=0;return d.isInstancedMesh&&(f+=2),d.isSkinnedMesh&&(f+=1),f}function o(d,f,_,v,p,m){let b=s[t];return b===void 0?(b={id:d.id,object:d,geometry:f,material:_,materialVariant:a(d),groupOrder:v,renderOrder:d.renderOrder,z:p,group:m},s[t]=b):(b.id=d.id,b.object=d,b.geometry=f,b.material=_,b.materialVariant=a(d),b.groupOrder=v,b.renderOrder=d.renderOrder,b.z=p,b.group=m),t++,b}function l(d,f,_,v,p,m,b){b.reversedDepth===!0&&(p=-p);const T=o(d,f,_,v,p,m);_.transmission>0?n.push(T):_.transparent===!0?i.push(T):e.push(T)}function c(d,f,_,v,p,m){const b=o(d,f,_,v,p,m);_.transmission>0?n.unshift(b):_.transparent===!0?i.unshift(b):e.unshift(b)}function h(d,f){e.length>1&&e.sort(d||Dg),n.length>1&&n.sort(f||dc),i.length>1&&i.sort(f||dc)}function u(){for(let d=t,f=s.length;d<f;d++){const _=s[d];if(_.id===null)break;_.id=null,_.object=null,_.geometry=null,_.material=null,_.group=null}}return{opaque:e,transmissive:n,transparent:i,init:r,push:l,unshift:c,finish:u,sort:h}}function Ig(){let s=new WeakMap;function t(n,i){const r=s.get(n);let a;return r===void 0?(a=new uc,s.set(n,[a])):i>=r.length?(a=new uc,r.push(a)):a=r[i],a}function e(){s=new WeakMap}return{get:t,dispose:e}}function Ug(){const s={};return{get:function(t){if(s[t.id]!==void 0)return s[t.id];let e;switch(t.type){case"SunLight":case"DirectionalLight":e={direction:new O,color:new At};break;case"SpotLight":e={position:new O,direction:new O,color:new At,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":e={position:new O,color:new At,distance:0,decay:0};break;case"HemisphereLight":e={direction:new O,skyColor:new At,groundColor:new At};break;case"RectAreaLight":e={color:new At,position:new O,halfWidth:new O,halfHeight:new O};break}return s[t.id]=e,e}}}function Ng(){const s={};return{get:function(t){if(s[t.id]!==void 0)return s[t.id];let e;switch(t.type){case"SunLight":case"DirectionalLight":e={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Bt};break;case"SpotLight":e={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Bt};break;case"PointLight":e={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Bt,shadowCameraNear:1,shadowCameraFar:1e3};break}return s[t.id]=e,e}}}let Fg=0;function kg(s,t){return(t.castShadow?2:0)-(s.castShadow?2:0)+(t.map?1:0)-(s.map?1:0)}function Bg(s){const t=new Ug,e=Ng(),n={version:0,hash:{sunLength:-1,directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numSunShadows:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],sun:[],sunShadow:[],sunShadowMap:[],sunShadowMatrix:[],sunShadowCascade:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let c=0;c<9;c++)n.probe.push(new O);const i=new O,r=new Zt,a=new Zt;function o(c){let h=0,u=0,d=0;for(let D=0;D<9;D++)n.probe[D].set(0,0,0);let f=0,_=0,v=0,p=0,m=0,b=0,T=0,y=0,E=0,w=0,R=0,x=0,S=0,C=0;c.sort(kg);for(let D=0,z=c.length;D<z;D++){const L=c[D],F=L.color,X=L.intensity,W=L.distance;let tt=null;if(L.shadow&&L.shadow.map&&(L.shadow.map.texture.format===yi?tt=L.shadow.map.texture:tt=L.shadow.map.depthTexture||L.shadow.map.texture),L.isAmbientLight)h+=F.r*X,u+=F.g*X,d+=F.b*X;else if(L.isLightProbe){for(let $=0;$<9;$++)n.probe[$].addScaledVector(L.sh.coefficients[$],X);C++}else if(L.isSunLight){const $=t.get(L);if($.color.copy(L.color).multiplyScalar(L.intensity),L.castShadow){const et=L.shadow,Z=e.get(L);Z.shadowIntensity=et.intensity,Z.shadowBias=et.bias,Z.shadowNormalBias=et.normalBias,Z.shadowRadius=et.radius,Z.shadowMapSize.copy(et.mapSize).multiply(et.getFrameExtents()),n.sunShadow[_]=Z,n.sunShadowMap[_]=tt;const _t=et.getViewportCount();for(let Tt=0;Tt<_t;Tt++)n.sunShadowMatrix[v+Tt]=et.getMatrix(Tt),n.sunShadowCascade[v+Tt]=et._cascadeData[Tt];v+=_t,_++}n.sun[f]=$,f++}else if(L.isDirectionalLight){const $=t.get(L);if($.color.copy(L.color).multiplyScalar(L.intensity),L.castShadow){const et=L.shadow,Z=e.get(L);Z.shadowIntensity=et.intensity,Z.shadowBias=et.bias,Z.shadowNormalBias=et.normalBias,Z.shadowRadius=et.radius,Z.shadowMapSize=et.mapSize,n.directionalShadow[p]=Z,n.directionalShadowMap[p]=tt,n.directionalShadowMatrix[p]=L.shadow.matrix,E++}n.directional[p]=$,p++}else if(L.isSpotLight){const $=t.get(L);$.position.setFromMatrixPosition(L.matrixWorld),$.color.copy(F).multiplyScalar(X),$.distance=W,$.coneCos=Math.cos(L.angle),$.penumbraCos=Math.cos(L.angle*(1-L.penumbra)),$.decay=L.decay,n.spot[b]=$;const et=L.shadow;if(L.map&&(n.spotLightMap[x]=L.map,x++,et.updateMatrices(L),L.castShadow&&S++),n.spotLightMatrix[b]=et.matrix,L.castShadow){const Z=e.get(L);Z.shadowIntensity=et.intensity,Z.shadowBias=et.bias,Z.shadowNormalBias=et.normalBias,Z.shadowRadius=et.radius,Z.shadowMapSize=et.mapSize,n.spotShadow[b]=Z,n.spotShadowMap[b]=tt,R++}b++}else if(L.isRectAreaLight){const $=t.get(L);$.color.copy(F).multiplyScalar(X),$.halfWidth.set(L.width*.5,0,0),$.halfHeight.set(0,L.height*.5,0),n.rectArea[T]=$,T++}else if(L.isPointLight){const $=t.get(L);if($.color.copy(L.color).multiplyScalar(L.intensity),$.distance=L.distance,$.decay=L.decay,L.castShadow){const et=L.shadow,Z=e.get(L);Z.shadowIntensity=et.intensity,Z.shadowBias=et.bias,Z.shadowNormalBias=et.normalBias,Z.shadowRadius=et.radius,Z.shadowMapSize=et.mapSize,Z.shadowCameraNear=et.camera.near,Z.shadowCameraFar=et.camera.far,n.pointShadow[m]=Z,n.pointShadowMap[m]=tt,n.pointShadowMatrix[m]=L.shadow.matrix,w++}n.point[m]=$,m++}else if(L.isHemisphereLight){const $=t.get(L);$.skyColor.copy(L.color).multiplyScalar(X),$.groundColor.copy(L.groundColor).multiplyScalar(X),n.hemi[y]=$,y++}}T>0&&(s.has("OES_texture_float_linear")===!0?(n.rectAreaLTC1=ft.LTC_FLOAT_1,n.rectAreaLTC2=ft.LTC_FLOAT_2):(n.rectAreaLTC1=ft.LTC_HALF_1,n.rectAreaLTC2=ft.LTC_HALF_2)),n.ambient[0]=h,n.ambient[1]=u,n.ambient[2]=d;const P=n.hash;(P.sunLength!==f||P.directionalLength!==p||P.pointLength!==m||P.spotLength!==b||P.rectAreaLength!==T||P.hemiLength!==y||P.numSunShadows!==_||P.numDirectionalShadows!==E||P.numPointShadows!==w||P.numSpotShadows!==R||P.numSpotMaps!==x||P.numLightProbes!==C)&&(n.sun.length=f,n.directional.length=p,n.spot.length=b,n.rectArea.length=T,n.point.length=m,n.hemi.length=y,n.sunShadow.length=_,n.sunShadowMap.length=_,n.sunShadowMatrix.length=v,n.sunShadowCascade.length=v,n.directionalShadow.length=E,n.directionalShadowMap.length=E,n.directionalShadowMatrix.length=E,n.pointShadow.length=w,n.pointShadowMap.length=w,n.pointShadowMatrix.length=w,n.spotShadow.length=R,n.spotShadowMap.length=R,n.spotLightMatrix.length=R+x-S,n.spotLightMap.length=x,n.numSpotLightShadowsWithMaps=S,n.numLightProbes=C,P.sunLength=f,P.directionalLength=p,P.pointLength=m,P.spotLength=b,P.rectAreaLength=T,P.hemiLength=y,P.numSunShadows=_,P.numDirectionalShadows=E,P.numPointShadows=w,P.numSpotShadows=R,P.numSpotMaps=x,P.numLightProbes=C,n.version=Fg++)}function l(c,h){let u=0,d=0,f=0,_=0,v=0,p=0;const m=h.matrixWorldInverse;for(let b=0,T=c.length;b<T;b++){const y=c[b];if(y.isSunLight){const E=n.sun[u];E.direction.setFromMatrixPosition(y.matrixWorld),E.direction.transformDirection(m),u++}else if(y.isDirectionalLight){const E=n.directional[d];E.direction.setFromMatrixPosition(y.matrixWorld),i.setFromMatrixPosition(y.target.matrixWorld),E.direction.sub(i),E.direction.transformDirection(m),d++}else if(y.isSpotLight){const E=n.spot[_];E.position.setFromMatrixPosition(y.matrixWorld),E.position.applyMatrix4(m),E.direction.setFromMatrixPosition(y.matrixWorld),i.setFromMatrixPosition(y.target.matrixWorld),E.direction.sub(i),E.direction.transformDirection(m),_++}else if(y.isRectAreaLight){const E=n.rectArea[v];E.position.setFromMatrixPosition(y.matrixWorld),E.position.applyMatrix4(m),a.identity(),r.copy(y.matrixWorld),r.premultiply(m),a.extractRotation(r),E.halfWidth.set(y.width*.5,0,0),E.halfHeight.set(0,y.height*.5,0),E.halfWidth.applyMatrix4(a),E.halfHeight.applyMatrix4(a),v++}else if(y.isPointLight){const E=n.point[f];E.position.setFromMatrixPosition(y.matrixWorld),E.position.applyMatrix4(m),f++}else if(y.isHemisphereLight){const E=n.hemi[p];E.direction.setFromMatrixPosition(y.matrixWorld),E.direction.transformDirection(m),p++}}}return{setup:o,setupView:l,state:n}}function fc(s){const t=new Bg(s),e=[],n=[],i=[];function r(d){u.camera=d,e.length=0,n.length=0,i.length=0}function a(d){e.push(d)}function o(d){n.push(d)}function l(d){i.push(d)}function c(){t.setup(e)}function h(d){t.setupView(e,d)}const u={lightsArray:e,shadowsArray:n,lightProbeGridArray:i,camera:null,lights:t,transmissionRenderTarget:{},textureUnits:0};return{init:r,state:u,setupLights:c,setupLightsView:h,pushLight:a,pushShadow:o,pushLightProbeGrid:l}}function Og(s){let t=new WeakMap;function e(i,r=0){const a=t.get(i);let o;return a===void 0?(o=new fc(s),t.set(i,[o])):r>=a.length?(o=new fc(s),a.push(o)):o=a[r],o}function n(){t=new WeakMap}return{get:e,dispose:n}}const zg=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,Gg=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ).rg;
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ).r;
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( max( 0.0, squared_mean - mean * mean ) );
	gl_FragColor = vec4( mean, std_dev, 0.0, 1.0 );
}`,Hg=[new O(1,0,0),new O(-1,0,0),new O(0,1,0),new O(0,-1,0),new O(0,0,1),new O(0,0,-1)],Vg=[new O(0,-1,0),new O(0,-1,0),new O(0,0,1),new O(0,0,-1),new O(0,-1,0),new O(0,-1,0)],pc=new Zt,ds=new O,ba=new O;function Wg(s,t,e){let n=new Oo;const i=new Bt,r=new Bt,a=new _e,o=new Qu,l=new ju,c={},h=e.maxTextureSize,u={[vi]:Ve,[Ve]:vi,[wn]:wn},d=new _n({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new Bt},radius:{value:4}},vertexShader:zg,fragmentShader:Gg}),f=d.clone();f.defines.HORIZONTAL_PASS=1;const _=new Ae;_.setAttribute("position",new Cn(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));const v=new le(_,d),p=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=gs;let m=this.type;this.render=function(w,R,x){if(p.enabled===!1||p.autoUpdate===!1&&p.needsUpdate===!1||w.length===0)return;this.type===Gd&&(Ut("WebGLShadowMap: PCFSoftShadowMap has been removed. Using PCFShadowMap instead."),this.type=gs);const S=s.getRenderTarget(),C=s.getActiveCubeFace(),P=s.getActiveMipmapLevel(),D=s.state;D.setBlending(zn),D.buffers.depth.getReversed()===!0?D.buffers.color.setClear(0,0,0,0):D.buffers.color.setClear(1,1,1,1),D.buffers.depth.setTest(!0),D.setScissorTest(!1);const z=m!==this.type;z&&R.traverse(function(L){L.material&&(Array.isArray(L.material)?L.material.forEach(F=>F.needsUpdate=!0):L.material.needsUpdate=!0)});for(let L=0,F=w.length;L<F;L++){const X=w[L],W=X.shadow;if(W===void 0){Ut("WebGLShadowMap:",X,"has no shadow.");continue}if(W.autoUpdate===!1&&W.needsUpdate===!1)continue;i.copy(W.mapSize);const tt=W.getFrameExtents();i.multiply(tt),r.copy(W.mapSize),(i.x>h||i.y>h)&&(i.x>h&&(r.x=Math.floor(h/tt.x),i.x=r.x*tt.x,W.mapSize.x=r.x),i.y>h&&(r.y=Math.floor(h/tt.y),i.y=r.y*tt.y,W.mapSize.y=r.y));const $=s.state.buffers.depth.getReversed();if(W.camera._reversedDepth=$,W.map===null||z===!0){if(W.map!==null&&(W.map.depthTexture!==null&&(W.map.depthTexture.dispose(),W.map.depthTexture=null),W.map.dispose()),this.type===ps){if(X.isPointLight){Ut("WebGLShadowMap: VSM shadow maps are not supported for PointLights. Use PCF or BasicShadowMap instead.");continue}W.map=new gn(i.x,i.y,{format:yi,type:Ln,minFilter:Ue,magFilter:Ue,generateMipmaps:!1}),W.map.texture.name=X.name+".shadowMap",W.map.depthTexture=new Ts(i.x,i.y,pn),W.map.depthTexture.name=X.name+".shadowMapDepth",W.map.depthTexture.format=Wn,W.map.depthTexture.compareFunction=null,W.map.depthTexture.minFilter=Ce,W.map.depthTexture.magFilter=Ce}else X.isPointLight?(W.map=new Mh(i.x),W.map.depthTexture=new qu(i.x,Pn)):(W.map=new gn(i.x,i.y),W.map.depthTexture=new Ts(i.x,i.y,Pn)),W.map.depthTexture.name=X.name+".shadowMap",W.map.depthTexture.format=Wn,this.type===gs?(W.map.depthTexture.compareFunction=$?No:Uo,W.map.depthTexture.minFilter=Ue,W.map.depthTexture.magFilter=Ue):(W.map.depthTexture.compareFunction=null,W.map.depthTexture.minFilter=Ce,W.map.depthTexture.magFilter=Ce);W.camera.updateProjectionMatrix()}W.map.isWebGLCubeRenderTarget!==!0&&(W.map.width!==i.x||W.map.height!==i.y)&&W.map.setSize(i.x,i.y);const et=W.map.isWebGLCubeRenderTarget?6:W.getViewportCount();X.isPointLight!==!0&&W.updateMatrices(X,x);for(let Z=0;Z<et;Z++){const _t=W.getCamera(Z);if(X.isPointLight){const Tt=W.camera,se=W.matrix,Yt=X.distance||Tt.far;Yt!==Tt.far&&(Tt.far=Yt,Tt.updateProjectionMatrix()),ds.setFromMatrixPosition(X.matrixWorld),Tt.position.copy(ds),ba.copy(Tt.position),ba.add(Hg[Z]),Tt.up.copy(Vg[Z]),Tt.lookAt(ba),Tt.updateMatrixWorld(),se.makeTranslation(-ds.x,-ds.y,-ds.z),pc.multiplyMatrices(Tt.projectionMatrix,Tt.matrixWorldInverse),W._frustum.setFromProjectionMatrix(pc,Tt.coordinateSystem,Tt.reversedDepth)}if(W.map.isWebGLCubeRenderTarget)s.setRenderTarget(W.map,Z),s.clear();else{Z===0&&(s.setRenderTarget(W.map),s.clear());const Tt=W.getViewport(Z);a.set(r.x*Tt.x,r.y*Tt.y,r.x*Tt.z,r.y*Tt.w),D.viewport(a)}n=W.getFrustum(Z),y(R,x,_t,X,this.type)}W.isPointLightShadow!==!0&&this.type===ps&&b(W,x),W.needsUpdate=!1}m=this.type,p.needsUpdate=!1,s.setRenderTarget(S,C,P)};function b(w,R){const x=t.update(v);d.defines.VSM_SAMPLES!==w.blurSamples&&(d.defines.VSM_SAMPLES=w.blurSamples,f.defines.VSM_SAMPLES=w.blurSamples,d.needsUpdate=!0,f.needsUpdate=!0),w.mapPass===null?w.mapPass=new gn(i.x,i.y,{format:yi,type:Ln}):(w.mapPass.width!==w.map.width||w.mapPass.height!==w.map.height)&&w.mapPass.setSize(w.map.width,w.map.height),d.uniforms.shadow_pass.value=w.map.depthTexture,d.uniforms.resolution.value.set(w.map.width,w.map.height),d.uniforms.radius.value=w.radius,s.setRenderTarget(w.mapPass),s.clear(),s.renderBufferDirect(R,null,x,d,v,null),f.uniforms.shadow_pass.value=w.mapPass.texture,f.uniforms.resolution.value.set(w.map.width,w.map.height),f.uniforms.radius.value=w.radius,s.setRenderTarget(w.map),s.clear(),s.renderBufferDirect(R,null,x,f,v,null)}function T(w,R,x,S){let C=null;const P=x.isPointLight===!0?w.customDistanceMaterial:w.customDepthMaterial;if(P!==void 0)C=P;else if(C=x.isPointLight===!0?l:o,s.localClippingEnabled&&R.clipShadows===!0&&Array.isArray(R.clippingPlanes)&&R.clippingPlanes.length!==0||R.displacementMap&&R.displacementScale!==0||R.alphaMap&&R.alphaTest>0||R.map&&R.alphaTest>0||R.alphaToCoverage===!0){const D=C.uuid,z=R.uuid;let L=c[D];L===void 0&&(L={},c[D]=L);let F=L[z];F===void 0&&(F=C.clone(),L[z]=F,R.addEventListener("dispose",E)),C=F}if(C.visible=R.visible,C.wireframe=R.wireframe,S===ps?C.side=R.shadowSide!==null?R.shadowSide:R.side:C.side=R.shadowSide!==null?R.shadowSide:u[R.side],C.alphaMap=R.alphaMap,C.alphaTest=R.alphaToCoverage===!0?.5:R.alphaTest,C.map=R.map,C.clipShadows=R.clipShadows,C.clippingPlanes=R.clippingPlanes,C.clipIntersection=R.clipIntersection,C.displacementMap=R.displacementMap,C.displacementScale=R.displacementScale,C.displacementBias=R.displacementBias,C.wireframeLinewidth=R.wireframeLinewidth,C.linewidth=R.linewidth,x.isPointLight===!0&&C.isMeshDistanceMaterial===!0){const D=s.properties.get(C);D.light=x}return C}function y(w,R,x,S,C){if(w.visible===!1)return;if(w.layers.test(R.layers)&&(w.isMesh||w.isLine||w.isPoints)&&(w.castShadow||w.receiveShadow&&C===ps)&&(!w.frustumCulled||w.intersectsFrustum(n))){w.modelViewMatrix.multiplyMatrices(x.matrixWorldInverse,w.matrixWorld);const z=t.update(w),L=w.material;if(Array.isArray(L)){const F=z.groups;for(let X=0,W=F.length;X<W;X++){const tt=F[X],$=L[tt.materialIndex];if($&&$.visible){const et=T(w,$,S,C);w.onBeforeShadow(s,w,R,x,z,et,tt),s.renderBufferDirect(x,null,z,et,w,tt),w.onAfterShadow(s,w,R,x,z,et,tt)}}}else if(L.visible){const F=T(w,L,S,C);w.onBeforeShadow(s,w,R,x,z,F,null),s.renderBufferDirect(x,null,z,F,w,null),w.onAfterShadow(s,w,R,x,z,F,null)}}const D=w.children;for(let z=0,L=D.length;z<L;z++)y(D[z],R,x,S,C)}function E(w){w.target.removeEventListener("dispose",E);for(const x in c){const S=c[x],C=w.target.uuid;C in S&&(S[C].dispose(),delete S[C])}}}function Xg(s,t){function e(){let k=!1;const ht=new _e;let nt=null;const dt=new _e(0,0,0,0);return{setMask:function(gt){nt!==gt&&!k&&(s.colorMask(gt,gt,gt,gt),nt=gt)},setLocked:function(gt){k=gt},setClear:function(gt,rt,Pt,wt,he){he===!0&&(gt*=wt,rt*=wt,Pt*=wt),ht.set(gt,rt,Pt,wt),dt.equals(ht)===!1&&(s.clearColor(gt,rt,Pt,wt),dt.copy(ht))},reset:function(){k=!1,nt=null,dt.set(-1,0,0,0)}}}function n(){let k=!1,ht=!1,nt=null,dt=null,gt=null;return{setReversed:function(rt){if(ht!==rt){const Pt=t.get("EXT_clip_control");rt?Pt.clipControlEXT(Pt.LOWER_LEFT_EXT,Pt.ZERO_TO_ONE_EXT):Pt.clipControlEXT(Pt.LOWER_LEFT_EXT,Pt.NEGATIVE_ONE_TO_ONE_EXT),ht=rt;const wt=gt;gt=null,this.setClear(wt)}},getReversed:function(){return ht},setTest:function(rt){rt?st(s.DEPTH_TEST):yt(s.DEPTH_TEST)},setMask:function(rt){nt!==rt&&!k&&(s.depthMask(rt),nt=rt)},setFunc:function(rt){if(ht&&(rt=bu[rt]),dt!==rt){switch(rt){case Pa:s.depthFunc(s.NEVER);break;case La:s.depthFunc(s.ALWAYS);break;case Da:s.depthFunc(s.LESS);break;case bs:s.depthFunc(s.LEQUAL);break;case Ia:s.depthFunc(s.EQUAL);break;case Ua:s.depthFunc(s.GEQUAL);break;case Na:s.depthFunc(s.GREATER);break;case Fa:s.depthFunc(s.NOTEQUAL);break;default:s.depthFunc(s.LEQUAL)}dt=rt}},setLocked:function(rt){k=rt},setClear:function(rt){gt!==rt&&(gt=rt,ht&&(rt=1-rt),s.clearDepth(rt))},reset:function(){k=!1,nt=null,dt=null,gt=null,ht=!1}}}function i(){let k=!1,ht=null,nt=null,dt=null,gt=null,rt=null,Pt=null,wt=null,he=null;return{setTest:function(jt){k||(jt?st(s.STENCIL_TEST):yt(s.STENCIL_TEST))},setMask:function(jt){ht!==jt&&!k&&(s.stencilMask(jt),ht=jt)},setFunc:function(jt,rn,xn){(nt!==jt||dt!==rn||gt!==xn)&&(s.stencilFunc(jt,rn,xn),nt=jt,dt=rn,gt=xn)},setOp:function(jt,rn,xn){(rt!==jt||Pt!==rn||wt!==xn)&&(s.stencilOp(jt,rn,xn),rt=jt,Pt=rn,wt=xn)},setLocked:function(jt){k=jt},setClear:function(jt){he!==jt&&(s.clearStencil(jt),he=jt)},reset:function(){k=!1,ht=null,nt=null,dt=null,gt=null,rt=null,Pt=null,wt=null,he=null}}}const r=new e,a=new n,o=new i,l=new WeakMap,c=new WeakMap;let h={},u={},d={},f=new WeakMap,_=[],v=null,p=!1,m=null,b=null,T=null,y=null,E=null,w=null,R=null,x=new At(0,0,0),S=0,C=!1,P=null,D=null,z=null,L=null,F=null;const X=s.getParameter(s.MAX_COMBINED_TEXTURE_IMAGE_UNITS);let W=!1,tt=0;const $=s.getParameter(s.VERSION);$.indexOf("WebGL")!==-1?(tt=parseFloat(/^WebGL (\d)/.exec($)[1]),W=tt>=1):$.indexOf("OpenGL ES")!==-1&&(tt=parseFloat(/^OpenGL ES (\d)/.exec($)[1]),W=tt>=2);let et=null,Z={};const _t=s.getParameter(s.SCISSOR_BOX),Tt=s.getParameter(s.VIEWPORT),se=new _e().fromArray(_t),Yt=new _e().fromArray(Tt);function Qt(k,ht,nt,dt){const gt=new Uint8Array(4),rt=s.createTexture();s.bindTexture(k,rt),s.texParameteri(k,s.TEXTURE_MIN_FILTER,s.NEAREST),s.texParameteri(k,s.TEXTURE_MAG_FILTER,s.NEAREST);for(let Pt=0;Pt<nt;Pt++)k===s.TEXTURE_3D||k===s.TEXTURE_2D_ARRAY?s.texImage3D(ht,0,s.RGBA,1,1,dt,0,s.RGBA,s.UNSIGNED_BYTE,gt):s.texImage2D(ht+Pt,0,s.RGBA,1,1,0,s.RGBA,s.UNSIGNED_BYTE,gt);return rt}const Q={};Q[s.TEXTURE_2D]=Qt(s.TEXTURE_2D,s.TEXTURE_2D,1),Q[s.TEXTURE_CUBE_MAP]=Qt(s.TEXTURE_CUBE_MAP,s.TEXTURE_CUBE_MAP_POSITIVE_X,6),Q[s.TEXTURE_2D_ARRAY]=Qt(s.TEXTURE_2D_ARRAY,s.TEXTURE_2D_ARRAY,1,1),Q[s.TEXTURE_3D]=Qt(s.TEXTURE_3D,s.TEXTURE_3D,1,1),r.setClear(0,0,0,1),a.setClear(1),o.setClear(0),st(s.DEPTH_TEST),a.setFunc(bs),Wt(!1),pe(ml),st(s.CULL_FACE),Jt(zn);function st(k){h[k]!==!0&&(s.enable(k),h[k]=!0)}function yt(k){h[k]!==!1&&(s.disable(k),h[k]=!1)}function Nt(k,ht){return d[k]!==ht?(s.bindFramebuffer(k,ht),d[k]=ht,k===s.DRAW_FRAMEBUFFER&&(d[s.FRAMEBUFFER]=ht),k===s.FRAMEBUFFER&&(d[s.DRAW_FRAMEBUFFER]=ht),!0):!1}function vt(k,ht){let nt=_,dt=!1;if(k){nt=f.get(ht),nt===void 0&&(nt=[],f.set(ht,nt));const gt=k.textures;if(nt.length!==gt.length||nt[0]!==s.COLOR_ATTACHMENT0){for(let rt=0,Pt=gt.length;rt<Pt;rt++)nt[rt]=s.COLOR_ATTACHMENT0+rt;nt.length=gt.length,dt=!0}}else nt[0]!==s.BACK&&(nt[0]=s.BACK,dt=!0);dt&&s.drawBuffers(nt)}function Gt(k){return v!==k?(s.useProgram(k),v=k,!0):!1}const be={[Vi]:s.FUNC_ADD,[Vd]:s.FUNC_SUBTRACT,[Wd]:s.FUNC_REVERSE_SUBTRACT};be[Xd]=s.MIN,be[qd]=s.MAX;const Ht={[Yd]:s.ZERO,[$d]:s.ONE,[Kd]:s.SRC_COLOR,[zc]:s.SRC_ALPHA,[eu]:s.SRC_ALPHA_SATURATE,[jd]:s.DST_COLOR,[Jd]:s.DST_ALPHA,[Zd]:s.ONE_MINUS_SRC_COLOR,[Gc]:s.ONE_MINUS_SRC_ALPHA,[tu]:s.ONE_MINUS_DST_COLOR,[Qd]:s.ONE_MINUS_DST_ALPHA,[nu]:s.CONSTANT_COLOR,[iu]:s.ONE_MINUS_CONSTANT_COLOR,[su]:s.CONSTANT_ALPHA,[ru]:s.ONE_MINUS_CONSTANT_ALPHA};function Jt(k,ht,nt,dt,gt,rt,Pt,wt,he,jt){if(k===zn){p===!0&&(yt(s.BLEND),p=!1);return}if(p===!1&&(st(s.BLEND),p=!0),k!==Hd){if(k!==m||jt!==C){if((b!==Vi||E!==Vi)&&(s.blendEquation(s.FUNC_ADD),b=Vi,E=Vi),jt)switch(k){case $i:s.blendFuncSeparate(s.ONE,s.ONE_MINUS_SRC_ALPHA,s.ONE,s.ONE_MINUS_SRC_ALPHA);break;case wr:s.blendFunc(s.ONE,s.ONE);break;case gl:s.blendFuncSeparate(s.ZERO,s.ONE_MINUS_SRC_COLOR,s.ZERO,s.ONE);break;case _l:s.blendFuncSeparate(s.DST_COLOR,s.ONE_MINUS_SRC_ALPHA,s.ZERO,s.ONE);break;default:Kt("WebGLState: Invalid blending: ",k);break}else switch(k){case $i:s.blendFuncSeparate(s.SRC_ALPHA,s.ONE_MINUS_SRC_ALPHA,s.ONE,s.ONE_MINUS_SRC_ALPHA);break;case wr:s.blendFuncSeparate(s.SRC_ALPHA,s.ONE,s.ONE,s.ONE);break;case gl:Kt("WebGLState: SubtractiveBlending requires material.premultipliedAlpha = true");break;case _l:Kt("WebGLState: MultiplyBlending requires material.premultipliedAlpha = true");break;default:Kt("WebGLState: Invalid blending: ",k);break}T=null,y=null,w=null,R=null,x.set(0,0,0),S=0,m=k,C=jt}return}gt=gt||ht,rt=rt||nt,Pt=Pt||dt,(ht!==b||gt!==E)&&(s.blendEquationSeparate(be[ht],be[gt]),b=ht,E=gt),(nt!==T||dt!==y||rt!==w||Pt!==R)&&(s.blendFuncSeparate(Ht[nt],Ht[dt],Ht[rt],Ht[Pt]),T=nt,y=dt,w=rt,R=Pt),(wt.equals(x)===!1||he!==S)&&(s.blendColor(wt.r,wt.g,wt.b,he),x.copy(wt),S=he),m=k,C=!1}function ce(k,ht){k.side===wn?yt(s.CULL_FACE):st(s.CULL_FACE);let nt=k.side===Ve;ht&&(nt=!nt),Wt(nt),k.blending===$i&&k.transparent===!1?Jt(zn):Jt(k.blending,k.blendEquation,k.blendSrc,k.blendDst,k.blendEquationAlpha,k.blendSrcAlpha,k.blendDstAlpha,k.blendColor,k.blendAlpha,k.premultipliedAlpha),a.setFunc(k.depthFunc),a.setTest(k.depthTest),a.setMask(k.depthWrite),r.setMask(k.colorWrite);const dt=k.stencilWrite;o.setTest(dt),dt&&(o.setMask(k.stencilWriteMask),o.setFunc(k.stencilFunc,k.stencilRef,k.stencilFuncMask),o.setOp(k.stencilFail,k.stencilZFail,k.stencilZPass)),ze(k.polygonOffset,k.polygonOffsetFactor,k.polygonOffsetUnits),k.alphaToCoverage===!0?st(s.SAMPLE_ALPHA_TO_COVERAGE):yt(s.SAMPLE_ALPHA_TO_COVERAGE)}function Wt(k){P!==k&&(k?s.frontFace(s.CW):s.frontFace(s.CCW),P=k)}function pe(k){k!==Od?(st(s.CULL_FACE),k!==D&&(k===ml?s.cullFace(s.BACK):k===zd?s.cullFace(s.FRONT):s.cullFace(s.FRONT_AND_BACK))):yt(s.CULL_FACE),D=k}function Ee(k){k!==z&&(W&&s.lineWidth(k),z=k)}function ze(k,ht,nt){k?(st(s.POLYGON_OFFSET_FILL),(L!==ht||F!==nt)&&(L=ht,F=nt,a.getReversed()&&(ht=-ht),s.polygonOffset(ht,nt))):yt(s.POLYGON_OFFSET_FILL)}function ge(k){k?st(s.SCISSOR_TEST):yt(s.SCISSOR_TEST)}function ve(k){k===void 0&&(k=s.TEXTURE0+X-1),et!==k&&(s.activeTexture(k),et=k)}function B(k,ht,nt){nt===void 0&&(et===null?nt=s.TEXTURE0+X-1:nt=et);let dt=Z[nt];dt===void 0&&(dt={type:void 0,texture:void 0},Z[nt]=dt),(dt.type!==k||dt.texture!==ht)&&(et!==nt&&(s.activeTexture(nt),et=nt),s.bindTexture(k,ht||Q[k]),dt.type=k,dt.texture=ht)}function Pe(){const k=Z[et];k!==void 0&&k.type!==void 0&&(s.bindTexture(k.type,null),k.type=void 0,k.texture=void 0)}function ne(){try{s.compressedTexImage2D(...arguments)}catch(k){Kt("WebGLState:",k)}}function A(){try{s.compressedTexImage3D(...arguments)}catch(k){Kt("WebGLState:",k)}}function g(){try{s.texSubImage2D(...arguments)}catch(k){Kt("WebGLState:",k)}}function G(){try{s.texSubImage3D(...arguments)}catch(k){Kt("WebGLState:",k)}}function q(){try{s.compressedTexSubImage2D(...arguments)}catch(k){Kt("WebGLState:",k)}}function J(){try{s.compressedTexSubImage3D(...arguments)}catch(k){Kt("WebGLState:",k)}}function at(){try{s.texStorage2D(...arguments)}catch(k){Kt("WebGLState:",k)}}function ot(){try{s.texStorage3D(...arguments)}catch(k){Kt("WebGLState:",k)}}function j(){try{s.texImage2D(...arguments)}catch(k){Kt("WebGLState:",k)}}function it(){try{s.texImage3D(...arguments)}catch(k){Kt("WebGLState:",k)}}function lt(k){return u[k]!==void 0?u[k]:s.getParameter(k)}function Ct(k,ht){u[k]!==ht&&(s.pixelStorei(k,ht),u[k]=ht)}function ut(k){se.equals(k)===!1&&(s.scissor(k.x,k.y,k.z,k.w),se.copy(k))}function ct(k){Yt.equals(k)===!1&&(s.viewport(k.x,k.y,k.z,k.w),Yt.copy(k))}function Rt(k,ht){let nt=c.get(ht);nt===void 0&&(nt=new WeakMap,c.set(ht,nt));let dt=nt.get(k);dt===void 0&&(dt=s.getUniformBlockIndex(ht,k.name),nt.set(k,dt))}function Dt(k,ht){const dt=c.get(ht).get(k);l.get(ht)!==dt&&(s.uniformBlockBinding(ht,dt,k.__bindingPointIndex),l.set(ht,dt))}function kt(){s.disable(s.BLEND),s.disable(s.CULL_FACE),s.disable(s.DEPTH_TEST),s.disable(s.POLYGON_OFFSET_FILL),s.disable(s.SCISSOR_TEST),s.disable(s.STENCIL_TEST),s.disable(s.SAMPLE_ALPHA_TO_COVERAGE),s.blendEquation(s.FUNC_ADD),s.blendFunc(s.ONE,s.ZERO),s.blendFuncSeparate(s.ONE,s.ZERO,s.ONE,s.ZERO),s.blendColor(0,0,0,0),s.colorMask(!0,!0,!0,!0),s.clearColor(0,0,0,0),s.depthMask(!0),s.depthFunc(s.LESS),a.setReversed(!1),s.clearDepth(1),s.stencilMask(4294967295),s.stencilFunc(s.ALWAYS,0,4294967295),s.stencilOp(s.KEEP,s.KEEP,s.KEEP),s.clearStencil(0),s.cullFace(s.BACK),s.frontFace(s.CCW),s.polygonOffset(0,0),s.activeTexture(s.TEXTURE0),s.bindFramebuffer(s.FRAMEBUFFER,null),s.bindFramebuffer(s.DRAW_FRAMEBUFFER,null),s.bindFramebuffer(s.READ_FRAMEBUFFER,null),s.useProgram(null),s.lineWidth(1),s.scissor(0,0,s.canvas.width,s.canvas.height),s.viewport(0,0,s.canvas.width,s.canvas.height),s.pixelStorei(s.PACK_ALIGNMENT,4),s.pixelStorei(s.UNPACK_ALIGNMENT,4),s.pixelStorei(s.UNPACK_FLIP_Y_WEBGL,!1),s.pixelStorei(s.UNPACK_PREMULTIPLY_ALPHA_WEBGL,!1),s.pixelStorei(s.UNPACK_COLORSPACE_CONVERSION_WEBGL,s.BROWSER_DEFAULT_WEBGL),s.pixelStorei(s.PACK_ROW_LENGTH,0),s.pixelStorei(s.PACK_SKIP_PIXELS,0),s.pixelStorei(s.PACK_SKIP_ROWS,0),s.pixelStorei(s.UNPACK_ROW_LENGTH,0),s.pixelStorei(s.UNPACK_IMAGE_HEIGHT,0),s.pixelStorei(s.UNPACK_SKIP_PIXELS,0),s.pixelStorei(s.UNPACK_SKIP_ROWS,0),s.pixelStorei(s.UNPACK_SKIP_IMAGES,0),h={},u={},et=null,Z={},d={},f=new WeakMap,_=[],v=null,p=!1,m=null,b=null,T=null,y=null,E=null,w=null,R=null,x=new At(0,0,0),S=0,C=!1,P=null,D=null,z=null,L=null,F=null,se.set(0,0,s.canvas.width,s.canvas.height),Yt.set(0,0,s.canvas.width,s.canvas.height),r.reset(),a.reset(),o.reset()}return{buffers:{color:r,depth:a,stencil:o},enable:st,disable:yt,bindFramebuffer:Nt,drawBuffers:vt,useProgram:Gt,setBlending:Jt,setMaterial:ce,setFlipSided:Wt,setCullFace:pe,setLineWidth:Ee,setPolygonOffset:ze,setScissorTest:ge,activeTexture:ve,bindTexture:B,unbindTexture:Pe,compressedTexImage2D:ne,compressedTexImage3D:A,texImage2D:j,texImage3D:it,pixelStorei:Ct,getParameter:lt,updateUBOMapping:Rt,uniformBlockBinding:Dt,texStorage2D:at,texStorage3D:ot,texSubImage2D:g,texSubImage3D:G,compressedTexSubImage2D:q,compressedTexSubImage3D:J,scissor:ut,viewport:ct,reset:kt}}function qg(s,t,e,n,i,r,a){const o=t.has("WEBGL_multisampled_render_to_texture")?t.get("WEBGL_multisampled_render_to_texture"):null,l=typeof navigator=="undefined"?!1:/OculusBrowser/g.test(navigator.userAgent),c=new Bt,h=new WeakMap,u=new Set;let d;const f=new WeakMap;let _=!1;try{_=typeof OffscreenCanvas!="undefined"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch{}function v(A,g){return _?new OffscreenCanvas(A,g):Rr("canvas")}function p(A,g,G){let q=1;const J=ne(A);if((J.width>G||J.height>G)&&(q=G/Math.max(J.width,J.height)),q<1)if(typeof HTMLImageElement!="undefined"&&A instanceof HTMLImageElement||typeof HTMLCanvasElement!="undefined"&&A instanceof HTMLCanvasElement||typeof ImageBitmap!="undefined"&&A instanceof ImageBitmap||typeof VideoFrame!="undefined"&&A instanceof VideoFrame){const at=Math.floor(q*J.width),ot=Math.floor(q*J.height);d===void 0&&(d=v(at,ot));const j=g?v(at,ot):d;return j.width=at,j.height=ot,j.getContext("2d").drawImage(A,0,0,at,ot),Ut("WebGLRenderer: Texture has been resized from ("+J.width+"x"+J.height+") to ("+at+"x"+ot+")."),j}else return"data"in A&&Ut("WebGLRenderer: Image in DataTexture is too big ("+J.width+"x"+J.height+")."),A;return A}function m(A){return A.generateMipmaps}function b(A){s.generateMipmap(A)}function T(A){return A.isWebGLCubeRenderTarget?s.TEXTURE_CUBE_MAP:A.isWebGL3DRenderTarget?s.TEXTURE_3D:A.isWebGLArrayRenderTarget||A.isCompressedArrayTexture?s.TEXTURE_2D_ARRAY:s.TEXTURE_2D}function y(A,g,G,q,J,at=!1){if(A!==null){if(s[A]!==void 0)return s[A];Ut("WebGLRenderer: Attempt to use non-existing WebGL internal format '"+A+"'")}let ot;q&&(ot=t.get("EXT_texture_norm16"),ot||Ut("WebGLRenderer: Unable to use normalized textures without EXT_texture_norm16 extension"));let j=g;if(g===s.RED&&(G===s.FLOAT&&(j=s.R32F),G===s.HALF_FLOAT&&(j=s.R16F),G===s.UNSIGNED_BYTE&&(j=s.R8),G===s.UNSIGNED_SHORT&&ot&&(j=ot.R16_EXT),G===s.SHORT&&ot&&(j=ot.R16_SNORM_EXT)),g===s.RED_INTEGER&&(G===s.UNSIGNED_BYTE&&(j=s.R8UI),G===s.UNSIGNED_SHORT&&(j=s.R16UI),G===s.UNSIGNED_INT&&(j=s.R32UI),G===s.BYTE&&(j=s.R8I),G===s.SHORT&&(j=s.R16I),G===s.INT&&(j=s.R32I)),g===s.RG&&(G===s.FLOAT&&(j=s.RG32F),G===s.HALF_FLOAT&&(j=s.RG16F),G===s.UNSIGNED_BYTE&&(j=s.RG8),G===s.UNSIGNED_SHORT&&ot&&(j=ot.RG16_EXT),G===s.SHORT&&ot&&(j=ot.RG16_SNORM_EXT)),g===s.RG_INTEGER&&(G===s.UNSIGNED_BYTE&&(j=s.RG8UI),G===s.UNSIGNED_SHORT&&(j=s.RG16UI),G===s.UNSIGNED_INT&&(j=s.RG32UI),G===s.BYTE&&(j=s.RG8I),G===s.SHORT&&(j=s.RG16I),G===s.INT&&(j=s.RG32I)),g===s.RGB_INTEGER&&(G===s.UNSIGNED_BYTE&&(j=s.RGB8UI),G===s.UNSIGNED_SHORT&&(j=s.RGB16UI),G===s.UNSIGNED_INT&&(j=s.RGB32UI),G===s.BYTE&&(j=s.RGB8I),G===s.SHORT&&(j=s.RGB16I),G===s.INT&&(j=s.RGB32I)),g===s.RGBA_INTEGER&&(G===s.UNSIGNED_BYTE&&(j=s.RGBA8UI),G===s.UNSIGNED_SHORT&&(j=s.RGBA16UI),G===s.UNSIGNED_INT&&(j=s.RGBA32UI),G===s.BYTE&&(j=s.RGBA8I),G===s.SHORT&&(j=s.RGBA16I),G===s.INT&&(j=s.RGBA32I)),g===s.RGB&&(G===s.UNSIGNED_SHORT&&ot&&(j=ot.RGB16_EXT),G===s.SHORT&&ot&&(j=ot.RGB16_SNORM_EXT),G===s.UNSIGNED_INT_5_9_9_9_REV&&(j=s.RGB9_E5),G===s.UNSIGNED_INT_10F_11F_11F_REV&&(j=s.R11F_G11F_B10F)),g===s.RGBA){const it=at?Cr:Xt.getTransfer(J);G===s.FLOAT&&(j=s.RGBA32F),G===s.HALF_FLOAT&&(j=s.RGBA16F),G===s.UNSIGNED_BYTE&&(j=it===ie?s.SRGB8_ALPHA8:s.RGBA8),G===s.UNSIGNED_SHORT&&ot&&(j=ot.RGBA16_EXT),G===s.SHORT&&ot&&(j=ot.RGBA16_SNORM_EXT),G===s.UNSIGNED_SHORT_4_4_4_4&&(j=s.RGBA4),G===s.UNSIGNED_SHORT_5_5_5_1&&(j=s.RGB5_A1)}return(j===s.R16F||j===s.R32F||j===s.RG16F||j===s.RG32F||j===s.RGBA16F||j===s.RGBA32F)&&t.get("EXT_color_buffer_float"),j}function E(A,g){let G;return A?g===null||g===Pn||g===ws?G=s.DEPTH24_STENCIL8:g===pn?G=s.DEPTH32F_STENCIL8:g===Ss&&(G=s.DEPTH24_STENCIL8,Ut("DepthTexture: 16 bit depth attachment is not supported with stencil. Using 24-bit attachment.")):g===null||g===Pn||g===ws?G=s.DEPTH_COMPONENT24:g===pn?G=s.DEPTH_COMPONENT32F:g===Ss&&(G=s.DEPTH_COMPONENT16),G}function w(A,g){return m(A)===!0||A.isFramebufferTexture&&A.minFilter!==Ce&&A.minFilter!==Ue?Math.log2(Math.max(g.width,g.height))+1:A.mipmaps!==void 0&&A.mipmaps.length>0?A.mipmaps.length:A.isCompressedTexture&&Array.isArray(A.image)?g.mipmaps.length:1}function R(A){const g=A.target;g.removeEventListener("dispose",R),S(g),g.isVideoTexture&&h.delete(g),g.isHTMLTexture&&u.delete(g)}function x(A){const g=A.target;g.removeEventListener("dispose",x),P(g)}function S(A){const g=n.get(A);if(g.__webglInit===void 0)return;const G=A.source,q=f.get(G);if(q){const J=q[g.__cacheKey];J.usedTimes--,J.usedTimes===0&&C(A),Object.keys(q).length===0&&f.delete(G)}n.remove(A)}function C(A){const g=n.get(A);s.deleteTexture(g.__webglTexture);const G=A.source,q=f.get(G);delete q[g.__cacheKey],a.memory.textures--}function P(A){const g=n.get(A);if(A.depthTexture&&(A.depthTexture.dispose(),n.remove(A.depthTexture)),A.isWebGLCubeRenderTarget)for(let q=0;q<6;q++){if(Array.isArray(g.__webglFramebuffer[q]))for(let J=0;J<g.__webglFramebuffer[q].length;J++)s.deleteFramebuffer(g.__webglFramebuffer[q][J]);else s.deleteFramebuffer(g.__webglFramebuffer[q]);g.__webglDepthbuffer&&s.deleteRenderbuffer(g.__webglDepthbuffer[q])}else{if(Array.isArray(g.__webglFramebuffer))for(let q=0;q<g.__webglFramebuffer.length;q++)s.deleteFramebuffer(g.__webglFramebuffer[q]);else s.deleteFramebuffer(g.__webglFramebuffer);if(g.__webglDepthbuffer&&s.deleteRenderbuffer(g.__webglDepthbuffer),g.__webglMultisampledFramebuffer&&s.deleteFramebuffer(g.__webglMultisampledFramebuffer),g.__webglColorRenderbuffer)for(let q=0;q<g.__webglColorRenderbuffer.length;q++)g.__webglColorRenderbuffer[q]&&s.deleteRenderbuffer(g.__webglColorRenderbuffer[q]);g.__webglDepthRenderbuffer&&s.deleteRenderbuffer(g.__webglDepthRenderbuffer)}const G=A.textures;for(let q=0,J=G.length;q<J;q++){const at=n.get(G[q]);at.__webglTexture&&(s.deleteTexture(at.__webglTexture),a.memory.textures--),n.remove(G[q])}n.remove(A)}let D=0;function z(){D=0}function L(){return D}function F(A){D=A}function X(){const A=D;return A>=i.maxTextures&&Ut("WebGLTextures: Trying to use "+(A+1)+" texture units while this GPU supports only "+i.maxTextures),D+=1,A}function W(A){const g=[];return g.push(A.wrapS),g.push(A.wrapT),g.push(A.wrapR||0),g.push(A.magFilter),g.push(A.minFilter),g.push(A.anisotropy),g.push(A.internalFormat),g.push(A.format),g.push(A.type),g.push(A.generateMipmaps),g.push(A.premultiplyAlpha),g.push(A.flipY),g.push(A.unpackAlignment),g.push(A.colorSpace),g.join()}function tt(A,g){const G=n.get(A);if(A.isVideoTexture&&B(A),A.isRenderTargetTexture===!1&&A.isExternalTexture!==!0&&A.version>0&&G.__version!==A.version){const q=A.image;if(q===null)Ut("WebGLRenderer: Texture marked for update but no image data found.");else if(q.complete===!1)Ut("WebGLRenderer: Texture marked for update but image is incomplete");else{yt(G,A,g);return}}else A.isExternalTexture&&(G.__webglTexture=A.sourceTexture?A.sourceTexture:null);e.bindTexture(s.TEXTURE_2D,G.__webglTexture,s.TEXTURE0+g)}function $(A,g){const G=n.get(A);if(A.isRenderTargetTexture===!1&&A.version>0&&G.__version!==A.version){yt(G,A,g);return}else A.isExternalTexture&&(G.__webglTexture=A.sourceTexture?A.sourceTexture:null);e.bindTexture(s.TEXTURE_2D_ARRAY,G.__webglTexture,s.TEXTURE0+g)}function et(A,g){const G=n.get(A);if(A.isRenderTargetTexture===!1&&A.version>0&&G.__version!==A.version){yt(G,A,g);return}e.bindTexture(s.TEXTURE_3D,G.__webglTexture,s.TEXTURE0+g)}function Z(A,g){const G=n.get(A);if(A.isCubeDepthTexture!==!0&&A.version>0&&G.__version!==A.version){Nt(G,A,g);return}e.bindTexture(s.TEXTURE_CUBE_MAP,G.__webglTexture,s.TEXTURE0+g)}const _t={[ka]:s.REPEAT,[On]:s.CLAMP_TO_EDGE,[Ba]:s.MIRRORED_REPEAT},Tt={[Ce]:s.NEAREST,[lu]:s.NEAREST_MIPMAP_NEAREST,[Fs]:s.NEAREST_MIPMAP_LINEAR,[Ue]:s.LINEAR,[qr]:s.LINEAR_MIPMAP_NEAREST,[_i]:s.LINEAR_MIPMAP_LINEAR},se={[uu]:s.NEVER,[_u]:s.ALWAYS,[fu]:s.LESS,[Uo]:s.LEQUAL,[pu]:s.EQUAL,[No]:s.GEQUAL,[mu]:s.GREATER,[gu]:s.NOTEQUAL};function Yt(A,g){if(g.type===pn&&t.has("OES_texture_float_linear")===!1&&(g.magFilter===Ue||g.magFilter===qr||g.magFilter===Fs||g.magFilter===_i||g.minFilter===Ue||g.minFilter===qr||g.minFilter===Fs||g.minFilter===_i)&&Ut("WebGLRenderer: Unable to use linear filtering with floating point textures. OES_texture_float_linear not supported on this device."),s.texParameteri(A,s.TEXTURE_WRAP_S,_t[g.wrapS]),s.texParameteri(A,s.TEXTURE_WRAP_T,_t[g.wrapT]),(A===s.TEXTURE_3D||A===s.TEXTURE_2D_ARRAY)&&s.texParameteri(A,s.TEXTURE_WRAP_R,_t[g.wrapR]),s.texParameteri(A,s.TEXTURE_MAG_FILTER,Tt[g.magFilter]),s.texParameteri(A,s.TEXTURE_MIN_FILTER,Tt[g.minFilter]),g.compareFunction&&(s.texParameteri(A,s.TEXTURE_COMPARE_MODE,s.COMPARE_REF_TO_TEXTURE),s.texParameteri(A,s.TEXTURE_COMPARE_FUNC,se[g.compareFunction])),t.has("EXT_texture_filter_anisotropic")===!0){if(g.magFilter===Ce||g.minFilter!==Fs&&g.minFilter!==_i||g.type===pn&&t.has("OES_texture_float_linear")===!1)return;if(g.anisotropy>1||n.get(g).__currentAnisotropy){const G=t.get("EXT_texture_filter_anisotropic");s.texParameterf(A,G.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(g.anisotropy,i.getMaxAnisotropy())),n.get(g).__currentAnisotropy=g.anisotropy}}}function Qt(A,g){let G=!1;A.__webglInit===void 0&&(A.__webglInit=!0,g.addEventListener("dispose",R));const q=g.source;let J=f.get(q);J===void 0&&(J={},f.set(q,J));const at=W(g);if(at!==A.__cacheKey){J[at]===void 0&&(J[at]={texture:s.createTexture(),usedTimes:0},a.memory.textures++,G=!0),J[at].usedTimes++;const ot=J[A.__cacheKey];ot!==void 0&&(J[A.__cacheKey].usedTimes--,ot.usedTimes===0&&C(g)),A.__cacheKey=at,A.__webglTexture=J[at].texture}return G}function Q(A,g,G){return Math.floor(Math.floor(A/G)/g)}function st(A,g,G,q){const at=A.updateRanges;if(at.length===0)e.texSubImage2D(s.TEXTURE_2D,0,0,0,g.width,g.height,G,q,g.data);else{at.sort((Ct,ut)=>Ct.start-ut.start);let ot=0;for(let Ct=1;Ct<at.length;Ct++){const ut=at[ot],ct=at[Ct],Rt=ut.start+ut.count,Dt=Q(ct.start,g.width,4),kt=Q(ut.start,g.width,4);ct.start<=Rt+1&&Dt===kt&&Q(ct.start+ct.count-1,g.width,4)===Dt?ut.count=Math.max(ut.count,ct.start+ct.count-ut.start):(++ot,at[ot]=ct)}at.length=ot+1;const j=e.getParameter(s.UNPACK_ROW_LENGTH),it=e.getParameter(s.UNPACK_SKIP_PIXELS),lt=e.getParameter(s.UNPACK_SKIP_ROWS);e.pixelStorei(s.UNPACK_ROW_LENGTH,g.width);for(let Ct=0,ut=at.length;Ct<ut;Ct++){const ct=at[Ct],Rt=Math.floor(ct.start/4),Dt=Math.ceil(ct.count/4),kt=Rt%g.width,k=Math.floor(Rt/g.width),ht=Dt,nt=1;e.pixelStorei(s.UNPACK_SKIP_PIXELS,kt),e.pixelStorei(s.UNPACK_SKIP_ROWS,k),e.texSubImage2D(s.TEXTURE_2D,0,kt,k,ht,nt,G,q,g.data)}A.clearUpdateRanges(),e.pixelStorei(s.UNPACK_ROW_LENGTH,j),e.pixelStorei(s.UNPACK_SKIP_PIXELS,it),e.pixelStorei(s.UNPACK_SKIP_ROWS,lt)}}function yt(A,g,G){let q=s.TEXTURE_2D;(g.isDataArrayTexture||g.isCompressedArrayTexture)&&(q=s.TEXTURE_2D_ARRAY),g.isData3DTexture&&(q=s.TEXTURE_3D);const J=Qt(A,g),at=g.source;e.bindTexture(q,A.__webglTexture,s.TEXTURE0+G);const ot=n.get(at);if(at.version!==ot.__version||J===!0){if(e.activeTexture(s.TEXTURE0+G),(typeof ImageBitmap!="undefined"&&g.image instanceof ImageBitmap)===!1){const nt=Xt.getPrimaries(Xt.workingColorSpace),dt=g.colorSpace===ii?null:Xt.getPrimaries(g.colorSpace),gt=g.colorSpace===ii||nt===dt?s.NONE:s.BROWSER_DEFAULT_WEBGL;e.pixelStorei(s.UNPACK_FLIP_Y_WEBGL,g.flipY),e.pixelStorei(s.UNPACK_PREMULTIPLY_ALPHA_WEBGL,g.premultiplyAlpha),e.pixelStorei(s.UNPACK_COLORSPACE_CONVERSION_WEBGL,gt)}e.pixelStorei(s.UNPACK_ALIGNMENT,g.unpackAlignment);let it=p(g.image,!1,i.maxTextureSize);it=Pe(g,it);const lt=r.convert(g.format,g.colorSpace),Ct=r.convert(g.type);let ut=y(g.internalFormat,lt,Ct,g.normalized,g.colorSpace,g.isVideoTexture);Yt(q,g);let ct;const Rt=g.mipmaps,Dt=g.isVideoTexture!==!0,kt=ot.__version===void 0||J===!0,k=at.dataReady,ht=w(g,it);if(g.isDepthTexture)ut=E(g.format===xi,g.type),kt&&(Dt?e.texStorage2D(s.TEXTURE_2D,1,ut,it.width,it.height):e.texImage2D(s.TEXTURE_2D,0,ut,it.width,it.height,0,lt,Ct,null));else if(g.isDataTexture)if(Rt.length>0){Dt&&kt&&e.texStorage2D(s.TEXTURE_2D,ht,ut,Rt[0].width,Rt[0].height);for(let nt=0,dt=Rt.length;nt<dt;nt++)ct=Rt[nt],Dt?k&&e.texSubImage2D(s.TEXTURE_2D,nt,0,0,ct.width,ct.height,lt,Ct,ct.data):e.texImage2D(s.TEXTURE_2D,nt,ut,ct.width,ct.height,0,lt,Ct,ct.data);g.generateMipmaps=!1}else Dt?(kt&&e.texStorage2D(s.TEXTURE_2D,ht,ut,it.width,it.height),k&&st(g,it,lt,Ct)):e.texImage2D(s.TEXTURE_2D,0,ut,it.width,it.height,0,lt,Ct,it.data);else if(g.isCompressedTexture)if(g.isCompressedArrayTexture){Dt&&kt&&e.texStorage3D(s.TEXTURE_2D_ARRAY,ht,ut,Rt[0].width,Rt[0].height,it.depth);for(let nt=0,dt=Rt.length;nt<dt;nt++)if(ct=Rt[nt],g.format!==mn)if(lt!==null)if(Dt){if(k)if(g.layerUpdates.size>0){const gt=ql(ct.width,ct.height,g.format,g.type);for(const rt of g.layerUpdates){const Pt=ct.data.subarray(rt*gt/ct.data.BYTES_PER_ELEMENT,(rt+1)*gt/ct.data.BYTES_PER_ELEMENT);e.compressedTexSubImage3D(s.TEXTURE_2D_ARRAY,nt,0,0,rt,ct.width,ct.height,1,lt,Pt)}}else e.compressedTexSubImage3D(s.TEXTURE_2D_ARRAY,nt,0,0,0,ct.width,ct.height,it.depth,lt,ct.data)}else e.compressedTexImage3D(s.TEXTURE_2D_ARRAY,nt,ut,ct.width,ct.height,it.depth,0,ct.data,0,0);else Ut("WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()");else Dt?k&&e.texSubImage3D(s.TEXTURE_2D_ARRAY,nt,0,0,0,ct.width,ct.height,it.depth,lt,Ct,ct.data):e.texImage3D(s.TEXTURE_2D_ARRAY,nt,ut,ct.width,ct.height,it.depth,0,lt,Ct,ct.data);g.layerUpdates.size>0&&g.clearLayerUpdates()}else{Dt&&kt&&e.texStorage2D(s.TEXTURE_2D,ht,ut,Rt[0].width,Rt[0].height);for(let nt=0,dt=Rt.length;nt<dt;nt++)ct=Rt[nt],g.format!==mn?lt!==null?Dt?k&&e.compressedTexSubImage2D(s.TEXTURE_2D,nt,0,0,ct.width,ct.height,lt,ct.data):e.compressedTexImage2D(s.TEXTURE_2D,nt,ut,ct.width,ct.height,0,ct.data):Ut("WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):Dt?k&&e.texSubImage2D(s.TEXTURE_2D,nt,0,0,ct.width,ct.height,lt,Ct,ct.data):e.texImage2D(s.TEXTURE_2D,nt,ut,ct.width,ct.height,0,lt,Ct,ct.data)}else if(g.isDataArrayTexture)if(Dt){if(kt&&e.texStorage3D(s.TEXTURE_2D_ARRAY,ht,ut,it.width,it.height,it.depth),k)if(g.layerUpdates.size>0){const nt=ql(it.width,it.height,g.format,g.type);for(const dt of g.layerUpdates){const gt=it.data.subarray(dt*nt/it.data.BYTES_PER_ELEMENT,(dt+1)*nt/it.data.BYTES_PER_ELEMENT);e.texSubImage3D(s.TEXTURE_2D_ARRAY,0,0,0,dt,it.width,it.height,1,lt,Ct,gt)}g.clearLayerUpdates()}else e.texSubImage3D(s.TEXTURE_2D_ARRAY,0,0,0,0,it.width,it.height,it.depth,lt,Ct,it.data)}else e.texImage3D(s.TEXTURE_2D_ARRAY,0,ut,it.width,it.height,it.depth,0,lt,Ct,it.data);else if(g.isData3DTexture)Dt?(kt&&e.texStorage3D(s.TEXTURE_3D,ht,ut,it.width,it.height,it.depth),k&&e.texSubImage3D(s.TEXTURE_3D,0,0,0,0,it.width,it.height,it.depth,lt,Ct,it.data)):e.texImage3D(s.TEXTURE_3D,0,ut,it.width,it.height,it.depth,0,lt,Ct,it.data);else if(g.isFramebufferTexture){if(kt)if(Dt)e.texStorage2D(s.TEXTURE_2D,ht,ut,it.width,it.height);else{let nt=it.width,dt=it.height;for(let gt=0;gt<ht;gt++)e.texImage2D(s.TEXTURE_2D,gt,ut,nt,dt,0,lt,Ct,null),nt>>=1,dt>>=1}}else if(g.isHTMLTexture){if("texElementImage2D"in s){const nt=s.canvas;if(nt.hasAttribute("layoutsubtree")||nt.setAttribute("layoutsubtree","true"),it.parentNode!==nt){nt.appendChild(it),u.add(g),nt.onpaint=dt=>{const gt=dt.changedElements;for(const rt of u)gt.includes(rt.image)&&(rt.needsUpdate=!0)},nt.requestPaint();return}if(s.texElementImage2D.length===3)s.texElementImage2D(s.TEXTURE_2D,s.RGBA8,it);else{const gt=s.RGBA,rt=s.RGBA,Pt=s.UNSIGNED_BYTE;s.texElementImage2D(s.TEXTURE_2D,0,gt,rt,Pt,it)}s.texParameteri(s.TEXTURE_2D,s.TEXTURE_MIN_FILTER,s.LINEAR),s.texParameteri(s.TEXTURE_2D,s.TEXTURE_WRAP_S,s.CLAMP_TO_EDGE),s.texParameteri(s.TEXTURE_2D,s.TEXTURE_WRAP_T,s.CLAMP_TO_EDGE)}}else if(Rt.length>0){if(Dt&&kt){const nt=ne(Rt[0]);e.texStorage2D(s.TEXTURE_2D,ht,ut,nt.width,nt.height)}for(let nt=0,dt=Rt.length;nt<dt;nt++)ct=Rt[nt],Dt?k&&e.texSubImage2D(s.TEXTURE_2D,nt,0,0,lt,Ct,ct):e.texImage2D(s.TEXTURE_2D,nt,ut,lt,Ct,ct);g.generateMipmaps=!1}else if(Dt){if(kt){const nt=ne(it);e.texStorage2D(s.TEXTURE_2D,ht,ut,nt.width,nt.height)}k&&e.texSubImage2D(s.TEXTURE_2D,0,0,0,lt,Ct,it)}else e.texImage2D(s.TEXTURE_2D,0,ut,lt,Ct,it);m(g)&&b(q),ot.__version=at.version,g.onUpdate&&g.onUpdate(g)}A.__version=g.version}function Nt(A,g,G){if(g.image.length!==6)return;const q=Qt(A,g),J=g.source;e.bindTexture(s.TEXTURE_CUBE_MAP,A.__webglTexture,s.TEXTURE0+G);const at=n.get(J);if(J.version!==at.__version||q===!0){e.activeTexture(s.TEXTURE0+G);const ot=Xt.getPrimaries(Xt.workingColorSpace),j=g.colorSpace===ii?null:Xt.getPrimaries(g.colorSpace),it=g.colorSpace===ii||ot===j?s.NONE:s.BROWSER_DEFAULT_WEBGL;e.pixelStorei(s.UNPACK_FLIP_Y_WEBGL,g.flipY),e.pixelStorei(s.UNPACK_PREMULTIPLY_ALPHA_WEBGL,g.premultiplyAlpha),e.pixelStorei(s.UNPACK_ALIGNMENT,g.unpackAlignment),e.pixelStorei(s.UNPACK_COLORSPACE_CONVERSION_WEBGL,it);const lt=g.isCompressedTexture||g.image[0].isCompressedTexture,Ct=g.image[0]&&g.image[0].isDataTexture,ut=[];for(let rt=0;rt<6;rt++)!lt&&!Ct?ut[rt]=p(g.image[rt],!0,i.maxCubemapSize):ut[rt]=Ct?g.image[rt].image:g.image[rt],ut[rt]=Pe(g,ut[rt]);const ct=ut[0],Rt=r.convert(g.format,g.colorSpace),Dt=r.convert(g.type),kt=y(g.internalFormat,Rt,Dt,g.normalized,g.colorSpace),k=g.isVideoTexture!==!0,ht=at.__version===void 0||q===!0,nt=J.dataReady;let dt=w(g,ct);Yt(s.TEXTURE_CUBE_MAP,g);let gt;if(lt){k&&ht&&e.texStorage2D(s.TEXTURE_CUBE_MAP,dt,kt,ct.width,ct.height);for(let rt=0;rt<6;rt++){gt=ut[rt].mipmaps;for(let Pt=0;Pt<gt.length;Pt++){const wt=gt[Pt];g.format!==mn?Rt!==null?k?nt&&e.compressedTexSubImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+rt,Pt,0,0,wt.width,wt.height,Rt,wt.data):e.compressedTexImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+rt,Pt,kt,wt.width,wt.height,0,wt.data):Ut("WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):k?nt&&e.texSubImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+rt,Pt,0,0,wt.width,wt.height,Rt,Dt,wt.data):e.texImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+rt,Pt,kt,wt.width,wt.height,0,Rt,Dt,wt.data)}}}else{if(gt=g.mipmaps,k&&ht){gt.length>0&&dt++;const rt=ne(ut[0]);e.texStorage2D(s.TEXTURE_CUBE_MAP,dt,kt,rt.width,rt.height)}for(let rt=0;rt<6;rt++)if(Ct){k?nt&&e.texSubImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+rt,0,0,0,ut[rt].width,ut[rt].height,Rt,Dt,ut[rt].data):e.texImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+rt,0,kt,ut[rt].width,ut[rt].height,0,Rt,Dt,ut[rt].data);for(let Pt=0;Pt<gt.length;Pt++){const he=gt[Pt].image[rt].image;k?nt&&e.texSubImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+rt,Pt+1,0,0,he.width,he.height,Rt,Dt,he.data):e.texImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+rt,Pt+1,kt,he.width,he.height,0,Rt,Dt,he.data)}}else{k?nt&&e.texSubImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+rt,0,0,0,Rt,Dt,ut[rt]):e.texImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+rt,0,kt,Rt,Dt,ut[rt]);for(let Pt=0;Pt<gt.length;Pt++){const wt=gt[Pt];k?nt&&e.texSubImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+rt,Pt+1,0,0,Rt,Dt,wt.image[rt]):e.texImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+rt,Pt+1,kt,Rt,Dt,wt.image[rt])}}}m(g)&&b(s.TEXTURE_CUBE_MAP),at.__version=J.version,g.onUpdate&&g.onUpdate(g)}A.__version=g.version}function vt(A,g,G,q,J,at){const ot=r.convert(G.format,G.colorSpace),j=r.convert(G.type),it=y(G.internalFormat,ot,j,G.normalized,G.colorSpace),lt=n.get(g),Ct=n.get(G);if(Ct.__renderTarget=g,!lt.__hasExternalTextures){const ut=Math.max(1,g.width>>at),ct=Math.max(1,g.height>>at);J===s.TEXTURE_3D||J===s.TEXTURE_2D_ARRAY?e.texImage3D(J,at,it,ut,ct,g.depth,0,ot,j,null):e.texImage2D(J,at,it,ut,ct,0,ot,j,null)}e.bindFramebuffer(s.FRAMEBUFFER,A),ve(g)?o.framebufferTexture2DMultisampleEXT(s.FRAMEBUFFER,q,J,Ct.__webglTexture,0,ge(g)):(J===s.TEXTURE_2D||J>=s.TEXTURE_CUBE_MAP_POSITIVE_X&&J<=s.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&s.framebufferTexture2D(s.FRAMEBUFFER,q,J,Ct.__webglTexture,at),e.bindFramebuffer(s.FRAMEBUFFER,null)}function Gt(A,g,G){if(s.bindRenderbuffer(s.RENDERBUFFER,A),g.depthBuffer){const q=g.depthTexture,J=q&&q.isDepthTexture?q.type:null,at=E(g.stencilBuffer,J),ot=g.stencilBuffer?s.DEPTH_STENCIL_ATTACHMENT:s.DEPTH_ATTACHMENT;ve(g)?o.renderbufferStorageMultisampleEXT(s.RENDERBUFFER,ge(g),at,g.width,g.height):G?s.renderbufferStorageMultisample(s.RENDERBUFFER,ge(g),at,g.width,g.height):s.renderbufferStorage(s.RENDERBUFFER,at,g.width,g.height),s.framebufferRenderbuffer(s.FRAMEBUFFER,ot,s.RENDERBUFFER,A)}else{const q=g.textures;for(let J=0;J<q.length;J++){const at=q[J],ot=r.convert(at.format,at.colorSpace),j=r.convert(at.type),it=y(at.internalFormat,ot,j,at.normalized,at.colorSpace);ve(g)?o.renderbufferStorageMultisampleEXT(s.RENDERBUFFER,ge(g),it,g.width,g.height):G?s.renderbufferStorageMultisample(s.RENDERBUFFER,ge(g),it,g.width,g.height):s.renderbufferStorage(s.RENDERBUFFER,it,g.width,g.height)}}s.bindRenderbuffer(s.RENDERBUFFER,null)}function be(A,g,G){const q=g.isWebGLCubeRenderTarget===!0;if(e.bindFramebuffer(s.FRAMEBUFFER,A),!(g.depthTexture&&g.depthTexture.isDepthTexture))throw new Error("THREE.WebGLTextures: renderTarget.depthTexture must be an instance of THREE.DepthTexture.");const J=n.get(g.depthTexture);if(J.__renderTarget=g,(!J.__webglTexture||g.depthTexture.image.width!==g.width||g.depthTexture.image.height!==g.height)&&(g.depthTexture.image.width=g.width,g.depthTexture.image.height=g.height,g.depthTexture.needsUpdate=!0),q){if(J.__webglInit===void 0&&(J.__webglInit=!0,g.depthTexture.addEventListener("dispose",R)),J.__webglTexture===void 0){J.__webglTexture=s.createTexture(),e.bindTexture(s.TEXTURE_CUBE_MAP,J.__webglTexture),Yt(s.TEXTURE_CUBE_MAP,g.depthTexture);const lt=r.convert(g.depthTexture.format),Ct=r.convert(g.depthTexture.type);let ut;g.depthTexture.format===Wn?ut=s.DEPTH_COMPONENT24:g.depthTexture.format===xi&&(ut=s.DEPTH24_STENCIL8);for(let ct=0;ct<6;ct++)s.texImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+ct,0,ut,g.width,g.height,0,lt,Ct,null)}}else tt(g.depthTexture,0);const at=J.__webglTexture,ot=ge(g),j=q?s.TEXTURE_CUBE_MAP_POSITIVE_X+G:s.TEXTURE_2D,it=g.depthTexture.format===xi?s.DEPTH_STENCIL_ATTACHMENT:s.DEPTH_ATTACHMENT;if(g.depthTexture.format===Wn)ve(g)?o.framebufferTexture2DMultisampleEXT(s.FRAMEBUFFER,it,j,at,0,ot):s.framebufferTexture2D(s.FRAMEBUFFER,it,j,at,0);else if(g.depthTexture.format===xi)ve(g)?o.framebufferTexture2DMultisampleEXT(s.FRAMEBUFFER,it,j,at,0,ot):s.framebufferTexture2D(s.FRAMEBUFFER,it,j,at,0);else throw new Error("THREE.WebGLTextures: Unknown depthTexture format.")}function Ht(A){const g=n.get(A),G=A.isWebGLCubeRenderTarget===!0;if(g.__boundDepthTexture!==A.depthTexture){const q=A.depthTexture;if(g.__depthDisposeCallback&&g.__depthDisposeCallback(),q){const J=()=>{delete g.__boundDepthTexture,delete g.__depthDisposeCallback,q.removeEventListener("dispose",J)};q.addEventListener("dispose",J),g.__depthDisposeCallback=J}g.__boundDepthTexture=q}if(A.depthTexture&&!g.__autoAllocateDepthBuffer)if(G)for(let q=0;q<6;q++)be(g.__webglFramebuffer[q],A,q);else{const q=A.texture.mipmaps;q&&q.length>0?be(g.__webglFramebuffer[0],A,0):be(g.__webglFramebuffer,A,0)}else if(G){g.__webglDepthbuffer=[];for(let q=0;q<6;q++)if(e.bindFramebuffer(s.FRAMEBUFFER,g.__webglFramebuffer[q]),g.__webglDepthbuffer[q]===void 0)g.__webglDepthbuffer[q]=s.createRenderbuffer(),Gt(g.__webglDepthbuffer[q],A,!1);else{const J=A.stencilBuffer?s.DEPTH_STENCIL_ATTACHMENT:s.DEPTH_ATTACHMENT,at=g.__webglDepthbuffer[q];s.bindRenderbuffer(s.RENDERBUFFER,at),s.framebufferRenderbuffer(s.FRAMEBUFFER,J,s.RENDERBUFFER,at)}}else{const q=A.texture.mipmaps;if(q&&q.length>0?e.bindFramebuffer(s.FRAMEBUFFER,g.__webglFramebuffer[0]):e.bindFramebuffer(s.FRAMEBUFFER,g.__webglFramebuffer),g.__webglDepthbuffer===void 0)g.__webglDepthbuffer=s.createRenderbuffer(),Gt(g.__webglDepthbuffer,A,!1);else{const J=A.stencilBuffer?s.DEPTH_STENCIL_ATTACHMENT:s.DEPTH_ATTACHMENT,at=g.__webglDepthbuffer;s.bindRenderbuffer(s.RENDERBUFFER,at),s.framebufferRenderbuffer(s.FRAMEBUFFER,J,s.RENDERBUFFER,at)}}e.bindFramebuffer(s.FRAMEBUFFER,null)}function Jt(A,g,G){const q=n.get(A);g!==void 0&&vt(q.__webglFramebuffer,A,A.texture,s.COLOR_ATTACHMENT0,s.TEXTURE_2D,0),G!==void 0&&Ht(A)}function ce(A){const g=A.texture,G=n.get(A),q=n.get(g);A.addEventListener("dispose",x);const J=A.textures,at=A.isWebGLCubeRenderTarget===!0,ot=J.length>1;if(ot||(q.__webglTexture===void 0&&(q.__webglTexture=s.createTexture()),q.__version=g.version,a.memory.textures++),at){G.__webglFramebuffer=[];for(let j=0;j<6;j++)if(g.mipmaps&&g.mipmaps.length>0){G.__webglFramebuffer[j]=[];for(let it=0;it<g.mipmaps.length;it++)G.__webglFramebuffer[j][it]=s.createFramebuffer()}else G.__webglFramebuffer[j]=s.createFramebuffer()}else{if(g.mipmaps&&g.mipmaps.length>0){G.__webglFramebuffer=[];for(let j=0;j<g.mipmaps.length;j++)G.__webglFramebuffer[j]=s.createFramebuffer()}else G.__webglFramebuffer=s.createFramebuffer();if(ot)for(let j=0,it=J.length;j<it;j++){const lt=n.get(J[j]);lt.__webglTexture===void 0&&(lt.__webglTexture=s.createTexture(),a.memory.textures++)}if(A.samples>0&&ve(A)===!1){G.__webglMultisampledFramebuffer=s.createFramebuffer(),G.__webglColorRenderbuffer=[],e.bindFramebuffer(s.FRAMEBUFFER,G.__webglMultisampledFramebuffer);for(let j=0;j<J.length;j++){const it=J[j];G.__webglColorRenderbuffer[j]=s.createRenderbuffer(),s.bindRenderbuffer(s.RENDERBUFFER,G.__webglColorRenderbuffer[j]);const lt=r.convert(it.format,it.colorSpace),Ct=r.convert(it.type),ut=y(it.internalFormat,lt,Ct,it.normalized,it.colorSpace,A.isXRRenderTarget===!0),ct=ge(A);s.renderbufferStorageMultisample(s.RENDERBUFFER,ct,ut,A.width,A.height),s.framebufferRenderbuffer(s.FRAMEBUFFER,s.COLOR_ATTACHMENT0+j,s.RENDERBUFFER,G.__webglColorRenderbuffer[j])}s.bindRenderbuffer(s.RENDERBUFFER,null),A.depthBuffer&&(G.__webglDepthRenderbuffer=s.createRenderbuffer(),Gt(G.__webglDepthRenderbuffer,A,!0)),e.bindFramebuffer(s.FRAMEBUFFER,null)}}if(at){e.bindTexture(s.TEXTURE_CUBE_MAP,q.__webglTexture),Yt(s.TEXTURE_CUBE_MAP,g);for(let j=0;j<6;j++)if(g.mipmaps&&g.mipmaps.length>0)for(let it=0;it<g.mipmaps.length;it++)vt(G.__webglFramebuffer[j][it],A,g,s.COLOR_ATTACHMENT0,s.TEXTURE_CUBE_MAP_POSITIVE_X+j,it);else vt(G.__webglFramebuffer[j],A,g,s.COLOR_ATTACHMENT0,s.TEXTURE_CUBE_MAP_POSITIVE_X+j,0);m(g)&&b(s.TEXTURE_CUBE_MAP),e.unbindTexture()}else if(ot){for(let j=0,it=J.length;j<it;j++){const lt=J[j],Ct=n.get(lt);let ut=s.TEXTURE_2D;(A.isWebGL3DRenderTarget||A.isWebGLArrayRenderTarget)&&(ut=A.isWebGL3DRenderTarget?s.TEXTURE_3D:s.TEXTURE_2D_ARRAY),e.bindTexture(ut,Ct.__webglTexture),Yt(ut,lt),vt(G.__webglFramebuffer,A,lt,s.COLOR_ATTACHMENT0+j,ut,0),m(lt)&&b(ut)}e.unbindTexture()}else{let j=s.TEXTURE_2D;if((A.isWebGL3DRenderTarget||A.isWebGLArrayRenderTarget)&&(j=A.isWebGL3DRenderTarget?s.TEXTURE_3D:s.TEXTURE_2D_ARRAY),e.bindTexture(j,q.__webglTexture),Yt(j,g),g.mipmaps&&g.mipmaps.length>0)for(let it=0;it<g.mipmaps.length;it++)vt(G.__webglFramebuffer[it],A,g,s.COLOR_ATTACHMENT0,j,it);else vt(G.__webglFramebuffer,A,g,s.COLOR_ATTACHMENT0,j,0);m(g)&&b(j),e.unbindTexture()}A.depthBuffer&&Ht(A)}function Wt(A){const g=A.textures;for(let G=0,q=g.length;G<q;G++){const J=g[G];if(m(J)){const at=T(A),ot=n.get(J).__webglTexture;e.bindTexture(at,ot),b(at),e.unbindTexture()}}}const pe=[],Ee=[];function ze(A){if(A.samples>0){if(ve(A)===!1){const g=A.textures,G=A.width,q=A.height;let J=s.COLOR_BUFFER_BIT;const at=A.stencilBuffer?s.DEPTH_STENCIL_ATTACHMENT:s.DEPTH_ATTACHMENT,ot=n.get(A),j=g.length>1;if(j)for(let lt=0;lt<g.length;lt++)e.bindFramebuffer(s.FRAMEBUFFER,ot.__webglMultisampledFramebuffer),s.framebufferRenderbuffer(s.FRAMEBUFFER,s.COLOR_ATTACHMENT0+lt,s.RENDERBUFFER,null),e.bindFramebuffer(s.FRAMEBUFFER,ot.__webglFramebuffer),s.framebufferTexture2D(s.DRAW_FRAMEBUFFER,s.COLOR_ATTACHMENT0+lt,s.TEXTURE_2D,null,0);e.bindFramebuffer(s.READ_FRAMEBUFFER,ot.__webglMultisampledFramebuffer);const it=A.texture.mipmaps;it&&it.length>0?e.bindFramebuffer(s.DRAW_FRAMEBUFFER,ot.__webglFramebuffer[0]):e.bindFramebuffer(s.DRAW_FRAMEBUFFER,ot.__webglFramebuffer);for(let lt=0;lt<g.length;lt++){if(A.resolveDepthBuffer&&(A.depthBuffer&&(J|=s.DEPTH_BUFFER_BIT),A.stencilBuffer&&A.resolveStencilBuffer&&(J|=s.STENCIL_BUFFER_BIT)),j){s.framebufferRenderbuffer(s.READ_FRAMEBUFFER,s.COLOR_ATTACHMENT0,s.RENDERBUFFER,ot.__webglColorRenderbuffer[lt]);const Ct=n.get(g[lt]).__webglTexture;s.framebufferTexture2D(s.DRAW_FRAMEBUFFER,s.COLOR_ATTACHMENT0,s.TEXTURE_2D,Ct,0)}s.blitFramebuffer(0,0,G,q,0,0,G,q,J,s.NEAREST),l===!0&&(pe.length=0,Ee.length=0,pe.push(s.COLOR_ATTACHMENT0+lt),A.depthBuffer&&A.storeMultisampledDepthBuffer===!1&&(pe.push(at),Ee.push(at),s.invalidateFramebuffer(s.DRAW_FRAMEBUFFER,Ee)),s.invalidateFramebuffer(s.READ_FRAMEBUFFER,pe))}if(e.bindFramebuffer(s.READ_FRAMEBUFFER,null),e.bindFramebuffer(s.DRAW_FRAMEBUFFER,null),j)for(let lt=0;lt<g.length;lt++){e.bindFramebuffer(s.FRAMEBUFFER,ot.__webglMultisampledFramebuffer),s.framebufferRenderbuffer(s.FRAMEBUFFER,s.COLOR_ATTACHMENT0+lt,s.RENDERBUFFER,ot.__webglColorRenderbuffer[lt]);const Ct=n.get(g[lt]).__webglTexture;e.bindFramebuffer(s.FRAMEBUFFER,ot.__webglFramebuffer),s.framebufferTexture2D(s.DRAW_FRAMEBUFFER,s.COLOR_ATTACHMENT0+lt,s.TEXTURE_2D,Ct,0)}e.bindFramebuffer(s.DRAW_FRAMEBUFFER,ot.__webglMultisampledFramebuffer)}else if(A.depthBuffer&&A.storeMultisampledDepthBuffer===!1&&l){const g=A.stencilBuffer?s.DEPTH_STENCIL_ATTACHMENT:s.DEPTH_ATTACHMENT;s.invalidateFramebuffer(s.DRAW_FRAMEBUFFER,[g])}}}function ge(A){return Math.min(i.maxSamples,A.samples)}function ve(A){const g=n.get(A);return A.samples>0&&t.has("WEBGL_multisampled_render_to_texture")===!0&&g.__useRenderToTexture!==!1}function B(A){const g=a.render.frame;h.get(A)!==g&&(h.set(A,g),A.update())}function Pe(A,g){const G=A.colorSpace,q=A.format,J=A.type;return A.isCompressedTexture===!0||A.isVideoTexture===!0||G!==Ar&&G!==ii&&(Xt.getTransfer(G)===ie?(q!==mn||J!==Ze)&&Ut("WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):Kt("WebGLTextures: Unsupported texture color space:",G)),g}function ne(A){return typeof HTMLImageElement!="undefined"&&A instanceof HTMLImageElement?(c.width=A.naturalWidth||A.width,c.height=A.naturalHeight||A.height):typeof VideoFrame!="undefined"&&A instanceof VideoFrame?(c.width=A.displayWidth,c.height=A.displayHeight):(c.width=A.width,c.height=A.height),c}this.allocateTextureUnit=X,this.resetTextureUnits=z,this.getTextureUnits=L,this.setTextureUnits=F,this.setTexture2D=tt,this.setTexture2DArray=$,this.setTexture3D=et,this.setTextureCube=Z,this.rebindTextures=Jt,this.setupRenderTarget=ce,this.updateRenderTargetMipmap=Wt,this.updateMultisampleRenderTarget=ze,this.setupDepthRenderbuffer=Ht,this.setupFrameBufferTexture=vt,this.useMultisampledRTT=ve,this.isReversedDepthBuffer=function(){return e.buffers.depth.getReversed()}}function Yg(s,t){function e(n,i=ii){let r;const a=Xt.getTransfer(i);if(n===Ze)return s.UNSIGNED_BYTE;if(n===Co)return s.UNSIGNED_SHORT_4_4_4_4;if(n===Ro)return s.UNSIGNED_SHORT_5_5_5_1;if(n===Qc)return s.UNSIGNED_INT_5_9_9_9_REV;if(n===jc)return s.UNSIGNED_INT_10F_11F_11F_REV;if(n===Zc)return s.BYTE;if(n===Jc)return s.SHORT;if(n===Ss)return s.UNSIGNED_SHORT;if(n===Ao)return s.INT;if(n===Pn)return s.UNSIGNED_INT;if(n===pn)return s.FLOAT;if(n===Ln)return s.HALF_FLOAT;if(n===th)return s.ALPHA;if(n===eh)return s.RGB;if(n===mn)return s.RGBA;if(n===Wn)return s.DEPTH_COMPONENT;if(n===xi)return s.DEPTH_STENCIL;if(n===Po)return s.RED;if(n===Lo)return s.RED_INTEGER;if(n===yi)return s.RG;if(n===Do)return s.RG_INTEGER;if(n===Io)return s.RGBA_INTEGER;if(n===dr||n===ur||n===fr||n===pr)if(a===ie)if(r=t.get("WEBGL_compressed_texture_s3tc_srgb"),r!==null){if(n===dr)return r.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(n===ur)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(n===fr)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(n===pr)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null;else if(r=t.get("WEBGL_compressed_texture_s3tc"),r!==null){if(n===dr)return r.COMPRESSED_RGB_S3TC_DXT1_EXT;if(n===ur)return r.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(n===fr)return r.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(n===pr)return r.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null;if(n===Oa||n===za||n===Ga||n===Ha)if(r=t.get("WEBGL_compressed_texture_pvrtc"),r!==null){if(n===Oa)return r.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(n===za)return r.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(n===Ga)return r.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(n===Ha)return r.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null;if(n===Va||n===Wa||n===Xa||n===qa||n===Ya||n===Er||n===$a)if(r=t.get("WEBGL_compressed_texture_etc"),r!==null){if(n===Va||n===Wa)return a===ie?r.COMPRESSED_SRGB8_ETC2:r.COMPRESSED_RGB8_ETC2;if(n===Xa)return a===ie?r.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:r.COMPRESSED_RGBA8_ETC2_EAC;if(n===qa)return r.COMPRESSED_R11_EAC;if(n===Ya)return r.COMPRESSED_SIGNED_R11_EAC;if(n===Er)return r.COMPRESSED_RG11_EAC;if(n===$a)return r.COMPRESSED_SIGNED_RG11_EAC}else return null;if(n===Ka||n===Za||n===Ja||n===Qa||n===ja||n===to||n===eo||n===no||n===io||n===so||n===ro||n===ao||n===oo||n===lo)if(r=t.get("WEBGL_compressed_texture_astc"),r!==null){if(n===Ka)return a===ie?r.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:r.COMPRESSED_RGBA_ASTC_4x4_KHR;if(n===Za)return a===ie?r.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:r.COMPRESSED_RGBA_ASTC_5x4_KHR;if(n===Ja)return a===ie?r.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:r.COMPRESSED_RGBA_ASTC_5x5_KHR;if(n===Qa)return a===ie?r.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:r.COMPRESSED_RGBA_ASTC_6x5_KHR;if(n===ja)return a===ie?r.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:r.COMPRESSED_RGBA_ASTC_6x6_KHR;if(n===to)return a===ie?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:r.COMPRESSED_RGBA_ASTC_8x5_KHR;if(n===eo)return a===ie?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:r.COMPRESSED_RGBA_ASTC_8x6_KHR;if(n===no)return a===ie?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:r.COMPRESSED_RGBA_ASTC_8x8_KHR;if(n===io)return a===ie?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:r.COMPRESSED_RGBA_ASTC_10x5_KHR;if(n===so)return a===ie?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:r.COMPRESSED_RGBA_ASTC_10x6_KHR;if(n===ro)return a===ie?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:r.COMPRESSED_RGBA_ASTC_10x8_KHR;if(n===ao)return a===ie?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:r.COMPRESSED_RGBA_ASTC_10x10_KHR;if(n===oo)return a===ie?r.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:r.COMPRESSED_RGBA_ASTC_12x10_KHR;if(n===lo)return a===ie?r.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:r.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null;if(n===co||n===ho||n===uo)if(r=t.get("EXT_texture_compression_bptc"),r!==null){if(n===co)return a===ie?r.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:r.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(n===ho)return r.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(n===uo)return r.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null;if(n===fo||n===po||n===Tr||n===mo)if(r=t.get("EXT_texture_compression_rgtc"),r!==null){if(n===fo)return r.COMPRESSED_RED_RGTC1_EXT;if(n===po)return r.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(n===Tr)return r.COMPRESSED_RED_GREEN_RGTC2_EXT;if(n===mo)return r.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null;return n===ws?s.UNSIGNED_INT_24_8:s[n]!==void 0?s[n]:null}return{convert:e}}const $g=`
void main() {

	gl_Position = vec4( position, 1.0 );

}`,Kg=`
uniform sampler2DArray depthColor;
uniform float depthWidth;
uniform float depthHeight;

void main() {

	vec2 coord = vec2( gl_FragCoord.x / depthWidth, gl_FragCoord.y / depthHeight );

	if ( coord.x >= 1.0 ) {

		gl_FragDepth = texture( depthColor, vec3( coord.x - 1.0, coord.y, 1 ) ).r;

	} else {

		gl_FragDepth = texture( depthColor, vec3( coord.x, coord.y, 0 ) ).r;

	}

}`;class Zg{constructor(){this.texture=null,this.mesh=null,this.depthNear=0,this.depthFar=0}init(t,e){if(this.texture===null){const n=new dh(t.texture);(t.depthNear!==e.depthNear||t.depthFar!==e.depthFar)&&(this.depthNear=t.depthNear,this.depthFar=t.depthFar),this.texture=n}}getMesh(t){if(this.texture!==null&&this.mesh===null){const e=t.cameras[0].viewport,n=new _n({vertexShader:$g,fragmentShader:Kg,uniforms:{depthColor:{value:this.texture},depthWidth:{value:e.z},depthHeight:{value:e.w}}});this.mesh=new le(new bi(20,20),n)}return this.mesh}reset(){this.texture=null,this.mesh=null}getDepthTexture(){return this.texture}}class Jg extends Si{constructor(t,e){super();const n=this;let i=null,r=1,a=null,o="local-floor",l=1,c=null,h=null,u=null,d=null,f=null,_=null;const v=typeof XRWebGLBinding!="undefined",p=new Zg,m={},b=e.getContextAttributes();let T=null,y=null;const E=[],w=[],R=new Bt;let x=null,S=null;const C=new Ke;C.viewport=new _e;const P=new Ke;P.viewport=new _e;const D=[C,P],z=new sf;let L=null,F=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(Q){let st=E[Q];return st===void 0&&(st=new ea,E[Q]=st),st.getTargetRaySpace()},this.getControllerGrip=function(Q){let st=E[Q];return st===void 0&&(st=new ea,E[Q]=st),st.getGripSpace()},this.getHand=function(Q){let st=E[Q];return st===void 0&&(st=new ea,E[Q]=st),st.getHandSpace()};function X(Q){const st=w.indexOf(Q.inputSource);if(st===-1)return;const yt=E[st];yt!==void 0&&(yt.update(Q.inputSource,Q.frame,c||a),yt.dispatchEvent({type:Q.type,data:Q.inputSource}))}function W(){i.removeEventListener("select",X),i.removeEventListener("selectstart",X),i.removeEventListener("selectend",X),i.removeEventListener("squeeze",X),i.removeEventListener("squeezestart",X),i.removeEventListener("squeezeend",X),i.removeEventListener("end",W),i.removeEventListener("inputsourceschange",tt);for(let Q=0;Q<E.length;Q++){const st=w[Q];st!==null&&(w[Q]=null,E[Q].disconnect(st))}L=null,F=null,p.reset();for(const Q in m)delete m[Q];if(t.setRenderTarget(T),f=null,d=null,u=null,i=null,y=null,Qt.stop(),n.isPresenting=!1,t.setPixelRatio(x),t.setSize(R.width,R.height,!1),S!==null){const Q=S.camera;Q.fov=S.fov,Q.zoom=S.zoom,Q.updateProjectionMatrix(),S=null}n.dispatchEvent({type:"sessionend"})}this.setFramebufferScaleFactor=function(Q){r=Q,n.isPresenting===!0&&Ut("WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function(Q){o=Q,n.isPresenting===!0&&Ut("WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return c||a},this.setReferenceSpace=function(Q){c=Q},this.getBaseLayer=function(){return d!==null?d:f},this.getBinding=function(){return u===null&&v&&(u=new XRWebGLBinding(i,e)),u},this.getFrame=function(){return _},this.getSession=function(){return i},this.setSession=async function(Q){if(i=Q,i!==null){if(T=t.getRenderTarget(),i.addEventListener("select",X),i.addEventListener("selectstart",X),i.addEventListener("selectend",X),i.addEventListener("squeeze",X),i.addEventListener("squeezestart",X),i.addEventListener("squeezeend",X),i.addEventListener("end",W),i.addEventListener("inputsourceschange",tt),b.xrCompatible!==!0&&await e.makeXRCompatible(),x=t.getPixelRatio(),t.getSize(R),v&&"createProjectionLayer"in XRWebGLBinding.prototype){let yt=null,Nt=null,vt=null;b.depth&&(vt=b.stencil?e.DEPTH24_STENCIL8:e.DEPTH_COMPONENT24,yt=b.stencil?xi:Wn,Nt=b.stencil?ws:Pn);const Gt={colorFormat:e.RGBA8,depthFormat:vt,scaleFactor:r};u=this.getBinding(),d=u.createProjectionLayer(Gt),i.updateRenderState({layers:[d]}),t.setPixelRatio(1),t.setSize(d.textureWidth,d.textureHeight,!1),y=new gn(d.textureWidth,d.textureHeight,{format:mn,type:Ze,depthTexture:new Ts(d.textureWidth,d.textureHeight,Nt,void 0,void 0,void 0,void 0,void 0,void 0,yt),stencilBuffer:b.stencil,colorSpace:t.outputColorSpace,samples:b.antialias?4:0,resolveDepthBuffer:d.ignoreDepthValues===!1,resolveStencilBuffer:d.ignoreDepthValues===!1,storeMultisampledDepthBuffer:d.ignoreDepthValues===!1,storeMultisampledStencilBuffer:d.ignoreDepthValues===!1})}else{const yt={antialias:b.antialias,alpha:!0,depth:b.depth,stencil:b.stencil,framebufferScaleFactor:r};f=new XRWebGLLayer(i,e,yt),i.updateRenderState({baseLayer:f}),t.setPixelRatio(1),t.setSize(f.framebufferWidth,f.framebufferHeight,!1),y=new gn(f.framebufferWidth,f.framebufferHeight,{format:mn,type:Ze,colorSpace:t.outputColorSpace,stencilBuffer:b.stencil,resolveDepthBuffer:f.ignoreDepthValues===!1,resolveStencilBuffer:f.ignoreDepthValues===!1,storeMultisampledDepthBuffer:f.ignoreDepthValues===!1,storeMultisampledStencilBuffer:f.ignoreDepthValues===!1})}y.isXRRenderTarget=!0,this.setFoveation(l),c=null,a=await i.requestReferenceSpace(o),Qt.setContext(i),Qt.start(),n.isPresenting=!0,n.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(i!==null)return i.environmentBlendMode},this.getDepthTexture=function(){return p.getDepthTexture()};function tt(Q){for(let st=0;st<Q.removed.length;st++){const yt=Q.removed[st],Nt=w.indexOf(yt);Nt>=0&&(w[Nt]=null,E[Nt].disconnect(yt))}for(let st=0;st<Q.added.length;st++){const yt=Q.added[st];let Nt=w.indexOf(yt);if(Nt===-1){for(let Gt=0;Gt<E.length;Gt++)if(Gt>=w.length){w.push(yt),Nt=Gt;break}else if(w[Gt]===null){w[Gt]=yt,Nt=Gt;break}if(Nt===-1)break}const vt=E[Nt];vt&&vt.connect(yt)}}const $=new O,et=new O;function Z(Q,st,yt){$.setFromMatrixPosition(st.matrixWorld),et.setFromMatrixPosition(yt.matrixWorld);const Nt=$.distanceTo(et),vt=st.projectionMatrix.elements,Gt=yt.projectionMatrix.elements,be=vt[14]/(vt[10]-1),Ht=vt[14]/(vt[10]+1),Jt=(vt[9]+1)/vt[5],ce=(vt[9]-1)/vt[5],Wt=(vt[8]-1)/vt[0],pe=(Gt[8]+1)/Gt[0],Ee=be*Wt,ze=be*pe,ge=Nt/(-Wt+pe),ve=ge*-Wt;if(st.matrixWorld.decompose(Q.position,Q.quaternion,Q.scale),Q.translateX(ve),Q.translateZ(ge),Q.matrixWorld.compose(Q.position,Q.quaternion,Q.scale),Q.matrixWorldInverse.copy(Q.matrixWorld).invert(),vt[10]===-1)Q.projectionMatrix.copy(st.projectionMatrix),Q.projectionMatrixInverse.copy(st.projectionMatrixInverse);else{const B=be+ge,Pe=Ht+ge,ne=Ee-ve,A=ze+(Nt-ve),g=Jt*Ht/Pe*B,G=ce*Ht/Pe*B;Q.projectionMatrix.makePerspective(ne,A,g,G,B,Pe),Q.projectionMatrixInverse.copy(Q.projectionMatrix).invert()}}function _t(Q,st){st===null?Q.matrixWorld.copy(Q.matrix):Q.matrixWorld.multiplyMatrices(st.matrixWorld,Q.matrix),Q.matrixWorldInverse.copy(Q.matrixWorld).invert()}this.updateCamera=function(Q){if(i===null)return;let st=Q.near,yt=Q.far;p.texture!==null&&(p.depthNear>0&&(st=p.depthNear),p.depthFar>0&&(yt=p.depthFar)),z.near=P.near=C.near=st,z.far=P.far=C.far=yt,(L!==z.near||F!==z.far)&&(i.updateRenderState({depthNear:z.near,depthFar:z.far}),L=z.near,F=z.far),z.layers.mask=Q.layers.mask|6,C.layers.mask=z.layers.mask&-5,P.layers.mask=z.layers.mask&-3;const Nt=Q.parent,vt=z.cameras;_t(z,Nt);for(let Gt=0;Gt<vt.length;Gt++)_t(vt[Gt],Nt);vt.length===2?Z(z,C,P):z.projectionMatrix.copy(C.projectionMatrix),S===null&&Q.isPerspectiveCamera&&(S={camera:Q,fov:Q.fov,zoom:Q.zoom}),Tt(Q,z,Nt)};function Tt(Q,st,yt){yt===null?Q.matrix.copy(st.matrixWorld):(Q.matrix.copy(yt.matrixWorld),Q.matrix.invert(),Q.matrix.multiply(st.matrixWorld)),Q.matrix.decompose(Q.position,Q.quaternion,Q.scale),Q.updateMatrixWorld(!0),Q.projectionMatrix.copy(st.projectionMatrix),Q.projectionMatrixInverse.copy(st.projectionMatrixInverse),Q.isPerspectiveCamera&&(Q.fov=_o*2*Math.atan(1/Q.projectionMatrix.elements[5]),Q.zoom=1)}this.getCamera=function(){return z},this.getFoveation=function(){if(!(d===null&&f===null))return l},this.setFoveation=function(Q){l=Q,d!==null&&(d.fixedFoveation=Q),f!==null&&f.fixedFoveation!==void 0&&(f.fixedFoveation=Q)},this.hasDepthSensing=function(){return p.texture!==null},this.getDepthSensingMesh=function(){return p.getMesh(z)},this.getCameraTexture=function(Q){return m[Q]};let se=null;function Yt(Q,st){if(h=st.getViewerPose(c||a),_=st,h!==null){const yt=h.views;f!==null&&(t.setRenderTargetFramebuffer(y,f.framebuffer),t.setRenderTarget(y));let Nt=!1;yt.length!==z.cameras.length&&(z.cameras.length=0,Nt=!0);for(let Ht=0;Ht<yt.length;Ht++){const Jt=yt[Ht];let ce=null;if(f!==null)ce=f.getViewport(Jt);else{const pe=u.getViewSubImage(d,Jt);ce=pe.viewport,Ht===0&&(t.setRenderTargetTextures(y,pe.colorTexture,pe.depthStencilTexture),t.setRenderTarget(y))}let Wt=D[Ht];Wt===void 0&&(Wt=new Ke,Wt.layers.enable(Ht),Wt.viewport=new _e,D[Ht]=Wt),Wt.matrix.fromArray(Jt.transform.matrix),Wt.matrix.decompose(Wt.position,Wt.quaternion,Wt.scale),Wt.projectionMatrix.fromArray(Jt.projectionMatrix),Wt.projectionMatrixInverse.copy(Wt.projectionMatrix).invert(),Wt.viewport.set(ce.x,ce.y,ce.width,ce.height),Ht===0&&(z.matrix.copy(Wt.matrix),z.matrix.decompose(z.position,z.quaternion,z.scale)),Nt===!0&&z.cameras.push(Wt)}const vt=i.enabledFeatures;if(vt&&vt.includes("depth-sensing")&&i.depthUsage=="gpu-optimized"&&v){u=n.getBinding();const Ht=u.getDepthInformation(yt[0]);Ht&&Ht.isValid&&Ht.texture&&p.init(Ht,i.renderState)}if(vt&&vt.includes("camera-access")&&v){t.state.unbindTexture(),u=n.getBinding();for(let Ht=0;Ht<yt.length;Ht++){const Jt=yt[Ht].camera;if(Jt){let ce=m[Jt];ce||(ce=new dh,m[Jt]=ce);const Wt=u.getCameraImage(Jt);ce.sourceTexture=Wt}}}}for(let yt=0;yt<E.length;yt++){const Nt=w[yt],vt=E[yt];Nt!==null&&vt!==void 0&&vt.update(Nt,st,c||a)}se&&se(Q,st),st.detectedPlanes&&n.dispatchEvent({type:"planesdetected",data:st}),_=null}const Qt=new xh;Qt.setAnimationLoop(Yt),this.setAnimationLoop=function(Q){se=Q},this.dispose=function(){}}}const Qg=new Zt,Eh=new Ft;Eh.set(-1,0,0,0,1,0,0,0,1);function jg(s,t){function e(p,m){p.matrixAutoUpdate===!0&&p.updateMatrix(),m.value.copy(p.matrix)}function n(p,m){m.color.getRGB(p.fogColor.value,uh(s)),m.isFog?(p.fogNear.value=m.near,p.fogFar.value=m.far):m.isFogExp2&&(p.fogDensity.value=m.density)}function i(p,m,b,T,y){m.isNodeMaterial?m.uniformsNeedUpdate=!1:m.isMeshBasicMaterial?r(p,m):m.isMeshLambertMaterial?(r(p,m),m.envMap&&(p.envMapIntensity.value=m.envMapIntensity)):m.isMeshToonMaterial?(r(p,m),u(p,m)):m.isMeshPhongMaterial?(r(p,m),h(p,m),m.envMap&&(p.envMapIntensity.value=m.envMapIntensity)):m.isMeshStandardMaterial?(r(p,m),d(p,m),m.isMeshPhysicalMaterial&&f(p,m,y)):m.isMeshMatcapMaterial?(r(p,m),_(p,m)):m.isMeshDepthMaterial?r(p,m):m.isMeshDistanceMaterial?(r(p,m),v(p,m)):m.isMeshNormalMaterial?r(p,m):m.isLineBasicMaterial?(a(p,m),m.isLineDashedMaterial&&o(p,m)):m.isPointsMaterial?l(p,m,b,T):m.isSpriteMaterial?c(p,m):m.isShadowMaterial?(p.color.value.copy(m.color),p.opacity.value=m.opacity):m.isShaderMaterial&&(m.uniformsNeedUpdate=!1)}function r(p,m){p.opacity.value=m.opacity,m.color&&p.diffuse.value.copy(m.color),m.emissive&&p.emissive.value.copy(m.emissive).multiplyScalar(m.emissiveIntensity),m.map&&(p.map.value=m.map,e(m.map,p.mapTransform)),m.alphaMap&&(p.alphaMap.value=m.alphaMap,e(m.alphaMap,p.alphaMapTransform)),m.bumpMap&&(p.bumpMap.value=m.bumpMap,e(m.bumpMap,p.bumpMapTransform),p.bumpScale.value=m.bumpScale,m.side===Ve&&(p.bumpScale.value*=-1)),m.normalMap&&(p.normalMap.value=m.normalMap,e(m.normalMap,p.normalMapTransform),p.normalScale.value.copy(m.normalScale),m.side===Ve&&p.normalScale.value.negate()),m.displacementMap&&(p.displacementMap.value=m.displacementMap,e(m.displacementMap,p.displacementMapTransform),p.displacementScale.value=m.displacementScale,p.displacementBias.value=m.displacementBias),m.emissiveMap&&(p.emissiveMap.value=m.emissiveMap,e(m.emissiveMap,p.emissiveMapTransform)),m.specularMap&&(p.specularMap.value=m.specularMap,e(m.specularMap,p.specularMapTransform)),m.alphaTest>0&&(p.alphaTest.value=m.alphaTest);const b=t.get(m),T=b.envMap,y=b.envMapRotation;T&&(p.envMap.value=T,p.envMapRotation.value.setFromMatrix4(Qg.makeRotationFromEuler(y)).transpose(),T.isCubeTexture&&T.isRenderTargetTexture===!1&&p.envMapRotation.value.premultiply(Eh),p.reflectivity.value=m.reflectivity,p.ior.value=m.ior,p.refractionRatio.value=m.refractionRatio),m.lightMap&&(p.lightMap.value=m.lightMap,p.lightMapIntensity.value=m.lightMapIntensity,e(m.lightMap,p.lightMapTransform)),m.aoMap&&(p.aoMap.value=m.aoMap,p.aoMapIntensity.value=m.aoMapIntensity,e(m.aoMap,p.aoMapTransform))}function a(p,m){p.diffuse.value.copy(m.color),p.opacity.value=m.opacity,m.map&&(p.map.value=m.map,e(m.map,p.mapTransform))}function o(p,m){p.dashSize.value=m.dashSize,p.totalSize.value=m.dashSize+m.gapSize,p.scale.value=m.scale}function l(p,m,b,T){p.diffuse.value.copy(m.color),p.opacity.value=m.opacity,p.size.value=m.size*b,p.scale.value=T*.5,m.map&&(p.map.value=m.map,e(m.map,p.uvTransform)),m.alphaMap&&(p.alphaMap.value=m.alphaMap,e(m.alphaMap,p.alphaMapTransform)),m.alphaTest>0&&(p.alphaTest.value=m.alphaTest)}function c(p,m){p.diffuse.value.copy(m.color),p.opacity.value=m.opacity,p.rotation.value=m.rotation,m.map&&(p.map.value=m.map,e(m.map,p.mapTransform)),m.alphaMap&&(p.alphaMap.value=m.alphaMap,e(m.alphaMap,p.alphaMapTransform)),m.alphaTest>0&&(p.alphaTest.value=m.alphaTest)}function h(p,m){p.specular.value.copy(m.specular),p.shininess.value=Math.max(m.shininess,1e-4)}function u(p,m){m.gradientMap&&(p.gradientMap.value=m.gradientMap)}function d(p,m){p.metalness.value=m.metalness,m.metalnessMap&&(p.metalnessMap.value=m.metalnessMap,e(m.metalnessMap,p.metalnessMapTransform)),p.roughness.value=m.roughness,m.roughnessMap&&(p.roughnessMap.value=m.roughnessMap,e(m.roughnessMap,p.roughnessMapTransform)),m.envMap&&(p.envMapIntensity.value=m.envMapIntensity)}function f(p,m,b){p.ior.value=m.ior,m.sheen>0&&(p.sheenColor.value.copy(m.sheenColor).multiplyScalar(m.sheen),p.sheenRoughness.value=m.sheenRoughness,m.sheenColorMap&&(p.sheenColorMap.value=m.sheenColorMap,e(m.sheenColorMap,p.sheenColorMapTransform)),m.sheenRoughnessMap&&(p.sheenRoughnessMap.value=m.sheenRoughnessMap,e(m.sheenRoughnessMap,p.sheenRoughnessMapTransform))),m.clearcoat>0&&(p.clearcoat.value=m.clearcoat,p.clearcoatRoughness.value=m.clearcoatRoughness,m.clearcoatMap&&(p.clearcoatMap.value=m.clearcoatMap,e(m.clearcoatMap,p.clearcoatMapTransform)),m.clearcoatRoughnessMap&&(p.clearcoatRoughnessMap.value=m.clearcoatRoughnessMap,e(m.clearcoatRoughnessMap,p.clearcoatRoughnessMapTransform)),m.clearcoatNormalMap&&(p.clearcoatNormalMap.value=m.clearcoatNormalMap,e(m.clearcoatNormalMap,p.clearcoatNormalMapTransform),p.clearcoatNormalScale.value.copy(m.clearcoatNormalScale),m.side===Ve&&p.clearcoatNormalScale.value.negate())),m.dispersion>0&&(p.dispersion.value=m.dispersion),m.retroreflectivity>0&&(p.retroreflectivity.value=m.retroreflectivity),m.iridescence>0&&(p.iridescence.value=m.iridescence,p.iridescenceIOR.value=m.iridescenceIOR,p.iridescenceThicknessMinimum.value=m.iridescenceThicknessRange[0],p.iridescenceThicknessMaximum.value=m.iridescenceThicknessRange[1],m.iridescenceMap&&(p.iridescenceMap.value=m.iridescenceMap,e(m.iridescenceMap,p.iridescenceMapTransform)),m.iridescenceThicknessMap&&(p.iridescenceThicknessMap.value=m.iridescenceThicknessMap,e(m.iridescenceThicknessMap,p.iridescenceThicknessMapTransform))),m.transmission>0&&(p.transmission.value=m.transmission,p.transmissionSamplerMap.value=b.texture,p.transmissionSamplerSize.value.set(b.width,b.height),m.transmissionMap&&(p.transmissionMap.value=m.transmissionMap,e(m.transmissionMap,p.transmissionMapTransform)),p.thickness.value=m.thickness,m.thicknessMap&&(p.thicknessMap.value=m.thicknessMap,e(m.thicknessMap,p.thicknessMapTransform)),p.attenuationDistance.value=m.attenuationDistance,p.attenuationColor.value.copy(m.attenuationColor)),m.anisotropy>0&&(p.anisotropyVector.value.set(m.anisotropy*Math.cos(m.anisotropyRotation),m.anisotropy*Math.sin(m.anisotropyRotation)),m.anisotropyMap&&(p.anisotropyMap.value=m.anisotropyMap,e(m.anisotropyMap,p.anisotropyMapTransform))),p.specularIntensity.value=m.specularIntensity,p.specularColor.value.copy(m.specularColor),m.specularColorMap&&(p.specularColorMap.value=m.specularColorMap,e(m.specularColorMap,p.specularColorMapTransform)),m.specularIntensityMap&&(p.specularIntensityMap.value=m.specularIntensityMap,e(m.specularIntensityMap,p.specularIntensityMapTransform))}function _(p,m){m.matcap&&(p.matcap.value=m.matcap)}function v(p,m){const b=t.get(m).light;p.referencePosition.value.setFromMatrixPosition(b.matrixWorld),p.nearDistance.value=b.shadow.camera.near,p.farDistance.value=b.shadow.camera.far}return{refreshFogUniforms:n,refreshMaterialUniforms:i}}function t_(s,t,e,n){let i={},r={},a=[];const o=s.getParameter(s.MAX_UNIFORM_BUFFER_BINDINGS);function l(y,E){const w=E.program;n.uniformBlockBinding(y,w)}function c(y,E){let w=i[y.id];w===void 0&&(p(y),w=h(y),i[y.id]=w,y.addEventListener("dispose",b));const R=E.program;n.updateUBOMapping(y,R);const x=t.render.frame;r[y.id]!==x&&(d(y),r[y.id]=x)}function h(y){const E=u();y.__bindingPointIndex=E;const w=s.createBuffer(),R=y.__size,x=y.usage;return s.bindBuffer(s.UNIFORM_BUFFER,w),s.bufferData(s.UNIFORM_BUFFER,R,x),s.bindBuffer(s.UNIFORM_BUFFER,null),s.bindBufferBase(s.UNIFORM_BUFFER,E,w),w}function u(){for(let y=0;y<o;y++)if(a.indexOf(y)===-1)return a.push(y),y;return Kt("WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached."),0}function d(y){const E=i[y.id],w=y.uniforms,R=y.__cache;s.bindBuffer(s.UNIFORM_BUFFER,E);for(let x=0,S=w.length;x<S;x++){const C=w[x];if(Array.isArray(C))for(let P=0,D=C.length;P<D;P++)f(C[P],x,P,R);else f(C,x,0,R)}s.bindBuffer(s.UNIFORM_BUFFER,null)}function f(y,E,w,R){if(v(y,E,w,R)===!0){const x=y.__offset,S=y.value;if(Array.isArray(S)){let C=0;for(let P=0;P<S.length;P++){const D=S[P],z=m(D);_(D,y.__data,C),typeof D!="number"&&typeof D!="boolean"&&!D.isMatrix3&&!ArrayBuffer.isView(D)&&(C+=z.storage/Float32Array.BYTES_PER_ELEMENT)}}else _(S,y.__data,0);s.bufferSubData(s.UNIFORM_BUFFER,x,y.__data)}}function _(y,E,w){typeof y=="number"||typeof y=="boolean"?E[0]=y:y.isMatrix3?(E[0]=y.elements[0],E[1]=y.elements[1],E[2]=y.elements[2],E[3]=0,E[4]=y.elements[3],E[5]=y.elements[4],E[6]=y.elements[5],E[7]=0,E[8]=y.elements[6],E[9]=y.elements[7],E[10]=y.elements[8],E[11]=0):ArrayBuffer.isView(y)?E.set(new y.constructor(y.buffer,y.byteOffset,E.length)):y.toArray(E,w)}function v(y,E,w,R){const x=y.value,S=E+"_"+w;if(R[S]===void 0)return typeof x=="number"||typeof x=="boolean"?R[S]=x:ArrayBuffer.isView(x)?R[S]=x.slice():R[S]=x.clone(),!0;{const C=R[S];if(typeof x=="number"||typeof x=="boolean"){if(C!==x)return R[S]=x,!0}else{if(ArrayBuffer.isView(x))return!0;if(C.equals(x)===!1)return C.copy(x),!0}}return!1}function p(y){const E=y.uniforms;let w=0;const R=16;for(let S=0,C=E.length;S<C;S++){const P=Array.isArray(E[S])?E[S]:[E[S]];for(let D=0,z=P.length;D<z;D++){const L=P[D],F=Array.isArray(L.value)?L.value:[L.value];for(let X=0,W=F.length;X<W;X++){const tt=F[X],$=m(tt),et=w%R,Z=et%$.boundary,_t=et+Z;w+=Z,_t!==0&&R-_t<$.storage&&(w+=R-_t),L.__data=new Float32Array($.storage/Float32Array.BYTES_PER_ELEMENT),L.__offset=w,w+=$.storage}}}const x=w%R;return x>0&&(w+=R-x),y.__size=w,y.__cache={},this}function m(y){const E={boundary:0,storage:0};return typeof y=="number"||typeof y=="boolean"?(E.boundary=4,E.storage=4):y.isVector2?(E.boundary=8,E.storage=8):y.isVector3||y.isColor?(E.boundary=16,E.storage=12):y.isVector4?(E.boundary=16,E.storage=16):y.isMatrix3?(E.boundary=48,E.storage=48):y.isMatrix4?(E.boundary=64,E.storage=64):y.isTexture?Ut("WebGLRenderer: Texture samplers can not be part of an uniforms group."):ArrayBuffer.isView(y)?(E.boundary=16,E.storage=y.byteLength):Ut("WebGLRenderer: Unsupported uniform value type.",y),E}function b(y){const E=y.target;E.removeEventListener("dispose",b);const w=a.indexOf(E.__bindingPointIndex);a.splice(w,1),s.deleteBuffer(i[E.id]),delete i[E.id],delete r[E.id]}function T(){for(const y in i)s.deleteBuffer(i[y]);a=[],i={},r={}}return{bind:l,update:c,dispose:T}}const e_=new Uint16Array([12469,15057,12620,14925,13266,14620,13807,14376,14323,13990,14545,13625,14713,13328,14840,12882,14931,12528,14996,12233,15039,11829,15066,11525,15080,11295,15085,10976,15082,10705,15073,10495,13880,14564,13898,14542,13977,14430,14158,14124,14393,13732,14556,13410,14702,12996,14814,12596,14891,12291,14937,11834,14957,11489,14958,11194,14943,10803,14921,10506,14893,10278,14858,9960,14484,14039,14487,14025,14499,13941,14524,13740,14574,13468,14654,13106,14743,12678,14818,12344,14867,11893,14889,11509,14893,11180,14881,10751,14852,10428,14812,10128,14765,9754,14712,9466,14764,13480,14764,13475,14766,13440,14766,13347,14769,13070,14786,12713,14816,12387,14844,11957,14860,11549,14868,11215,14855,10751,14825,10403,14782,10044,14729,9651,14666,9352,14599,9029,14967,12835,14966,12831,14963,12804,14954,12723,14936,12564,14917,12347,14900,11958,14886,11569,14878,11247,14859,10765,14828,10401,14784,10011,14727,9600,14660,9289,14586,8893,14508,8533,15111,12234,15110,12234,15104,12216,15092,12156,15067,12010,15028,11776,14981,11500,14942,11205,14902,10752,14861,10393,14812,9991,14752,9570,14682,9252,14603,8808,14519,8445,14431,8145,15209,11449,15208,11451,15202,11451,15190,11438,15163,11384,15117,11274,15055,10979,14994,10648,14932,10343,14871,9936,14803,9532,14729,9218,14645,8742,14556,8381,14461,8020,14365,7603,15273,10603,15272,10607,15267,10619,15256,10631,15231,10614,15182,10535,15118,10389,15042,10167,14963,9787,14883,9447,14800,9115,14710,8665,14615,8318,14514,7911,14411,7507,14279,7198,15314,9675,15313,9683,15309,9712,15298,9759,15277,9797,15229,9773,15166,9668,15084,9487,14995,9274,14898,8910,14800,8539,14697,8234,14590,7790,14479,7409,14367,7067,14178,6621,15337,8619,15337,8631,15333,8677,15325,8769,15305,8871,15264,8940,15202,8909,15119,8775,15022,8565,14916,8328,14804,8009,14688,7614,14569,7287,14448,6888,14321,6483,14088,6171,15350,7402,15350,7419,15347,7480,15340,7613,15322,7804,15287,7973,15229,8057,15148,8012,15046,7846,14933,7611,14810,7357,14682,7069,14552,6656,14421,6316,14251,5948,14007,5528,15356,5942,15356,5977,15353,6119,15348,6294,15332,6551,15302,6824,15249,7044,15171,7122,15070,7050,14949,6861,14818,6611,14679,6349,14538,6067,14398,5651,14189,5311,13935,4958,15359,4123,15359,4153,15356,4296,15353,4646,15338,5160,15311,5508,15263,5829,15188,6042,15088,6094,14966,6001,14826,5796,14678,5543,14527,5287,14377,4985,14133,4586,13869,4257,15360,1563,15360,1642,15358,2076,15354,2636,15341,3350,15317,4019,15273,4429,15203,4732,15105,4911,14981,4932,14836,4818,14679,4621,14517,4386,14359,4156,14083,3795,13808,3437,15360,122,15360,137,15358,285,15355,636,15344,1274,15322,2177,15281,2765,15215,3223,15120,3451,14995,3569,14846,3567,14681,3466,14511,3305,14344,3121,14037,2800,13753,2467,15360,0,15360,1,15359,21,15355,89,15346,253,15325,479,15287,796,15225,1148,15133,1492,15008,1749,14856,1882,14685,1886,14506,1783,14324,1608,13996,1398,13702,1183]);let yn=null;function n_(){return yn===null&&(yn=new ch(e_,16,16,yi,Ln),yn.name="DFG_LUT",yn.minFilter=Ue,yn.magFilter=Ue,yn.wrapS=On,yn.wrapT=On,yn.generateMipmaps=!1,yn.needsUpdate=!0),yn}class Th{constructor(t={}){const{canvas:e=Mu(),context:n=null,depth:i=!0,stencil:r=!1,alpha:a=!1,antialias:o=!1,premultipliedAlpha:l=!0,preserveDrawingBuffer:c=!1,powerPreference:h="default",failIfMajorPerformanceCaveat:u=!1,reversedDepthBuffer:d=!1,outputBufferType:f=Ze}=t;this.isWebGLRenderer=!0;let _;if(n!==null){if(typeof WebGLRenderingContext!="undefined"&&n instanceof WebGLRenderingContext)throw new Error("THREE.WebGLRenderer: WebGL 1 is not supported since r163.");_=n.getContextAttributes().alpha}else _=a;const v=f,p=new Set([Io,Do,Lo]),m=new Set([Ze,Pn,Ss,ws,Co,Ro]),b=new Uint32Array(4),T=new Int32Array(4),y=new O;let E=null,w=null;const R=[],x=[];let S=null;this.domElement=e,this.debug={checkShaderErrors:!0,diagnostics:{keywords:!1},onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this.toneMapping=An,this.toneMappingExposure=1,this.transmissionResolutionScale=1;const C=this;let P=!1,D=null,z=null,L=null,F=null;this._outputColorSpace=He;let X=0,W=0,tt=null,$=-1,et=null;const Z=new _e,_t=new _e;let Tt=null;const se=new At(0);let Yt=0,Qt=e.width,Q=e.height,st=1,yt=null,Nt=null;const vt=new _e(0,0,Qt,Q),Gt=new _e(0,0,Qt,Q);let be=!1;const Ht=new Oo;let Jt=!1,ce=!1;const Wt=new Zt,pe=new O,Ee=new _e,ze={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0};let ge=!1;function ve(){return tt===null?st:1}let B=n;function Pe(M,N){return e.getContext(M,N)}let ne,A,g,G,q,J,at,ot,j,it,lt,Ct,ut,ct,Rt,Dt,kt,k,ht,nt,dt,gt,rt;try{const M={alpha:!0,depth:i,stencil:r,antialias:o,premultipliedAlpha:l,preserveDrawingBuffer:c,powerPreference:h,failIfMajorPerformanceCaveat:u};if("setAttribute"in e&&e.setAttribute("data-engine",`three.js r${Eo}`),e.addEventListener("webglcontextlost",he,!1),e.addEventListener("webglcontextrestored",jt,!1),e.addEventListener("webglcontextcreationerror",rn,!1),B===null){const N="webgl2";if(B=Pe(N,M),B===null)throw Pe(N)?new Error("THREE.WebGLRenderer: Error creating WebGL context with your selected attributes."):new Error("THREE.WebGLRenderer: Error creating WebGL context.")}Pt()}catch(M){throw e.removeEventListener("webglcontextlost",he,!1),e.removeEventListener("webglcontextrestored",jt,!1),e.removeEventListener("webglcontextcreationerror",rn,!1),Kt("WebGLRenderer: "+M.message),M}function Pt(){ne=new n0(B),ne.init(),dt=new Yg(B,ne),A=new qm(B,ne,t,dt),g=new Xg(B,ne),A.reversedDepthBuffer&&d&&g.buffers.depth.setReversed(!0),z=B.createFramebuffer(),L=B.createFramebuffer(),F=B.createFramebuffer(),G=new r0(B),q=new Lg,J=new qg(B,ne,g,q,A,dt,G),at=new e0(C),ot=new of(B),gt=new Wm(B,ot),j=new i0(B,ot,G,gt),it=new o0(B,j,ot,gt,G),k=new a0(B,A,J),Rt=new Ym(q),lt=new Pg(C,at,ne,A,gt,Rt),Ct=new jg(C,q),ut=new Ig,ct=new Og(ne),kt=new Vm(C,at,g,it,_,l),Dt=new Wg(C,it,A),rt=new t_(B,G,A,g),ht=new Xm(B,ne,G),nt=new s0(B,ne,G),G.programs=lt.programs,C.capabilities=A,C.extensions=ne,C.properties=q,C.renderLists=ut,C.shadowMap=Dt,C.state=g,C.info=G}v!==Ze&&(S=new c0(v,e.width,e.height,o,i,r));const wt=new Jg(C,B);this.xr=wt,this.getContext=function(){return B},this.getContextAttributes=function(){return B.getContextAttributes()},this.forceContextLoss=function(){const M=ne.get("WEBGL_lose_context");M&&M.loseContext()},this.forceContextRestore=function(){const M=ne.get("WEBGL_lose_context");M&&M.restoreContext()},this.getPixelRatio=function(){return st},this.setPixelRatio=function(M){M!==void 0&&(st=M,this.setSize(Qt,Q,!1))},this.getSize=function(M){return M.set(Qt,Q)},this.setSize=function(M,N,K=!0){if(wt.isPresenting){Ut("WebGLRenderer: Can't change size while VR device is presenting.");return}Qt=M,Q=N,e.width=Math.floor(M*st),e.height=Math.floor(N*st),K===!0&&(e.style.width=M+"px",e.style.height=N+"px"),S!==null&&S.setSize(e.width,e.height),this.setViewport(0,0,M,N)},this.getDrawingBufferSize=function(M){return M.set(Qt*st,Q*st).floor()},this.setDrawingBufferSize=function(M,N,K){Qt=M,Q=N,st=K,e.width=Math.floor(M*K),e.height=Math.floor(N*K),this.setViewport(0,0,M,N)},this.setEffects=function(M){if(v===Ze){Kt("WebGLRenderer: setEffects() requires outputBufferType set to HalfFloatType or FloatType.");return}if(M){for(let N=0;N<M.length;N++)if(M[N].isOutputPass===!0){Ut("WebGLRenderer: OutputPass is not needed in setEffects(). Tone mapping and color space conversion are applied automatically.");break}}S.setEffects(M||[])},this.getCurrentViewport=function(M){return M.copy(Z)},this.getViewport=function(M){return M.copy(vt)},this.setViewport=function(M,N,K,H){M.isVector4?vt.set(M.x,M.y,M.z,M.w):vt.set(M,N,K,H),g.viewport(Z.copy(vt).multiplyScalar(st).round())},this.getScissor=function(M){return M.copy(Gt)},this.setScissor=function(M,N,K,H){M.isVector4?Gt.set(M.x,M.y,M.z,M.w):Gt.set(M,N,K,H),g.scissor(_t.copy(Gt).multiplyScalar(st).round())},this.getScissorTest=function(){return be},this.setScissorTest=function(M){g.setScissorTest(be=M)},this.setOpaqueSort=function(M){yt=M},this.setTransparentSort=function(M){Nt=M},this.getClearColor=function(M){return M.copy(kt.getClearColor())},this.setClearColor=function(){kt.setClearColor(...arguments)},this.getClearAlpha=function(){return kt.getClearAlpha()},this.setClearAlpha=function(){kt.setClearAlpha(...arguments)},this.clear=function(M=!0,N=!0,K=!0){let H=0;if(M){let V=!1;if(tt!==null){const mt=tt.texture.format;V=p.has(mt)}if(V){const mt=tt.texture.type,Mt=m.has(mt),pt=kt.getClearColor(),bt=kt.getClearAlpha(),Et=pt.r,Ot=pt.g,Vt=pt.b;Mt?(b[0]=Et,b[1]=Ot,b[2]=Vt,b[3]=bt,B.clearBufferuiv(B.COLOR,0,b)):(T[0]=Et,T[1]=Ot,T[2]=Vt,T[3]=bt,B.clearBufferiv(B.COLOR,0,T))}else H|=B.COLOR_BUFFER_BIT}N&&(H|=B.DEPTH_BUFFER_BIT,this.state.buffers.depth.setMask(!0)),K&&(H|=B.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),H!==0&&B.clear(H)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.setNodesHandler=function(M){M.setRenderer(this),D=M},this.dispose=function(){e.removeEventListener("webglcontextlost",he,!1),e.removeEventListener("webglcontextrestored",jt,!1),e.removeEventListener("webglcontextcreationerror",rn,!1),kt.dispose(),ut.dispose(),ct.dispose(),q.dispose(),at.dispose(),it.dispose(),gt.dispose(),rt.dispose(),lt.dispose(),wt.dispose(),wt.removeEventListener("sessionstart",Jo),wt.removeEventListener("sessionend",Qo),oi.stop()};function he(M){M.preventDefault(),Ml("WebGLRenderer: Context Lost."),P=!0}function jt(){Ml("WebGLRenderer: Context Restored."),P=!1;const M=G.autoReset,N=Dt.enabled,K=Dt.autoUpdate,H=Dt.needsUpdate,V=Dt.type;Pt(),G.autoReset=M,Dt.enabled=N,Dt.autoUpdate=K,Dt.needsUpdate=H,Dt.type=V}function rn(M){Kt("WebGLRenderer: A WebGL context could not be created. Reason: ",M.statusMessage)}function xn(M){const N=M.target;N.removeEventListener("dispose",xn),Lh(N)}function Lh(M){Dh(M),q.remove(M)}function Dh(M){const N=q.get(M).programs;N!==void 0&&(N.forEach(function(K){lt.releaseProgram(K)}),M.isShaderMaterial&&lt.releaseShaderCache(M))}this.renderBufferDirect=function(M,N,K,H,V,mt){N===null&&(N=ze);const Mt=V.isMesh&&V.matrixWorld.determinantAffine()<0,pt=Nh(M,N,K,H,V);g.setMaterial(H,Mt);let bt=K.index,Et=1;if(H.wireframe===!0){if(bt=j.getWireframeAttribute(K),bt===void 0)return;Et=2}const Ot=K.drawRange,Vt=K.attributes.position;let St=Ot.start*Et,te=(Ot.start+Ot.count)*Et;mt!==null&&(St=Math.max(St,mt.start*Et),te=Math.min(te,(mt.start+mt.count)*Et)),bt!==null?(St=Math.max(St,0),te=Math.min(te,bt.count)):Vt!=null&&(St=Math.max(St,0),te=Math.min(te,Vt.count));const Me=te-St;if(Me<0||Me===1/0)return;gt.setup(V,H,pt,K,bt);let ue,oe=ht;if(bt!==null&&(ue=ot.get(bt),oe=nt,oe.setIndex(ue)),V.isMesh)H.wireframe===!0?(g.setLineWidth(H.wireframeLinewidth*ve()),oe.setMode(B.LINES)):oe.setMode(B.TRIANGLES);else if(V.isLine){let Le=H.linewidth;Le===void 0&&(Le=1),g.setLineWidth(Le*ve()),V.isLineSegments?oe.setMode(B.LINES):V.isLineLoop?oe.setMode(B.LINE_LOOP):oe.setMode(B.LINE_STRIP)}else V.isPoints?oe.setMode(B.POINTS):V.isSprite&&oe.setMode(B.TRIANGLES);if(V.isBatchedMesh)if(ne.get("WEBGL_multi_draw"))oe.renderMultiDraw(V._multiDrawStarts,V._multiDrawCounts,V._multiDrawCount);else{const Le=V._multiDrawStarts,xt=V._multiDrawCounts,Ne=V._multiDrawCount,$t=bt?ot.get(bt).bytesPerElement:1,Je=q.get(H).currentProgram.getUniforms();for(let vn=0;vn<Ne;vn++)Je.setValue(B,"_gl_DrawID",vn),oe.render(Le[vn]/$t,xt[vn])}else if(V.isInstancedMesh)oe.renderInstances(St,Me,V.count);else if(K.isInstancedBufferGeometry){const Le=K._maxInstanceCount!==void 0?K._maxInstanceCount:1/0,xt=Math.min(K.instanceCount,Le);oe.renderInstances(St,Me,xt)}else oe.render(St,Me)};function Zo(M,N,K,H){D!==null&&M.isNodeMaterial&&D.setObject(H,M),Jt===!0&&Rt.setState(M,K,!1),M.transparent===!0&&M.side===wn&&M.forceSinglePass===!1?(M.side=Ve,M.needsUpdate=!0,Is(M,N,H),M.side=vi,M.needsUpdate=!0,Is(M,N,H),M.side=wn):Is(M,N,H)}this.compile=function(M,N,K=null){K===null&&(K=M),D!==null&&D.renderStart(M,N,K),w=ct.get(K),w.init(N),x.push(w),K.traverseVisible(function(V){V.isLight&&V.layers.test(N.layers)&&(w.pushLight(V),V.castShadow&&w.pushShadow(V))}),M!==K&&M.traverseVisible(function(V){V.isLight&&V.layers.test(N.layers)&&(w.pushLight(V),V.castShadow&&w.pushShadow(V))}),w.setupLights(),D!==null&&D.updateLights(w.state.lightsArray),ce=this.localClippingEnabled,Jt=Rt.init(this.clippingPlanes,ce),Jt===!0&&Rt.setGlobalState(this.clippingPlanes,N),D!==null&&Dt.render(w.state.shadowsArray,K,N);const H=new Set;return M.traverse(function(V){if(!(V.isMesh||V.isPoints||V.isLine||V.isSprite))return;const mt=V.material;if(mt)if(Array.isArray(mt))for(let Mt=0;Mt<mt.length;Mt++){const pt=mt[Mt];Zo(pt,K,N,V),H.add(pt)}else Zo(mt,K,N,V),H.add(mt)}),w=x.pop(),D!==null&&D.renderEnd(),H},this.compileAsync=function(M,N,K=null){const H=this.compile(M,N,K);return new Promise(V=>{function mt(){if(H.forEach(function(Mt){const bt=q.get(Mt).currentProgram;(bt===void 0||bt.isReady())&&H.delete(Mt)}),H.size===0){V(M);return}setTimeout(mt,10)}ne.get("KHR_parallel_shader_compile")!==null?mt():setTimeout(mt,10)})};let zr=null;function Ih(M){zr&&zr(M)}function Jo(){oi.stop()}function Qo(){oi.start()}const oi=new xh;oi.setAnimationLoop(Ih),typeof self!="undefined"&&oi.setContext(self),this.setAnimationLoop=function(M){zr=M,wt.setAnimationLoop(M),M===null?oi.stop():oi.start()},wt.addEventListener("sessionstart",Jo),wt.addEventListener("sessionend",Qo),this.render=function(M,N){if(N!==void 0&&N.isCamera!==!0){Kt("WebGLRenderer.render: camera is not an instance of THREE.Camera.");return}if(P===!0)return;D!==null&&D.renderStart(M,N);const K=wt.enabled===!0&&wt.isPresenting===!0,H=S!==null&&(tt===null||K)&&S.begin(C,tt);if(M.matrixWorldAutoUpdate===!0&&M.updateMatrixWorld(),N.parent===null&&N.matrixWorldAutoUpdate===!0&&N.updateMatrixWorld(),wt.enabled===!0&&wt.isPresenting===!0&&(S===null||S.isCompositing()===!1)&&(wt.cameraAutoUpdate===!0&&wt.updateCamera(N),N=wt.getCamera()),M.isScene===!0&&M.onBeforeRender(C,M,N,tt),w=ct.get(M,x.length),w.init(N),w.state.textureUnits=J.getTextureUnits(),x.push(w),Wt.multiplyMatrices(N.projectionMatrix,N.matrixWorldInverse),Ht.setFromProjectionMatrix(Wt,Tn,N.reversedDepth),ce=this.localClippingEnabled,Jt=Rt.init(this.clippingPlanes,ce),E=ut.get(M,R.length),E.init(),R.push(E),wt.enabled===!0&&wt.isPresenting===!0){const Mt=C.xr.getDepthSensingMesh();Mt!==null&&Gr(Mt,N,-1/0,C.sortObjects)}Gr(M,N,0,C.sortObjects),E.finish(),D!==null&&D.updateLights(w.state.lightsArray),C.sortObjects===!0&&E.sort(yt,Nt),ge=wt.enabled===!1||wt.isPresenting===!1||wt.hasDepthSensing()===!1,ge&&kt.addToRenderList(E,M),this.info.render.frame++,this.info.autoReset===!0&&this.info.reset(),Jt===!0&&Rt.beginShadows();const V=w.state.shadowsArray;if(Dt.render(V,M,N),Jt===!0&&Rt.endShadows(),(H&&S.hasRenderPass())===!1){const Mt=E.opaque,pt=E.transmissive;if(w.setupLights(),N.isArrayCamera){const bt=N.cameras;if(pt.length>0)for(let Et=0,Ot=bt.length;Et<Ot;Et++){const Vt=bt[Et];tl(Mt,pt,M,Vt)}ge&&kt.render(M);for(let Et=0,Ot=bt.length;Et<Ot;Et++){const Vt=bt[Et];jo(E,M,Vt,Vt.viewport)}}else pt.length>0&&tl(Mt,pt,M,N),ge&&kt.render(M),jo(E,M,N)}tt!==null&&W===0&&(J.updateMultisampleRenderTarget(tt),J.updateRenderTargetMipmap(tt)),H&&S.end(C),M.isScene===!0&&M.onAfterRender(C,M,N),gt.resetDefaultState(),$=-1,et=null,x.pop(),x.length>0?(w=x[x.length-1],J.setTextureUnits(w.state.textureUnits),Jt===!0&&Rt.setGlobalState(C.clippingPlanes,w.state.camera)):w=null,R.pop(),R.length>0?E=R[R.length-1]:E=null,D!==null&&D.renderEnd()};function Gr(M,N,K,H){if(M.visible===!1)return;if(M.layers.test(N.layers)){if(M.isGroup)K=M.renderOrder;else if(M.isLOD)M.autoUpdate===!0&&M.update(N);else if(M.isLightProbeGrid)w.pushLightProbeGrid(M);else if(M.isLight)w.pushLight(M),M.castShadow&&w.pushShadow(M);else if(M.isSprite){if(!M.frustumCulled||M.intersectsFrustum(Ht)){H&&Ee.setFromMatrixPosition(M.matrixWorld).applyMatrix4(Wt);const Mt=it.update(M),pt=M.material;pt.visible&&E.push(M,Mt,pt,K,Ee.z,null,N)}}else if((M.isMesh||M.isLine||M.isPoints)&&(!M.frustumCulled||M.intersectsFrustum(Ht))){const Mt=it.update(M),pt=M.material;if(H&&(M.boundingSphere!==void 0?(M.boundingSphere===null&&M.computeBoundingSphere(),Ee.copy(M.boundingSphere.center)):(Mt.boundingSphere===null&&Mt.computeBoundingSphere(),Ee.copy(Mt.boundingSphere.center)),Ee.applyMatrix4(M.matrixWorld).applyMatrix4(Wt)),Array.isArray(pt)){const bt=Mt.groups;for(let Et=0,Ot=bt.length;Et<Ot;Et++){const Vt=bt[Et],St=pt[Vt.materialIndex];St&&St.visible&&E.push(M,Mt,St,K,Ee.z,Vt,N)}}else pt.visible&&E.push(M,Mt,pt,K,Ee.z,null,N)}}const mt=M.children;for(let Mt=0,pt=mt.length;Mt<pt;Mt++)Gr(mt[Mt],N,K,H)}function jo(M,N,K,H){const{opaque:V,transmissive:mt,transparent:Mt}=M;w.setupLightsView(K),Jt===!0&&Rt.setGlobalState(C.clippingPlanes,K),H&&g.viewport(Z.copy(H)),V.length>0&&Ds(V,N,K),mt.length>0&&Ds(mt,N,K),Mt.length>0&&Ds(Mt,N,K),g.buffers.depth.setTest(!0),g.buffers.depth.setMask(!0),g.buffers.color.setMask(!0),g.setPolygonOffset(!1)}function tl(M,N,K,H){if((K.isScene===!0?K.overrideMaterial:null)!==null)return;if(w.state.transmissionRenderTarget[H.id]===void 0){const St=ne.has("EXT_color_buffer_half_float")||ne.has("EXT_color_buffer_float");w.state.transmissionRenderTarget[H.id]=new gn(1,1,{generateMipmaps:!0,type:St?Ln:Ze,minFilter:_i,samples:Math.max(4,A.samples),stencilBuffer:r,resolveDepthBuffer:!1,resolveStencilBuffer:!1,storeMultisampledDepthBuffer:!1,storeMultisampledStencilBuffer:!1,colorSpace:Xt.workingColorSpace})}const mt=w.state.transmissionRenderTarget[H.id],Mt=H.viewport||Z;mt.setSize(Mt.z*C.transmissionResolutionScale,Mt.w*C.transmissionResolutionScale);const pt=C.getRenderTarget(),bt=C.getActiveCubeFace(),Et=C.getActiveMipmapLevel();C.setRenderTarget(mt),C.getClearColor(se),Yt=C.getClearAlpha(),Yt<1&&C.setClearColor(16777215,.5),C.clear(),ge&&kt.render(K);const Ot=C.toneMapping;C.toneMapping=An;const Vt=H.viewport;if(H.viewport!==void 0&&(H.viewport=void 0),w.setupLightsView(H),Jt===!0&&Rt.setGlobalState(C.clippingPlanes,H),Ds(M,K,H),J.updateMultisampleRenderTarget(mt),J.updateRenderTargetMipmap(mt),ne.has("WEBGL_multisampled_render_to_texture")===!1){let St=!1;for(let te=0,Me=N.length;te<Me;te++){const ue=N[te],{object:oe,geometry:Le,material:xt,group:Ne}=ue;if(xt.side===wn&&oe.layers.test(H.layers)){const $t=xt.side;xt.side=Ve,xt.needsUpdate=!0,el(oe,K,H,Le,xt,Ne),xt.side=$t,xt.needsUpdate=!0,St=!0}}St===!0&&(J.updateMultisampleRenderTarget(mt),J.updateRenderTargetMipmap(mt))}C.setRenderTarget(pt,bt,Et),C.setClearColor(se,Yt),Vt!==void 0&&(H.viewport=Vt),C.toneMapping=Ot}function Ds(M,N,K){const H=N.isScene===!0?N.overrideMaterial:null;for(let V=0,mt=M.length;V<mt;V++){const Mt=M[V],{object:pt,geometry:bt,group:Et}=Mt;let Ot=Mt.material;Ot.allowOverride===!0&&H!==null&&(Ot=H),pt.layers.test(K.layers)&&el(pt,N,K,bt,Ot,Et)}}function el(M,N,K,H,V,mt){D!==null&&V.isNodeMaterial&&D.setObject(M,V),M.onBeforeRender(C,N,K,H,V,mt),M.modelViewMatrix.multiplyMatrices(K.matrixWorldInverse,M.matrixWorld),M.normalMatrix.getNormalMatrix(M.modelViewMatrix),V.onBeforeRender(C,N,K,H,M,mt),V.transparent===!0&&V.side===wn&&V.forceSinglePass===!1?(V.side=Ve,V.needsUpdate=!0,C.renderBufferDirect(K,N,H,V,M,mt),V.side=vi,V.needsUpdate=!0,C.renderBufferDirect(K,N,H,V,M,mt),V.side=wn):C.renderBufferDirect(K,N,H,V,M,mt),M.onAfterRender(C,N,K,H,V,mt)}function Is(M,N,K){N.isScene!==!0&&(N=ze);const H=q.get(M),V=w.state.lights,mt=w.state.shadowsArray,Mt=V.state.version,pt=lt.getParameters(M,V.state,mt,N,K,w.state.lightProbeGridArray),bt=lt.getProgramCacheKey(pt);let Et=H.programs;H.environment=M.isMeshStandardMaterial||M.isMeshLambertMaterial||M.isMeshPhongMaterial?N.environment:null,H.fog=N.fog;const Ot=M.isMeshStandardMaterial||M.isMeshLambertMaterial&&!M.envMap||M.isMeshPhongMaterial&&!M.envMap;H.envMap=at.get(M.envMap||H.environment,Ot),H.envMapRotation=H.environment!==null&&M.envMap===null?N.environmentRotation:M.envMapRotation,Et===void 0&&(M.addEventListener("dispose",xn),Et=new Map,H.programs=Et);let Vt=Et.get(bt);if(Vt!==void 0){if(H.currentProgram===Vt&&H.lightsStateVersion===Mt)return il(M,pt),Vt}else pt.uniforms=lt.getUniforms(M),D!==null&&M.isNodeMaterial&&D.build(M,K,pt),M.onBeforeCompile(pt,C),Vt=lt.acquireProgram(pt,bt),Et.set(bt,Vt),H.uniforms=pt.uniforms;const St=H.uniforms;return(!M.isShaderMaterial&&!M.isRawShaderMaterial||M.clipping===!0)&&(St.clippingPlanes=Rt.uniform),il(M,pt),H.needsLights=kh(M),H.lightsStateVersion=Mt,H.needsLights&&(St.ambientLightColor.value=V.state.ambient,St.lightProbe.value=V.state.probe,St.sunLights.value=V.state.sun,St.sunLightShadows.value=V.state.sunShadow,St.directionalLights.value=V.state.directional,St.directionalLightShadows.value=V.state.directionalShadow,St.spotLights.value=V.state.spot,St.spotLightShadows.value=V.state.spotShadow,St.rectAreaLights.value=V.state.rectArea,St.ltc_1.value=V.state.rectAreaLTC1,St.ltc_2.value=V.state.rectAreaLTC2,St.pointLights.value=V.state.point,St.pointLightShadows.value=V.state.pointShadow,St.hemisphereLights.value=V.state.hemi,St.sunShadowMatrix.value=V.state.sunShadowMatrix,St.sunShadowCascade.value=V.state.sunShadowCascade,St.directionalShadowMatrix.value=V.state.directionalShadowMatrix,St.spotLightMatrix.value=V.state.spotLightMatrix,St.spotLightMap.value=V.state.spotLightMap,St.pointShadowMatrix.value=V.state.pointShadowMatrix),H.lightProbeGrid=w.state.lightProbeGridArray.length>0,H.currentProgram=Vt,H.uniformsList=null,Vt}function nl(M){if(M.uniformsList===null){const N=M.currentProgram.getUniforms();M.uniformsList=mr.seqWithValue(N.seq,M.uniforms)}return M.uniformsList}function il(M,N){const K=q.get(M);K.outputColorSpace=N.outputColorSpace,K.batching=N.batching,K.batchingColor=N.batchingColor,K.instancing=N.instancing,K.instancingColor=N.instancingColor,K.instancingMorph=N.instancingMorph,K.skinning=N.skinning,K.morphTargets=N.morphTargets,K.morphNormals=N.morphNormals,K.morphColors=N.morphColors,K.morphTargetsCount=N.morphTargetsCount,K.numClippingPlanes=N.numClippingPlanes,K.numIntersection=N.numClipIntersection,K.vertexAlphas=N.vertexAlphas,K.vertexTangents=N.vertexTangents,K.toneMapping=N.toneMapping}function Uh(M,N){if(M.length===0)return null;if(M.length===1)return M[0].texture!==null?M[0]:null;y.setFromMatrixPosition(N.matrixWorld);for(let K=0,H=M.length;K<H;K++){const V=M[K];if(V.texture!==null&&V.boundingBox.containsPoint(y))return V}return null}function Nh(M,N,K,H,V){N.isScene!==!0&&(N=ze),J.resetTextureUnits();const mt=N.fog,Mt=H.isMeshStandardMaterial||H.isMeshLambertMaterial||H.isMeshPhongMaterial?N.environment:null,pt=tt===null?C.outputColorSpace:tt.isXRRenderTarget===!0?tt.texture.colorSpace:Xt.workingColorSpace,bt=H.isMeshStandardMaterial||H.isMeshLambertMaterial&&!H.envMap||H.isMeshPhongMaterial&&!H.envMap,Et=at.get(H.envMap||Mt,bt),Ot=H.vertexColors===!0&&!!K.attributes.color&&K.attributes.color.itemSize===4,Vt=!!K.attributes.tangent&&(!!H.normalMap||H.anisotropy>0),St=!!K.morphAttributes.position,te=!!K.morphAttributes.normal,Me=!!K.morphAttributes.color;let ue=An;H.toneMapped&&(tt===null||tt.isXRRenderTarget===!0)&&(ue=C.toneMapping);const oe=K.morphAttributes.position||K.morphAttributes.normal||K.morphAttributes.color,Le=oe!==void 0?oe.length:0,xt=q.get(H),Ne=w.state.lights;if(Jt===!0&&(ce===!0||M!==et)){const de=M===et&&H.id===$;Rt.setState(H,M,de)}let $t=!1;H.version===xt.__version?(xt.needsLights&&xt.lightsStateVersion!==Ne.state.version||xt.outputColorSpace!==pt||V.isBatchedMesh&&xt.batching===!1||!V.isBatchedMesh&&xt.batching===!0||V.isBatchedMesh&&xt.batchingColor===!0&&V._colorsTexture===null||V.isBatchedMesh&&xt.batchingColor===!1&&V._colorsTexture!==null||V.isInstancedMesh&&xt.instancing===!1||!V.isInstancedMesh&&xt.instancing===!0||V.isSkinnedMesh&&xt.skinning===!1||!V.isSkinnedMesh&&xt.skinning===!0||V.isInstancedMesh&&xt.instancingColor===!0&&V.instanceColor===null||V.isInstancedMesh&&xt.instancingColor===!1&&V.instanceColor!==null||V.isInstancedMesh&&xt.instancingMorph===!0&&V.morphTexture===null||V.isInstancedMesh&&xt.instancingMorph===!1&&V.morphTexture!==null||xt.envMap!==Et||H.fog===!0&&xt.fog!==mt||xt.numClippingPlanes!==void 0&&(xt.numClippingPlanes!==Rt.numPlanes||xt.numIntersection!==Rt.numIntersection)||xt.vertexAlphas!==Ot||xt.vertexTangents!==Vt||xt.morphTargets!==St||xt.morphNormals!==te||xt.morphColors!==Me||xt.toneMapping!==ue||xt.morphTargetsCount!==Le||!!xt.lightProbeGrid!=w.state.lightProbeGridArray.length>0)&&($t=!0):($t=!0,xt.__version=H.version);let Je=xt.currentProgram;$t===!0&&(Je=Is(H,N,V),D&&H.isNodeMaterial&&D.onUpdateProgram(H,Je,xt));let vn=!1,Xn=!1,Ei=!1;const re=Je.getUniforms(),xe=xt.uniforms;if(g.useProgram(Je.program)&&(vn=!0,Xn=!0,Ei=!0),H.id!==$&&($=H.id,Xn=!0),xt.needsLights){const de=Uh(w.state.lightProbeGridArray,V);xt.lightProbeGrid!==de&&(xt.lightProbeGrid=de,Xn=!0)}if(vn||et!==M){g.buffers.depth.getReversed()&&M.reversedDepth!==!0&&(M._reversedDepth=!0,M.updateProjectionMatrix()),re.setValue(B,"projectionMatrix",M.projectionMatrix),re.setValue(B,"viewMatrix",M.matrixWorldInverse);const Yn=re.map.cameraPosition;Yn!==void 0&&Yn.setValue(B,pe.setFromMatrixPosition(M.matrixWorld)),A.logarithmicDepthBuffer&&re.setValue(B,"logDepthBufFC",2/(Math.log(M.far+1)/Math.LN2)),(H.isMeshPhongMaterial||H.isMeshToonMaterial||H.isMeshLambertMaterial||H.isMeshBasicMaterial||H.isMeshStandardMaterial||H.isShaderMaterial)&&re.setValue(B,"isOrthographic",M.isOrthographicCamera===!0),et!==M&&(et=M,Xn=!0,Ei=!0)}if(xt.needsLights&&(Ne.state.sunShadowMap.length>0&&re.setValue(B,"sunShadowMap",Ne.state.sunShadowMap,J),Ne.state.directionalShadowMap.length>0&&re.setValue(B,"directionalShadowMap",Ne.state.directionalShadowMap,J),Ne.state.spotShadowMap.length>0&&re.setValue(B,"spotShadowMap",Ne.state.spotShadowMap,J),Ne.state.pointShadowMap.length>0&&re.setValue(B,"pointShadowMap",Ne.state.pointShadowMap,J)),V.isSkinnedMesh){re.setOptional(B,V,"bindMatrix"),re.setOptional(B,V,"bindMatrixInverse");const de=V.skeleton;de&&(de.boneTexture===null&&de.computeBoneTexture(),re.setValue(B,"boneTexture",de.boneTexture,J))}V.isBatchedMesh&&(re.setOptional(B,V,"batchingTexture"),re.setValue(B,"batchingTexture",V._matricesTexture,J),re.setOptional(B,V,"batchingIdTexture"),re.setValue(B,"batchingIdTexture",V._indirectTexture,J),re.setOptional(B,V,"batchingColorTexture"),V._colorsTexture!==null&&re.setValue(B,"batchingColorTexture",V._colorsTexture,J));const qn=K.morphAttributes;if((qn.position!==void 0||qn.normal!==void 0||qn.color!==void 0)&&k.update(V,K,Je),(Xn||xt.receiveShadow!==V.receiveShadow)&&(xt.receiveShadow=V.receiveShadow,re.setValue(B,"receiveShadow",V.receiveShadow)),(H.isMeshStandardMaterial||H.isMeshLambertMaterial||H.isMeshPhongMaterial)&&H.envMap===null&&N.environment!==null&&(xe.envMapIntensity.value=N.environmentIntensity),xe.dfgLUT!==void 0&&(xe.dfgLUT.value=n_()),Xn){if(re.setValue(B,"toneMappingExposure",C.toneMappingExposure),xt.needsLights&&Fh(xe,Ei),mt&&H.fog===!0&&Ct.refreshFogUniforms(xe,mt),Ct.refreshMaterialUniforms(xe,H,st,Q,w.state.transmissionRenderTarget[M.id]),xt.needsLights&&xt.lightProbeGrid){const de=xt.lightProbeGrid;xe.probesSH.value=de.texture,xe.probesMin.value.copy(de.boundingBox.min),xe.probesMax.value.copy(de.boundingBox.max),xe.probesResolution.value.copy(de.resolution)}mr.upload(B,nl(xt),xe,J)}if(H.isShaderMaterial&&H.uniformsNeedUpdate===!0&&(mr.upload(B,nl(xt),xe,J),H.uniformsNeedUpdate=!1),H.isSpriteMaterial&&re.setValue(B,"center",V.center),re.setValue(B,"modelViewMatrix",V.modelViewMatrix),re.setValue(B,"normalMatrix",V.normalMatrix),re.setValue(B,"modelMatrix",V.matrixWorld),H.uniformsGroups!==void 0){const de=H.uniformsGroups;for(let Yn=0,Ti=de.length;Yn<Ti;Yn++){const rl=de[Yn];rt.update(rl,Je),rt.bind(rl,Je)}}return Je}function Fh(M,N){M.ambientLightColor.needsUpdate=N,M.lightProbe.needsUpdate=N,M.sunLights.needsUpdate=N,M.sunLightShadows.needsUpdate=N,M.directionalLights.needsUpdate=N,M.directionalLightShadows.needsUpdate=N,M.pointLights.needsUpdate=N,M.pointLightShadows.needsUpdate=N,M.spotLights.needsUpdate=N,M.spotLightShadows.needsUpdate=N,M.rectAreaLights.needsUpdate=N,M.hemisphereLights.needsUpdate=N}function kh(M){return M.isMeshLambertMaterial||M.isMeshToonMaterial||M.isMeshPhongMaterial||M.isMeshStandardMaterial||M.isShadowMaterial||M.isShaderMaterial&&M.lights===!0}this.getActiveCubeFace=function(){return X},this.getActiveMipmapLevel=function(){return W},this.getRenderTarget=function(){return tt},this.setRenderTargetTextures=function(M,N,K){const H=q.get(M);H.__autoAllocateDepthBuffer=M.resolveDepthBuffer===!1,H.__autoAllocateDepthBuffer===!1&&(H.__useRenderToTexture=!1),q.get(M.texture).__webglTexture=N,q.get(M.depthTexture).__webglTexture=H.__autoAllocateDepthBuffer?void 0:K,H.__hasExternalTextures=!0},this.setRenderTargetFramebuffer=function(M,N){const K=q.get(M);K.__webglFramebuffer=N,K.__useDefaultFramebuffer=N===void 0},this.setRenderTarget=function(M,N=0,K=0){tt=M,X=N,W=K;let H=null,V=!1,mt=!1;if(M){const pt=q.get(M);if(pt.__useDefaultFramebuffer!==void 0){g.bindFramebuffer(B.FRAMEBUFFER,pt.__webglFramebuffer),Z.copy(M.viewport),_t.copy(M.scissor),Tt=M.scissorTest,g.viewport(Z),g.scissor(_t),g.setScissorTest(Tt),$=-1;return}else if(pt.__webglFramebuffer===void 0)J.setupRenderTarget(M);else if(pt.__hasExternalTextures)J.rebindTextures(M,q.get(M.texture).__webglTexture,q.get(M.depthTexture).__webglTexture);else if(M.depthBuffer){const Ot=M.depthTexture;if(pt.__boundDepthTexture!==Ot){if(Ot!==null&&q.has(Ot)&&(M.width!==Ot.image.width||M.height!==Ot.image.height))throw new Error("THREE.WebGLRenderer: Attached DepthTexture is initialized to the incorrect size.");J.setupDepthRenderbuffer(M)}}const bt=M.texture;(bt.isData3DTexture||bt.isDataArrayTexture||bt.isCompressedArrayTexture)&&(mt=!0);const Et=q.get(M).__webglFramebuffer;M.isWebGLCubeRenderTarget?(Array.isArray(Et[N])?H=Et[N][K]:H=Et[N],V=!0):M.samples>0&&J.useMultisampledRTT(M)===!1?H=q.get(M).__webglMultisampledFramebuffer:Array.isArray(Et)?H=Et[K]:H=Et,Z.copy(M.viewport),_t.copy(M.scissor),Tt=M.scissorTest}else Z.copy(vt).multiplyScalar(st).floor(),_t.copy(Gt).multiplyScalar(st).floor(),Tt=be;if(K!==0&&(H=z),g.bindFramebuffer(B.FRAMEBUFFER,H)&&g.drawBuffers(M,H),g.viewport(Z),g.scissor(_t),g.setScissorTest(Tt),V){const pt=q.get(M.texture);B.framebufferTexture2D(B.FRAMEBUFFER,B.COLOR_ATTACHMENT0,B.TEXTURE_CUBE_MAP_POSITIVE_X+N,pt.__webglTexture,K)}else if(mt){const pt=N;for(let bt=0;bt<M.textures.length;bt++){const Et=q.get(M.textures[bt]);B.framebufferTextureLayer(B.FRAMEBUFFER,B.COLOR_ATTACHMENT0+bt,Et.__webglTexture,K,pt)}}else if(M!==null&&K!==0){const pt=q.get(M.texture);B.framebufferTexture2D(B.FRAMEBUFFER,B.COLOR_ATTACHMENT0,B.TEXTURE_2D,pt.__webglTexture,K)}$=-1};function sl(M){const N=q.get(M);return(N.__readFormat!==M.format||N.__readType!==M.type)&&(N.__readFormat=M.format,N.__readType=M.type,N.__formatReadable=A.textureFormatReadable(M.format),N.__typeReadable=A.textureTypeReadable(M.type)),N}this.readRenderTargetPixels=function(M,N,K,H,V,mt,Mt,pt=0){if(!(M&&M.isWebGLRenderTarget)){Kt("WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");return}let bt=q.get(M).__webglFramebuffer;if(M.isWebGLCubeRenderTarget&&Mt!==void 0&&(bt=bt[Mt]),bt){g.bindFramebuffer(B.FRAMEBUFFER,bt);try{const Et=M.textures[pt],Ot=Et.format,Vt=Et.type;M.textures.length>1&&B.readBuffer(B.COLOR_ATTACHMENT0+pt);const St=sl(Et);if(St.__formatReadable===!1){Kt("WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");return}if(St.__typeReadable===!1){Kt("WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");return}N>=0&&N<=M.width-H&&K>=0&&K<=M.height-V&&B.readPixels(N,K,H,V,dt.convert(Ot),dt.convert(Vt),mt)}finally{const Et=tt!==null?q.get(tt).__webglFramebuffer:null;g.bindFramebuffer(B.FRAMEBUFFER,Et)}}},this.readRenderTargetPixelsAsync=async function(M,N,K,H,V,mt,Mt,pt=0){if(!(M&&M.isWebGLRenderTarget))throw new Error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");let bt=q.get(M).__webglFramebuffer;if(M.isWebGLCubeRenderTarget&&Mt!==void 0&&(bt=bt[Mt]),bt)if(N>=0&&N<=M.width-H&&K>=0&&K<=M.height-V){g.bindFramebuffer(B.FRAMEBUFFER,bt);const Et=M.textures[pt],Ot=Et.format,Vt=Et.type;M.textures.length>1&&B.readBuffer(B.COLOR_ATTACHMENT0+pt);const St=sl(Et);if(St.__formatReadable===!1)throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in RGBA or implementation defined format.");if(St.__typeReadable===!1)throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in UnsignedByteType or implementation defined type.");const te=B.createBuffer();B.bindBuffer(B.PIXEL_PACK_BUFFER,te),B.bufferData(B.PIXEL_PACK_BUFFER,mt.byteLength,B.STREAM_READ),B.readPixels(N,K,H,V,dt.convert(Ot),dt.convert(Vt),0),B.bindBuffer(B.PIXEL_PACK_BUFFER,null);const Me=tt!==null?q.get(tt).__webglFramebuffer:null;g.bindFramebuffer(B.FRAMEBUFFER,Me);const ue=B.fenceSync(B.SYNC_GPU_COMMANDS_COMPLETE,0);return B.flush(),await yu(B,ue,4),B.bindBuffer(B.PIXEL_PACK_BUFFER,te),B.getBufferSubData(B.PIXEL_PACK_BUFFER,0,mt),B.bindBuffer(B.PIXEL_PACK_BUFFER,null),B.deleteBuffer(te),B.deleteSync(ue),mt}else throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: requested read bounds are out of range.")},this.copyFramebufferToTexture=function(M,N=null,K=0){const H=Math.pow(2,-K),V=Math.floor(M.image.width*H),mt=Math.floor(M.image.height*H),Mt=N!==null?N.x:0,pt=N!==null?N.y:0;J.setTexture2D(M,0),B.copyTexSubImage2D(B.TEXTURE_2D,K,0,0,Mt,pt,V,mt),g.unbindTexture()},this.copyTextureToTexture=function(M,N,K=null,H=null,V=0,mt=0){let Mt,pt,bt,Et,Ot,Vt,St,te,Me;const ue=M.isCompressedTexture?M.mipmaps[mt]:M.image;if(K!==null)Mt=K.max.x-K.min.x,pt=K.max.y-K.min.y,bt=K.isBox3?K.max.z-K.min.z:1,Et=K.min.x,Ot=K.min.y,Vt=K.isBox3?K.min.z:0;else{const xe=Math.pow(2,-V);Mt=Math.floor(ue.width*xe),pt=Math.floor(ue.height*xe),M.isDataArrayTexture?bt=ue.depth:M.isData3DTexture?bt=Math.floor(ue.depth*xe):bt=1,Et=0,Ot=0,Vt=0}H!==null?(St=H.x,te=H.y,Me=H.z):(St=0,te=0,Me=0);const oe=dt.convert(N.format),Le=dt.convert(N.type);let xt;N.isData3DTexture?(J.setTexture3D(N,0),xt=B.TEXTURE_3D):N.isDataArrayTexture||N.isCompressedArrayTexture?(J.setTexture2DArray(N,0),xt=B.TEXTURE_2D_ARRAY):(J.setTexture2D(N,0),xt=B.TEXTURE_2D),g.activeTexture(B.TEXTURE0),g.pixelStorei(B.UNPACK_FLIP_Y_WEBGL,N.flipY),g.pixelStorei(B.UNPACK_PREMULTIPLY_ALPHA_WEBGL,N.premultiplyAlpha),g.pixelStorei(B.UNPACK_ALIGNMENT,N.unpackAlignment);const Ne=g.getParameter(B.UNPACK_ROW_LENGTH),$t=g.getParameter(B.UNPACK_IMAGE_HEIGHT),Je=g.getParameter(B.UNPACK_SKIP_PIXELS),vn=g.getParameter(B.UNPACK_SKIP_ROWS),Xn=g.getParameter(B.UNPACK_SKIP_IMAGES);g.pixelStorei(B.UNPACK_ROW_LENGTH,ue.width),g.pixelStorei(B.UNPACK_IMAGE_HEIGHT,ue.height),g.pixelStorei(B.UNPACK_SKIP_PIXELS,Et),g.pixelStorei(B.UNPACK_SKIP_ROWS,Ot),g.pixelStorei(B.UNPACK_SKIP_IMAGES,Vt);const Ei=M.isDataArrayTexture||M.isData3DTexture,re=N.isDataArrayTexture||N.isData3DTexture;if(M.isDepthTexture){const xe=q.get(M),qn=q.get(N),de=q.get(xe.__renderTarget),Yn=q.get(qn.__renderTarget);g.bindFramebuffer(B.READ_FRAMEBUFFER,de.__webglFramebuffer),g.bindFramebuffer(B.DRAW_FRAMEBUFFER,Yn.__webglFramebuffer);for(let Ti=0;Ti<bt;Ti++)Ei&&(B.framebufferTextureLayer(B.READ_FRAMEBUFFER,B.COLOR_ATTACHMENT0,q.get(M).__webglTexture,V,Vt+Ti),B.framebufferTextureLayer(B.DRAW_FRAMEBUFFER,B.COLOR_ATTACHMENT0,q.get(N).__webglTexture,mt,Me+Ti)),B.blitFramebuffer(Et,Ot,Mt,pt,St,te,Mt,pt,B.DEPTH_BUFFER_BIT,B.NEAREST);g.bindFramebuffer(B.READ_FRAMEBUFFER,null),g.bindFramebuffer(B.DRAW_FRAMEBUFFER,null)}else if(V!==0||M.isRenderTargetTexture||q.has(M)){const xe=q.get(M),qn=q.get(N);g.bindFramebuffer(B.READ_FRAMEBUFFER,L),g.bindFramebuffer(B.DRAW_FRAMEBUFFER,F);for(let de=0;de<bt;de++)Ei?B.framebufferTextureLayer(B.READ_FRAMEBUFFER,B.COLOR_ATTACHMENT0,xe.__webglTexture,V,Vt+de):B.framebufferTexture2D(B.READ_FRAMEBUFFER,B.COLOR_ATTACHMENT0,B.TEXTURE_2D,xe.__webglTexture,V),re?B.framebufferTextureLayer(B.DRAW_FRAMEBUFFER,B.COLOR_ATTACHMENT0,qn.__webglTexture,mt,Me+de):B.framebufferTexture2D(B.DRAW_FRAMEBUFFER,B.COLOR_ATTACHMENT0,B.TEXTURE_2D,qn.__webglTexture,mt),V!==0?B.blitFramebuffer(Et,Ot,Mt,pt,St,te,Mt,pt,B.COLOR_BUFFER_BIT,B.NEAREST):re?B.copyTexSubImage3D(xt,mt,St,te,Me+de,Et,Ot,Mt,pt):B.copyTexSubImage2D(xt,mt,St,te,Et,Ot,Mt,pt);g.bindFramebuffer(B.READ_FRAMEBUFFER,null),g.bindFramebuffer(B.DRAW_FRAMEBUFFER,null)}else re?M.isDataTexture||M.isData3DTexture?B.texSubImage3D(xt,mt,St,te,Me,Mt,pt,bt,oe,Le,ue.data):N.isCompressedArrayTexture?B.compressedTexSubImage3D(xt,mt,St,te,Me,Mt,pt,bt,oe,ue.data):B.texSubImage3D(xt,mt,St,te,Me,Mt,pt,bt,oe,Le,ue):M.isDataTexture?B.texSubImage2D(B.TEXTURE_2D,mt,St,te,Mt,pt,oe,Le,ue.data):M.isCompressedTexture?B.compressedTexSubImage2D(B.TEXTURE_2D,mt,St,te,ue.width,ue.height,oe,ue.data):B.texSubImage2D(B.TEXTURE_2D,mt,St,te,Mt,pt,oe,Le,ue);g.pixelStorei(B.UNPACK_ROW_LENGTH,Ne),g.pixelStorei(B.UNPACK_IMAGE_HEIGHT,$t),g.pixelStorei(B.UNPACK_SKIP_PIXELS,Je),g.pixelStorei(B.UNPACK_SKIP_ROWS,vn),g.pixelStorei(B.UNPACK_SKIP_IMAGES,Xn),mt===0&&N.generateMipmaps&&B.generateMipmap(xt),g.unbindTexture()},this.initRenderTarget=function(M){q.get(M).__webglFramebuffer===void 0&&J.setupRenderTarget(M)},this.initTexture=function(M){M.isCubeTexture?J.setTextureCube(M,0):M.isData3DTexture?J.setTexture3D(M,0):M.isDataArrayTexture||M.isCompressedArrayTexture?J.setTexture2DArray(M,0):J.setTexture2D(M,0),g.unbindTexture()},this.resetState=function(){X=0,W=0,tt=null,g.reset(),gt.reset()},typeof __THREE_DEVTOOLS__!="undefined"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return Tn}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(t){this._outputColorSpace=t;const e=this.getContext();e.drawingBufferColorSpace=Xt._getDrawingBufferColorSpace(t),e.unpackColorSpace=Xt._getUnpackColorSpace()}}const Gi=new O,je={x:0,y:0,behind:!1};function i_(s,t){var a,o,l,c,h,u,d,f,_,v,p,m;const e=[],n=s.stats,i=t==null?void 0:t.stats;if(n.income&&e.push({s:Y("stat.income",{n:n.income}),up:n.income>((a=i==null?void 0:i.income)!=null?a:0)}),n.attack){const b=n.attack,T=i==null?void 0:i.attack;e.push({s:Y("stat.dmg",{n:Math.round(b.damage)}),up:!!T&&b.damage>T.damage}),e.push({s:Y("stat.rate",{n:(1/b.cooldown).toFixed(1)}),up:!!T&&b.cooldown<T.cooldown}),((o=b.multishot)!=null?o:1)>1&&e.push({s:Y("stat.multi",{n:b.multishot}),up:((l=b.multishot)!=null?l:1)>((c=T==null?void 0:T.multishot)!=null?c:1)}),b.splash&&e.push({s:Y("stat.splash"),up:!(T!=null&&T.splash)}),b.slow&&e.push({s:Y("stat.slow"),up:!(T!=null&&T.slow)}),b.burn&&e.push({s:Y("stat.burn"),up:!(T!=null&&T.burn)}),b.pierce&&e.push({s:Y("stat.pierce",{n:b.pierce}),up:!(T!=null&&T.pierce)}),T&&b.range>T.range&&e.push({s:Y("stat.range",{n:b.range.toFixed(1)}),up:!0})}n.troops&&e.push({s:Y("stat.troops",{n:n.troops.count}),up:n.troops.count>((u=(h=i==null?void 0:i.troops)==null?void 0:h.count)!=null?u:0)});const r=Math.round((((d=n.buffTroops)!=null?d:0)+((f=n.buffTowers)!=null?f:0)+((_=n.buffHero)!=null?_:0))/3*100);return s.kind==="forge"&&e.push({s:Y("stat.buff",{n:r}),up:!!i}),n.hpTroops&&e.push({s:Y("stat.hpTroops",{n:Math.round(n.hpTroops*100)}),up:n.hpTroops>((v=i==null?void 0:i.hpTroops)!=null?v:0)}),n.thorns&&e.push({s:Y("stat.thorns",{n:n.thorns}),up:n.thorns>((p=i==null?void 0:i.thorns)!=null?p:0)}),n.troopBurn&&e.push({s:Y("stat.burn"),up:!0}),n.cleanBonus&&e.push({s:Y("stat.clean",{n:n.cleanBonus}),up:n.cleanBonus>((m=i==null?void 0:i.cleanBonus)!=null?m:0)}),e.push({s:Y("stat.hp",{n:n.hp}),up:!!i&&n.hp>i.hp}),e}function gr(s){return fe(Tc(s.id))}function s_(s){return fe(Tc(s.id)+".d")}class r_{constructor(t,e,n,i,r){this.g=e,this.stage=n,this.icons=i,this.cb=r,this.labels=new Map,this.waveEls=[],this.choiceEl=null,this.lastCoins=-1,this.lastNightTxt="",this.wavePlanNight=-1,this.coinsAdUsed=!1,this.respawnAdUsed=!1,this.touch=!1,this.bigHold=!1,this.root=U("div",{class:"layer",id:"hud"}),this.labelLayer=U("div",{class:"layer"}),this.waveLayer=U("div",{class:"layer"}),this.coinsNum=U("span",null,"0"),this.coinsEl=U("div",{class:"pill coins"},It("coin"),this.coinsNum),this.nightIcon=It("sun"),this.nightTxt=U("span",null,""),this.nightEl=U("div",{class:"pill night"},this.nightIcon,this.nightTxt);const a=U("div",{class:"hud-tl"},this.coinsEl,this.nightEl),o=U("button",{class:"btn round","aria-label":"pause",onclick:()=>r.pause()},It("pause")),l=U("div",{class:"hud-tr"},o);this.startBtn=U("button",{class:"btn night-btn",onclick:()=>r.startNight()},It("moon"),Y("hud.startNight")),this.adBtn=U("button",{class:"btn gold small",onclick:()=>r.coinsAd()},U("span",{class:"ad"},It("video")),It("coin"),Y("hud.coinsAd",{n:me.rewardCoins}));const c=U("div",{class:"hud-bc"},this.adBtn,this.startBtn);this.buildCost=U("span",{class:"cost"}),this.buildBtn=U("button",{class:"act big","aria-label":"build"},It("hammer"),this.buildCost);const h=f=>_=>{_.preventDefault(),this.bigHold=f,r.holdButton(f),this.buildBtn.classList.toggle("pressed",f)};this.buildBtn.addEventListener("pointerdown",f=>{try{this.buildBtn.setPointerCapture(f.pointerId)}catch{}h(!0)(f)}),this.buildBtn.addEventListener("pointerup",h(!1)),this.buildBtn.addEventListener("pointercancel",h(!1)),this.buildBtn.addEventListener("lostpointercapture",h(!1)),this.abilityCd=U("div",{class:"cd"});const u=e.hero.weapon.id==="bow"?"bow":e.hero.weapon.id==="spear"?"spear":e.hero.weapon.id==="staff"?"staff":"sword";this.abilityBtn=U("button",{class:"act","aria-label":"ability",onpointerdown:f=>{f.preventDefault(),r.ability()}},It(u),this.abilityCd,U("span",{class:"key"},"Q")),this.rallyBtn=U("button",{class:"act small","aria-label":"rally",onpointerdown:f=>{f.preventDefault(),r.rally()}},It("people"),U("span",{class:"key"},"R"));const d=U("div",{class:"hud-br"},this.rallyBtn,U("div"),this.abilityBtn,this.buildBtn);this.toasts=U("div",{class:"toasts"}),this.hintEl=U("div",{class:"hint hidden"}),this.bossName=U("div"),this.bossFill=U("div",{class:"fill"}),this.bossEl=U("div",{class:"bossbar hidden"},this.bossName,U("div",{class:"bar"},this.bossFill)),this.respawnTxt=U("div",{class:"t"}),this.respawnBtn=U("button",{class:"btn gold",onclick:()=>r.respawnAd()},U("span",{class:"ad"},It("video")),Y("hud.respawnAd")),this.respawnEl=U("div",{class:"respawn hidden"},this.respawnTxt,this.respawnBtn),this.root.append(this.waveLayer,this.labelLayer,a,l,this.bossEl,this.hintEl,this.toasts,this.respawnEl,c,d);for(const f of[a,this.labelLayer,this.waveLayer,this.toasts,this.hintEl,this.bossEl])f.style.pointerEvents="none";t.appendChild(this.root)}setTouch(t){this.touch=t,this.root.querySelectorAll(".act .key").forEach(e=>e.style.display=t?"none":"")}get holding(){return this.bigHold}toast(t,e=""){const n=U("div",{class:`toast ${e}`},t);for(this.toasts.appendChild(n),setTimeout(()=>n.remove(),2300);this.toasts.children.length>4;)this.toasts.firstChild.remove()}banner(t,e=""){this.root.querySelectorAll(".banner").forEach(i=>i.remove());const n=U("div",{class:"banner"},U("div",{class:"big"},t),e?U("div",{class:"sub"},e):null);this.root.appendChild(n),setTimeout(()=>n.remove(),2700)}floatText(t,e,n,i){if(Gi.set(t,e,n),this.stage.project(Gi,je),je.behind)return;const r=U("div",{class:"float-text",style:{left:`${je.x}px`,top:`${je.y}px`}},i);this.labelLayer.appendChild(r),setTimeout(()=>r.remove(),1700)}hint(t){if(!t){this.hintEl.classList.add("hidden");return}(this.hintEl.textContent!==t||this.hintEl.classList.contains("hidden"))&&(this.hintEl.textContent=t,this.hintEl.classList.remove("hidden"))}showChoice(t,e){this.hideChoice();const n=e.map((i,r)=>U("div",{class:"card",onclick:()=>this.cb.choose(r)},U("span",{class:"key"},this.touch?"":String(r+1)),U("div",{class:"img"},U("img",{src:this.icons.building(i),alt:""})),U("div",{class:"t"},gr(i)),U("div",{class:"d"},s_(i)),U("div",{class:"stats"},i_(i,t.node).map(a=>U("span",{class:a.up?"up":""},a.s)))));this.choiceEl=U("div",{class:"screen dim"},U("div",{class:"panel",style:{maxWidth:"680px"}},U("h2",null,Y("choice.title")),U("div",{class:"sub"},Y("choice.sub")),U("div",{class:"scroll"},U("div",{class:"choice"},n)))),this.root.appendChild(this.choiceEl)}hideChoice(){var t;(t=this.choiceEl)==null||t.remove(),this.choiceEl=null}get choiceOpen(){return!!this.choiceEl}update(){const t=this.g,e=t.coins;e!==this.lastCoins&&(this.lastCoins>=0&&e>this.lastCoins&&(this.coinsEl.classList.remove("bump"),this.coinsEl.offsetWidth,this.coinsEl.classList.add("bump")),this.lastCoins=e,this.coinsNum.textContent=String(e));const n=t.phase==="night";let i=t.cfg.endless?Y("hud.nightEndless",{n:t.night}):Y("hud.night",{n:t.night,m:t.map.nights});n&&t.enemiesAlive>0&&(i+=` · ${t.enemiesAlive}`),i!==this.lastNightTxt&&(this.lastNightTxt=i,this.nightTxt.textContent=i,this.nightIcon.innerHTML=It(n?"moon":"sun").innerHTML);const r=t.phase==="day";this.startBtn.classList.toggle("hidden",!r||this.choiceOpen),this.adBtn.classList.toggle("hidden",!r||this.coinsAdUsed||this.choiceOpen);const a=t.activeSlot(),o=a?t.actionFor(a):null;this.buildBtn.classList.toggle("hidden",!this.touch||!o),o&&(this.buildCost.replaceChildren(It("coin"),String(o.cost)),this.buildBtn.classList.toggle("off",o.cost>t.coins));const l=t.hero,c=l.abilityCd>0?l.abilityCd/(l.weapon.abilityCd*t.mods.abilityCd):0;this.abilityCd.style.background=c>0?`conic-gradient(rgba(20,10,30,.6) ${c*360}deg, transparent 0)`:"none",this.abilityBtn.classList.toggle("cooling",c>0),this.abilityBtn.classList.toggle("ready",c===0&&n&&l.alive);const h=t.units.some(f=>f.team===0&&f.alive);this.rallyBtn.classList.toggle("hidden",!h),this.rallyBtn.classList.toggle("on",t.rallyFollow);const u=!l.alive;this.respawnEl.classList.toggle("hidden",!u),u&&(this.respawnTxt.textContent=Y("hud.respawnIn",{n:Math.ceil(l.deadT)}),this.respawnBtn.classList.toggle("hidden",this.respawnAdUsed||l.deadT<1.5));const d=t.bossUnit;this.bossEl.classList.toggle("hidden",!d||!d.alive),d&&d.alive&&(this.bossName.textContent=fe(`unit.${d.def.id}`),this.bossFill.style.width=`${d.hp/d.maxHp*100}%`),this.updateLabels(a),this.updateWaves()}makeLabel(){const t=U("span"),e=U("span",{class:"tag"},It("coin"),t),n=U("div",{class:"name"}),i="http://www.w3.org/2000/svg",r=document.createElementNS(i,"svg");r.setAttribute("viewBox","0 0 64 64");const a=document.createElementNS(i,"circle");a.setAttribute("cx","32"),a.setAttribute("cy","32"),a.setAttribute("r","27"),a.setAttribute("fill","rgba(30,20,50,.35)"),a.setAttribute("stroke","rgba(255,255,255,.55)"),a.setAttribute("stroke-width","6");const o=document.createElementNS(i,"circle");o.setAttribute("cx","32"),o.setAttribute("cy","32"),o.setAttribute("r","27"),o.setAttribute("fill","none"),o.setAttribute("stroke","#ffd34d"),o.setAttribute("stroke-width","6"),o.setAttribute("stroke-linecap","round"),o.setAttribute("stroke-dasharray",`${2*Math.PI*27}`),r.append(a,o);const l=U("span",{class:"kh"}),c=U("div",{class:"ring"},r,l),h=U("div",{class:"slot-label"},n,e,c);return this.labelLayer.appendChild(h),{el:h,tag:e,num:t,name:n,ring:c,arc:o,kh:l,state:""}}updateLabels(t){const e=this.g,n=e.phase==="day"&&!this.choiceOpen;for(const i of e.buildings){const r=n?e.actionFor(i):null,a=i===t&&!!r,o=Math.hypot(i.x-e.hero.x,i.z-e.hero.z)<20,l=!!r&&(a||!i.node&&o);let c=this.labels.get(i);if(!l){c&&c.state!=="hide"&&(c.el.style.display="none",c.state="hide");continue}c||(c=this.makeLabel(),this.labels.set(i,c));const h=i.node?i.kind==="castle"?8.6:i.kind==="wall"?2.8:4.6:.6;if(Gi.set(i.x,e.heightAt(i.x,i.z)+h,i.z),this.stage.project(Gi,je),je.behind){c.el.style.display="none",c.state="hide";continue}const u=a?"active":"far";c.state!==u&&(c.el.style.display="",c.el.classList.toggle("far",!a),c.ring.style.display=a&&!this.touch?"":"none",c.name.style.display=a?"":"none",c.state=u),c.el.style.transform=`translate(${je.x}px, ${je.y}px) translate(-50%, -100%)`,c.el.style.left="0",c.el.style.top="0";const d=r.cost;if(c.num.textContent!==String(d)&&(c.num.textContent=String(d)),c.tag.classList.toggle("poor",d>e.coins),a){const f=i.node?`${gr(i.node)} → ${Y("hud.upgrade")}`:gr(gi[i.kind]);c.name.textContent!==f&&(c.name.textContent=f);const _=e.hold&&e.hold.b===i?e.hold.t/e.hold.need:0,v=2*Math.PI*27;c.arc.setAttribute("stroke-dashoffset",String(v*(1-_)));const p=this.touch?"":Pc()==="ru"?"Пробел":"Space";c.kh.textContent!==p&&(c.kh.textContent=p)}}}updateWaves(){const t=this.g;if(!(t.phase==="day"&&!this.choiceOpen)){for(const a of this.waveEls)a.style.display="none";return}if(this.wavePlanNight!==t.plan.night){this.wavePlanNight=t.plan.night,this.waveLayer.replaceChildren(),this.waveEls=[];for(const a of t.plan.paths){const o=t.plan.preview.get(a);if(!o)continue;const l=[...o.entries()].sort((h,u)=>u[1]-h[1]).slice(0,3),c=U("div",{class:"wave-ind"},U("div",{class:"arrow"}),l.map(([h,u])=>[U("img",{src:this.icons.unit(h),alt:""}),U("span",{class:"cnt"},`×${u}`)]).flat());c.dataset.path=String(a),this.waveLayer.appendChild(c),this.waveEls.push(c)}}const n=window.innerWidth,i=window.innerHeight,r=70;for(const a of this.waveEls){const o=Number(a.dataset.path),l=t.paths[o],c=l.sample(Math.min(6,l.length*.15),{x:0,z:0,tx:0,tz:0});Gi.set(c.x,t.heightAt(c.x,c.z)+1.5,c.z),this.stage.project(Gi,je);let h=je.x,u=je.y;const d=n/2,f=i/2;je.behind&&(h=d+(d-h)*10,u=f+(f-u)*10);const _=h<r||h>n-r||u<r+40||u>i-r-60,v=a.firstChild;if(_){const p=h-d,m=u-f,b=p!==0?(n/2-r)/Math.abs(p):1/0,T=m!==0?(i/2-r-50)/Math.abs(m):1/0,y=Math.min(b,T,1);h=d+p*y,u=f+m*y;const E=Math.atan2(m,p);v.style.display="",v.style.transform=`rotate(${E}rad) translate(46px)`}else v.style.display="none";a.style.display="",a.style.left=`${h}px`,a.style.top=`${u}px`}}dispose(){this.root.remove(),this.labels.clear()}}const a_={sword:"sword",bow:"bow",spear:"spear",staff:"staff"};class o_{constructor(t,e){this.host=e,this.current=null,this.modal=null,this.root=U("div",{class:"layer",id:"screens"}),t.appendChild(this.root)}get save(){return this.host.save.data}set(t){var e;(e=this.current)==null||e.remove(),this.current=t,t&&this.root.appendChild(t)}clear(){this.set(null),this.closeModal()}get open(){return!!this.current||!!this.modal}btn(t,e,n){return U("button",{class:`btn ${e}`,onclick:()=>{this.host.click(),n()}},...Array.isArray(t)?t:[t])}head(t,e){return U("div",{class:"panel-head"},U("button",{class:"btn ghost round","aria-label":Y("back"),onclick:()=>{this.host.click(),e()}},It("back")),U("h2",null,t),U("div",{class:"spacer"}))}showMenu(){const t=this.save,e=Xi(t.glory),n=Ta(e),i=Ta(e+1),r=Math.min(1,(t.glory-n)/Math.max(1,i-n)),a=t.run,o=[];a?(o.push(this.btn([It("play"),U("span",null,Y("menu.continue"),U("div",{class:"cont-info"},Y("menu.continueInfo",{map:fe(`map.${a.map}`),n:a.night})))],"gold play",()=>this.host.continueRun())),o.push(this.btn([It("flag"),Y("menu.newRun")],"small",()=>this.confirm(Y("menu.newRunConfirm"),()=>this.showMaps())))):o.push(this.btn([It("play"),Y("menu.play")],"gold play",()=>this.quickPlay()));const l=U("div",{class:"grid2"},this.btn([It("map"),Y("menu.maps")],"",()=>this.showMaps()),this.btn([It("sword"),Y("menu.armory")],"",()=>this.showArmory(()=>this.showMenu())),this.btn([It("skull"),Y("menu.mutators")],"violet",()=>this.showMutators(()=>this.showMenu())),this.btn([It("star"),Y("menu.achievements")],"violet",()=>this.showAchievements()),this.btn([It("trophy"),Y("menu.leaders")],"green",()=>this.showLeaders()),this.btn([It("gear"),Y("menu.settings")],"ghost",()=>this.showSettings(()=>this.showMenu()))),h=Y("title").split(" "),u=U("div",{class:"logo"},U("span",{class:"l1"},h[0]),U("span",{class:"l2"},h.slice(1).join(" ")),U("span",{class:"tag"},Y("subtitle"))),d=U("div",{class:"ruler"},It("crown"),U("span",null,Y("ruler.level",{n:e})),U("div",{class:"xp"},U("div",{style:{width:`${r*100}%`}})));this.set(U("div",{class:"menu"},U("div",{class:"side"},u,d,...o,l)))}quickPlay(){let t="valley";for(const e of Hn)if(Sr(this.save,e)&&(t=e,!this.save.maps[e].won))break;this.host.startRun(t,!1)}showMaps(){const t=this.save,e=Hn.map(a=>{const o=Dc[a],l=Sr(t,a),c=t.maps[a];return U("div",{class:`card ${l?"":"locked"}`},c.won?U("span",{class:"badge done"},It("check"),Y("map.won")):null,U("div",{class:"t"},fe(`map.${a}`)),U("div",{class:"d"},fe(`map.${a}.d`)),U("div",{class:"stats"},U("span",null,Y("map.nights",{n:o.nights})),c.best?U("span",null,Y("map.best",{n:c.best})):null,c.endlessBest?U("span",null,Y("map.endlessBest",{n:c.endlessBest})):null),l?U("div",{class:"row",style:{marginTop:"auto"}},this.btn([It("flag"),Y("map.start")],"gold small",()=>this.host.startRun(a,!1)),c.won?this.btn([It("moon"),Y("map.endless")],"violet small",()=>this.host.startRun(a,!0)):null):U("div",{class:"d"},It("lock")," ",Y("map.locked")),l&&!c.won?U("div",{class:"d",style:{fontSize:"12px"}},It("moon")," ",Y("map.endlessLocked")):null)}),n=t.perks.length?t.perks.map(a=>fe(`perk.${a}`)).join(", "):Y("map.none"),i=t.mutators.length?`×${vr(t.mutators)}`:Y("map.none"),r=U("div",{class:"item"},It(a_[t.weapon],"big"),U("div",{class:"grow"},U("div",{class:"d"},Y("map.loadout",{w:fe(`weapon.${t.weapon}`),p:n,m:i}))),this.btn([It("gear")],"small ghost",()=>this.showArmory(()=>this.showMaps())));this.set(U("div",{class:"screen dim"},U("div",{class:"panel"},this.head(Y("map.title"),()=>this.showMenu()),U("div",{class:"scroll"},U("div",{class:"cards"},e)),r)))}showArmory(t){const e=this.save,n=Xi(e.glory),i=xs.map(o=>{const l=Mr[o],c=n<l.unlockLevel;return U("div",{class:`card ${e.weapon===o?"sel":""} ${c?"locked":""}`,onclick:()=>{c||(this.host.click(),this.host.save.change(h=>{h.weapon=o}),this.showArmory(t))}},c?U("span",{class:"badge"},It("lock"),Y("armory.level",{n:l.unlockLevel})):e.weapon===o?U("span",{class:"badge done"},It("check")):null,U("div",{class:"img"},U("img",{src:this.host.icons.weapon(o),alt:""})),U("div",{class:"t"},fe(`weapon.${o}`)),U("div",{class:"d"},fe(`weapon.${o}.d`)),U("div",{class:"d"},U("b",null,fe(`ability.${l.ability}`))," — ",fe(`ability.${l.ability}.d`)))}),r=Xh(n),a=bo.map(o=>{const l=n<o.unlockLevel,c=e.perks.includes(o.id),h=U("button",{class:`toggle ${c?"on":""}`,"aria-label":fe(`perk.${o.id}`)});return U("div",{class:`item ${l?"locked":""}`,onclick:()=>{l||(this.host.click(),this.host.save.change(d=>{if(d.perks.includes(o.id))d.perks=d.perks.filter(f=>f!==o.id);else for(d.perks.push(o.id);d.perks.length>r;)d.perks.shift()}),this.showArmory(t))}},It(l?"lock":"star","big"),U("div",{class:"grow"},U("div",{class:"t"},fe(`perk.${o.id}`)),U("div",{class:"d"},l?Y("armory.level",{n:o.unlockLevel}):fe(`perk.${o.id}.d`))),l?null:h)});this.set(U("div",{class:"screen dim"},U("div",{class:"panel"},this.head(Y("armory.title"),t),U("div",{class:"scroll"},U("div",{class:"t",style:{margin:"2px 0 8px",fontSize:"18px"}},Y("armory.weapons")),U("div",{class:"cards"},i),U("div",{class:"t",style:{margin:"16px 0 8px",fontSize:"18px"}},`${Y("armory.perks")} · ${Y("armory.slots",{n:e.perks.length,m:r})}`),U("div",{class:"list"},a)))))}showMutators(t){const e=this.save,i=Xi(e.glory)<xr,r=So.map(a=>{const o=e.mutators.includes(a.id);return U("div",{class:`item ${i?"locked":""}`,onclick:()=>{i||(this.host.click(),this.host.save.change(l=>{l.mutators=o?l.mutators.filter(c=>c!==a.id):[...l.mutators,a.id]}),this.showMutators(t))}},It("skull","big"),U("div",{class:"grow"},U("div",{class:"t"},`${fe(`mut.${a.id}`)} ×${a.mult}`),U("div",{class:"d"},fe(`mut.${a.id}.d`))),i?null:U("button",{class:`toggle ${o?"on":""}`,"aria-label":fe(`mut.${a.id}`)}))});this.set(U("div",{class:"screen dim"},U("div",{class:"panel narrow",style:{maxWidth:"560px"}},this.head(Y("mut.title"),t),U("div",{class:"sub"},i?Y("mut.locked",{n:xr}):Y("mut.sub")),U("div",{class:"scroll"},U("div",{class:"list"},r)),U("div",{class:"sub",style:{marginTop:0,fontSize:"18px",color:"var(--ink)"}},Y("mut.mult",{n:vr(e.mutators)})))))}showAchievements(){const t=this.save,e=Ra.map(n=>{const i=t.ach.includes(n);return U("div",{class:`item ${i?"":"locked"}`},It(i?"trophy":"lock","big"),U("div",{class:"grow"},U("div",{class:"t"},fe(`ach.${n}`)),U("div",{class:"d"},fe(`ach.${n}.d`))))});this.set(U("div",{class:"screen dim"},U("div",{class:"panel",style:{maxWidth:"620px"}},this.head(Y("ach.title"),()=>this.showMenu()),U("div",{class:"sub"},Y("ach.count",{n:t.ach.length,m:Ra.length})),U("div",{class:"scroll"},U("div",{class:"list"},e)))))}showLeaders(){const t=U("div",{class:"list"},U("div",{class:"sub"},Y("lb.loading"))),e=U("div",{class:"panel narrow",style:{maxWidth:"520px"}},this.head(Y("lb.title"),()=>this.showMenu()),U("div",{class:"sub"},Y("lb.sub")),U("div",{class:"scroll"},t));this.set(U("div",{class:"screen dim"},e));const n=this.current;this.host.platform.getLeaderboard().then(i=>{if(this.current!==n)return;t.replaceChildren();const r=this.save.endlessBest;if(!i){t.append(U("div",{class:"sub"},Y("lb.unavailable")),U("div",{class:"item me"},It("moon","big"),U("div",{class:"grow t"},Y("lb.local",{n:r}))));return}i.entries.length||t.append(U("div",{class:"sub"},Y("lb.empty")));for(const a of i.entries)t.append(U("div",{class:`item ${a.me?"me":""}`},U("div",{class:"t",style:{width:"34px",textAlign:"center"}},String(a.rank)),U("div",{class:"grow t"},a.me?Y("lb.you"):a.name||Y("lb.player")),U("div",{class:"t"},It("moon")," ",String(a.score))));i.entries.some(a=>a.me)||t.append(U("div",{class:"item me"},It("moon","big"),U("div",{class:"grow t"},Y("lb.local",{n:r})))),!i.authorized&&this.host.platform.id==="yandex"&&t.append(U("div",{class:"item"},U("div",{class:"grow d"},Y("lb.auth")),this.btn(Y("lb.authBtn"),"small",()=>{this.host.platform.requestAuth().then(a=>{a&&r>0&&this.host.platform.submitScore(r),this.showLeaders()})})))})}showSettings(t){const e=this.save.settings,n=(o,l)=>{const c=U("input",{type:"range",min:"0",max:"100",value:String(Math.round(o*100))});return c.addEventListener("input",()=>{l(Number(c.value)/100),this.host.save.change(),this.host.applySettings()}),c},i=(o,l,c)=>U("div",{class:"seg"},o.map(([h,u])=>U("button",{class:h===l?"on":"",onclick:()=>{this.host.click(),c(h)}},u))),r=U("button",{class:`toggle ${e.vibration?"on":""}`,"aria-label":Y("set.vibration"),onclick:()=>{this.host.save.change(o=>{o.settings.vibration=!o.settings.vibration}),this.host.applySettings(),this.showSettings(t)}}),a=(o,l,c)=>U("div",{class:"item"},It(o,"big"),U("div",{class:"t",style:{minWidth:"92px"}},l),U("div",{class:"grow",style:{display:"flex",justifyContent:"flex-end"}},c));this.set(U("div",{class:"screen dim"},U("div",{class:"panel narrow",style:{maxWidth:"560px"}},this.head(Y("set.title"),t),U("div",{class:"scroll"},U("div",{class:"list"},a("music",Y("set.music"),n(e.music,o=>{this.save.settings.music=o})),a("sound",Y("set.sfx"),n(e.sfx,o=>{this.save.settings.sfx=o})),a("heart",Y("set.vibration"),r),a("gear",Y("set.quality"),i([["auto",Y("set.q.auto")],["high",Y("set.q.high")],["medium",Y("set.q.medium")],["low",Y("set.q.low")]],e.quality,o=>{this.host.save.change(l=>{l.settings.quality=o}),this.host.applySettings(),this.showSettings(t)})),a("globe",Y("set.language"),i([["auto",Y("set.q.auto")],["ru","Русский"],["en","English"]],e.lang,o=>{this.host.save.change(l=>{l.settings.lang=o}),this.host.applySettings(),this.showSettings(t)})),U("div",{class:"row",style:{marginTop:"8px"}},this.btn(Y("set.reset"),"red small",()=>this.confirm(Y("set.resetConfirm"),()=>{this.host.resetProgress()},()=>this.showSettings(t)))))))))}showPause(t,e,n,i){this.set(U("div",{class:"screen dim"},U("div",{class:"panel narrow"},U("h2",null,Y("pause.title")),this.btn([It("play"),Y("pause.resume")],"gold wide",t),this.btn([It("gear"),Y("menu.settings")],"ghost wide",e),this.btn([It("castle"),Y("pause.exit")],"wide",()=>this.confirm(Y("pause.exitConfirm"),n,()=>this.showPause(t,e,n,i))),U("div",{class:"sub",style:{marginTop:"4px",fontSize:"13px"}},U("b",null,Y("pause.controls")),U("br"),Y(i?"pause.controlsTouch":"pause.controlsPc")))))}showDefeat(t,e,n){this.set(U("div",{class:"screen dim"},U("div",{class:"panel narrow results"},U("div",{class:"big-title lose"},Y("defeat.title")),t?U("div",{class:"sub",style:{marginTop:0}},Y("defeat.secondDesc")):null,t?this.btn([U("span",{class:"ad"},It("video"),Y("video")),Y("defeat.second")],"gold wide",e):null,this.btn(Y("defeat.results"),"wide",n))))}showResults(t,e,n){const i=t.endless?Y("results.endless"):t.victory?Y("results.victory"):Y("results.defeat"),r=[];t.mult>1&&r.push(U("div",{class:"extra"},Y("results.mult",{n:t.mult}))),t.record&&r.push(U("div",{class:"extra"},U("b",null,Y("results.record")))),t.levelAfter>t.levelBefore&&r.push(U("div",{class:"extra"},It("crown")," ",U("b",null,Y("results.levelUp",{n:t.levelAfter})))),t.unlocks.length&&r.push(U("div",{class:"extra"},Y("results.unlocked",{s:t.unlocks.map(l=>fe(l)).join(", ")}))),t.mapUnlocked&&r.push(U("div",{class:"extra"},U("b",null,Y("results.mapUnlocked")))),t.achievements.length&&r.push(U("div",{class:"extra"},It("trophy")," ",t.achievements.map(l=>fe(`ach.${l}`)).join(", ")));const a=U("div",{class:"glory"},It("crown"),U("span",{class:"gv"},`+${t.glory}`),U("span",{style:{fontSize:"16px",color:"var(--ink2)"}},Y("glory"))),o=t.canDouble?this.btn([U("span",{class:"ad"},It("video"),Y("video")),Y("results.double")],"gold",()=>{o.disabled=!0,e()}):null;this.set(U("div",{class:"screen dim"},U("div",{class:"panel results",style:{maxWidth:"620px"}},U("div",{class:`big-title ${t.victory?"win":"lose"}`},i),U("div",{class:"sub",style:{marginTop:"-4px"}},fe(`map.${t.map}`)),U("div",{class:"scroll"},U("div",{class:"statrow"},U("div",{class:"stat"},U("div",{class:"v"},String(t.nights)),U("div",{class:"k"},Y("results.nights"))),U("div",{class:"stat"},U("div",{class:"v"},String(t.kills)),U("div",{class:"k"},Y("results.kills"))),U("div",{class:"stat"},U("div",{class:"v"},String(t.lost)),U("div",{class:"k"},Y("results.lost")))),U("div",{style:{height:"10px"}}),a,...r),U("div",{class:"row"},o,this.btn(Y("results.continue"),"green",n)))))}updateGlory(t){var i,r;const e=(i=this.current)==null?void 0:i.querySelector(".gv");e&&(e.textContent=`+${t}`);const n=(r=this.current)==null?void 0:r.querySelector(".glory");n&&n.animate([{transform:"scale(1)"},{transform:"scale(1.25)"},{transform:"scale(1)"}],{duration:500})}confirm(t,e,n){this.closeModal();const i=()=>this.closeModal();this.modal=U("div",{class:"screen dim",style:{zIndex:"5"}},U("div",{class:"panel narrow confirm"},U("p",null,t),U("div",{class:"row"},this.btn(Y("no"),"ghost",()=>{i(),n==null||n()}),this.btn(Y("yes"),"red",()=>{i(),e()})))),this.root.appendChild(this.modal)}closeModal(){var t;(t=this.modal)==null||t.remove(),this.modal=null}static spaceKey(){return Pc()==="ru"?"Пробел":"Space"}}class l_{constructor(t,e,n,i){this.g=t,this.hud=e,this.touch=n,this.onDone=i,this.step="move",this.t0=0,this.choiceSeen=!1,this.finished=!1,this.startX=t.hero.x,this.startZ=t.hero.z}update(t){if(this.finished)return;const e=this.g;if(this.t0+=t,e.choice&&!this.choiceSeen){this.hud.hint(Y("tut.choice"));return}switch(!e.choice&&this.choiceSeen===!1&&e.stats.built>1&&(this.choiceSeen=!0),this.step){case"move":this.hud.hint(this.touch()?Y("tut.moveTouch"):Y("tut.move")),Math.hypot(e.hero.x-this.startX,e.hero.z-this.startZ)>3&&this.go("slot");break;case"slot":this.hud.hint(Y("tut.slot")),e.activeSlot()&&this.go("hold"),e.stats.built>0&&this.go("paths");break;case"hold":this.hud.hint(this.touch()?Y("tut.holdTouch"):Y("tut.hold")),e.stats.built>0?this.go("paths"):!e.activeSlot()&&this.t0>1.5&&this.go("slot");break;case"paths":this.hud.hint(Y("tut.paths")),this.t0>5&&this.go("night"),e.phase==="night"&&this.go("fight");break;case"night":this.hud.hint(e.stats.built>=2||e.coins<3?Y("tut.night"):Y("tut.slot")),e.phase==="night"&&this.go("fight");break;case"fight":this.hud.hint(this.touch()?Y("tut.fightTouch"):Y("tut.fight")),(this.t0>7||e.phase!=="night")&&this.go("done");break;case"done":this.hud.hint(null),this.finished=!0,this.onDone();break}this.choiceSeen&&!e.choice&&this.step==="done"&&this.hud.hint(null)}go(t){this.step=t,this.t0=0}}const Or={uNight:{value:0},uTime:{value:0}};function Ah(s={}){var e;const t=new fh({vertexColors:!0,flatShading:!0,transparent:!!s.transparent,opacity:(e=s.opacity)!=null?e:1});return t.onBeforeCompile=n=>{n.uniforms.uNight=Or.uNight,n.vertexShader=n.vertexShader.replace("#include <common>",`#include <common>
attribute float glow;
varying float vGlow;`).replace("#include <begin_vertex>",`#include <begin_vertex>
vGlow = glow;`),n.fragmentShader=n.fragmentShader.replace("#include <common>",`#include <common>
uniform float uNight;
varying float vGlow;`).replace("#include <emissivemap_fragment>",`#include <emissivemap_fragment>
float gl = vGlow > 1.5 ? (vGlow - 1.0) * (0.55 + 0.45 * uNight) : vGlow * uNight;
totalEmissiveRadiance += vColor.rgb * gl * 1.35;`)},t.customProgramCacheKey=()=>"world-glow"+(s.transparent?"-t":""),t}function c_(s){const t=new fh({color:s,flatShading:!0,transparent:!0,opacity:.82});return t.onBeforeCompile=e=>{e.uniforms.uTime=Or.uTime,e.vertexShader=e.vertexShader.replace("#include <common>",`#include <common>
uniform float uTime;`).replace("#include <begin_vertex>",`#include <begin_vertex>
transformed.y += sin(position.x * 0.55 + uTime * 1.1) * 0.07 + cos(position.z * 0.45 + uTime * 0.8) * 0.07;`)},t.customProgramCacheKey=()=>"water",t}const mc=new Zt,gc=new sn,_c=new nn,xc=new O,vc=new O,rr=new At;class Be{constructor(){this.pos=[],this.nor=[],this.col=[],this.glo=[]}add(t,e,n,i,r,a={}){var u,d,f,_,v,p,m,b;const o=t.index?t.toNonIndexed():t;_c.set((u=a.rx)!=null?u:0,(d=a.ry)!=null?d:0,(f=a.rz)!=null?f:0,(_=a.order)!=null?_:"XYZ"),gc.setFromEuler(_c),xc.set(n,i,r),vc.set((v=a.sx)!=null?v:1,(p=a.sy)!=null?p:1,(m=a.sz)!=null?m:1),mc.compose(xc,gc,vc),o.applyMatrix4(mc),o.computeVertexNormals();const l=o.getAttribute("position"),c=o.getAttribute("normal");rr.set(e);const h=(b=a.glow)!=null?b:0;for(let T=0;T<l.count;T++)this.pos.push(l.getX(T),l.getY(T),l.getZ(T)),this.nor.push(c.getX(T),c.getY(T),c.getZ(T)),this.col.push(rr.r,rr.g,rr.b),this.glo.push(h);return o.dispose(),o!==t&&t.dispose(),this}box(t,e,n,i,r,a,o,l){return this.add(new ts(t,e,n),i,r,a,o,l)}boxB(t,e,n,i,r,a,o,l){return this.box(t,e,n,i,r,a+e/2,o,l)}cyl(t,e,n,i,r,a,o,l,c){return this.add(new As(t,e,n,i),r,a,o+n/2,l,c)}cone(t,e,n,i,r,a,o,l){return this.add(new zo(t,e,n),i,r,a+e/2,o,l)}ico(t,e,n,i,r,a,o=0){return this.add(new Ho(t,o),e,n,i,r,a)}oct(t,e,n,i,r,a){return this.add(new Nr(t,0),e,n,i,r,a)}dodec(t,e,n,i,r,a){return this.add(new Go(t,0),e,n,i,r,a)}roof(t,e,n,i,r,a,o,l={}){var h;const c=new As(1,1,1,3);return this.add(c,i,r,a+e/3,o,{...l,rz:Math.PI/2,rx:-Math.PI/2,ry:(h=l.ry)!=null?h:0,order:"YXZ",sx:n*.577,sy:t,sz:e/1.5})}build(){const t=new Ae;return t.setAttribute("position",new ee(this.pos,3)),t.setAttribute("normal",new ee(this.nor,3)),t.setAttribute("color",new ee(this.col,3)),t.setAttribute("glow",new ee(this.glo,1)),t.computeBoundingSphere(),t}}const I={stone:15853784,stone2:14471616,stoneDark:12168861,slate:9278374,roofBlue:6128329,roofRed:14713451,roofTeal:5222818,roofPurple:9269705,roofGreen:6989930,wood:11566674,woodDark:8346429,woodLight:13870710,gold:16041298,banner:4878289,bannerRed:14178127,window:16765562,fire:16751164,wheat:15519854,field:12112751,hay:15254620,skin:15910560,white:16777215,iron:12041419,dark:3880272,ice:10478591,arcane:12950527,ember:16742970};function ji(s,t,e,n,i=0){for(let r=0;r<t;r++){const a=i+r/t*Math.PI*2;s.box(.22,.34,.08,I.window,Math.sin(a)*e,n,Math.cos(a)*e,{ry:a,glow:1})}}function Ch(s,t,e,n,i,r=.32){for(let a=0;a<n;a++){const o=a/n*Math.PI*2;s.boxB(r,r,r,i,Math.sin(o)*t,e,Math.cos(o)*t,{ry:o})}}function Rn(s,t,e,n,i=I.banner,r=1.1){s.cyl(.04,.04,r+.5,4,I.woodDark,t,e,n),s.boxB(.55,r*.6,.05,i,t+.3,e+r*.45,n),s.boxB(.6,.08,.07,I.gold,t+.3,e+r*.45+r*.6,n)}function ai(s,t,e,n){s.cyl(.05,.05,.5,4,I.woodDark,t,e,n),s.oct(.13,I.fire,t,e+.6,n,{glow:2.2})}function h_(s,t,e){const n=t==="court"?I.roofRed:I.roofBlue;s.cyl(3.7,3.9,.45,8,I.stoneDark,0,0,0,{ry:Math.PI/8});const i=2.55;for(let a=0;a<4;a++){const o=a/4*Math.PI*2+Math.PI/4,l=Math.sin(o)*i*.71,c=Math.cos(o)*i*.71;s.boxB(3.6,1.9,.6,I.stone2,l,.4,c,{ry:o});for(let h=-2;h<=2;h++)s.boxB(.36,.34,.66,I.stone2,l+Math.cos(o)*h*.72,2.3,c-Math.sin(o)*h*.72,{ry:o})}for(let a=0;a<4;a++){const o=a/4*Math.PI*2,l=Math.sin(o)*i,c=Math.cos(o)*i;s.cyl(.78,.86,3.3,8,I.stone,l,.4,c),s.cone(1,1.5,8,n,l,3.7,c),s.box(.2,.3,.08,I.window,l+Math.sin(o+.6)*.8,2.6,c+Math.cos(o+.6)*.8,{ry:o+.6,glow:1}),e>=2&&s.cone(.16,.5,4,I.gold,l,5.15,c)}const r=t==="citadel"?4.6:3.7;s.boxB(2.4,r,2.4,I.stone,0,.4,0),s.cone(1.95,2.1,4,n,0,.4+r,0,{ry:Math.PI/4}),ji(s,4,1.23,.4+r*.62,Math.PI/4*0),ji(s,4,1.23,.4+r*.3,Math.PI/4*0),Rn(s,0,.4+r+1.8,0,I.banner,1.1),s.boxB(1.1,1.4,.3,I.woodDark,0,.4,i*.74+.25,{ry:Math.PI/4}),ai(s,.9,.4,i*.95),ai(s,i*.95,.4,.9),t==="court"&&(s.boxB(.9,.7,.7,I.wood,2.6,.4,-1.2).boxB(1.1,.12,.9,I.bannerRed,2.6,1.2,-1.2,{rz:.2}),s.boxB(.9,.7,.7,I.wood,-1.2,.4,2.6).boxB(1.1,.12,.9,I.gold,-1.2,1.2,2.6,{rx:.2})),t==="citadel"&&(s.cyl(.5,.6,1.4,6,I.stone,0,.4+r,0),Ch(s,1.25,.4+r-.05,8,I.stone2,.28)),e>=2&&(Rn(s,2.2,2.4,2.2,I.banner,1.3),Rn(s,-2.2,2.4,-2.2,I.banner,1.3),s.oct(.35,I.gold,0,.4+r+2.6,0,{glow:1.8}))}function d_(s,t,e){if(t==="base"||t==="spiked"){for(let i=-6.4/2;i<=6.4/2+.01;i+=.42){if(Math.abs(i)<.9)continue;const a=1.5+Math.sin(i*7)*.15;s.cyl(.2,.22,a,5,I.wood,i,0,0),s.cone(.2,.35,5,I.woodLight,i,a,0)}if(s.boxB(1.9,.18,.18,I.woodDark,0,1.45,0),s.boxB(.8,1.2,.12,I.woodDark,-.45,0,.05,{ry:.2}).boxB(.8,1.2,.12,I.woodDark,.45,0,.05,{ry:-.2}),t==="spiked")for(let i=-6.4/2+.3;i<=6.4/2;i+=.75)Math.abs(i)<1||(s.cone(.08,.9,4,I.iron,i,.6,.45,{rx:Math.PI/2.4}),s.cone(.08,.9,4,I.iron,i,.6,-.45,{rx:-Math.PI/2.4}))}else{for(const i of[-1,1]){s.boxB(2.4,1.8,.7,I.stone2,i*2,0,0);for(let r=0;r<3;r++)s.boxB(.38,.35,.74,I.stone2,i*(1.1+r*.85),1.8,0);s.cyl(.55,.6,2.4,6,I.stone,i*1,0,0),s.cone(.62,.7,6,I.roofBlue,i*1,2.4,0)}s.boxB(1.4,.4,.7,I.stone,0,1.7,0),s.boxB(1.2,1.4,.1,I.woodDark,0,0,0)}if(e>=2){if(t==="stone"||t==="base")ai(s,-1.3,2.4,.4),ai(s,1.3,2.4,.4);else for(const i of[-1,1])s.cyl(.35,.3,.4,6,I.dark,i*1.4,0,.7).oct(.18,I.ember,i*1.4,.5,.7,{glow:2});Rn(s,1.2,1.6,-.2,I.banner,.8)}}function u_(s,t,e){if(t==="base"){for(const[n,i]of[[-.7,-.7],[.7,-.7],[-.7,.7],[.7,.7]])s.cyl(.13,.16,3.2,5,I.wood,n,0,i);s.boxB(1.9,.25,1.9,I.woodDark,0,3,0);for(const[n,i,r]of[[0,-.9,0],[0,.9,0],[-.9,0,Math.PI/2],[.9,0,Math.PI/2]])s.boxB(1.9,.5,.1,I.wood,n,3.25,i,{ry:r});s.cone(1.45,1.2,4,I.roofRed,0,3.9,0,{ry:Math.PI/4}),s.boxB(.12,.6,1.4,I.woodLight,0,1.2,0,{rx:.9});return}t==="archer"?(s.cyl(.85,1.05,3.6,8,I.stone,0,0,0),s.cyl(1.2,1,.4,8,I.stone2,0,3.6,0),Ch(s,1.05,4,8,I.stone2,.3),s.cone(1.25,1.8,8,I.roofBlue,0,4.4,0),ji(s,3,.95,2.2,.5),e>=2&&(Rn(s,0,6,0,I.banner,.8),s.cyl(1.22,1.22,.1,8,I.gold,0,4.35,0))):(s.cyl(1.1,1.25,2.6,6,I.stone2,0,0,0),s.cyl(1.35,1.2,.35,6,I.stoneDark,0,2.6,0),s.boxB(.5,.4,.5,I.woodDark,0,2.95,0),s.boxB(.3,.25,1.9,I.wood,0,3.35,.2,{rx:-.12}),s.boxB(2,.14,.2,I.woodDark,0,3.45,.7,{rx:-.12}),s.cone(.08,.4,4,I.iron,0,3.4,1.35,{rx:Math.PI/2}),ji(s,2,1.14,1.6,.8),e>=2&&(s.boxB(.18,.18,1.7,I.gold,.6,3,0),s.boxB(.18,.18,1.7,I.gold,-.6,3,0)))}function f_(s,t,e){const n=t==="frost"?I.ice:t==="fire"?I.ember:I.arcane,i=t==="frost"?8370406:t==="fire"?14183002:I.roofPurple;s.cyl(.75,1.1,1.2,7,I.stone2,0,0,0),s.cyl(.55,.72,2.8,7,I.stone,0,1.2,0),s.cyl(.95,.6,.45,7,i,0,4,0);for(let r=0;r<3;r++){const a=r/3*Math.PI*2;s.cone(.12,.9,4,i,Math.sin(a)*.75,4.3,Math.cos(a)*.75)}if(s.oct(.45,n,0,5.4,0,{glow:2.4,sy:1.5}),ji(s,3,.62,2.6,.2),e>=2)for(let r=0;r<4;r++){const a=r/4*Math.PI*2+.4;s.oct(.14,n,Math.sin(a)*1,5,Math.cos(a)*1,{glow:2.2})}}function p_(s,t,e){s.boxB(3.2,1.5,2,I.stone,0,0,0),s.roof(3.5,1.3,2.4,t==="sword"?I.roofRed:I.roofBlue,0,1.5,0),s.boxB(.7,1,.1,I.woodDark,0,0,1.01),ji(s,0,0,0),s.box(.3,.3,.06,I.window,-.95,.9,1.02,{glow:1}).box(.3,.3,.06,I.window,.95,.9,1.02,{glow:1}),s.boxB(1.3,.12,.12,I.woodDark,1.9,.6,1,{ry:Math.PI/2});for(let n=0;n<4;n++)t==="sword"?s.boxB(.08,.9,.22,I.iron,1.95,0,.5+n*.32):s.cyl(.03,.03,1.8,4,I.wood,1.95,0,.5+n*.32).cone(.06,.25,4,I.iron,1.95,1.8,.5+n*.32);t==="sword"&&s.box(.55,.7,.08,I.banner,0,2.3,1.15,{rx:.5}).oct(.12,I.gold,0,2.35,1.2),Rn(s,-1.8,0,.9,t==="sword"?I.bannerRed:I.banner,1.2),e>=2&&(Rn(s,1.6,1.4,-.8,I.gold,.9),ai(s,-1,0,1.3))}function m_(s,t,e){for(const[n,i]of[[-1.3,-.8],[1.3,-.8],[-1.3,.6],[1.3,.6]])s.cyl(.1,.12,1.6,5,I.wood,n,0,i);s.roof(3.1,.9,1.9,t==="xbows"?I.roofTeal:I.roofGreen,0,1.6,-.1),s.boxB(2.4,.5,.15,I.woodDark,0,0,-.8);for(const n of[-1,1])s.cyl(.06,.06,1.1,4,I.woodDark,n,0,1.6),s.cyl(.45,.45,.1,10,I.white,n,1,1.6,{rx:Math.PI/2}),s.cyl(.3,.3,.12,10,I.bannerRed,n,1,1.6,{rx:Math.PI/2}),s.cyl(.12,.12,.14,8,I.gold,n,1,1.6,{rx:Math.PI/2});s.cone(.5,.9,6,I.hay,-1.9,0,-.2),t==="xbows"&&s.boxB(.9,.25,.25,I.woodDark,.4,.6,.1).boxB(.08,.08,.9,I.iron,.4,.75,.1),e>=2&&(Rn(s,1.8,0,-.6,I.banner,1.1),ai(s,0,0,1))}function g_(s,t,e){for(const[n,i,r,a]of[[1,.9,1.4,1.6],[-1.1,1.2,1.3,1.1]]){s.boxB(r,.12,a,10189394,n,0,i);for(let o=0;o<4;o++)s.boxB(r*.9,.22,a*.14,e>=2?I.wheat:I.field,n,.1,i-a*.36+o*a*.24)}if(s.boxB(1.3,1,1.1,I.stone,-.7,0,-.8),s.roof(1.5,.8,1.4,I.roofRed,-.7,1,-.8),s.box(.24,.26,.06,I.window,-.7,.6,-.24,{glow:1}),s.cone(.45,.7,6,I.hay,.9,0,-.9),t==="mill"){s.cyl(.35,.55,2.4,6,I.stone2,.9,0,-.9),s.cone(.5,.6,6,I.roofRed,.9,2.4,-.9);for(let n=0;n<4;n++)s.box(.18,1.4,.05,I.woodLight,.9+Math.sin(n*Math.PI/2+.4)*.7,2.2+Math.cos(n*Math.PI/2+.4)*.7,-.4,{rz:-(n*Math.PI/2+.4)})}if(t==="militia"){for(let n=-1.8;n<=1.8;n+=.6)s.boxB(.1,.6,.1,I.woodDark,n,0,2);s.boxB(3.7,.08,.08,I.wood,0,.45,2),Rn(s,-1.8,0,-.2,I.banner,.8)}e>=2&&ai(s,0,0,-.2)}function __(s,t,e){if(s.dodec(1.3,I.slate,-.3,.6,-.4,{sy:.8}),s.dodec(.9,10657712,.8,.4,-.6,{ry:.6}),s.dodec(.6,I.slate,-1.2,.3,.5),s.boxB(.9,.9,.3,I.dark,.1,0,.55),s.boxB(.14,1.1,.14,I.wood,-.35,0,.7).boxB(.14,1.1,.14,I.wood,.55,0,.7).boxB(1.1,.16,.18,I.wood,.1,1.05,.7),s.oct(.1,I.fire,.75,1,.85,{glow:2}),s.boxB(.6,.35,.45,I.woodDark,1,.12,1).ico(.2,I.gold,1,.55,1,{glow:1.6}),s.cyl(.1,.1,.06,6,I.dark,.75,.12,1.25,{rx:Math.PI/2}),t==="deep"){for(const n of[-.9,.3])s.cyl(.07,.07,2.4,4,I.wood,n,0,-1.2);s.boxB(1.4,.12,.2,I.wood,-.3,2.3,-1.2).cyl(.25,.25,.1,8,I.iron,-.3,2,-1.1,{rx:Math.PI/2})}if(t==="fort"){for(let n=0;n<Math.PI*1.4;n+=.32)s.cyl(.15,.17,1.2,5,I.wood,Math.cos(n+2.3)*1.75,0,Math.sin(n+2.3)*1.75);s.cyl(.4,.5,1.8,6,I.stone2,-1.4,0,1).cone(.55,.6,6,I.roofBlue,-1.4,1.8,1)}e>=2&&s.ico(.3,I.gold,-.6,1.5,.2,{glow:1.7})}function x_(s,t,e){for(const[i,r]of[[-.6,-.5],[.6,-.5],[-.6,.5],[.6,.5]])s.cyl(.08,.08,.7,4,I.woodDark,i,-.2,r);s.boxB(1.5,.12,1.3,I.wood,0,.5,0),s.boxB(1.2,.85,1,I.woodLight,0,.62,0),s.roof(1.5,.7,1.3,I.roofTeal,0,1.47,0),s.box(.22,.22,.05,I.window,0,1.05,.51,{glow:1});const n=t==="pier"?3.2:2;s.boxB(n,.1,.6,I.wood,-.75-n/2,.35,.2),s.cyl(.3,.3,1.2,6,I.woodDark,-1.5,.1,1,{rz:Math.PI/2,sy:1,sz:.6}),s.boxB(.06,.7,.06,I.woodDark,.95,0,.9).boxB(.06,.7,.06,I.woodDark,.95,0,-.1).boxB(.06,.06,1.1,I.woodDark,.95,.68,.4);for(let i=0;i<3;i++)s.boxB(.05,.28,.1,10470616,.95,.38,.1+i*.3);if(t==="pier"&&s.cyl(.3,.3,1,6,I.wood,-2.4,.1,-.6,{rz:Math.PI/2,sz:.6}),t==="market"){s.boxB(.8,.5,.6,I.wood,.4,0,1.6).boxB(1,.1,.8,I.bannerRed,.4,.95,1.6,{rx:.25});for(const i of[.05,.75])s.boxB(.05,.9,.05,I.woodDark,i,0,1.95)}e>=2&&ai(s,.8,.5,-.6)}function v_(s,t,e){if(s.boxB(2.2,1.4,1.8,I.stone2,0,0,0),s.roof(2.4,.9,2.1,t==="workshop"?I.roofTeal:I.roofRed,0,1.4,0),s.cyl(.32,.4,2.6,6,I.stoneDark,.7,0,-.5),s.boxB(.9,.7,.2,I.dark,-.2,0,.91),s.boxB(.7,.4,.15,I.ember,-.2,.1,.95,{glow:2.3}),s.boxB(.3,.35,.3,I.dark,1,0,1.3).boxB(.6,.18,.28,6052459,1,.35,1.3),t==="armory"){for(let n=0;n<3;n++)s.boxB(.08,.8,.22,I.iron,-1.35,0,-.5+n*.4);s.box(.5,.6,.08,I.banner,-1.15,1.6,.95)}t==="workshop"&&(s.cyl(.45,.45,.14,8,I.gold,-1.2,.6,.9,{rx:Math.PI/2}),s.cyl(.3,.3,.14,7,I.iron,-.7,1,.95,{rx:Math.PI/2})),e>=2&&(s.oct(.18,I.ember,.7,2.8,-.5,{glow:2.2}),Rn(s,-1,0,1.2,I.banner,1))}const M_={castle:h_,wall:d_,tower:u_,magic:f_,barracks:p_,range:m_,farm:g_,mine:__,fish:x_,forge:v_},We=new Map;function Rh(s,t,e){const n=`${s}:${t}:${e}`;let i=We.get(n);if(!i){const r=new Be;M_[s](r,t,e),i=r.build(),We.set(n,i)}return i}function y_(s,t){const e=`rubble:${s.toFixed(1)}:${t%3}`;let n=We.get(e);if(!n){const i=new Be;let r=t;const a=()=>(r=(r*9301+49297)%233280)/233280;i.cyl(s*.9,s,.2,7,I.stoneDark,0,0,0);for(let o=0;o<6+s*3;o++){const l=a()*Math.PI*2,c=a()*s*.85;i.box(.3+a()*.5,.25+a()*.4,.3+a()*.4,a()<.5?I.stone2:I.woodDark,Math.cos(l)*c,.3,Math.sin(l)*c,{ry:a()*3,rx:a()*.6})}i.cyl(.07,.07,.9,4,I.woodDark,.2,.1,.1,{rz:.7}),n=i.build(),We.set(e,n)}return n}const b_=16773280;function dn(s,t,e,n=.09,i=b_){s.box(.07,.05,.04,i,-n,t,e,{glow:2.4}).box(.07,.05,.04,i,n,t,e,{glow:2.4})}const un=7297200,tn=5719706,Mc=9206220;function us(s,t,e){s.cyl(.24,.3,.55,6,t,0,.18,0),s.boxB(.12,.2,.12,I.woodDark,-.1,0,0).boxB(.12,.2,.12,I.woodDark,.1,0,0),s.ico(.17,I.skin,0,.88,0),s.cone(.2,.22,6,e,0,.92,0)}function Ph(s){const t=`unit:${s}`;let e=We.get(t);if(e)return e;const n=new Be;switch(s){case"militia":us(n,11111010,9071946),n.cyl(.025,.025,1.1,4,I.wood,.28,.2,.1,{rx:.2}).cone(.07,.18,3,I.iron,.28,1.25,.32);break;case"spearman":us(n,I.banner,I.iron),n.cyl(.025,.025,1.6,4,I.wood,.28,.1,.15,{rx:.35}).cone(.06,.25,4,I.iron,.28,1.45,.6,{rx:.35}),n.boxB(.08,.4,.3,I.gold,-.28,.25,.05);break;case"swordsman":us(n,4154040,I.iron),n.boxB(.06,.55,.12,I.iron,.3,.35,.2,{rx:.5}),n.boxB(.1,.5,.42,I.banner,-.3,.2,.05).boxB(.11,.12,.12,I.gold,-.3,.42,.05);break;case"bowman":us(n,5940075,4947285),n.boxB(.05,.75,.05,I.woodDark,.28,.2,.1,{rx:.15}),n.boxB(.12,.4,.12,I.woodDark,-.05,.4,-.27,{rx:-.3});break;case"crossbowman":us(n,4099466,I.iron),n.boxB(.12,.1,.5,I.woodDark,.18,.5,.3).boxB(.5,.06,.06,I.iron,.18,.58,.48);break;case"grunt":n.cone(.34,.85,6,un,0,0,0),n.ico(.22,tn,0,.92,0),dn(n,.95,.19),n.cyl(.05,.09,.6,5,I.woodDark,.3,.3,.15,{rx:.6});break;case"runner":n.cone(.24,.75,5,Mc,0,0,0,{rx:.25}),n.ico(.17,un,0,.8,.12),dn(n,.82,.28,.07),n.cone(.08,.3,4,tn,-.12,.85,-.05,{rz:.6}).cone(.08,.3,4,tn,.12,.85,-.05,{rz:-.6});break;case"shieldbearer":n.cone(.42,.95,6,tn,0,0,0),n.ico(.24,un,0,1.02,0),dn(n,1.04,.2),n.boxB(.75,.9,.12,7302026,0,.15,.42).boxB(.2,.2,.06,I.gold,0,.55,.49);break;case"skirmisher":n.cone(.3,.8,6,6968984,0,0,0),n.ico(.19,tn,0,.88,0),n.cone(.24,.4,6,4010595,0,.88,-.02),dn(n,.88,.17),n.boxB(.05,.7,.05,I.woodDark,.28,.25,.1);break;case"ram":n.cyl(.3,.3,2,7,I.woodDark,0,.55,-.2,{rx:Math.PI/2}),n.cone(.32,.35,7,I.iron,0,.55,.95,{rx:Math.PI/2}),n.boxB(1,.12,1.6,4864556,0,.25,-.2);for(const[i,r]of[[-.55,.3],[.55,.3],[-.55,-.7],[.55,-.7]])n.cyl(.24,.24,.1,8,3812900,i,.24,r,{rz:Math.PI/2});n.roof(1.2,.6,1.8,tn,0,.9,-.2,{ry:Math.PI/2}),dn(n,.95,-1.1,.12);break;case"wisp":n.ico(.32,Mc,0,0,0,{},0),n.oct(.16,14268671,0,0,.2,{glow:2.4}),n.box(.6,.04,.25,un,-.45,.1,-.05,{rz:.4}).box(.6,.04,.25,un,.45,.1,-.05,{rz:-.4}),dn(n,.08,.28,.1);break;case"raider":n.cone(.36,.85,6,7229318,0,0,0,{rx:.2}),n.ico(.21,tn,0,.88,.12),dn(n,.9,.3),n.cyl(.04,.04,.7,4,I.woodDark,.32,.4,.2,{rx:.4}).oct(.12,I.fire,.32,1.12,.35,{glow:2.4});break;case"giant":n.boxB(.9,.9,.6,tn,0,.45,0),n.boxB(.28,.5,.28,un,-.25,0,0).boxB(.28,.5,.28,un,.25,0,0),n.ico(.3,un,0,1.55,.05),dn(n,1.58,.3,.11),n.boxB(.25,.7,.25,un,-.6,.6,0).boxB(.25,.7,.25,un,.6,.6,.1),n.cyl(.08,.2,1.1,6,I.woodDark,.7,.1,.35,{rx:.7});break;case"boss_warlord":n.boxB(1,1,.7,4009827,0,.45,0),n.boxB(.3,.5,.3,tn,-.28,0,0).boxB(.3,.5,.3,tn,.28,0,0),n.ico(.32,un,0,1.68,.05),dn(n,1.7,.32,.12,16738906),n.cone(.08,.45,4,15327952,-.3,1.8,0,{rz:.6}).cone(.08,.45,4,15327952,.3,1.8,0,{rz:-.6}),n.cyl(.36,.36,.14,6,I.gold,0,1.92,.05,{glow:1.8}),n.boxB(.28,.75,.28,tn,-.68,.6,0).boxB(.28,.75,.28,tn,.68,.6,.1),n.boxB(.12,1.2,.5,I.iron,.78,.4,.45,{rx:.6});break;case"boss_hag":n.cone(.6,1.5,7,4086350,0,0,0),n.ico(.27,3099200,0,1.6,0),n.cone(.36,.6,7,2373679,0,1.6,-.03,{rx:-.2}),dn(n,1.6,.24,.1,10354586),n.cyl(.04,.04,1.9,4,I.woodDark,.5,0,.2).oct(.2,9305994,.5,2,.2,{glow:2.5});break;case"boss_colossus":n.dodec(.75,8222352,0,.95,0,{sy:1.1}),n.dodec(.38,9143456,0,1.95,.1),n.dodec(.32,7104128,-.85,1.1,0).dodec(.32,7104128,.85,1.1,0),n.dodec(.3,7104128,-.35,.25,0).dodec(.3,7104128,.35,.25,0),dn(n,2,.42,.13,9431295),n.box(.5,.06,.06,9431295,0,1.2,.68,{glow:2.2});break}if(e=n.build(),!S_.has(s)){const i=e.getAttribute("glow");for(let r=0;r<i.count;r++)i.getX(r)===0&&i.setX(r,.28)}return We.set(t,e),e}const S_=new Set(["militia","spearman","swordsman","bowman","crossbowman"]);function w_(s){const t=`proj:${s}`;let e=We.get(t);if(e)return e;const n=new Be;switch(s){case"arrow":n.box(.05,.05,.75,I.woodLight,0,0,0).cone(.06,.16,4,I.iron,0,-.08,.4,{rx:Math.PI/2}).box(.14,.02,.14,I.white,0,0,-.33);break;case"bolt":n.box(.1,.1,1.3,I.woodDark,0,0,0).cone(.13,.3,4,I.iron,0,-.15,.7,{rx:Math.PI/2});break;case"dart":n.box(.05,.05,.6,4010595,0,0,0).cone(.06,.15,4,14268671,0,-.07,.32,{rx:Math.PI/2,glow:2});break;case"rock":n.dodec(.3,I.slate,0,0,0);break;default:{const i=s==="frost"?I.ice:s==="fire"?I.ember:s==="hex"?9305994:s==="star"?16773800:I.arcane;n.ico(s==="star"?.22:.26,i,0,0,0,{glow:2.8})}}return e=n.build(),We.set(t,e),e}function E_(){let s=We.get("coin");return s||(s=new Be().cyl(.22,.22,.07,10,I.gold,0,-.035,0,{rx:Math.PI/2,glow:1.7}).build(),We.set("coin",s)),s}function T_(s,t){const e=`tree:${s}:${t}`;let n=We.get(e);if(n)return n;const i=new Be;switch(s){case"pine":i.cyl(.12,.16,.6,4,I.woodDark,0,0,0),i.cone(.95,1.5,5,t,0,.5,0).cone(.68,1.3,5,t,0,1.25,0,{ry:.6}).cone(.4,1,5,t,0,1.95,0);break;case"snowpine":i.cyl(.12,.16,.6,4,I.woodDark,0,0,0),i.cone(.95,1.5,5,t,0,.5,0).cone(.68,1.3,5,t,0,1.25,0,{ry:.6}).cone(.4,.8,5,16054015,0,2,0);break;case"birch":i.cyl(.08,.11,1.4,4,15657696,0,0,0),i.ico(.62,t,0,1.85,0,{sy:1.25});break;case"willow":i.cyl(.14,.2,1,4,I.woodDark,0,0,0),i.ico(.95,t,0,1.5,0,{sy:.75}),i.cone(.95,1,6,t,0,.55,0,{rx:Math.PI});break;case"dead":i.cyl(.08,.15,1.5,4,9075306,0,0,0),i.cyl(.04,.06,.7,3,9075306,.22,1,0,{rz:-.8}).cyl(.04,.06,.6,3,9075306,-.2,1.2,0,{rz:.9});break;default:i.cyl(.13,.18,.8,4,I.woodDark,0,0,0),i.ico(.9,t,0,1.5,0)}return n=i.build(),We.set(e,n),n}function A_(s,t){const e=new en,n=new en;e.add(n);const i=new Be().boxB(.55,.5,1.3,15986664,0,.75,0).boxB(.3,.6,.35,15986664,0,1.05,.62,{rx:.5}).boxB(.28,.28,.55,15986664,0,1.5,.9,{rx:.2}).boxB(.1,.5,.36,9071178,0,1.25,.55,{rx:.5}).cone(.1,.55,4,9071178,0,.75,-.75,{rx:-2.4}).boxB(.6,.12,.6,I.banner,0,1.22,-.05).boxB(.62,.3,.05,I.gold,0,.95,.3).box(.04,.04,.04,2236979,-.14,1.66,1.08).box(.04,.04,.04,2236979,.14,1.66,1.08),r=new le(i.build(),s);r.castShadow=!0,n.add(r);const a=new Be().boxB(.13,.8,.13,15130838,0,-.8,0).boxB(.15,.1,.15,6969930,0,-.8,0).build(),o=[];for(const[d,f]of[[-.18,.5],[.18,.5],[-.18,-.48],[.18,-.48]]){const _=new le(a,s);_.position.set(d,.8,f),_.castShadow=!0,n.add(_),o.push(_)}const l=new en;l.position.set(0,1.25,-.05);const c=new le(new Be().cyl(.2,.26,.6,6,I.banner,0,.05,0).boxB(.5,.12,.2,I.gold,0,.5,0).ico(.18,I.skin,0,.82,0).cyl(.2,.2,.1,7,I.gold,0,.94,0,{glow:1.6}).cone(.05,.12,4,I.gold,.12,1.02,0).cone(.05,.12,4,I.gold,-.12,1.02,0).cone(.05,.12,4,I.gold,0,1.02,.12).boxB(.1,.4,.12,I.banner,-.22,.2,.05).boxB(.1,.4,.12,I.banner,.22,.2,.05).build(),s);c.castShadow=!0,l.add(c);const h=new le(new Be().box(.5,.7,.04,I.bannerRed,0,-.35,0).build(),s);h.position.set(0,.6,-.2),h.castShadow=!0,l.add(h);const u=new en;return u.position.set(.3,.45,.1),u.add(new le(Wo(t),s)),l.add(u),n.add(l),{root:e,body:n,legs:o,rider:l,weapon:u,cape:h}}function Wo(s){const t=`weapon:${s}`;let e=We.get(t);if(e)return e;const n=new Be;switch(s){case"bow":n.boxB(.05,1,.05,I.woodDark,0,-.3,0,{rx:.1}).boxB(.02,1,.02,I.white,0,-.3,-.12);break;case"spear":n.cyl(.03,.03,2,4,I.wood,0,-.6,.2,{rx:1.1}).cone(.07,.3,4,I.iron,0,0,1.15,{rx:1.1}).box(.25,.15,.03,I.bannerRed,0,-.05,.85,{rx:1.1});break;case"staff":n.cyl(.035,.035,1.4,5,I.woodLight,0,-.3,0).oct(.14,16773800,0,1.2,0,{glow:2.6});break;default:n.boxB(.07,.9,.14,I.iron,0,0,0).boxB(.3,.06,.1,I.gold,0,0,0).boxB(.06,.2,.06,I.woodDark,0,-.2,0)}return e=n.build(),We.set(t,e),e}class C_{constructor(t=128){this.renderer=null,this.scene=new rh,this.camera=new Ke(26,1,.1,100),this.cache=new Map,this.material=Ah(),this.canvas=document.createElement("canvas"),this.canvas.width=this.canvas.height=t;try{this.renderer=new Th({canvas:this.canvas,alpha:!0,antialias:!0,preserveDrawingBuffer:!0}),this.renderer.setPixelRatio(1),this.renderer.setSize(t,t,!1),this.renderer.outputColorSpace=He,this.renderer.setClearColor(0,0)}catch{this.renderer=null}const e=new mh(15398143,9076586,1.6),n=new _h(16777215,2.2);n.position.set(3,6,4),this.scene.add(e,n),this.mesh=new le(new Ae,this.material),this.scene.add(this.mesh)}shoot(t,e,n=.6,i=.42){const r=this.cache.get(t);if(r!==void 0)return r;if(!this.renderer)return this.cache.set(t,""),"";this.mesh.geometry=e,this.mesh.rotation.y=n,e.computeBoundingBox();const a=e.boundingBox,o=a.getCenter(new O),l=a.getSize(new O),h=(Math.max(l.x,l.y,l.z)*.62+.05)/Math.sin(this.camera.fov*Math.PI/360);this.camera.position.set(o.x,o.y+Math.sin(i)*h,o.z+Math.cos(i)*h),this.camera.lookAt(o),this.renderer.render(this.scene,this.camera);let u="";try{u=this.canvas.toDataURL("image/png")}catch{u=""}return this.cache.set(t,u),u}unit(t){return this.shoot(`u:${t}`,Ph(t),.5,.25)}building(t){return this.shoot(`b:${t.kind}:${t.look}:${t.tier}`,Rh(t.kind,t.look,t.tier),.65,.5)}weapon(t){return this.shoot(`w:${t}`,Wo(t),1.2,.2)}dispose(){var t,e;this.material.dispose(),(t=this.renderer)==null||t.dispose(),(e=this.renderer)==null||e.forceContextLoss(),this.renderer=null}}const pi=new At,Hi=new At;class R_{constructor(t){this.canvas=t,this.scene=new rh,this.camera=new Ke(32,1,1,400),this.sun=new _h(16777215,2.4),this.hemi=new mh(13625599,9076586,1.3),this.fog=new Bo(13625070,60,150),this.quality="high",this.setting="auto",this.dayness=1,this.dayTarget=1,this.palette=null,this.target=new O,this.yaw=Math.PI/4,this.pitch=.92,this.distance=46,this.zoom=1,this.focus=new O,this.w=1,this.h=1,this.fpsAcc=0,this.fpsFrames=0,this.lowStreak=0,this.highStreak=0,this.onQualityChange=null,this.sunDir=new O;const e=window.devicePixelRatio||1;this.renderer=new Th({canvas:t,antialias:e<1.5,powerPreference:"high-performance",stencil:!1}),this.renderer.outputColorSpace=He,this.renderer.shadowMap.enabled=!0,this.renderer.shadowMap.type=gs,this.scene.fog=this.fog,this.scene.background=new At(13625070),this.sun.castShadow=!0,this.sun.shadow.bias=-6e-4,this.sun.shadow.normalBias=.04;const n=this.sun.shadow.camera;n.left=-34,n.right=34,n.top=34,n.bottom=-34,n.near=1,n.far=140,this.scene.add(this.sun,this.sun.target,this.hemi),this.applyQuality("high")}setPalette(t){this.palette=t}setQualitySetting(t){this.setting=t,t!=="auto"?this.applyQuality(t):this.applyQuality(this.guessQuality())}guessQuality(){return/Android|iPhone|iPad|iPod|Mobile/i.test(navigator.userAgent)||navigator.maxTouchPoints>1&&window.innerWidth<1100?"medium":"high"}applyQuality(t){var r,a;this.quality=t;const e=window.devicePixelRatio||1,n=t==="high"?Math.min(e,2):t==="medium"?Math.min(e,1.5):Math.min(e,1);this.renderer.setPixelRatio(n),this.renderer.shadowMap.enabled=t!=="low";const i=t==="high"?2048:1024;this.sun.shadow.mapSize.x!==i&&(this.sun.shadow.mapSize.set(i,i),(r=this.sun.shadow.map)==null||r.dispose(),this.sun.shadow.map=null),this.scene.traverse(o=>{const l=o.material;l&&"needsUpdate"in l&&(l.needsUpdate=!0)}),this.resize(this.w,this.h),(a=this.onQualityChange)==null||a.call(this,t)}resize(t,e){this.w=Math.max(1,t),this.h=Math.max(1,e),this.renderer.setSize(this.w,this.h,!1),this.camera.aspect=this.w/this.h;const n=this.h>this.w;this.camera.fov=n?44:32,this.distance=n?60:this.w/this.h<1.5?58:54,this.camera.updateProjectionMatrix()}get aspect(){return this.w/this.h}follow(t,e,n,i,r=!1){this.focus.set(t,e,n),r?this.target.copy(this.focus):this.target.lerp(this.focus,1-Math.pow(.0025,i))}updateCamera(t,e){const n=this.distance*this.zoom,i=Math.cos(this.pitch),r=Math.sin(this.pitch),a=t>0?(Math.sin(e*61)+Math.sin(e*37))*t*.25:0,o=t>0?Math.sin(e*53)*t*.25:0;this.camera.position.set(this.target.x+Math.sin(this.yaw)*i*n+a,this.target.y+r*n+o,this.target.z+Math.cos(this.yaw)*i*n-a),this.camera.lookAt(this.target.x+a*.5,this.target.y,this.target.z),this.fog.near=n*.95,this.fog.far=n*2.3;const l=68/this.sun.shadow.mapSize.x*2,c=Math.round(this.target.x/l)*l,h=Math.round(this.target.z/l)*l,u=this.sunDirection();this.sun.position.set(c+u.x*60,u.y*60,h+u.z*60),this.sun.target.position.set(c,0,h)}sunDirection(){const t=this.dayness,e=Ns(-.9,.55,t),n=Ns(.95,1.05,t);return this.sunDir.set(Math.sin(e)*.9,n,Math.cos(e)*.6+.2).normalize()}updateLighting(t){this.dayness+=(this.dayTarget-this.dayness)*Math.min(1,t*.9);const e=Vn(this.dayness,0,1),n=this.palette,i=Math.max(0,1-Math.abs(e-.5)*2.4);pi.set(16774112).lerp(Hi.set(9349887),1-e),pi.lerp(Hi.set(16754795),i*.8),this.sun.color.copy(pi),this.sun.intensity=Ns(1.15,2.5,e),this.hemi.color.set(14085375).lerp(Hi.set(6649804),1-e).lerp(pi.set(16762010),i*.5),this.hemi.groundColor.set(9405552).lerp(Hi.set(3024982),1-e),this.hemi.intensity=Ns(1.1,1.35,e),n&&(pi.set(n.fogDay).lerp(Hi.set(n.fogNight),1-e).lerp(Hi.set(15905676),i*.45),this.fog.color.copy(pi),this.scene.background.copy(pi)),Or.uNight.value=Vn((.75-e)/.55,0,1)}render(){this.renderer.render(this.scene,this.camera)}trackFps(t){if(this.setting!=="auto"||t<=0||(this.fpsAcc+=t,this.fpsFrames++,this.fpsAcc<2.5))return;const e=this.fpsFrames/this.fpsAcc;this.fpsAcc=0,this.fpsFrames=0,!document.hidden&&(e<42?(this.lowStreak++,this.highStreak=0):e>58?(this.highStreak++,this.lowStreak=0):(this.lowStreak=0,this.highStreak=0),this.lowStreak>=2&&this.quality!=="low"?(this.lowStreak=0,this.applyQuality(this.quality==="high"?"medium":"low")):this.highStreak>=8&&this.quality==="low"&&(this.highStreak=0,this.applyQuality("medium")))}project(t,e){const n=t.clone().project(this.camera);return e.x=(n.x*.5+.5)*this.w,e.y=(-n.y*.5+.5)*this.h,e.behind=n.z>1,e}groundPoint(t,e){const n=new Bt(t/this.w*2-1,-(e/this.h)*2+1),i=new rf;i.setFromCamera(n,this.camera);const r=-i.ray.origin.y/i.ray.direction.y;return!isFinite(r)||r<0?null:i.ray.origin.clone().addScaledVector(i.ray.direction,r)}dispose(){this.renderer.dispose()}}const P_=["arrow","bolt","orb","frost","fire","dart","hex","rock","star"],jn=new Zt,mi=new sn,fs=new nn,ti=new O,ei=new O,kn=new At,ar=new O;function L_(s){return 1+2.70158*Math.pow(s-1,3)+1.70158*Math.pow(s-1,2)}class D_{constructor(t,e){this.g=t,this.material=e,this.group=new en,this.bviews=new Map,this.unitMeshes=new Map,this.projMeshes=new Map,this.barCount=0,this.ringGeo=new Fr(.9,1,48),this.discGeo=new Pr(1,40),this.lineGeo=new bi(1,.22),this.disposables=[],this.highlight=null,this.barQ=new sn;for(const o of jh){const l=o.startsWith("boss"),c=["militia","spearman","swordsman","bowman","crossbowman"].includes(o),h=l?6:c?90:o==="grunt"||o==="runner"?220:140,u=new ri(Ph(o),e,h);u.instanceMatrix.setUsage(_s),u.setColorAt(0,kn.setRGB(1,1,1)),u.instanceColor.setUsage(_s),u.castShadow=!0,u.frustumCulled=!1,u.count=0,this.unitMeshes.set(o,u),this.group.add(u),this.disposables.push(u)}for(const o of P_){const l=new ri(w_(o),e,160);l.instanceMatrix.setUsage(_s),l.frustumCulled=!1,l.count=0,this.projMeshes.set(o,l),this.group.add(l),this.disposables.push(l)}const n=new bi(1,1),i=new si({color:16777215,depthTest:!1,depthWrite:!1,transparent:!0});this.bars=new ri(n,i,700),this.bars.setColorAt(0,kn.setRGB(1,1,1)),this.bars.frustumCulled=!1,this.bars.renderOrder=20,this.bars.count=0,this.group.add(this.bars),this.disposables.push(n,i,this.bars,this.ringGeo,this.discGeo,this.lineGeo),this.hero=A_(e,t.hero.weapon.id),this.group.add(this.hero.root);const r=new Pr(.9,24);r.rotateX(-Math.PI/2);const a=new si({color:16773560,transparent:!0,opacity:.35,depthWrite:!1});this.heroShadow=new le(r,a),this.group.add(this.heroShadow),this.disposables.push(r,a);for(const o of t.buildings)this.createBView(o)}setWeapon(t){const e=this.hero.weapon.children[0];e.geometry=Wo(t)}createBView(t){const e=new le(new Ae,this.material);e.castShadow=!0,e.receiveShadow=!0,e.visible=!1;const n=this.g.heightAt(t.x,t.z);e.position.set(t.x,n,t.z),t.wall?e.rotation.y=Math.atan2(-(t.wall.bz-t.wall.az),t.wall.bx-t.wall.ax):t.kind==="castle"?e.rotation.y=Math.PI/4:e.rotation.y=Math.atan2(t.rallyX-t.x,t.rallyZ-t.z),this.group.add(e);const i=new en,r=new si({color:16771496,transparent:!0,opacity:.9,depthWrite:!1}),a=new si({color:16777215,transparent:!0,opacity:.18,depthWrite:!1}),o=t.wall?1.3:t.radius+.25,l=new le(this.ringGeo,r);l.rotation.x=-Math.PI/2,l.scale.setScalar(o);const c=new le(this.discGeo,a);if(c.rotation.x=-Math.PI/2,c.scale.setScalar(o*.9),i.add(c,l),t.wall){const h=Math.hypot(t.wall.bx-t.wall.ax,t.wall.bz-t.wall.az);for(let u=-2;u<=2;u++){if(u===0)continue;const d=new le(this.lineGeo,r);d.rotation.x=-Math.PI/2,d.scale.set(h/7,1,1),d.position.x=u/2.5*(h/2),i.add(d)}i.rotation.y=e.rotation.y}i.position.set(t.x,Math.max(n,.05)+.06,t.z),i.renderOrder=3,this.group.add(i),this.disposables.push(r,a),this.bviews.set(t,{mesh:e,key:"",marker:i,markerMat:r,discMat:a,pulse:Math.random()*6})}update(t,e,n){const i=this.g;n.getWorldQuaternion(mi),ar.set(1,0,0).applyQuaternion(mi),this.barCount=0,this.barQ.copy(mi);const r=i.phase==="day";for(const[o,l]of this.bviews){const c=o.node?o.ruined?`ruin:${o.kind}`:`${o.kind}:${o.node.look}:${o.node.tier}`:"";if(c!==l.key&&(l.key=c,o.node?(l.mesh.geometry=o.ruined?y_(o.radius,o.id):Rh(o.kind,o.node.look,o.node.tier),l.mesh.visible=!0):l.mesh.visible=!1),o.node){const d=o.builtT;let f=1,_=1;if(d<.7&&!o.ruined){const b=Math.min(1,d/.7);f=Math.max(.02,L_(b)),_=.75+.25*Math.min(1,b*1.5)}let v=0,p=0;o.hitT<.15&&!o.ruined&&(v=(Math.random()-.5)*.12,p=(Math.random()-.5)*.12);const m=i.heightAt(o.x,o.z);l.mesh.position.set(o.x+v,m,o.z+p),l.mesh.scale.set(_,f,_),o.alive&&o.hp<o.maxHp&&this.addBar(o.x,m+(o.kind==="castle"?8.2:o.kind==="wall"?2.6:4.4),o.z,o.hp/o.maxHp,o.kind==="castle"?2.6:1.4,.16,7328111)}const h=r?i.actionFor(o):null,u=!!h&&(!o.node||this.highlight===o);if(l.marker.visible=u,u){l.pulse+=t*3;const d=this.highlight===o,f=h.cost<=i.coins,_=d?1:.65;l.markerMat.opacity=_*(.75+.25*Math.sin(l.pulse)),l.markerMat.color.set(f?d?16773536:16771496:14209224),l.discMat.opacity=d?.32:.14;const v=d?1.06+Math.sin(l.pulse*1.5)*.03:1;o.wall||l.marker.scale.setScalar(v)}}for(const o of this.unitMeshes.values())o.count=0;for(const o of i.units){if(!o.alive)continue;const l=this.unitMeshes.get(o.def.id);if(l.count>=l.instanceMatrix.count)continue;const c=l.count++,h=o.def.scale*1.35;let u=i.heightAt(o.x,o.z);o.def.flying&&(u=Math.max(u,0)+1.7+Math.sin(o.age*3+o.id)*.25);const d=o.age*o.speed*3.2+o.id;let f=0,_=0,v=0;if(o.moving&&(u+=Math.abs(Math.sin(d))*.12*h,f=.1,_=Math.sin(d)*.09),o.attackT<.28){const y=Math.sin(o.attackT/.28*Math.PI);v=y*.35*h,f+=y*.35}let p=1;if(o.age<.6&&o.team===1){const y=o.age/.6;u-=(1-y)*.9*h,p=.4+.6*y}const m=Math.sin(o.facing),b=Math.cos(o.facing);ti.set(o.x+m*v,u,o.z+b*v),fs.set(f,o.facing,_,"YXZ"),mi.setFromEuler(fs);let T=1;if(o.hitT<.1&&(T=.88),ei.set(h*p*(2-T),h*p*T,h*p*(2-T)),jn.compose(ti,mi,ei),l.setMatrixAt(c,jn),o.hitT<.08?kn.setRGB(2.6,2.6,2.6):o.slowT>0?kn.setRGB(.75,.95,1.5):o.burnT>0?kn.setRGB(1.5,.95,.75):kn.setRGB(1,1,1),l.setColorAt(c,kn),o.hp<o.maxHp){const y=o.def.flying?u+.9*h:u+1.3*h+(o.def.big?.4:0);this.addBar(o.x,y,o.z,o.hp/o.maxHp,o.def.boss?2.4:o.def.big?1.3:.8,o.def.boss?.2:.11,o.team===0?7321599:16739179)}}for(const o of this.unitMeshes.values())o.instanceMatrix.needsUpdate=!0,o.instanceColor&&(o.instanceColor.needsUpdate=!0);for(const o of this.projMeshes.values())o.count=0;for(const o of i.projectiles){if(!o.alive||o.delay>0)continue;const l=this.projMeshes.get(o.kind);if(l.count>=160)continue;const c=Math.min(1,o.traveled/Math.max(.01,o.total)),h=i.heightAt(o.sx,o.sz),u=i.heightAt(o.tx,o.tz),d=o.team===0?.7:1,f=o.arc*o.total,_=h+o.h0+(u+d-h-o.h0)*c+f*4*c*(1-c),v=u+d-h-o.h0+f*4*(1-2*c),p=o.total,m=o.tx-o.x,b=o.tz-o.z,T=Math.atan2(m,b),y=-Math.atan2(v,p);ti.set(o.x,_,o.z),o.kind==="arrow"||o.kind==="bolt"||o.kind==="dart"?fs.set(y,T,0,"YXZ"):fs.set(e*5,e*7,0),mi.setFromEuler(fs),ei.setScalar(o.kind==="star"?1.4:1),jn.compose(ti,mi,ei),l.setMatrixAt(l.count++,jn)}for(const o of this.projMeshes.values())o.instanceMatrix.needsUpdate=!0;this.updateHero(t,e);const a=i.hero;a.alive&&(a.hp<a.maxHp||i.phase==="night")&&this.addBar(a.x,i.heightAt(a.x,a.z)+3.6,a.z,a.hp/a.maxHp,1.3,.15,16765773),this.bars.count=this.barCount,this.bars.instanceMatrix.needsUpdate=!0,this.bars.instanceColor&&(this.bars.instanceColor.needsUpdate=!0)}addBar(t,e,n,i,r,a,o){if(this.barCount+2>700)return;i=Math.max(0,Math.min(1,i));const l=this.barQ;ti.set(t,e,n),ei.set(r+.08,a+.07,1),jn.compose(ti,l,ei),this.bars.setMatrixAt(this.barCount,jn),this.bars.setColorAt(this.barCount++,kn.setRGB(.12,.1,.16));const c=-(1-i)*r*.5;ti.set(t+ar.x*c,e+ar.y*c,n+ar.z*c),ei.set(Math.max(.001,r*i),a,1),jn.compose(ti,l,ei),this.bars.setMatrixAt(this.barCount,jn),this.bars.setColorAt(this.barCount++,kn.set(o))}updateHero(t,e){const n=this.g,i=n.hero,r=this.hero;if(r.root.visible=i.alive,this.heroShadow.visible=i.alive,!i.alive)return;const a=n.heightAt(i.x,i.z);r.root.position.set(i.x,a,i.z),r.root.rotation.y=i.facing,this.heroShadow.position.set(i.x,Math.max(a,0)+.04,i.z);const o=i.moving?1:0,l=e*11;r.legs.forEach((d,f)=>{const _=f===0||f===3?0:Math.PI;d.rotation.x=o*Math.sin(l+_)*.7}),r.body.position.y=o*Math.abs(Math.sin(l))*.12,r.body.rotation.x=o*.05,r.cape.rotation.x=.2+o*(.5+Math.sin(l*.5)*.15);const c=i.attackT<.3?Math.sin(i.attackT/.3*Math.PI):0,h=i.abilityT<.5?Math.sin(i.abilityT/.5*Math.PI):0;r.weapon.rotation.x=-c*1.4,r.rider.rotation.y=h*Math.PI*2*(i.weapon.ability==="whirl"?1:.1),r.rider.rotation.x=c*.15;const u=i.hitT<.1;r.root.scale.setScalar(u?1.36:1.3)}dispose(){for(const t of this.disposables)t.dispose();this.group.clear(),this.bviews.clear()}}class yc{constructor(t,e,n,i=!1){this.cap=n,this.additive=i,this.ps=[],this.free=[],this.m=new Zt,this.q=new sn,this.e=new nn,this.s=new O,this.v=new O,this.c=new At,this.mesh=new ri(t,e,n),this.mesh.instanceMatrix.setUsage(_s),this.mesh.setColorAt(0,new At(1,1,1)),this.mesh.instanceColor.setUsage(_s),this.mesh.frustumCulled=!1,this.mesh.count=0}spawn(){var e;if(this.ps.length>=this.cap)return null;const t=(e=this.free.pop())!=null?e:{};return this.ps.push(t),t}update(t){let e=0;for(let n=0;n<this.ps.length;n++){const i=this.ps[n];if(i.life-=t,i.life<=0){this.free.push(i);continue}this.ps[e++]=i,i.vy-=i.grav*t;const r=Math.pow(i.drag,t);i.vx*=r,i.vy*=r,i.vz*=r,i.x+=i.vx*t,i.y+=i.vy*t,i.z+=i.vz*t,i.y<.02&&i.grav>0&&(i.y=.02,i.vy*=-.3,i.vx*=.6,i.vz*=.6),i.rot+=i.spin*t}this.ps.length=e;for(let n=0;n<e;n++){const i=this.ps[n],r=i.life/i.max,a=i.size*(i.grow>0?(1+(1-r)*i.grow)*Math.min(1,r*3):Math.min(1,r*2.5));this.e.set(i.rot,i.rot*.7,0),this.q.setFromEuler(this.e),this.s.set(a,a,a),this.v.set(i.x,i.y,i.z),this.m.compose(this.v,this.q,this.s),this.mesh.setMatrixAt(n,this.m);const o=this.additive?Math.min(1,r*1.5):1;this.c.setRGB(i.r*o,i.g*o,i.b*o),this.mesh.setColorAt(n,this.c)}this.mesh.count=e,this.mesh.instanceMatrix.needsUpdate=!0,this.mesh.instanceColor&&(this.mesh.instanceColor.needsUpdate=!0)}clear(){for(const t of this.ps)this.free.push(t);this.ps.length=0,this.mesh.count=0}}const or=new At;class I_{constructor(t){this.group=new en,this.coins=[],this.rings=[],this.ringGeo=new Fr(.85,1,40),this.disposables=[],this.shake=0,this.m=new Zt,this.q=new sn,this.v=new O,this.s=new O;const e=new Be().box(1,1,1,16777215,0,0,0).build(),n=new si({color:16777215,transparent:!0,blending:wr,depthWrite:!1}),i=new Nr(.5,0);this.debris=new yc(e,t,700),this.sparks=new yc(i,n,500,!0),this.debris.mesh.castShadow=!1,this.group.add(this.debris.mesh,this.sparks.mesh),this.coinMesh=new ri(E_(),t,80),this.coinMesh.frustumCulled=!1,this.coinMesh.count=0,this.group.add(this.coinMesh),this.ringGeo.rotateX(-Math.PI/2),this.disposables.push(e,n,i,this.ringGeo,this.debris.mesh,this.sparks.mesh,this.coinMesh)}burst(t,e,n,i,r){var o,l,c,h,u,d,f,_;const a=r.glow?this.sparks:this.debris;or.set(r.color);for(let v=0;v<i;v++){const p=a.spawn();if(!p)return;const m=Math.random()*Math.PI*2,b=((o=r.speed)!=null?o:3)*(.4+Math.random()*.8),T=(l=r.spread)!=null?l:.2;p.x=t+(Math.random()-.5)*T,p.y=e+(Math.random()-.5)*T,p.z=n+(Math.random()-.5)*T,p.vx=Math.cos(m)*b,p.vz=Math.sin(m)*b,p.vy=((c=r.up)!=null?c:2)*(.5+Math.random()),p.max=p.life=((h=r.life)!=null?h:.6)*(.7+Math.random()*.6),p.size=((u=r.size)!=null?u:.15)*(.6+Math.random()*.8);const y=.85+Math.random()*.3;p.r=or.r*y,p.g=or.g*y,p.b=or.b*y,p.grav=(d=r.grav)!=null?d:9,p.drag=(f=r.drag)!=null?f:.4,p.spin=(Math.random()-.5)*12,p.rot=Math.random()*6,p.grow=(_=r.grow)!=null?_:0}}mist(t,e,n,i=1){this.burst(t,e+.5*i,n,Math.round(7*i),{color:5917328,speed:1.4*i,up:1.4,life:.8,size:.32*i,grav:-1.5,drag:.15,grow:1.4,spread:.6*i,glow:!0}),this.burst(t,e+.6*i,n,Math.round(5*i),{color:14272767,speed:2.4,up:2.2,life:.5,size:.12,grav:2,glow:!0})}dust(t,e,n,i,r=16){for(let a=0;a<r;a++){const o=a/r*Math.PI*2;this.burst(t+Math.cos(o)*i,e+.1,n+Math.sin(o)*i,1,{color:15326402,speed:1.2,up:.8,life:.8,size:.4,grav:-.5,drag:.2,grow:1.4,spread:.2})}}coin(t,e,n=0,i,r=.42){if(this.coins.length>=80){i==null||i();return}this.coins.push({from:t.clone(),to:e.clone(),t:0,dur:r,delay:n,h:1.6+t.distanceTo(e)*.18,cb:i})}ring(t,e,n,i,r,a=.5){let o=this.rings.find(l=>l.t>=l.max);if(!o){if(this.rings.length>12)return;const l=new si({color:r,transparent:!0,blending:wr,depthWrite:!1,side:wn}),c=new le(this.ringGeo,l);this.group.add(c),o={mesh:c,t:0,max:a,r:i},this.rings.push(o),this.disposables.push(l)}o.t=0,o.max=a,o.r=i,o.mesh.material.color.set(r),o.mesh.position.set(t,e+.15,n),o.mesh.visible=!0}addShake(t){this.shake=Math.min(1.2,this.shake+t)}update(t){var i;this.debris.update(t),this.sparks.update(t),this.shake=Math.max(0,this.shake-t*2.2);let e=0,n=0;for(let r=0;r<this.coins.length;r++){const a=this.coins[r];if(a.delay>0){a.delay-=t,this.coins[e++]=a;continue}a.t+=t;const o=Math.min(1,a.t/a.dur);if(o>=1){(i=a.cb)==null||i.call(a),this.sparkle(a.to);continue}this.coins[e++]=a;const l=o;this.v.lerpVectors(a.from,a.to,l),this.v.y+=Math.sin(l*Math.PI)*a.h,this.q.setFromAxisAngle(this.s.set(0,1,0),a.t*14),this.s.setScalar(1.1),this.m.compose(this.v,this.q,this.s),n<80&&this.coinMesh.setMatrixAt(n++,this.m)}this.coins.length=e,this.coinMesh.count=n,this.coinMesh.instanceMatrix.needsUpdate=!0;for(const r of this.rings){if(r.t>=r.max){r.mesh.visible=!1;continue}r.t+=t;const a=Math.min(1,r.t/r.max),o=r.r*(.2+.8*(1-(1-a)*(1-a)));r.mesh.scale.set(o,1,o),r.mesh.material.opacity=1-a}}sparkle(t){this.burst(t.x,t.y+.2,t.z,3,{color:16769162,speed:1.5,up:1.5,life:.35,size:.12,grav:3,glow:!0})}clear(){var t;this.debris.clear(),this.sparks.clear();for(const e of this.coins)(t=e.cb)==null||t.call(e);this.coins.length=0,this.coinMesh.count=0;for(const e of this.rings)e.t=e.max,e.mesh.visible=!1;this.shake=0}dispose(){for(const t of this.disposables)t.dispose();this.group.clear()}}const bn=new At,bc=new At;class U_{constructor(t,e,n){this.map=t,this.hf=e,this.material=n,this.group=new en,this.disposables=[],this.pathRibbons=[],this.ribbonMat=new _n({uniforms:{uTime:Or.uTime,uColor:{value:new At(16738906)},uOpacity:{value:0}},vertexShader:"varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }",fragmentShader:`uniform float uTime; uniform vec3 uColor; uniform float uOpacity; varying vec2 vUv;
        void main(){
          float edge = 1.0 - abs(vUv.y - 0.5) * 2.0;
          float chev = fract(vUv.x * 0.45 - uTime * 0.9 - abs(vUv.y - 0.5) * 0.9);
          float a = smoothstep(0.0, 0.35, edge) * (0.25 + 0.75 * smoothstep(0.45, 0.6, chev) * (1.0 - smoothstep(0.75, 0.95, chev)));
          gl_FragColor = vec4(uColor, a * uOpacity);
        }`,transparent:!0,depthWrite:!1,blending:$i}),this.disposables.push(this.ribbonMat),this.buildGround(),this.buildWater(),this.buildVegetation(),this.buildBridges(),this.buildRibbons()}buildGround(){const t=this.map,e=t.palette,n=this.hf,i=n.ext+18,r=1.5,a=Math.ceil(i*2/r),o=yr(t.seed+11),l=t.paths.map(L=>new qi(L)),c=new Ms(t.seed),h=[],u=[],d=[];for(let L=0;L<=a;L++)for(let F=0;F<=a;F++){let X=-i+F*r,W=-i+L*r;F>0&&F<a&&L>0&&L<a&&(X+=c.range(-.26,.26)*r,W+=c.range(-.26,.26)*r),h.push(X),u.push(W),d.push(Math.abs(X)>n.ext||Math.abs(W)>n.ext?n.compute(X,W):n.height(X,W))}const f=[],_=[],v=[],p=new At(e.grass),m=new At(e.grass2),b=new At(e.meadow),T=new At(e.path),y=new At(e.sand),E=new At(e.rock),w=new At(e.cliff),R=new At(e.snow),x=new At(e.water).lerp(new At(e.sand),.35),S=(L,F,X,W)=>{const tt=o(L*.12,F*.12);bn.copy(p).lerp(m,$e(-.2,.6,tt)*.8),o(L*.05+40,F*.05)>.35&&bn.lerp(b,.55);let $=1/0;for(const _t of l)$=Math.min($,_t.distanceTo(L,F));const et=1.55+o(L*.4,F*.4)*.35;$<et&&bn.lerp(T,$<et-.5?1:.6);for(const _t of t.slots){if(_t.x===void 0)continue;const Tt=Math.hypot(L-_t.x,F-_t.z),se=_r[_t.kind]+(_t.kind==="castle"?1.4:.5);Tt<se&&bn.lerp(T,_t.kind==="castle"?.7:.35)}X<.15&&bn.lerp(y,$e(.15,-.05,X)),X<-.25&&bn.copy(x).lerp(y,$e(-1,-.25,X)*.6),(W>.6||X>2.6)&&bn.lerp(W>1.1?w:E,$e(.6,1,W)*.9+$e(2.6,4.5,X)*.6),X>7.5&&bn.lerp(R,$e(7.5,9,X));const Z=1+(c.next()-.5)*.035;return bn.multiplyScalar(Z),bn},C=a+1,P=(L,F,X)=>{const W=(h[L]+h[F]+h[X])/3,tt=(u[L]+u[F]+u[X])/3,$=(d[L]+d[F]+d[X])/3,et=(Math.max(d[L],d[F],d[X])-Math.min(d[L],d[F],d[X]))/r,Z=S(W,tt,$,et);for(const _t of[L,F,X])f.push(h[_t],d[_t],u[_t]),_.push(Z.r,Z.g,Z.b),v.push(0)};for(let L=0;L<a;L++)for(let F=0;F<a;F++){const X=L*C+F,W=X+1,tt=X+C,$=tt+1;(F+L)%2===0?(P(X,tt,W),P(W,tt,$)):(P(X,tt,$),P(X,$,W))}const D=new Ae;D.setAttribute("position",new ee(f,3)),D.setAttribute("color",new ee(_,3)),D.setAttribute("glow",new ee(v,1)),D.computeVertexNormals(),D.computeBoundingSphere();const z=new le(D,this.material);z.receiveShadow=!0,this.group.add(z),this.disposables.push(D)}buildWater(){const t=this.hf.ext+18,e=new bi(t*2,t*2,60,60);e.rotateX(-Math.PI/2);const n=c_(this.map.palette.water),i=new le(e,n);i.position.y=hd-.12,i.receiveShadow=!0,this.group.add(i),this.disposables.push(e,n)}buildVegetation(){const t=this.map,e=this.hf,n=t.terrain,i=new Ms(t.seed+99),r=t.paths.map(S=>new qi(S)),a=e.ext+4,o=[...new Set(n.trees)],l=new Map,c=new Map,h=(S,C,P)=>{for(const D of r)if(D.distanceTo(S,C)<3.3+P)return!0;for(const D of t.slots)if(D.x!==void 0&&Math.hypot(S-D.x,C-D.z)<_r[D.kind]+2.4+P+(D.kind==="castle"?3:0))return!0;for(const[D,z,L]of n.rocks)if(Math.hypot(S-D,C-z)<L+.5)return!0;return!1},u=2.1,d=N_(t.seed),f=new sn,_=new nn,v=new O,p=new O;for(let S=-a;S<=a;S+=u)for(let C=-a;C<=a;C+=u){const P=C+i.range(-.9,.9),D=S+i.range(-.9,.9),z=Math.max(Math.abs(P),Math.abs(D)),L=$e(t.half*.45,t.half+2,z),F=d(P,D),X=$e(t.half+8,t.half+20,z),W=n.treeDensity*(.06+.7*L+.35*Math.max(0,F))*(1-X*.45);if(i.next()>W)continue;const tt=z>e.ext?e.compute(P,D):e.height(P,D);if(tt<.12||tt>8.2||z<t.half+2&&h(P,D,0))continue;let $=i.pick(o);tt>5.5&&o.includes("snowpine")&&($="snowpine");const et=i.pick(t.palette.leaves),Z=`${$}:${et}`,_t=i.range(.75,1.35)*($==="willow"?1.1:1);p.set(P,tt-.05,D),f.setFromEuler(_.set(i.range(-.06,.06),i.range(0,Math.PI*2),i.range(-.06,.06))),v.set(_t,_t*i.range(.9,1.15),_t),l.has(Z)||(l.set(Z,[]),c.set(Z,[])),l.get(Z).push(new Zt().compose(p,f,v)),c.get(Z).push(new At().setScalar(i.range(.9,1.08)))}for(const[S,C]of l){const[P,D]=S.split(":"),z=T_(P,Number(D)),L=new ri(z,this.material,C.length);C.forEach((F,X)=>{L.setMatrixAt(X,F),L.setColorAt(X,c.get(S)[X])}),L.castShadow=!0,L.receiveShadow=!1,L.computeBoundingSphere(),this.group.add(L),this.disposables.push(L)}const m=[],b=[],T=(S,C,P)=>{const D=e.compute(S,C);D<-.6||(p.set(S,D+P*.15,C),f.setFromEuler(_.set(i.range(0,3),i.range(0,3),i.range(0,3))),v.set(P,P*i.range(.6,1),P),m.push(new Zt().compose(p,f,v)),b.push(bc.set(t.palette.rock).multiplyScalar(i.range(.85,1.1)).clone()))};for(const[S,C,P]of n.rocks){const D=Math.round(P*3);for(let z=0;z<D;z++){const L=i.range(0,Math.PI*2),F=i.range(0,P);T(S+Math.cos(L)*F,C+Math.sin(L)*F,i.range(.4,1))}}for(let S=0;S<160;S++){const C=i.range(-a,a),P=i.range(-a,a),D=Math.max(Math.abs(C),Math.abs(P));D<t.half*.55||D<t.half+2&&h(C,P,.5)||T(C,P,i.range(.25,.9)*(D>t.half?1.6:1))}if(m.length){const S=new Be().dodec(.8,16777215,0,0,0).build(),C=new ri(S,this.material,m.length);m.forEach((P,D)=>{C.setMatrixAt(D,P),C.setColorAt(D,b[D])}),C.castShadow=!0,C.receiveShadow=!0,C.computeBoundingSphere(),this.group.add(C),this.disposables.push(C,S)}const y=[],E=[],w=[16777215,16767083,16752562,12166911,10473727];for(let S=0;S<900;S++){const C=i.range(-t.half,t.half),P=i.range(-t.half,t.half),D=e.height(C,P);if(D<.1||D>3||h(C,P,-1.5))continue;const z=i.next()<.35;p.set(C,D,P),f.setFromEuler(_.set(0,i.range(0,6),0));const L=z?.6:i.range(.6,1.1);v.set(L,L,L),y.push(new Zt().compose(p,f,v)),E.push(z?new At(i.pick(w)):bc.set(t.palette.grass2).multiplyScalar(i.range(.75,.95)).clone())}const R=new Be().cone(.12,.35,3,16777215,0,0,0).cone(.09,.28,3,16777215,.12,0,.05).build(),x=new ri(R,this.material,y.length);y.forEach((S,C)=>{x.setMatrixAt(C,S),x.setColorAt(C,E[C])}),x.computeBoundingSphere(),this.group.add(x),this.disposables.push(x,R)}buildBridges(){for(const t of this.map.bridges){const e=new Be;for(let r=-t.len/2;r<=t.len/2;r+=.55)e.boxB(.5,.15,3.2,r%1.1===0?I.wood:I.woodLight,r,.25,0,{ry:Math.sin(r*9)*.04});for(const r of[-1.6,1.6]){for(let a=-t.len/2;a<=t.len/2+.01;a+=t.len/4)e.cyl(.1,.1,1.6,5,I.woodDark,a,-.6,r);e.boxB(t.len,.12,.12,I.woodDark,0,.9,r)}const n=e.build(),i=new le(n,this.material);i.position.set(t.x,0,t.z),i.rotation.y=t.rot,i.castShadow=!0,i.receiveShadow=!0,this.group.add(i),this.disposables.push(n)}}buildRibbons(){for(const t of this.map.paths){const e=new qi(t),n=[],i=[],r=[],a={x:0,z:0,tx:0,tz:0},o=Math.ceil(e.length/.8);for(let h=0;h<=o;h++){const u=h/o*(e.length-3.5);e.sample(u,a);const d=-a.tz,f=a.tx,_=1.25;for(const v of[-1,1]){const p=a.x+d*_*v,m=a.z+f*_*v;n.push(p,Math.max(this.hf.height(p,m),.05)+.12,m),i.push(u,v<0?0:1)}if(h<o){const v=h*2;r.push(v,v+1,v+2,v+1,v+3,v+2)}}const l=new Ae;l.setAttribute("position",new ee(n,3)),l.setAttribute("uv",new ee(i,2)),l.setIndex(r);const c=new le(l,this.ribbonMat.clone());c.renderOrder=2,c.visible=!1,this.group.add(c),this.pathRibbons.push(c),this.disposables.push(l,c.material)}}updateRibbons(t,e){this.pathRibbons.forEach((n,i)=>{const r=n.material,a=t&&t.includes(i)?.85:0,o=r.uniforms.uOpacity.value,l=o+(a-o)*Math.min(1,e*3);r.uniforms.uOpacity.value=l,n.visible=l>.01})}dispose(){for(const t of this.disposables)t.dispose();this.disposables=[],this.group.clear()}}function N_(s){const t=yr(s+5);return(e,n)=>t(e*.09,n*.09)*1.4-.25}const lr=new O,cr=new O,F_={orb:12950527,frost:10478591,fire:16747068,hex:9305994,star:16773800,rock:11117493,arrow:15260864,bolt:15260864,dart:14268671};class Sc{constructor(t,e,n){this.stage=t,this.g=e,this.offs=[],this.showcase=!1,this.orbit=0,t.setPalette(e.map.palette),this.terrain=new U_(e.map,e.hf,n),this.entities=new D_(e,n),this.fx=new I_(n),t.scene.add(this.terrain.group,this.entities.group,this.fx.group),this.bind(),t.follow(e.hero.x,0,e.hero.z,0,!0)}h(t,e){return this.g.heightAt(t,e)}bind(){const t=this.g,e=this.fx,n=t.events;this.offs.push(n.on("coinIn",({b:i})=>{lr.set(t.hero.x,this.h(t.hero.x,t.hero.z)+2.4,t.hero.z),cr.set(i.x,this.h(i.x,i.z)+1.2,i.z),e.coin(lr,cr,0,void 0,.32)}),n.on("built",({b:i})=>{const r=this.h(i.x,i.z);e.dust(i.x,r,i.z,i.radius+.4,18),e.burst(i.x,r+1.5,i.z,16,{color:16769162,speed:3,up:4,life:.7,size:.16,grav:6,glow:!0}),e.ring(i.x,r,i.z,i.radius+1.8,16771496,.55),e.addShake(.12)}),n.on("income",({parts:i})=>{let r=0;for(const a of i){const o=Math.min(5,a.n);for(let l=0;l<o;l++)lr.set(a.b.x,this.h(a.b.x,a.b.z)+2,a.b.z),cr.set(t.hero.x,this.h(t.hero.x,t.hero.z)+2.4,t.hero.z),e.coin(lr,cr,.4+r*.06+l*.08,void 0,.6);r++}}),n.on("spawn",({u:i})=>{i.team===1&&e.burst(i.x,this.h(i.x,i.z)+.3,i.z,3,{color:4865152,speed:.8,up:.8,life:.7,size:.35,grav:-.6,drag:.2,grow:1.2,spread:.8,glow:!0})}),n.on("death",({u:i})=>{const r=this.h(i.x,i.z)+(i.def.flying?1.7:0);i.team===1?(e.mist(i.x,r,i.z,i.def.boss?3:i.def.big?1.8:1),i.def.boss&&(e.addShake(.9),e.ring(i.x,r,i.z,7,14272767,.9))):e.burst(i.x,r+.5,i.z,8,{color:12109020,speed:1.6,up:1.5,life:.6,size:.2,grav:-1,grow:1.2})}),n.on("impact",({x:i,z:r,kind:a,splash:o})=>{var h;const l=this.h(i,r)+.6,c=(h=F_[a])!=null?h:16777215;a==="arrow"||a==="bolt"||a==="dart"?Math.random()<.5&&e.burst(i,l,r,2,{color:15326402,speed:1.2,up:1,life:.3,size:.1,grav:6}):(e.burst(i,l,r,o>0?10:5,{color:c,speed:3+o,up:2.5,life:.45,size:.15,grav:4,glow:!0}),a==="fire"&&e.burst(i,l,r,4,{color:5918816,speed:1,up:1.4,life:.8,size:.35,grav:-1,grow:1.4})),o>0&&e.ring(i,l-.5,r,o,c,.35)}),n.on("melee",({x:i,z:r,team:a})=>{Math.random()<.6&&e.burst(i,this.h(i,r)+.8,r,3,{color:a===0?16773824:14268671,speed:2.5,up:2,life:.25,size:.1,grav:5,glow:!0})}),n.on("hit",({e:i})=>{i.ent==="b"&&Math.random()<.35&&e.burst(i.x,this.h(i.x,i.z)+1.5,i.z,2,{color:14274495,speed:2,up:2,life:.5,size:.14,grav:9}),i.ent==="h"&&e.addShake(.06)}),n.on("bdestroyed",({b:i})=>{const r=this.h(i.x,i.z);e.burst(i.x,r+1.5,i.z,26,{color:14274495,speed:5,up:6,life:1.1,size:.35,grav:14,spread:i.radius}),e.burst(i.x,r+1.2,i.z,10,{color:9071178,speed:4,up:5,life:1,size:.3,grav:14,spread:i.radius}),e.dust(i.x,r,i.z,i.radius+.6,20),e.addShake(i.kind==="castle"?1.2:.45)}),n.on("repaired",({b:i})=>{e.burst(i.x,this.h(i.x,i.z)+1,i.z,10,{color:12578984,speed:2,up:3,life:.8,size:.14,grav:2,glow:!0})}),n.on("ability",({kind:i,x:r,z:a,r:o})=>{const l=this.h(r,a),c=i==="whirl"?16777215:i==="volley"?16771496:i==="charge"?16765562:16773800;e.ring(r,l,a,o,c,.45),e.burst(r,l+1,a,18,{color:c,speed:o*2,up:2,life:.5,size:.14,grav:3,glow:!0}),i==="starfall"&&e.ring(r,l,a,o*.6,12578984,.6),e.addShake(.25)}),n.on("heroDeath",()=>{const i=t.hero;e.burst(i.x,this.h(i.x,i.z)+1.2,i.z,24,{color:16771496,speed:3,up:3,life:1,size:.2,grav:2,glow:!0}),e.addShake(.5)}),n.on("heroRespawn",()=>{const i=t.hero;for(let r=0;r<4;r++)e.burst(i.x,this.h(i.x,i.z)+r*.8,i.z,6,{color:16769162,speed:1.2,up:3,life:.8,size:.14,grav:-1,glow:!0});e.ring(i.x,this.h(i.x,i.z),i.z,2.5,16769162,.6)}),n.on("bossSpawn",({u:i})=>{e.addShake(.9),e.ring(i.x,this.h(i.x,i.z),i.z,6,11570175,.9)}))}update(t,e){const n=this.g,i=this.stage;if(i.dayTarget=n.phase==="night"||n.phase==="defeat"?0:1,this.showcase)this.orbit+=t*.05,i.follow(Math.sin(this.orbit)*3,0,Math.cos(this.orbit)*3,t),i.zoom=.82;else{const r=n.hero,a=r.moving?2.2:0;i.follow(r.x+Math.sin(r.facing)*a,0,r.z+Math.cos(r.facing)*a,t);const o=n.phase==="night"?1.12:1;i.zoom+=(o-i.zoom)*Math.min(1,t*1.5)}this.terrain.updateRibbons(n.phase==="day"&&!this.showcase?n.plan.paths:null,t),this.entities.highlight=n.activeSlot(),this.entities.update(t,e,i.camera),this.fx.update(t)}dispose(){for(const t of this.offs)t();this.offs=[],this.stage.scene.remove(this.terrain.group,this.entities.group,this.fx.group),this.terrain.dispose(),this.entities.dispose(),this.fx.dispose()}}class k_{constructor(t,e,n){this.platform=t,this.root=e,this.audio=new Oh,this.material=Ah(),this.mode="boot",this.game=null,this.view=null,this.hud=null,this.tutorial=null,this.bot=null,this.offs=[],this.pauses=new Set,this.gameplayActive=!1,this.readyCalled=!1,this.lastInterstitial=0,this.time=0,this.last=0,this.raf=0,this.outcome=null,this.resultsData=null,this.respawnAdNight=-1,this.timeScale=1,this.errors=[],this.frame=r=>{this.raf=requestAnimationFrame(this.frame);const a=Math.min(.1,Math.max(0,(r-this.last)/1e3));if(this.last=r,!document.hidden)try{this.tick(a)}catch(o){this.reportError(o)}},this.save=new Kh(t),this.stage=new R_(n),this.icons=new C_(128);const i=document.getElementById("joy");this.input=new Gh(n,i),this.input.onGesture=()=>this.audio.unlock(),this.screens=new o_(document.getElementById("ui"),this)}async init(t){await this.save.load(),t(.35),this.applySettings(),t(.5),this.resize(),window.addEventListener("resize",()=>this.resize()),window.addEventListener("orientationchange",()=>setTimeout(()=>this.resize(),120)),document.addEventListener("visibilitychange",()=>this.setPause("hidden",document.hidden)),window.addEventListener("blur",()=>this.setPause("blur",!0)),window.addEventListener("focus",()=>this.setPause("blur",!1)),window.addEventListener("pagehide",()=>this.save.flush()),this.platform.onPause(()=>this.setPause("sdk",!0)),this.platform.onResume(()=>this.setPause("sdk",!1)),document.addEventListener("contextmenu",e=>e.preventDefault());for(const e of["grunt","runner","shieldbearer"])this.icons.unit(e);t(.7),this.showMenu(!1),this.stage.render(),t(1),this.last=performance.now(),this.raf=requestAnimationFrame(this.frame)}ready(){this.readyCalled||(this.readyCalled=!0,this.platform.loadingReady())}applySettings(){const t=this.save.data.settings;this.audio.setVolumes(t.music,t.sfx);const e=t.lang==="auto"?Cc(this.platform.langCode()):t.lang;Rc(e),document.title=Y("title"),this.stage.setting!==t.quality&&this.stage.setQualitySetting(t.quality)}resetProgress(){this.save.reset(!0),this.applySettings(),this.hudToast(Y("set.resetDone")),this.showMenu(!1)}click(){this.audio.unlock(),this.audio.play("click",.6)}resize(){const t=window.innerWidth,e=window.innerHeight;this.stage.resize(t,e)}setPause(t,e){e?this.pauses.add(t):this.pauses.delete(t);const n=this.pauses.has("ad")||this.pauses.has("hidden")||this.pauses.has("blur")||this.pauses.has("sdk");this.audio.setMuted("sys",n),e&&(t==="hidden"||t==="blur"||t==="sdk")&&this.mode==="run"&&!this.pauses.has("user")&&!this.pauses.has("ad")&&this.openPause(),e&&this.input.reset(),this.syncGameplay()}get paused(){return this.pauses.size>0}syncGameplay(){const t=this.game,e=this.mode==="run"&&!!t&&!this.paused&&t.phase!=="victory"&&t.phase!=="defeat";t&&(t.paused=this.paused),e!==this.gameplayActive&&(this.gameplayActive=e,e?this.platform.gameplayStart():this.platform.gameplayStop())}adHooks(){return{onStart:()=>{this.setPause("ad",!0),this.audio.setMuted("ad",!0)},onEnd:()=>{this.audio.setMuted("ad",!1),this.setPause("ad",!1)}}}async rewarded(){const t=await this.platform.showRewarded(this.adHooks());return t||this.hudToast(Y("hud.adFail")),t}interstitial(t){const e=Date.now();if(!this.readyCalled||e-this.lastInterstitial<me.interstitialCooldownMs||this.mode==="run"){t();return}this.lastInterstitial=e,this.platform.showInterstitial(this.adHooks()).then(t)}menuGame(){const t=new pl({map:"valley",weapon:this.save.data.weapon,perks:[],mutators:[],endless:!1,seed:7}),e={castle:"castle_citadel_bastions",tower1:"tower_archer_keen",tower2:"tower_ballista",tower3:"tower_archer",magic1:"magic_frost",farm1:"farm_mill_harvest",farm2:"farm_mill",farm3:"farm",barracks1:"barracks_spear",forge1:"forge_armory",wall1:"wall_stone",fish1:"fish_pier",range1:"range_bows",mine1:"mine_deep"};for(const[n,i]of Object.entries(e)){const r=t.bySlot.get(n);r&&t.applyNode(r,gi[i],!1,!0)}return t.hero.x=4.5,t.hero.z=6,t.hero.facing=.6,t}showMenu(t){const e=()=>{this.teardownRun(),this.mode="menu";const n=this.menuGame();this.game=n,this.view=new Sc(this.stage,n,this.material),this.view.showcase=!0,this.stage.dayness=1,this.stage.dayTarget=1,this.audio.setMood("menu"),this.screens.showMenu(),this.syncGameplay()};t?this.interstitial(e):e()}startRun(t,e){const n=this.save.data,i={map:t,weapon:n.weapon,perks:[...n.perks],mutators:[...n.mutators],endless:e,seed:Math.random()*1e9|0};this.save.change(r=>{r.run=null}),this.beginRun(i)}continueRun(){const t=this.save.data.run;if(!t){this.screens.showMenu();return}this.beginRun({map:t.map,weapon:t.weapon,perks:t.perks,mutators:t.mutators,endless:t.endless,seed:t.seed,snapshot:t})}beginRun(t){this.audio.unlock(),this.teardownRun(),this.screens.clear();const e=new pl(t);e.timeScale=this.timeScale,this.game=e,this.view=new Sc(this.stage,e,this.material),this.stage.dayness=1;const n=new r_(document.getElementById("ui"),e,this.stage,this.icons,{pause:()=>{this.click(),this.openPause()},startNight:()=>{this.click(),e.input.startNight=!0},rally:()=>{e.input.rally=!0},ability:()=>{e.input.ability=!0},coinsAd:()=>{this.coinsAd()},respawnAd:()=>{this.respawnAd()},choose:i=>this.choose(i),holdButton:i=>{this.input.holdButton=i,this.audio.unlock()}});this.hud=n,n.setTouch(this.platform.isMobile()||this.input.touchMode||navigator.maxTouchPoints>0&&matchMedia("(pointer: coarse)").matches),this.mode="run",this.respawnAdNight=-1,this.bindRun(e,n),!this.save.data.tutorialDone&&t.map==="valley"&&!t.snapshot&&(this.tutorial=new l_(e,n,()=>n.touch,()=>{this.save.change(i=>{i.tutorialDone=!0})})),this.audio.setMood("day"),n.banner(Y("hud.day"),fe(`map.${t.map}`)),this.saveSnapshot(),this.syncGameplay()}bindRun(t,e){const n=t.events,i=(o,l,c=1)=>{const h=Math.hypot(o-this.stage.target.x,l-this.stage.target.z);return c*Math.max(0,1-h/38)},r=(o,l=1,c=1)=>this.audio.play(o,l,c),a=o=>Bd(this.save.data.settings.vibration&&e.touch,o);this.offs.push(n.on("coinIn",()=>r("coin",.5,.9+(t.hold?t.hold.t/t.hold.need*.5:0))),n.on("built",({b:o,upgrade:l})=>{r("build",.9),r(l?"upgrade":"chime",.7),a(18),o.node&&e.floatText(o.x,t.heightAt(o.x,o.z)+3.5,o.z,gr(o.node)),this.liveAchievements()}),n.on("choice",({b:o,options:l})=>{r("chime",.6,1.2),e.showChoice(o,l)}),n.on("phase",({phase:o,night:l})=>{if(e.hideChoice(),o==="night"){this.audio.setMood("night"),r("horn",.9);const c=t.plan.boss;e.banner(Y("hud.nightFalls",{n:l}),c?Y("hud.bossNight"):!t.cfg.endless&&l===t.map.nights?Y("hud.lastNight"):Y("hud.nightFallsSub"))}else if(o==="dawn"){this.audio.setMood("day"),r("dawn",.8);const c=t.lastIncome;e.banner(Y("hud.dawn"),c?Y("hud.dawnIncome",{n:c.total})+(c.clean?` · ${Y("hud.clean")}`:""):Y("hud.dawnSub")),this.liveAchievements()}else o==="day"?(e.coinsAdUsed=!1,this.saveSnapshot()):o==="victory"?(r("victory",1),this.finishRun(!0)):o==="defeat"&&(r("defeat",1),this.audio.setMood("silent"),this.onDefeat());this.syncGameplay()}),n.on("income",({parts:o})=>{let l=0;for(const c of o)e.floatText(c.b.x,t.heightAt(c.b.x,c.b.z)+3,c.b.z,`+${c.n}`),l++<6&&setTimeout(()=>r("coin",.5,1+l*.05),400+l*120)}),n.on("shoot",({p:o})=>{const l=i(o.x,o.z,.7);if(l<=.05)return;const c=o.kind;r(c==="arrow"||c==="dart"?"arrow":c==="bolt"?"bolt":c==="fire"?"fire":c==="frost"?"frost":"magic",l)}),n.on("death",({u:o})=>{o.team===1&&r("poof",i(o.x,o.z,o.def.big?1:.55),o.def.big?.6:1)}),n.on("melee",({x:o,z:l})=>r("hit",i(o,l,.45))),n.on("hit",({e:o})=>{o.ent==="h"&&(r("hurt",.6),a(12))}),n.on("bdestroyed",({b:o})=>{r("crash",i(o.x,o.z,1)),a(60)}),n.on("ability",({kind:o})=>{r(o==="starfall"?"heal":"whoosh",.9),a(25)}),n.on("heroDeath",()=>{r("defeat",.5,1.6),a(80)}),n.on("heroRespawn",()=>r("respawn",.7)),n.on("bossSpawn",()=>{r("roar",1),a(120)}),n.on("rally",({follow:o})=>{r("click",.7),e.toast(Y(o?"hud.rallyOn":"hud.rallyOff"))}),n.on("holdCancel",()=>{}))}liveAchievements(){const t=this.game;if(!t||!this.hud)return;const e=Oc(this.save.data,void 0,t.stats);if(e.length){this.save.change();for(const n of e)this.hud.toast(Y("ach.unlocked",{s:fe(`ach.${n}`)}),"ach")}}saveSnapshot(){const t=this.game;!t||this.mode!=="run"||t.phase!=="day"||this.save.change(e=>{e.run=t.snapshot()})}choose(t){var n;const e=this.game;!e||!e.choice||(this.click(),e.chooseUpgrade(t),(n=this.hud)==null||n.hideChoice())}async coinsAd(){const t=this.game,e=this.hud;!t||!e||e.coinsAdUsed||t.phase!=="day"||(this.click(),e.coinsAdUsed=!0,await this.rewarded()?(t.coins+=me.rewardCoins,e.toast(Y("hud.rewardOk"),"good"),this.audio.play("coin",.8)):e.coinsAdUsed=!1)}async respawnAd(){const t=this.game,e=this.hud;!t||!e||t.hero.alive||this.respawnAdNight===t.night||(this.click(),await this.rewarded()&&(this.respawnAdNight=t.night,e.respawnAdUsed=!0,t.hero.alive||t.respawnHero()))}openPause(){if(this.mode!=="run"||this.pauses.has("user"))return;this.pauses.add("user"),this.syncGameplay();const t=()=>{this.screens.clear(),this.pauses.delete("user"),this.syncGameplay()},e=()=>{var n;return this.screens.showPause(t,()=>this.screens.showSettings(e),()=>this.exitToMenu(),!!((n=this.hud)!=null&&n.touch))};e()}exitToMenu(){this.pauses.delete("user"),this.saveSnapshot(),this.save.flush(),this.showMenu(!0)}onDefeat(){var n;const t=this.game;(n=this.hud)==null||n.hideChoice();const e=!t.secondChanceUsed;setTimeout(()=>{this.game!==t||t.phase!=="defeat"||this.screens.showDefeat(e,async()=>{var i;this.click(),await this.rewarded()&&(this.screens.clear(),t.secondChance(),this.audio.setMood("day"),(i=this.hud)==null||i.banner(Y("hud.day"),Y("defeat.secondDesc")),this.syncGameplay())},()=>{this.click(),this.finishRun(!1)})},1400)}finishRun(t){const e=this.game;if(!e||this.mode!=="run")return;this.mode="results",this.syncGameplay();const n=t?e.map.nights:e.nightsSurvived,i={map:e.cfg.map,endless:e.cfg.endless,victory:t&&!e.cfg.endless,nights:n,stats:e.stats,weapon:e.cfg.weapon,mutators:e.cfg.mutators};let r;this.save.change(o=>{o.run=null,r=Fd(o,i)},!0),this.outcome=r,e.cfg.endless&&this.platform.submitScore(this.save.data.endlessBest);const a={victory:i.victory,endless:i.endless,map:i.map,nights:n,kills:e.stats.kills,lost:e.stats.lost,glory:r.glory,mult:vr(e.cfg.mutators),levelBefore:r.levelBefore,levelAfter:r.levelAfter,unlocks:r.unlocks,achievements:r.achievements,record:r.record,mapUnlocked:r.mapUnlocked,canDouble:r.glory>0};this.resultsData=a,this.audio.setMood("menu"),setTimeout(()=>{var o;(o=this.hud)==null||o.hint(null),this.screens.showResults(a,()=>{this.doubleGlory()},()=>{this.click(),this.showMenu(!0)})},t?2200:300)}async doubleGlory(){const t=this.outcome,e=this.resultsData;!t||!e||!e.canDouble||(this.click(),await this.rewarded()&&(e.canDouble=!1,this.save.change(n=>{n.glory+=t.glory},!0),e.glory=t.glory*2,this.screens.updateGlory(e.glory),this.audio.play("chime",.8)))}hudToast(t){var e;(e=this.hud)==null||e.toast(t)}teardownRun(){var t,e,n;for(const i of this.offs)i();this.offs=[],(t=this.hud)==null||t.dispose(),this.hud=null,this.tutorial=null,this.bot=null,(e=this.view)==null||e.dispose(),this.view=null,(n=this.game)==null||n.dispose(),this.game=null,this.input.reset(),this.pauses.delete("user")}reportError(t){const e=t instanceof Error?`${t.message}
${t.stack}`:String(t);this.errors.length<20&&this.errors.push(e)}tick(t){var n,i,r,a,o;this.time+=t;const e=this.game;if(this.audio.update(),e){this.mode==="run"&&!this.paused&&this.handleInput(e),this.bot&&this.mode==="run"&&!this.paused&&this.bot.update(t*e.timeScale);const l=this.paused?0:t;e.update(l),this.mode==="menu"&&e.update(0),(n=this.tutorial)==null||n.update(t)}(i=this.view)==null||i.update(this.paused?0:t,this.time),this.stage.updateLighting(t),this.stage.updateCamera((a=(r=this.view)==null?void 0:r.fx.shake)!=null?a:0,this.time),(o=this.hud)==null||o.update(),this.stage.render(),this.stage.trackFps(t),this.input.endFrame()}handleInput(t){var u;const e=this.input;if(e.pressed("Escape","KeyP")){t.choice?(t.cancelChoice(),(u=this.hud)==null||u.hideChoice()):this.openPause();return}if(t.choice){e.pressed("Digit1","Numpad1","ArrowLeft","KeyA")?this.choose(0):e.pressed("Digit2","Numpad2","ArrowRight","KeyD")&&this.choose(1),t.input.moveX=0,t.input.moveZ=0,t.input.hold=!1;return}if(this.bot)return;const n=e.screenMove(),i=this.stage.yaw,r=Math.cos(i),a=-Math.sin(i),o=-Math.sin(i),l=-Math.cos(i);let c=r*n.x-o*n.y,h=a*n.x-l*n.y;if(e.mouse.down&&c===0&&h===0){const d=this.stage.groundPoint(e.mouse.x,e.mouse.y);if(d){const f=d.x-t.hero.x,_=d.z-t.hero.z,v=Math.hypot(f,_);v>.6&&(c=f/v,h=_/v)}}t.input.moveX=c,t.input.moveZ=h,t.input.hold=e.hold,e.pressed("KeyQ","KeyE","ShiftLeft","ShiftRight")&&(t.input.ability=!0),e.pressed("KeyR","KeyF")&&(t.input.rally=!0),e.pressed("Enter","NumpadEnter","KeyN")&&t.phase==="day"&&(t.input.startNight=!0),e.touchMode&&this.hud&&!this.hud.touch&&this.hud.setTouch(!0)}enableBot(t){!this.game||this.mode!=="run"||(this.bot=t?new td(this.game,{skill:.9,noise:.05,seed:3}):null)}fastForward(t,e=1/20){var r,a;const n=this.game;if(!n||this.mode!=="run")return;const i=n.timeScale;n.timeScale=1;for(let o=0;o<t&&this.mode==="run"&&n.phase!=="defeat";o+=e)(r=this.bot)==null||r.update(e),n.update(e),(a=this.view)==null||a.update(e,this.time+=e),n.choice&&!this.bot&&n.chooseUpgrade(0);n.timeScale=i}debugEndRun(t){this.mode==="run"&&this.finishRun(t)}setSpeed(t){this.timeScale=t,this.game&&(this.game.timeScale=t)}stop(){cancelAnimationFrame(this.raf)}}const Lr=[];function B_(s){const t=e=>{Lr.length<50&&Lr.push(e)};window.addEventListener("error",e=>{var n,i,r;t(e.error?`${e.message}
${(n=e.error.stack)!=null?n:""}`:`resource: ${(r=(i=e.target)==null?void 0:i.tagName)!=null?r:"unknown"}`)},!0),window.addEventListener("unhandledrejection",e=>{var i;const n=e.reason;t(n instanceof Error?`${n.message}
${(i=n.stack)!=null?i:""}`:String(n)),e.preventDefault()})}const wc="lastbastion.cloud",Sa="lastbastion.localscore";function wa(s){try{return localStorage.getItem(s)}catch{return null}}function Ec(s,t){try{localStorage.setItem(s,t)}catch{}}class O_{constructor(){this.id="local"}async init(){}langCode(){return(navigator.language||"ru").slice(0,2)}isMobile(){return/Android|iPhone|iPad|iPod|Mobile/i.test(navigator.userAgent)||navigator.maxTouchPoints>1}loadingReady(){}gameplayStart(){}gameplayStop(){}async showInterstitial(t){t.onStart(),await new Promise(e=>setTimeout(e,150)),t.onEnd()}async showRewarded(t){return t.onStart(),await new Promise(e=>setTimeout(e,350)),t.onEnd(),!0}async loadCloud(){const t=wa(wc);if(!t)return null;try{return JSON.parse(t)}catch{return null}}async saveCloud(t){Ec(wc,JSON.stringify(t))}isAuthorized(){return!1}async requestAuth(){return!1}async submitScore(t){const e=Number(wa(Sa)||0);t>e&&Ec(Sa,String(t))}async getLeaderboard(){const t=Number(wa(Sa)||0);return{entries:[],player:t>0?{rank:1,name:"",score:t,me:!0}:null,authorized:!1}}onPause(){}onResume(){}}function hr(s,t){return new Promise((e,n)=>{const i=setTimeout(()=>n(new Error("timeout")),t);s.then(r=>{clearTimeout(i),e(r)},r=>{clearTimeout(i),n(r)})})}class z_{constructor(){this.id="yandex",this.ysdk=null,this.player=null,this.lastScoreAt=0}async init(){this.ysdk=await hr(window.YaGames.init(),1e4),await this.loadPlayer()}async loadPlayer(){try{this.player=await hr(this.ysdk.getPlayer({scopes:!1}),6e3)}catch{this.player=null}}langCode(){var t,e,n;try{return String(((n=(e=(t=this.ysdk)==null?void 0:t.environment)==null?void 0:e.i18n)==null?void 0:n.lang)||"ru")}catch{return"ru"}}isMobile(){var t,e,n,i,r,a;try{return!!((n=(e=(t=this.ysdk)==null?void 0:t.deviceInfo)==null?void 0:e.isMobile)!=null&&n.call(e)||(a=(r=(i=this.ysdk)==null?void 0:i.deviceInfo)==null?void 0:r.isTablet)!=null&&a.call(r))}catch{return!1}}loadingReady(){var t,e,n;try{(n=(e=(t=this.ysdk)==null?void 0:t.features)==null?void 0:e.LoadingAPI)==null||n.ready()}catch{}}gameplayStart(){var t,e,n;try{(n=(e=(t=this.ysdk)==null?void 0:t.features)==null?void 0:e.GameplayAPI)==null||n.start()}catch{}}gameplayStop(){var t,e,n;try{(n=(e=(t=this.ysdk)==null?void 0:t.features)==null?void 0:e.GameplayAPI)==null||n.stop()}catch{}}showInterstitial(t){return new Promise(e=>{let n=!1,i=!1;const r=()=>{n||(n=!0,i&&t.onEnd(),e())};try{this.ysdk.adv.showFullscreenAdv({callbacks:{onOpen:()=>{i=!0,t.onStart()},onClose:()=>r(),onError:()=>r(),onOffline:()=>r()}})}catch{r()}setTimeout(r,9e4)})}showRewarded(t){return new Promise(e=>{let n=!1,i=!1;t.onStart();const r=()=>{n||(n=!0,t.onEnd(),e(i))};try{this.ysdk.adv.showRewardedVideo({callbacks:{onOpen:()=>{},onRewarded:()=>{i=!0},onClose:()=>r(),onError:()=>r()}})}catch{r()}setTimeout(r,18e4)})}async loadCloud(){if(!this.player)return null;try{return await hr(this.player.getData(),6e3)}catch{return null}}async saveCloud(t,e){if(this.player)try{await this.player.setData(t,e)}catch{}}isAuthorized(){var t,e;try{return this.player?typeof this.player.isAuthorized=="function"?!!this.player.isAuthorized():((e=(t=this.player).getMode)==null?void 0:e.call(t))!=="lite":!1}catch{return!1}}async requestAuth(){try{return await this.ysdk.auth.openAuthDialog(),await this.loadPlayer(),this.isAuthorized()}catch{return!1}}async submitScore(t){if(!this.isAuthorized())return;const e=Date.now();if(!(e-this.lastScoreAt<1500)){this.lastScoreAt=e;try{if(this.ysdk.isAvailableMethod&&!await this.ysdk.isAvailableMethod("leaderboards.setScore"))return;await this.ysdk.leaderboards.setScore(me.leaderboardName,Math.floor(t))}catch{}}}async getLeaderboard(){var t,e,n,i;try{const r=await hr(this.ysdk.leaderboards.getEntries(me.leaderboardName,{quantityTop:10,includeUser:this.isAuthorized(),quantityAround:2}),8e3),a=(e=(t=this.player)==null?void 0:t.getUniqueID)==null?void 0:e.call(t),o=((n=r==null?void 0:r.entries)!=null?n:[]).map(h=>{var u,d;return{rank:h.rank,name:((u=h.player)==null?void 0:u.publicName)||"",score:h.score,me:!!a&&((d=h.player)==null?void 0:d.uniqueID)===a}}),l=r==null?void 0:r.userRank,c=(i=o.find(h=>h.me))!=null?i:l?{rank:l,name:"",score:0,me:!0}:null;return{entries:o,player:c,authorized:this.isAuthorized()}}catch{return null}}onPause(t){try{this.ysdk.on("game_api_pause",t)}catch{}}onResume(t){try{this.ysdk.on("game_api_resume",t)}catch{}}}async function G_(){if(typeof window!="undefined"&&window.YaGames&&typeof window.YaGames.init=="function"){const t=new z_;try{return await t.init(),t}catch{}}const s=new O_;return await s.init(),s}function Ea(s){const t=document.getElementById("load-fill");t&&(t.style.width=`${Math.round(Math.min(1,s)*100)}%`)}function H_(){try{const s=document.createElement("canvas");return!!(s.getContext("webgl2")||s.getContext("webgl"))}catch{return!1}}async function V_(){B_(),Ea(.08);const s=await G_();Rc(Cc(s.langCode()));const t=document.getElementById("load-text");t&&(t.textContent=Y("loading")),Ea(.25);const e=document.getElementById("game");if(!H_()){t&&(t.textContent=Y("err.fatal")),s.loadingReady();return}const n=new k_(s,document.getElementById("app"),e);await n.init(a=>Ea(.25+a*.75));const i=document.getElementById("loading");i==null||i.classList.add("out"),setTimeout(()=>i==null?void 0:i.remove(),500),n.ready();const r=location.search;/[?&](test|shot)/.test(r)&&(window.__lb={app:n,errors:Lr})}V_().catch(s=>{Lr.push(String(s));const t=document.getElementById("load-text");t&&(t.textContent=Y("err.fatal"))});
